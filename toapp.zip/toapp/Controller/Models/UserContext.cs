﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using MandiParishadWebApi.Models;

namespace MandiParishadWebApi.Models
{
    public class UserContext : DbContext
    {
        public UserContext() : base("MandiContext")
        {

        }
        public List<MailBox> GetUsermail(Int64 Rid)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@Rid",Value=Rid}
                 };
            var sqlQuery = @"Sp_NewInboxMail @Rid";
            var res = this.Database.SqlQuery<MailBox>(sqlQuery, sqlParam).ToList();
            return res;
        }

    }
}