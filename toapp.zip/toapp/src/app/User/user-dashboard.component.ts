import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styles: []
})
export class UserDashboardComponent implements OnInit {
  private allmails: any = [];
  Rid = localStorage.getItem("userToken");

  constructor(private service: ApihandlerService) { }

  ngOnInit() {
    this.service.getmail(this.Rid).subscribe(k => {
      this.allmails = k;
    });
  }

}
