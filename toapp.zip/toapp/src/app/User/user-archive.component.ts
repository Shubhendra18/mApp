import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-archive',
  templateUrl: './user-archive.component.html',
  styles: []
})
export class UserArchiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
