import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-compose',
  templateUrl: './user-compose.component.html',
  styles: []
})
export class UserComposeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
