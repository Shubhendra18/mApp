import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-important',
  templateUrl: './user-important.component.html',
  styles: []
})
export class UserImportantComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
