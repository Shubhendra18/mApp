import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bredcrum',
  templateUrl: './bredcrum.component.html',
  styles: []
})
export class BredcrumComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
