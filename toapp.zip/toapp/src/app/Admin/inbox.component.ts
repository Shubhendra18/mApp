import { Component, OnInit } from '@angular/core';
import { ApihandlerService } from '../apihandler.service';

@Component({
  selector: 'app-inbox',
  templateUrl: './inbox.component.html',
  styles: []
})
export class InboxComponent implements OnInit {
  private allmails: any = [];
  constructor(private q: ApihandlerService) { }

  ngOnInit() {
    // this.q.getmail().subscribe(k => {
    //   this.allmails = k;
    // });
  }

}
