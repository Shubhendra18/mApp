﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Drawing;

public partial class frmSentMessage : NOTICEBOARD.BaseClass
{
    String subject = "";
    String remark = "";
    String office = "";
    DateTime postDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null);
    DateTime postToDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null);
    bool isUrgent = false;
    int NoOfDaysfrom;
    int NoOfDaysto;
   int Index = 0;
   int Size = 0;
    //protected void BindYear()
    //{
    //    try
    //    {
    //        DataTable dtyear = Common.GetCurrentYear();
    //        int Currentyear = Convert.ToInt32(dtyear.Rows[0][0].ToString());
    //        //Code for bind Financial Year.
    //        for (int year = 2005; year <= Currentyear; year++)
    //        {
    //            ddlYearto.Items.Add(year.ToString());
    //            ddlYearto.SelectedValue = Currentyear.ToString();
    //            ddlYearfrom.Items.Add(year.ToString());
    //            ddlYearfrom.SelectedValue = Currentyear.ToString();
    //            NoOfDaysfrom = DateTime.DaysInMonth(Convert.ToInt32(ddlYearfrom.SelectedValue), Convert.ToInt32(ddlMonthfrom.SelectedValue));
    //            NoOfDaysto = DateTime.DaysInMonth(Convert.ToInt32(ddlYearto.SelectedValue), Convert.ToInt32(ddlMonthto.SelectedValue));
    //        }
    //        ddlMonthfrom.SelectedValue = dtyear.Rows[0]["CurrentMonth"].ToString();
    //        ddlMonthto.SelectedValue = dtyear.Rows[0]["CurrentMonth"].ToString();
    //        ViewState["FromDate"] = "01/" + ddlMonthfrom.SelectedValue + "/" + ddlYearfrom.SelectedValue;
    //        ViewState["ToDate"] = NoOfDaysfrom + "/" + ddlMonthfrom.SelectedValue + "/" + ddlYearfrom.SelectedValue;
    //    }
    //    catch (Exception ex)
    //    {
    //    }
    //}
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterClientStartupScript();
        if (!IsPostBack)
        {
            //BindYear();
            //getUnReadMessages();
            BindYear();
            ddlYear.SelectedValue = DateTime.Now.Year.ToString();
            Size = string.IsNullOrEmpty(Request["Size"]) ? 50 : Convert.ToInt32(Request["Size"]);
            Index = string.IsNullOrEmpty(Request["Index"]) ? 1 : Convert.ToInt32(Request["Index"]);
            fillGrid();
        }
    }

    public void BindYear()
    {
        int currentYear = DateTime.Now.Date.Year;
        for (int i = currentYear; i >= 2005; i--)
        {
            ddlYear.Items.Add(new ListItem(i.ToString(), i.ToString()));
        }
    }
    private void RegisterClientStartupScript()
    {
        if (ddlSearchCond.SelectedValue == "3")
        {
            string path = Page.ResolveUrl("~/Themes/common/js/jquery-ui.min.js");
            ScriptManager sManager = ScriptManager.GetCurrent(this.Page);
            //UpdatePanel obj = (UpdatePanel)this.Page.Master.FindControl("UpdatePanel1");
            //ScriptManager sManager = (ScriptManager)this.Page.Master.FindControl("ToolkitScriptManager1");
            if (sManager != null && sManager.IsInAsyncPostBack)
            {
                //ScriptManager.RegisterClientScriptInclude(
                //   obj, typeof(string), "include-js",
                //   path);
                //ScriptManager.RegisterStartupScript(obj, obj.GetType(), "SliderScript",
                //   "Recall();", true);
                ScriptManager.RegisterClientScriptInclude(
                   this, typeof(string), "include-js",
                   path);
                ScriptManager.RegisterStartupScript(this, this.GetType(), "SliderScript",
                   "setDatePicker();", true);

            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptInclude("SliderScript", path);
            }
        }        
    }

    protected void fillGrid()
    {
         postToDate = DateTime.Now.AddDays(1);
        string url = ConfigurationManager.AppSettings["URL"].ToString();
        //string templates for links
        string link = "<a  href='" + url + "?Index=##Index##&amp;Size=##Size##'><span class='page-numbers'>##Text##</span></a>";
        string link_pre = "<a href='" + url + "?Index=##Index##&amp;Size=##Size##'><span class='page-numbers prev'>##Text##</span></a>";
        string link_next = "<a href='" + url + "?Index=##Index##&amp;Size=##Size##'><span class='page-numbers next'>##Text##</span></a>";

        postDate = DateTime.ParseExact("01/01/2000", "dd/MM/yyyy", null);
      //  postToDate = DateTime.ParseExact(PostDate.ToString(), "dd/MM/yyyy", null);
        DataTable dt = new DataTable();
        dt = Common.ViewUserSentMessage(UserLogin.loginUserId, subject, remark, postDate, postToDate, isUrgent,Size,Index);
       
            ViewState["SentData"] = dt;
            grdRecords.DataSource = dt;
            grdRecords.DataBind();
            //if (ViewState["text"] != null)
            //{
            //    txtSearch.Text = ViewState["text"].ToString();
            //}
            if (dt.Rows.Count > 0)
            {
            Double n = Convert.ToDouble(dt.Rows[0]["Pages"]);
            /////////setting page numbers with links
            if (Index != 1)
                lblpre.Text = link_pre.Replace("##Size##", Size.ToString()).Replace("##Index##", (Index - 1).ToString()).Replace("##Text##", "Prev");
            else
                lblpre.Text = "<span class='page-numbers prev'>Prev</span>";
            if (Index != Convert.ToInt32(n))
                lblnext.Text = link_next.Replace("##Size##", Size.ToString()).Replace("##Index##", (Index + 1).ToString()).Replace("##Text##", "Next");
            else
                lblnext.Text = "<span class='page-numbers next'>Next</span>";
            //generate dynamic paging 
            int start;
            if (Index <= 5) start = 1;
            else start = Index - 4;
            for (int i = start; i < start + 20; i++)
            {
                if (i > n) continue;
                //create dynamic HyperLinks 
                HyperLink lnk = new HyperLink();

                lnk.ID = "lnk_" + i.ToString();
                if (i == Index)//current page
                {
                    lnk.CssClass = "page-numbers current";
                    lnk.Text = " " + i.ToString();
                }
                else
                {
                    lnk.Text = " " + i.ToString();
                    lnk.CssClass = "page-numbers";
                    lnk.NavigateUrl = url + "?Index=" + i + "&Size=" + Size + "";
                }
                //add links to page
                this.pl.Controls.Add(lnk);
            }
            //------------------------------------------------------------------
            //set up the ist page and the last page
            if (n > 7)
            {
                if (Index <= Convert.ToInt32(n / 2))
                {
                    lblLast.Visible = true;
                    lblIst.Visible = false;
                    lblLast.Text = link.Replace("##Index##", n.ToString()).Replace("##Size##", Size.ToString()).Replace("##Text##", n.ToString());
                    spDot2.Visible = true;
                    spDot1.Visible = false;
                }
                else
                {
                    lblLast.Visible = false;
                    lblIst.Visible = true;
                    lblIst.Text = link.Replace("##Index##", (n - n + 1).ToString()).Replace("##Size##", Size.ToString()).Replace("##Text##", (n - n + 1).ToString());
                    spDot2.Visible = false;
                    spDot1.Visible = true;
                }
            }
            else
            {
                lblLast.Text = "";
                spDot2.Visible = false;
            }
        }
       

    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void grdRecords_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            //HiddenField hndTransDate = (HiddenField)e.Row.FindControl("hndTransDate");
            //CheckBox chkbox = (CheckBox)e.Row.FindControl("chkMessage");
            //DateTime dtTrans = Convert.ToDateTime(hndTransDate.Value);
            //if (dtTrans.CompareTo(DateTime.Now) > 0)
            //{
            //    chkbox.Visible = false;
            //}
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                Label isView = (Label)e.Row.FindControl("lblisViewed");
                LinkButton lnkMsg = (LinkButton)e.Row.FindControl("lnkMsg");
                Label lblID = (Label)e.Row.FindControl("lblID");
                Label lblIsUrg = (Label)e.Row.FindControl("lblIsUrg");
                Label lblImg = (Label)e.Row.FindControl("lblImg");
                lnkMsg.PostBackUrl = "frmViewMessage.aspx?cd=" + lblID.Text + "&p=euyq7zx&pg=" + Size + "&ind=" + Index+"&frm=sent";
                //lnkMsg.Font.Bold = false;
                if (lblIsUrg.Text == "Urgent")
                {
                    lblImg.Visible = true;
                }
                else
                {
                    lblImg.Visible = false;
                }
                if (isView.Text == "False")
                {
                    e.Row.BackColor = ColorTranslator.FromHtml("#FFF1E5");
                }               
            }
        }
        catch { }
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGrid();
        //grdRecords.DataSource = (DataTable)ViewState["SentData"];
        //grdRecords.DataBind();
        //fillGrid();
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        subject = "";
        remark = "";
        office = "";

        postDate = DateTime.ParseExact("01/01/"+ddlYear.SelectedValue.ToString(), "dd/MM/yyyy", null);
        postToDate = DateTime.ParseExact("31/12/" + ddlYear.SelectedValue.ToString(), "dd/MM/yyyy", null);
        isUrgent = false;


        if (ddlSearchCond.SelectedValue == "0")
        {
            //subject = txtSearch.Text.Trim();       
        }
        else if (ddlSearchCond.SelectedValue == "1")
        {
            subject = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "2")
        {
            remark = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "3")
        {
            try
            {
                if (txtSearch2.Text != "")
                {
                    postDate = DateTime.ParseExact(txtSearch2.Text.Trim(), "dd/MM/yyyy", null);
                    //postDate = Convert.ToDateTime(txtSearch2.Text).Date;
                }
                else
                {
                    postDate = DateTime.ParseExact("01/01/" + ddlYear.SelectedValue.ToString(), "dd/MM/yyyy", null);
                   
                }

                if (txtSearch.Text != "")
                {
                    postToDate = DateTime.ParseExact(txtSearch.Text.Trim(), "dd/MM/yyyy", null);
                }
                else
                {
                    postToDate = DateTime.ParseExact("31/12/" + ddlYear.SelectedValue.ToString(), "dd/MM/yyyy", null);
                }
            }
            catch { 
                Messagebox1.Show("Invalid Date"); 
            }
        }
        else if (ddlSearchCond.SelectedValue == "4")
        {
            office = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "5")
        {
            isUrgent = true;
        }
        //ViewState["text"] = txtSearch.Text;3.
        Size = string.IsNullOrEmpty(Request["Size"]) ? 50 : Convert.ToInt32(Request["Size"]);
        Index = string.IsNullOrEmpty(Request["Index"]) ? 1 : Convert.ToInt32(Request["Index"]);
        fillGrid();
    }
    protected void chkMessage_CheckedChanged(object sender, EventArgs e)
    {
        try
        {
            CheckBox headBox = (CheckBox)sender;
            for (int i = 0; i < grdRecords.Rows.Count; i++)
            {
                CheckBox chk = (CheckBox)grdRecords.Rows[i].FindControl("chkMessage");
                chk.Checked = headBox.Checked;
            }
        }
        catch { }
    }
    protected void btnDelete_Click(object sender, EventArgs e)
    {
        try
        {
            return;
            int cnt = 0;
            for (int i = 0; i < grdRecords.Rows.Count; i++)
            {
                CheckBox chk = (CheckBox)grdRecords.Rows[i].FindControl("chkMessage");
                if (chk.Checked == true)
                {
                    HiddenField hnd = (HiddenField)grdRecords.Rows[i].FindControl("hndMessageId");
                    Common.DeleteUserReceivedMessages(Convert.ToInt32(hnd.Value));
                    cnt++;
                }
            }
            if (cnt > 0)
            {
                fillGrid();
               Messagebox1.Show(cnt.ToString() + " Messgae successfully deleted");
            }
            else
            {
                Messagebox1.Show("Please select messages.");
            }
        }
        catch { }
    }

    protected void btnView_Click(object sender, EventArgs e)
    {
        string fromDate = (string)ViewState["FromDate"];
        string todate = (string)ViewState["ToDate"];
        if (DateTime.ParseExact(fromDate, "dd/MM/yyyy", null) > DateTime.ParseExact(todate, "dd/MM/yyyy", null))
        {
            ScriptManager.RegisterClientScriptBlock(Page, Page.GetType(), Guid.NewGuid().ToString(), "alert('From date should not greater than to date');", true);
        }
        else
        {
            fillGrid();
        }
    }
    protected void grdRecords_PageIndexChanging1(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGrid();
    }
}
