﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmChangePassword : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //getUnReadMessages();
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    #region save User detail
    protected void btnSave_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt = UserLogin.checkLoginById(UserLogin.loginUserId, txtOldPass.Text.Trim());
        if (dt.Rows.Count > 0)
        {
            UserLogin.changePasswordById(UserLogin.loginUserId, txtPassword.Text.Trim());
            Messagebox1.Show("Password successfully changed");
            resetForm();
        }
        else
        {
            Messagebox1.Show("Old password not found");
        }
    }
    #endregion

    #region resets the form
    public void resetForm()
    {
        txtCnfPassword.Text = "";
        txtOldPass.Text = "";
        txtPassword.Text = "";
    }

    #endregion
}
