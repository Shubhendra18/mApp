﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmNewUser : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGroup();
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    #region bind Group
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupId";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-Select-", "0"));
    }
    #endregion

    #region add user
    protected void btnAddUser_Click(object sender, EventArgs e)
    {
        Validate();
        if (Page.IsValid)
        {
            DataTable chkUser = new DataTable();
            chkUser = Common.CheckUserName(txtUserName.Text.Trim());
            if (chkUser == null)
            {
                Messagebox1.Show("This user name already exist. Please try with another username!");
                return;
            }
            else
            {
                if (txtPassword.Text.Trim() != txtRePassword.Text.Trim())
                {
                    Messagebox1.Show("New Password do not matched!");
                    return;
                }
                else
                {
                    DataTable dt = Common.GetUsersCount(0);
                    if (dt.Rows.Count > 0)
                    {
                        if (Convert.ToInt16(dt.Rows[0]["cntuserId"]) == 425)
                        {
                            Messagebox1.Show("You have completed maximum limit of user creation!");
                            return;
                        }
                    }
                    int insert = Common.AddUser(txtUserName.Text.Trim(), txtPassword.Text.Trim(), Convert.ToInt32(ddlGroup.SelectedValue), "A", txtMobileNo.Text);
                    if (insert == 1)
                    {
                        Messagebox1.Show("User has been registred successfully!");
                        clear();
                    }
                    else
                    {
                        Messagebox1.Show("Registration Failed!");
                        return;
                    }
                }
            }
        }
    }
    #endregion

    #region reset form fields
    protected void btnreset_Click(object sender, EventArgs e)
    {
        clear();
    }
    #endregion

    #region clear
    private void clear()
    {
        ddlGroup.SelectedIndex = 0;
        txtUserName.Text = "";
        txtPassword.Text = "";
        txtRePassword.Text = "";
        txtMobileNo.Text = "";
    }
    #endregion

    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmHome.aspx");
    }
}
