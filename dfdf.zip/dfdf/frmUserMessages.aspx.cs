﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmUserMessages : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGrid();
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void fillGrid()
    {
        
        if (Request.QueryString["u"] != null)
        {
            int userId=0;
            userId=Convert.ToInt32(Request.QueryString["u"]);
            DataTable dt = new DataTable();
            if (Request.QueryString["s"] != null)
            {
                if (Request.QueryString["s"].ToString() == "2")
                {
                    dt = Common.ViewUserSentMessageStatus(userId, "", "", DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null), DateTime.Now, false, 1, 50);
                    lblHeading.Text = (dt.Rows.Count > 0 ? Convert.ToString(dt.Rows[0]["postedBy"]) : "User") + "'s Sent Messages";
                }
                else
                {
                    //dt = Common.getUserReceivedMessages(userId, "", "", "", DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null),false,false);
                    dt = Common.getUserReceivedMessagesForSummary(userId, "", "", "", DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null));
                    lblHeading.Text = (dt.Rows.Count>0?Convert.ToString(dt.Rows[0]["officeName"]):"User")+"'s Received Messages";
                }
            }
            else
            {
                //dt = Common.getUserReceivedMessages(userId, "", "", "", DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null), false, false);
                dt = Common.getUserReceivedMessagesForSummary(userId, "", "", "", DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null));
                lblHeading.Text = (dt.Rows.Count > 0 ? Convert.ToString(dt.Rows[0]["officeName"]) : "User") + "'s Received Messages";
            }
            grdRecords.DataSource = dt;
            grdRecords.DataBind();
        }
        else
        {
            Response.Redirect("frmMessageCounterReport.aspx");
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmMessageCounterReport.aspx");
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGrid();
    }   
}
