﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmViewMessageRpt : NOTICEBOARD.BaseClass
{    
    DateTime postDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillOffice();
        }
    }
   
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    #region fill office
    private void fillOffice()
    {
        DataTable dt = new DataTable();
        dt = Common.GetAllOffice();
        ddlOffice.DataSource = dt;

        ddlOffice.DataTextField = "officeName";
        ddlOffice.DataValueField = "userId";
        ddlOffice.DataBind();
        ddlOffice.Items.Insert(0, new ListItem("-Select-", "0"));
    }
    #endregion

    #region search button click
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        fillGrid();
    }

    public void fillGrid()
    {
        DateTime dtstart = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null);
        if (txtFromDate.Text != "")
        {
            dtstart = DateTime.ParseExact(txtFromDate.Text, "dd/MM/yyyy", null);
        }
        DateTime dtend = DateTime.ParseExact(DateTime.Now.Date.ToString("dd/MM/yyyy"), "dd/MM/yyyy", null);
        if (txtToDate.Text != "")
        {
            dtend = DateTime.ParseExact(txtToDate.Text, "dd/MM/yyyy", null);
        }
        DataTable dt = new DataTable();
        dt = Common.getPostedMessageRecord(Convert.ToInt32(ddlOffice.SelectedValue), Convert.ToInt32(rblSearch.SelectedValue), txtSearchCriteria.Text.Trim(), dtstart, dtend);
        grdRecords.DataSource = dt;
        grdRecords.DataBind();
        lblCount.Visible = true;
        lblCount.Text = "Total Messages : " + dt.Rows.Count.ToString();
        //trCount.Visible = true;
        //Session["dataSet"] = dt;
    }
    #endregion

    #region grid paging
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGrid();
    }

    protected void grdRecords_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            //HiddenField hndTransDate = (HiddenField)e.Row.FindControl("hndTransDate");
            //CheckBox chkbox = (CheckBox)e.Row.FindControl("chkMessage");
            //DateTime dtTrans = Convert.ToDateTime(hndTransDate.Value);
            //if (dtTrans.CompareTo(DateTime.Now) > 0)
            //{
            //    chkbox.Visible = false;
            //}
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lnkMsg = (LinkButton)e.Row.FindControl("lnkMsg");
                Label lblID = (Label)e.Row.FindControl("lblID");
                //Label lblIsUrg = (Label)e.Row.FindControl("lblIsUrg");
                Label lblImg = (Label)e.Row.FindControl("lblImg");
                lnkMsg.PostBackUrl = "frmViewMessage.aspx?cd=" + lblID.Text + "&p=dsjh4eru";
                //if (lblIsUrg.Text == "Urgent")
                //{
                //    lblImg.Visible = true;
                //}
                //else
                //{
                //    lblImg.Visible = false;
                //}
            }
        }
        catch { }
    }
    #endregion

    #region shows/hides rows acc to selected option
    protected void rblSearch_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (rblSearch.SelectedValue == "0")
        {
            lbltext.Text = "By Subject";
            BySubject.Visible = true;
            ByDate.Visible = false;
            ByOffice.Visible = false;
            txtFromDate.Text = "";
            txtToDate.Text = "";
        }
        else if (rblSearch.SelectedValue == "2")
        {
            BySubject.Visible = false;
            ByDate.Visible = true;
            ByOffice.Visible = false;
            txtSearchCriteria.Text = "";
        }
        else if (rblSearch.SelectedValue == "3")
        {
            BySubject.Visible = false;
            ByDate.Visible = false;
            ByOffice.Visible = true;
            txtFromDate.Text = "";
            txtToDate.Text = "";
            txtSearchCriteria.Text = "";
        }
        fillOffice();
    }
    #endregion
}
