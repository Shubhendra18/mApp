﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmResetPassword : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //forPostBacking();
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGroup();
            //ddlGroup.Attributes.Add("onchange", "javascript:GetOffices('" + ddlGroup.ClientID + "')");
            //ddlOffice.Attributes.Add("onchange", "javascript:GetOfficeName('" + ddlOffice.ClientID + "')");
        }
    }
    //for downloading attachment
    public void forPostBacking()
    {
        ScriptManager objSM = (ScriptManager)this.Page.Master.FindControl("ScriptManager1");
        if (objSM != null)
        {
            objSM.RegisterPostBackControl(ddlGroup);
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupId";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-Select-", "0"));
    }
    protected void ddlGroup_OnSelectedIndexChanged1(object sender, EventArgs e)
    {
        if (ddlGroup.SelectedValue != "0")
        {
            DataTable dt = new DataTable();
            dt = Common.getGroupUsers(Convert.ToInt32(ddlGroup.SelectedValue));
            ddlOffice.DataSource = dt;
            ddlOffice.DataTextField = "officeName";
            ddlOffice.DataValueField = "userId";
            ddlOffice.DataBind();
            ddlOffice.Items.Insert(0, new ListItem("-Select-", "0"));
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Validate();
        if (Page.IsValid)
        {
            if (txtNewPassword.Text.Trim().Length < 6 || txtRePassword.Text.Trim().Length < 6)
            {
                Messagebox1.Show("New Password length must be between 6-15 characters");
                return;
            }
            if (txtNewPassword.Text.Trim() != txtRePassword.Text.Trim())
            {
                Messagebox1.Show("New Password do not matched.");
                return;
            }
            UserLogin.ResetPassword(ddlOffice.SelectedItem.Text, Convert.ToInt32(ddlGroup.SelectedValue), txtNewPassword.Text.Trim());
            //UserLogin.ResetPassword(hfdOffice.Value.Trim(), Convert.ToInt32(hfdGroup.Value.Trim()), txtNewPassword.Text.Trim());
            Messagebox1.Show("Password Successfully changed.");
        }
    }
    protected void ddlGroup_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlGroup.SelectedIndex > 0)
        {
            DataTable dt = new DataTable();
            dt = Common.getGroupUsers(Convert.ToInt32(ddlGroup.SelectedValue));
            ddlOffice.DataSource = dt;
            ddlOffice.DataTextField = "officeName";
            ddlOffice.DataValueField = "userId";
            ddlOffice.DataBind();
            ddlOffice.Items.Insert(0, new ListItem("-Select-", "0"));
        }
    }
    [System.Web.Services.WebMethod]
    public static DataTable GetOffices(Int16 GroupID)
    {
        DataTable dt = Common.getGroupUsers(GroupID);
        return dt;
    }
}
