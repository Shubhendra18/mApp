Cufon.replace('#logo .logo_name span');
Cufon.replace('#logo .logo_name', {
				color: '-linear-gradient(#2d2c2c, 0.2=#2d2c2c, 0.5=#2d2c2c, #cac9c9)'
			});

Cufon.replace('#notice', {color: '-linear-gradient(#1d9eca, 0.2=#1d9eca, 0.5=#07709c, #073d54)'
			});
