Cufon.replace('#logo .logo_name span');
Cufon.replace('#logo .logo_name', {
				color: '-linear-gradient(#2d2c2c, 0.2=#ffffff, 0.5=#ffffff, #cac9c9)'
			});

Cufon.replace('#notice', {color: '-linear-gradient(#2d2c2c, 0.2=#ffffff, 0.5=#ffffff, #cac9c9)'
			});


