﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmViewUser : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillGroup();
            fillGrid();
            divForm.Visible = false;
        }
    }
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupID";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-All-", "0"));
    }
    protected void fillGrid()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroupUsers(Convert.ToInt32(ddlGroup.SelectedValue));
        grdRecords.DataSource = dt;
        grdRecords.DataBind();
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGrid();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        fillGrid();
    }
    protected void grdRecord_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "EDI")
        {
            DataTable dt = new DataTable();
            dt = Common.getUserById(Convert.ToInt32(e.CommandArgument));
            if (dt.Rows.Count > 0)
            {
                hndUserid.Value = Convert.ToString(dt.Rows[0]["userId"]);
                txtUserName.Text = Convert.ToString(dt.Rows[0]["officeName"]);
                divForm.Visible = true;
            }
            else
            {
                hndUserid.Value = "0";
                divForm.Visible = false;
                Messagebox1.Show("No record found");
            }
        }
        if (e.CommandName == "DEL")
        {
            Common.deletUserName(Convert.ToInt32(e.CommandArgument));
            Messagebox1.Show("User Successfully Deleted.");
            fillGrid();
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Validate();
        if (Page.IsValid)
        {
            if (hndUserid.Value != "0")
            {
                Common.updateUserName(Convert.ToInt32(hndUserid.Value), txtUserName.Text.Trim());
                hndUserid.Value = "0";
                txtUserName.Text = "";
                divForm.Visible = false;
                fillGrid();
                Messagebox1.Show("User successfully updated.");
            }
            else
            {
                Messagebox1.Show("Please select user.");
            }
        }
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        hndUserid.Value = "0";
        txtUserName.Text = "";
        divForm.Visible = false;
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmNewUser.aspx");
    }
}
