﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillGroup();
            ddlGroup.Attributes.Add("onchange", "javascript:GetOffices('" + ddlGroup.ClientID + "')");
            ddlOffice.Attributes.Add("onchange", "javascript:GetOfficeName('" + ddlOffice.ClientID + "')");
        }
    }
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = GroupMaster.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupId";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-Select-", "0"));
    }
    protected void ddlGroup_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlGroup.SelectedValue != "0")
        {
            DataTable dt = new DataTable();
            dt = Common.getGroupUsers(Convert.ToInt32(ddlGroup.SelectedValue));
            ddlOffice.DataSource = dt;
            ddlOffice.DataTextField = "officeName";
            ddlOffice.DataValueField = "userId";
            ddlOffice.DataBind();
            ddlOffice.Items.Insert(0, new ListItem("-Select-", "0"));
        }
    }
    [System.Web.Services.WebMethod]
    public static DataTable GetOffices(Int16 GroupID)
    {
        DataTable dt = Common.getGroupUsers(GroupID);
        return dt;
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        //Validate();
        //if (Page.IsValid)
        //{
        if (txtPassword.Text == "")
        {
            MessageBox1.Show("Password Cannot be empty");
            return;
        }
        DataTable dt = new DataTable();
        //dt = UserLogin.checkLogin(ddlOffice.SelectedItem.Text.Trim(), txtPassword.Text.Trim());
        dt = UserLogin.checkLogin(hfdOffice.Value.Trim(), txtPassword.Text.Trim());
        if (dt.Rows.Count > 0)
        {
            Session["OfficeName"] = hfdOffice.Value.Trim();//ddlOffice.SelectedItem.Text;
            Session["UserID"] = Convert.ToString(dt.Rows[0]["userId"]);
            Session["UserType"] = "1";
            UserLogin.updateLastLogin(Convert.ToInt32(dt.Rows[0]["userId"]), DateTime.Now);
            //------Login Details( Last Login and Login Expiration)------//
            Session["LASTLOGINON"] = dt.Rows[0]["LastLogin"].ToString();
            Session["LOGINEXPIREDAYS"] = dt.Rows[0]["LoginExpirInDays"].ToString();
            //------------------------//
            UserLogin.updateLastLogin(Convert.ToInt32(dt.Rows[0]["userId"]), DateTime.Now);
            if (dt.Rows[0]["LoginExpired"].ToString() == "true")
            {
                //pnlChangePwd.Visible = true;
                //pnlLogin.Visible = false;
                Session["typ"] = "1";
                Response.Redirect("~/frmNewLoginChangePassword.aspx");
                //lblWelHeader.Text = "Welcome: " + ddlOffice.SelectedItem.Text;
                //lblMsg.Text = "As your password is expired, you are suggested to change your password to proceed further.";
                //pnlChangePwd_ModalPopupExtender.Show();
            }
            else if (Convert.ToBoolean(dt.Rows[0]["FirstLogin"].ToString()) == false)
            {
                //pnlChangePwd.Visible = true;
                //pnlLogin.Visible = false;
                Session["typ"] = "2";
                Response.Redirect("~/frmNewLoginChangePassword.aspx");
                //lblWelHeader.Text = "Welcome: " + ddlOffice.SelectedItem.Text;
                //lblMsg.Text = "As you have logged in first time, you are suggested to change your password to proceed further.";
                //pnlChangePwd_ModalPopupExtender.Show();
            }
            else
            {
                //pnlChangePwd.Visible = false;
                //pnlLogin.Visible = true;
                Response.Redirect("~/frmHome.aspx");
            }
        }
        else
        {
            MessageBox1.Show("Invalid User Name/Password!");
            RegisterClientStartupScript();
        }
        //}
    }
    private void RegisterClientStartupScript()
    {
        ScriptManager sManager = ScriptManager.GetCurrent(this.Page);
        UpdatePanel obj = (UpdatePanel)this.Page.FindControl("UpdatePanel1");
        if (sManager != null && sManager.IsInAsyncPostBack)
        {
            ScriptManager.RegisterStartupScript(obj, obj.GetType(), "SliderScript",
               "GetOffices('" + ddlGroup.ClientID + "');", true);
        }
    }
    #region save User detail
    protected void btnSave_Click(object sender, EventArgs e)
    {
        //DataTable dt = new DataTable();
        //dt = UserLogin.checkLoginById(UserLogin.loginUserId, txtOldPass.Text.Trim());
        //if (dt.Rows.Count > 0)
        //{
        //    Session["LOGINEXPIREDAYS"] = 90;
        //    UserLogin.changePasswordById(UserLogin.loginUserId, txtNewPassword.Text.Trim());
        //    Response.Redirect("~/frmHome.aspx");
        //}
        //else
        //{
        //    pnlChangePwd_ModalPopupExtender.Show();
        //    MessageBox1.Show("Old password not found");
        //}
    }
    #endregion
}
