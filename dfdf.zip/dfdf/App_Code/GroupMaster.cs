﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

/// <summary>
/// Summary description for Common
/// </summary>
public class GroupMaster
{
    public GroupMaster()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    #region check login group
    public static DataTable getGroup(int grpID, String gpName)
    {
        string _procName = "sp_getGroups";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@grpID", DbType.Int32, grpID);
        objDatabase.AddInParameter(objDbCommand, "@gpName", DbType.String, gpName);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    
    #region update view date
    public static DataTable SaveUpdateRecord(int transId, String groupName)
    {
        string _procName = "sp_saveUpdateGroup";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@transId", DbType.Int32, transId);
        objDatabase.AddInParameter(objDbCommand, "@groupName", DbType.String, groupName);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, UserLogin.loginUserId);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }
    #endregion

    #region delete group
    public static void deleteRecord(int transId)
    {
        string _procName = "sp_deleteGroup";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@transId", DbType.Int32, transId);
        objDatabase.ExecuteNonQuery(objDbCommand);        
    }
    #endregion
    #region update Order of group
    public static void updateOrder(int grpid,int GroupOrder, string updateType)
    {
        string _procName = "sp_updateGroupOrder";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@grpID", DbType.Int32, grpid);
        objDatabase.AddInParameter(objDbCommand, "@GroupOrder", DbType.Int32, GroupOrder);
        objDatabase.AddInParameter(objDbCommand, "@updateType", DbType.String, updateType);
        objDatabase.ExecuteNonQuery(objDbCommand);
    }
    #endregion
}
