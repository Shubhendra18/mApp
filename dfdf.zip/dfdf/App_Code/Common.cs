﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;

/// <summary>
/// Summary description for Common
/// </summary>
public class Common
{
    public Common()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    #region check login group
    public static DataTable getGroup(int grpID, String gpName)
    {
        string _procName = "Proc_getUserGroup";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@grpID", DbType.Int32, grpID);
        objDatabase.AddInParameter(objDbCommand, "@gpName", DbType.String, gpName);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region check login user
    public static DataTable getGroupUsers(int grpID)
    {
        string _procName = "Proc_selectUser";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, grpID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region For All user List
    public static DataTable getGroupUsersForUserList(int grpID)
    {
        string _procName = "Proc_selectUserForManage";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, grpID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    //#region check login user existing
    //public static DataTable getUserReceivedMessages(int userID, String subject, String remarks, String office, DateTime postDate, DateTime postToDate, bool isUrgent, bool isArchived, DateTime fromdate, DateTime todate)
    //{
    //    string _procName = "proc_userHome_getRecevedMessage";
    //    DataTable dt1 = new DataTable();
    //    Database objDatabase = DatabaseFactory.CreateDatabase();
    //    DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
    //    objDatabase.AddInParameter(objDbCommand, "@postedto", DbType.Int32, userID);
    //    objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
    //    objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
    //    objDatabase.AddInParameter(objDbCommand, "@office", DbType.String, office);
    //    objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
    //    objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, postToDate);
    //    objDatabase.AddInParameter(objDbCommand, "@isUrgent", DbType.Boolean, isUrgent);
    //    objDatabase.AddInParameter(objDbCommand, "@isArchived", DbType.Boolean, isArchived);
    //    objDatabase.AddInParameter(objDbCommand, "@fromDate", DbType.DateTime, fromdate);
    //    objDatabase.AddInParameter(objDbCommand, "@todate", DbType.DateTime, todate);
    //    using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
    //    {
    //        dt1.Load(dr);
    //    }
    //    return dt1;
    //}

    #region check login user
    public static DataTable getUserReceivedMessages_New(int userID, String subject, String remarks, String office, DateTime postDate, DateTime postToDate, bool isUrgent, bool isArchived,int Size,int Index)
    {
        //string _procName = "proc_userHome_getRecevedMessage_shubh";
        string _procName = "proc_userHome_getRecevedMessage";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@postedto", DbType.Int32, userID);
        objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
        objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
        objDatabase.AddInParameter(objDbCommand, "@office", DbType.String, office);
        if (postDate.Year == 1900)
        {
            objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, DBNull.Value);
        }
        else 
        {
        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
        }
        if (postToDate.Year == 1900)
        {
            objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, DBNull.Value);
        }
        else 
        {
        objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, postToDate);
        }
        objDatabase.AddInParameter(objDbCommand, "@isUrgent", DbType.Boolean, isUrgent);
        objDatabase.AddInParameter(objDbCommand, "@isArchived", DbType.Boolean, isArchived);

        objDatabase.AddInParameter(objDbCommand, "@PageSize", DbType.Int32, Size);
        objDatabase.AddInParameter(objDbCommand, "@PageIndex", DbType.Int32, Index);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    public static DataTable getUserReceivedMessages(int userID, String subject, String remarks, String office, DateTime postDate, DateTime postToDate, bool isUrgent, bool isArchived, int PageSize, int PageIndex)
    {
        string _procName = "proc_userHome_getRecevedMessage";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@postedto", DbType.Int32, userID);
        objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
        objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
        objDatabase.AddInParameter(objDbCommand, "@office", DbType.String, office);
        if (postDate.Year == 1900)
        {
            objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, DBNull.Value);
        }
        else
        {
            objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
        }
        if (postToDate.Year == 1900)
        {
            objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, DBNull.Value);
        }
        else
        {
            objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, postToDate);
        }
        objDatabase.AddInParameter(objDbCommand, "@isUrgent", DbType.Boolean, isUrgent);
        objDatabase.AddInParameter(objDbCommand, "@isArchived", DbType.Boolean, isArchived);

        objDatabase.AddInParameter(objDbCommand, "@PageSize", DbType.Int32, PageSize);
        objDatabase.AddInParameter(objDbCommand, "@PageIndex", DbType.Int32, PageIndex);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion


    #region GetCurrentYear
    public static DataTable GetCurrentYear()
    {
        string _procName = "Proc_GetCurrentYear";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region check login user
    public static DataTable getUserReceivedMessagesForSummary(int userID, String subject, String remarks, String office, DateTime postDate)
    {
        string _procName = "proc_userHome_getRecevedMessageForSummary";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@postedto", DbType.Int32, userID);
        objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
        objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
        objDatabase.AddInParameter(objDbCommand, "@office", DbType.String, office);
        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region count unviewd messages
    public static DataTable getUnReadMessages(int userID)
    {
        string _procName = "proc_userHome_getUnreadMessages";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@postedto", DbType.Int32, userID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region check login user
    public static DataTable getUserDeletedMessages(int userID, String subject, String remarks, String office, DateTime postDate)
    {
        string _procName = "proc_userHome_getDeletedMessage";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@postedto", DbType.Int32, userID);
        objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
        objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
        objDatabase.AddInParameter(objDbCommand, "@office", DbType.String, office);
        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region check login user
    public static DataTable DeleteUserReceivedMessages(int MsgID)
    {
        string _procName = "proc_userHome_DeleteRecivedMessage";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@MsgID", DbType.Int32, MsgID);
        objDatabase.AddInParameter(objDbCommand, "@userID", DbType.Int32, UserLogin.loginUserId);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region check login user
    public static void SaveMessages(String description, String file_description, String attachment1, String attachment2, String attachment3, String attachment4, int postedId, String remark, String postedBy, String postedto, int msgPriority, bool isUrgent, bool isViewed)
    {
        string _procName = "proc_SaveMessage";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@description", DbType.String, description);
        objDatabase.AddInParameter(objDbCommand, "@file_description", DbType.String, file_description);
        objDatabase.AddInParameter(objDbCommand, "@attachment1", DbType.String, attachment1);
        objDatabase.AddInParameter(objDbCommand, "@attachment2", DbType.String, attachment2);
        objDatabase.AddInParameter(objDbCommand, "@attachment3", DbType.String, attachment3);
        objDatabase.AddInParameter(objDbCommand, "@attachment4", DbType.String, attachment4);
        objDatabase.AddInParameter(objDbCommand, "@postedId", DbType.Int32, postedId);
        objDatabase.AddInParameter(objDbCommand, "@remark", DbType.String, remark);
        objDatabase.AddInParameter(objDbCommand, "@postedBy", DbType.String, postedBy);
        objDatabase.AddInParameter(objDbCommand, "@postedto", DbType.String, postedto);
        objDatabase.AddInParameter(objDbCommand, "@isUrgent", DbType.Boolean, isUrgent);
        objDatabase.AddInParameter(objDbCommand, "@isViewed", DbType.Boolean, isViewed);
        objDatabase.AddInParameter(objDbCommand, "@msgPriority", DbType.Int32, msgPriority);
        objDatabase.ExecuteNonQuery(objDbCommand);
    }
    #endregion

    #region View Sent Messages
    public static DataTable ViewSentMessage(string OficeName, String subject, String remarks, DateTime postDate)
    {
        string proc_Name = "proc_GetSentMessage";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@postedBy", DbType.String, OficeName);
        objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
        objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }
    #endregion

    #region View Sent Messages
    public static DataTable ViewUserSentMessage(int userId, String subject, String remarks, DateTime postDate, DateTime postToDate, bool isUrgent, int PageSize, int PageIndex)
    {
        string proc_Name = "proc_GetUserSentMessage";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.String, userId);
        objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
        objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
        objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, postToDate);
        objDatabase.AddInParameter(objDbCommand, "@isUrgent", DbType.Boolean, isUrgent);
        objDatabase.AddInParameter(objDbCommand, "@PageSize", DbType.Int32, PageSize);
        objDatabase.AddInParameter(objDbCommand, "@PageIndex", DbType.Int32, PageIndex);
      using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }

    public static DataTable ViewUserSentMessageStatus(int userId, String subject, String remarks, DateTime postDate, DateTime postToDate, bool isUrgent, int PageSize, int PageIndex)
    {
        string proc_Name = "proc_GetUserSentMessageStatus";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.String, userId);
        objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
        objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
        objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, postToDate);
        objDatabase.AddInParameter(objDbCommand, "@isUrgent", DbType.Boolean, isUrgent);
        objDatabase.AddInParameter(objDbCommand, "@PageSize", DbType.Int32, PageSize);
        objDatabase.AddInParameter(objDbCommand, "@PageIndex", DbType.Int32, PageIndex);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }

    //public static DataTable ViewUserSentMessage(int userId, String subject, String remarks, string office, DateTime postDate, DateTime postToDate, bool isUrgent, Int32 MonthName, Int32 YearName )
    //{
    //    string proc_Name = "proc_GetUserSentMessage_Shubh";
    //    DataTable dt = new DataTable();
    //    Database objDatabase = DatabaseFactory.CreateDatabase();
    //    DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
    //    objDatabase.AddInParameter(objDbCommand, "@userId", DbType.String, userId);
    //    objDatabase.AddInParameter(objDbCommand, "@subject", DbType.String, subject);
    //    objDatabase.AddInParameter(objDbCommand, "@remarks", DbType.String, remarks);
    //    objDatabase.AddInParameter(objDbCommand, "@office", DbType.String, office);
    //    if (postDate.Year == 1900)
    //    {
    //        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, DBNull.Value);
    //    }
    //    else
    //    {
    //        objDatabase.AddInParameter(objDbCommand, "@postDate", DbType.DateTime, postDate);
    //    }
    //    if(postToDate.Year==1900)
    //    {
    //        objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, DBNull.Value);
    //    }
    //    else
    //    {
    //        objDatabase.AddInParameter(objDbCommand, "@postToDate", DbType.DateTime, postToDate);
    //    }
    //    objDatabase.AddInParameter(objDbCommand, "@isUrgent", DbType.Boolean, isUrgent);
    //    objDatabase.AddInParameter(objDbCommand, "@MonthName", DbType.Int32, MonthName);
    //    objDatabase.AddInParameter(objDbCommand, "@YearName", DbType.Int32, YearName);
    //    using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
    //    {
    //        dt.Load(dr);
    //    }
    //    return dt;
    //}
    #endregion

    #region Get All offices
    public static DataTable GetAllOffice()
    {
        string proc_Name = "Proc_selectOffice";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }
    #endregion

    #region Search Received Messages
    public static DataTable getSearchedRecord(int postedid, int searchType, String searchCriteria, DateTime fromDate, DateTime toDate)
    {
        string proc_Name = "proc_SearchSentMessage";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@postedid", DbType.Int32, postedid);
        objDatabase.AddInParameter(objDbCommand, "@searchType", DbType.Int32, searchType);
        objDatabase.AddInParameter(objDbCommand, "@searchCriteria", DbType.String, searchCriteria);
        objDatabase.AddInParameter(objDbCommand, "@fromDate", DbType.DateTime, fromDate);
        objDatabase.AddInParameter(objDbCommand, "@toDate", DbType.DateTime, toDate);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }
    #endregion

    #region Add user
    public static int AddUser(String NAME_OF_OFFICES, String Password, Int32 GroupId, String recFlag, string mobileNo)
    {

        string proc_Name = "Proc_UserMaster_Ins";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@NAME_OF_OFFICES", DbType.String, NAME_OF_OFFICES);
        objDatabase.AddInParameter(objDbCommand, "@PASSWORD1", DbType.String, Password);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, GroupId);
        objDatabase.AddInParameter(objDbCommand, "@recflag", DbType.String, recFlag);
        objDatabase.AddInParameter(objDbCommand, "@mobileNo", DbType.String, mobileNo);
        int RecordInserted = 0;
        try
        {
            RecordInserted = objDatabase.ExecuteNonQuery(objDbCommand);
            if (RecordInserted > 0)
            {
                return 1;
            }
        }
        catch (Exception ex) { throw ex; }
        finally { objDbCommand.Dispose(); }
        return RecordInserted;
    }
    #endregion

    #region Get All Users Count
    public static DataTable GetUsersCount(int GroupId)
    {
        string proc_Name = "Proc_selectUserCount";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, GroupId);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }
    #endregion

    #region Add user
    public static DataTable CheckUserName(String username)
    {
        DataTable dt = new DataTable();
        string proc_Name = "Proc_getUserName";
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@userName", DbType.String, username);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }
    #endregion

    #region get Msg details
    public static DataTable GetMsgDetails(int MsgID)
    {
        string _procName = "sp_getMsgDetails";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@MsgID", DbType.Int32, MsgID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }
    #endregion

    #region update view date
    public static DataTable updateMsgViewDetails(int MsgID, DateTime viewDate)
    {
        string _procName = "proc_userHome_updateViewMessage";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@Viewdate", DbType.DateTime, viewDate);
        objDatabase.AddInParameter(objDbCommand, "@messageID", DbType.Int32, MsgID);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, UserLogin.loginUserId);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region Delete User
    public static void deletUserName(Int32 userID)
    {
        string proc_Name = "sp_deleteUserLogin";
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, userID);
        objDatabase.ExecuteNonQuery(objDbCommand);
    }
    #endregion

    #region get user by Id
    public static DataTable getUserById(Int32 userID)
    {
        DataTable dt1 = new DataTable();
        string proc_Name = "sp_getUserLogin";
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, userID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region update view date
    public static DataTable getLastLoginReport(int groupID)
    {
        string _procName = "sp_getLastLoginReport";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, groupID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }
    #endregion

    #region Message Board Used User List
    public static DataTable getUsedUserListReport(int groupID)
    {
        string _procName = "sp_userMaster_UsedUser";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, groupID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }
    #endregion

    #region Message Board Not Used User List
    public static DataTable getNotUsedUserListReport(int groupID)
    {
        string _procName = "sp_userMaster_NotUsedUser";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, groupID);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }
    #endregion

    #region get sent & received messgaes statistics
    public static DataTable getSentAndReceivedStats(int groupId)
    {
        string _procName = "sp_getSentAndReceivedStats";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@groupId", DbType.Int32, groupId);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }

    #endregion

    #region Search Posted Messages
    public static DataTable getPostedMessageRecord(int postedid, int searchType, String searchCriteria, DateTime fromDate, DateTime toDate)
    {
        string proc_Name = "sp_getPostedMessageRecord";
        DataTable dt = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(proc_Name);
        objDatabase.AddInParameter(objDbCommand, "@postedid", DbType.Int32, postedid);
        objDatabase.AddInParameter(objDbCommand, "@searchType", DbType.Int32, searchType);
        objDatabase.AddInParameter(objDbCommand, "@searchCriteria", DbType.String, searchCriteria);
        objDatabase.AddInParameter(objDbCommand, "@fromDate", DbType.DateTime, fromDate);
        objDatabase.AddInParameter(objDbCommand, "@toDate", DbType.DateTime, toDate);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt.Load(dr);
        }
        return dt;
    }
    #endregion

    #region get All themes
    public static DataTable getAllThemes(String themeName)
    {
        string _procName = "sp_getAllThemes";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@themeName", DbType.String, themeName);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }
    #endregion

    #region update user name
    public static void updateUserName(int userId, String userName)
    {
        string _procName = "sp_updateUserName";
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, userId);
        objDatabase.AddInParameter(objDbCommand, "@userName", DbType.String, userName);
        objDatabase.ExecuteNonQuery(objDbCommand);
    }
    #endregion

    #region update user name and Mobile No.
    public static int updateUserMaster(int userId, String userName, String mobileNo)
    {
        string _procName = "sp_updateUserMaster";
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, userId);
        objDatabase.AddInParameter(objDbCommand, "@userName", DbType.String, userName);
        objDatabase.AddInParameter(objDbCommand, "@mobileNo", DbType.String, mobileNo);
        int i = objDatabase.ExecuteNonQuery(objDbCommand);
        return i;
    }
    #endregion

    #region update Activate Deactivate
    public static int updateActivateDeactivateUserMaster(int userId, String recflag)
    {
        string _procName = "sp_updateUserMasterActvateDeactivate";
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, userId);
        objDatabase.AddInParameter(objDbCommand, "@recflag", DbType.String, recflag);
        int i = objDatabase.ExecuteNonQuery(objDbCommand);
        return i;
    }
    #endregion

    #region SaveArchieve
    public static int SaveArchieve(string xmlID, bool isArchived)
    {
        string _procName = "proc_UpdateMessageArchive";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@xmlID", DbType.String, xmlID);
        objDatabase.AddInParameter(objDbCommand, "@isArchived", DbType.Boolean, isArchived);
        int RecordInserted = objDatabase.ExecuteNonQuery(objDbCommand);
        return RecordInserted;
    }
    #endregion

    #region get sent & received messgaes Total Count
    public static DataTable getSentAndReceivedTotalCount(int groupId)
    {
        string _procName = "Proc_getMessageCountByGroupId";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@groupId", DbType.Int32, groupId);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;

    }
    #endregion
}
