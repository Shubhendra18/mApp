﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data;
using System.Data.Common;
using Microsoft.Practices.EnterpriseLibrary.Data;


/// <summary>
/// Class created by Shiwanshu
/// </summary>

public class UserLogin
{
	public UserLogin()
	{
		//
		// TODO: Add constructor logic here
		//
    }

    #region check login code
    public static DataTable checkLogin(String officeName, String password)
    {
        string _procName = "Proc_userLogin_selectLogin";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@officeName", DbType.String, officeName);
        objDatabase.AddInParameter(objDbCommand, "@password", DbType.String, password);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region check login code
    public static DataTable checkLoginById(int userId, String oldPassword)
    {
        string _procName = "sp_checkLoginBYID";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@userID", DbType.Int32, userId);
        objDatabase.AddInParameter(objDbCommand, "@oldPassword", DbType.String, oldPassword);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region change password
    public static void changePassword(String officeName, String password, String newPassword)
    {
        string _procName = "sp_changePassword";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@NAME_OF_OFFICES", DbType.String, officeName);
        objDatabase.AddInParameter(objDbCommand, "@PASSWORD1", DbType.String, password);
        objDatabase.AddInParameter(objDbCommand, "@newPassword", DbType.String, newPassword);
        objDatabase.ExecuteReader(objDbCommand);        
    }
    #endregion

    #region change password
    public static void changePasswordById(int userID, String newPassword)
    {
        string _procName = "sp_changePasswordBYID";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@userID", DbType.Int32, userID);       
        objDatabase.AddInParameter(objDbCommand, "@newPassword", DbType.String, newPassword);
        objDatabase.ExecuteReader(objDbCommand);
    }
    #endregion

    #region Reset password
    public static void ResetPassword(String officeName, int groupID, String newPassword)
    {
        string _procName = "sp_ResetPassword";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@NAME_OF_OFFICES", DbType.String, officeName);
        objDatabase.AddInParameter(objDbCommand, "@groupID", DbType.Int32, groupID); 
        objDatabase.AddInParameter(objDbCommand, "@newPassword", DbType.String, newPassword);
        objDatabase.ExecuteReader(objDbCommand);
    }
    #endregion

    #region update last login 
    public static void updateLastLogin(int userID, DateTime loginDate)
    {
        string _procName = "proc_userLogin_updateLastLogin";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, userID);
        objDatabase.AddInParameter(objDbCommand, "@lastLogin", DbType.DateTime, loginDate);  
        objDatabase.ExecuteReader(objDbCommand);
    }
    #endregion

    #region get User Details
    public DataTable getUserDetails(String userName, String password)
    {
        string _procName = "sp_getUserDetails";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@userName", DbType.String, userName);
        objDatabase.AddInParameter(objDbCommand, "@password", DbType.String, password);
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    public static Int32 loginUserId
    {
        get
        {
            if (HttpContext.Current.Session["UserID"] == null)
            {
                string baseUrl = HttpContext.Current.Request.Url.Scheme + "://" + HttpContext.Current.Request.Url.Authority + HttpContext.Current.Request.ApplicationPath.TrimEnd('/');
                HttpContext.Current.Response.Redirect(baseUrl + "/frmLogin.aspx");
            }
            else
            {
                return Convert.ToInt32(HttpContext.Current.Session["UserID"]);
            }
            return 0;
        }
    }
    public static String siteUrl
    {
        get
        {
            return HttpContext.Current.Request.Url.Scheme + "://" + HttpContext.Current.Request.Url.Authority + HttpContext.Current.Request.ApplicationPath.TrimEnd('/');
        }
    }

    #region Site Configuration
    public static void updateSiteConfig(String title, String subTitle, String module, String url, String adminMail, String keywords, String logoname)
    {
        string _procName = "sp_saveUpdateConfig";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@siteTitle", DbType.String, title);
        objDatabase.AddInParameter(objDbCommand, "@siteSubTitle", DbType.String, subTitle);
        objDatabase.AddInParameter(objDbCommand, "@module", DbType.String, module);
        objDatabase.AddInParameter(objDbCommand, "@siteUrl", DbType.String, url);
        objDatabase.AddInParameter(objDbCommand, "@adminMail", DbType.String, adminMail);
        objDatabase.AddInParameter(objDbCommand, "@keywords", DbType.String, keywords);
        objDatabase.AddInParameter(objDbCommand, "@logoname", DbType.String, logoname);
        objDatabase.AddInParameter(objDbCommand, "@userId", DbType.Int32, 1);//loginUserId);
        objDatabase.ExecuteReader(objDbCommand);
    }
    #endregion

    #region get site config
    public static DataTable getSiteConfig()
    {
        string _procName = "sp_getSiteConfig";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);        
        using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
        {
            dt1.Load(dr);
        }
        return dt1;
    }
    #endregion

    #region Set Application parameters
    public static void setSiteParameters()
    {        
        DataTable dt = new DataTable();
        dt = UserLogin.getSiteConfig();
        if (dt.Rows.Count > 0)
        {
            if (System.IO.Directory.Exists(System.Web.HttpContext.Current.Server.MapPath("~/Themes/" + Convert.ToString(dt.Rows[0]["theme"]))))
            {
                HttpContext.Current.Application["SiteTitle"] = Convert.ToString(dt.Rows[0]["siteTitle"]);
                HttpContext.Current.Application["SiteSubTitle"] = Convert.ToString(dt.Rows[0]["siteSubTitle"]);
                HttpContext.Current.Application["SiteModule"] = Convert.ToString(dt.Rows[0]["moduleName"]);
                HttpContext.Current.Application["AdminMail"] = Convert.ToString(dt.Rows[0]["adminMail"]);
                HttpContext.Current.Application["SiteTheme"] = Convert.ToString(dt.Rows[0]["theme"]);
                HttpContext.Current.Application["SiteMetaKeyWord"] = Convert.ToString(dt.Rows[0]["metaKeyWords"]);
                HttpContext.Current.Application["SiteURL"] = Convert.ToString(dt.Rows[0]["baseUrl"]);
                //HttpContext.Current.Application["SiteLogo"] = Convert.ToString(dt.Rows[0]["logoName"]);
            }
            else
            {
                HttpContext.Current.Application["SiteTitle"] = "My Message Board";
                HttpContext.Current.Application["SiteSubTitle"] = "Theme Directory not found";
                HttpContext.Current.Application["SiteModule"] = "Message Board";
                HttpContext.Current.Application["AdminMail"] = "Shiwanshu@otpl.co.in";
                HttpContext.Current.Application["SiteTheme"] = "default";
                HttpContext.Current.Application["SiteMetaKeyWord"] = "Message Board";
                HttpContext.Current.Application["SiteURL"] = "#";
                //HttpContext.Current.Application["SiteLogo"] = Convert.ToString(dt.Rows[0]["logoName"]);
            }
        }
        else
        {
            HttpContext.Current.Application["SiteTitle"] = "My Message Board";
            HttpContext.Current.Application["SiteSubTitle"] = "Here is My Sub title";
            HttpContext.Current.Application["SiteModule"] = "Message Board";
            HttpContext.Current.Application["AdminMail"] = "Shiwanshu@otpl.co.in";
            HttpContext.Current.Application["SiteTheme"] = "default";
            HttpContext.Current.Application["SiteMetaKeyWord"] = "Message Board";
            HttpContext.Current.Application["SiteURL"] = "#";
            //HttpContext.Current.Application["SiteLogo"] = Convert.ToString(dt.Rows[0]["logoName"]);
        }
    }
    #endregion

    #region UPdate Site Theme
    public static void updateSiteTheme(String SiteTheme)
    {
        string _procName = "sp_saveUpdateTheme";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@siteTheme", DbType.String, SiteTheme);        
        objDatabase.ExecuteReader(objDbCommand);
    }
    #endregion
}
