﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for NoticeBoardConfigure
/// </summary>
public class NoticeBoardConfigure
{
	public NoticeBoardConfigure()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static String ApplicationTitle {
        get
        {
            if (HttpContext.Current.Application["SiteTitle"] == null)
            {
                UserLogin.setSiteParameters();
            }
            return HttpContext.Current.Application["SiteTitle"].ToString();
        }
    }
    public static String ApplicationSubTitle
    {
        get
        {
            if (HttpContext.Current.Application["SiteSubTitle"] == null)
            {
                UserLogin.setSiteParameters();
            }
            return HttpContext.Current.Application["SiteSubTitle"].ToString();
        }
    }
    public static String ModuleName
    {
        get
        {
            if (HttpContext.Current.Application["SiteModule"] == null)
            {
                UserLogin.setSiteParameters();
            }
            return HttpContext.Current.Application["SiteModule"].ToString();
        }
    }
    public static String BaseUrl
    {
        get
        {
            if (HttpContext.Current.Application["SiteURL"] == null)
            {
                UserLogin.setSiteParameters();
            }
            return HttpContext.Current.Application["SiteURL"].ToString();
        }
    }
    public static String CurrentTheme
    {
        get
        {
            if (HttpContext.Current.Application["SiteTheme"] == null)
            {
                UserLogin.setSiteParameters();
            }
            return HttpContext.Current.Application["SiteTheme"].ToString();
        }
    }
    public static String AdminMail
    {
        get
        {
            if (HttpContext.Current.Application["AdminMail"] == null)
            {
                UserLogin.setSiteParameters();
            }
            return HttpContext.Current.Application["AdminMail"].ToString();
        }
    }
    public static String CurrentThemeURL
    {
        get
        {
            if (HttpContext.Current.Application["SiteTheme"] == null)
            {
                UserLogin.setSiteParameters();
            }
            if (System.IO.Directory.Exists(System.Web.HttpContext.Current.Server.MapPath("~/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString())))
            {
                return "Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/";
            }
            else
            {
                return "Themes/default/";
            }
        }
    }
    public static String SiteFavicon
    {
        get
        {
            if (HttpContext.Current.Application["SiteTheme"] == null)
            {
                UserLogin.setSiteParameters();
            }
            if (System.IO.File.Exists(System.Web.HttpContext.Current.Server.MapPath("~/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/favicon.ico")))
            {
                return "<link href=\"Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/favicon.ico\" type=\"image/ico\" rel=\"shortcut icon\" />";
            }
            else
            {
                return "<link href=\"Themes/default/images/favicon.ico\" type=\"image/ico\" rel=\"shortcut icon\" />";
            }
        }
    }
    public static String SiteMetaTags
    {
        get
        {
            if (HttpContext.Current.Application["SiteMetaKeyWord"] == null)
            {
                UserLogin.setSiteParameters();
            }
            return "<meta content=\"en-us\" http-equiv=\"Content-Language\"><meta content=\""+HttpContext.Current.Application["SiteMetaKeyWord"].ToString()+"\" name=\"Keywords\"><meta content=\"Shiwanshu\" name=\"author\">";
        }
    }
    public static String SiteLogo
    {
        get
        {
            if (HttpContext.Current.Application["SiteTheme"] == null)
            {
                UserLogin.setSiteParameters();
            }
            string[] dirs = System.IO.Directory.GetFiles(System.Web.HttpContext.Current.Server.MapPath("~/Themes/"+ HttpContext.Current.Application["SiteTheme"].ToString()+"/images/"), HttpContext.Current.Application["SiteTheme"].ToString()+"_logo.*");
            //string[] dirs = System.IO.Directory.GetFiles(System.Web.HttpContext.Current.Server.MapPath("~/uploaded/"), HttpContext.Current.Application["SiteLogo"].ToString());
            if (dirs.Length > 0)
            {
                String ext = System.IO.Path.GetExtension(dirs[0]);
                if (ext.ToLower() == ".jpg" || ext.ToLower() == ".png" || ext.ToLower() == ".gif")
                {
                    if (HttpContext.Current.Request.Url.ToString().EndsWith("frmLogin.aspx") || HttpContext.Current.Request.Url.ToString().EndsWith("frmAdminLogin.aspx"))
                    {
                        return "<img src=\"" + UserLogin.siteUrl + "/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/form_logo.jpg" + "\" class=\"logoimg\"/>";
                    }
                    else
                    {
                        return "<img src=\"" + UserLogin.siteUrl + "/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/" + System.IO.Path.GetFileName(dirs[0]) + "\" class=\"logoimg\"/>";
                        //return "<img src=\"" + UserLogin.siteUrl + "/uploaded/" + HttpContext.Current.Application["SiteLogo"].ToString() + "\" class=\"logoimg\"/>";
                    }
                }
                else if (ext.ToLower() == ".swf")
                {
                    if (HttpContext.Current.Request.Url.ToString().EndsWith("frmLogin.aspx") || HttpContext.Current.Request.Url.ToString().EndsWith("frmAdminLogin.aspx"))
                    {
                        return "<div class=\"logo_swf\"><object data=\"" + UserLogin.siteUrl + "/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/swajal_logo.swf\" type=\"application/x-shockwave-flash\" width=\"91\" height=\"87\">" +
                                "<param name=\"movie\" value=\"" + UserLogin.siteUrl + "/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/swajal_logo.swf\" /><param name=\"quality\" value=\"high\" />" +
                                "<param name=\"wmode\" value=\"transparent\"  /></object></div>";
                    }
                    else
                    {
                        return "<object type=\"application/x-shockwave-flash\" data=\"" + UserLogin.siteUrl + "/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/swajal_logo.swf\" width=\"91\" height=\"90\" style=\"float:right; padding-left:10px;\">" +
                                "<param name=\"movie\" value=\"" + UserLogin.siteUrl + "/Themes/" + HttpContext.Current.Application["SiteTheme"].ToString() + "/images/swajal_logo.swf\" /><param name=\"quality\" value=\"high\" />" +
                                "<param name=\"wmode\" value=\"transparent\" /></object>";
                        //return "<object type=\"application/x-shockwave-flash\" data=\"" + UserLogin.siteUrl + "/uploaded/" + HttpContext.Current.Application["SiteLogo"].ToString() + "\" width=\"91\" height=\"90\" style=\"float:right; padding-left:10px;\">" +
                        //        "<param name=\"movie\" value=\"" + UserLogin.siteUrl + "/uploaded/" + HttpContext.Current.Application["SiteLogo"].ToString() + "\" /><param name=\"quality\" value=\"high\" />" +
                        //        "<param name=\"wmode\" value=\"transparent\" /></object>";
                    }
                }
                else
                {
                    return "";
                }
            }
            else
            {
                return "";
                //return "<img src=\"" + UserLogin.siteUrl + "/uploaded/logo.jpg\" class=\"logoimg\"/>";
            }           
        }
    }
}
