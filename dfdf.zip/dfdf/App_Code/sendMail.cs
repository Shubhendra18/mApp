﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mail;

/// <summary>
/// Summary description for sendMail
/// </summary>

public class SendMail
{
    public static  bool Sending(string mailTo, string mailSubject, string tdSalutation, string tdInformation, string tdSender)
    {
        string mailForm = System.Configuration.ConfigurationManager.AppSettings["MailFrom"].ToString();// "info@lcoarch.ac.in";
        MailMessage mail = new MailMessage();
        mail.From = mailForm;
        mail.To = mailTo;
        mail.Subject = mailSubject;
        mail.Body = PassmailBodyReturn(tdSalutation, tdInformation, tdSender);
        mail.BodyFormat = MailFormat.Html;
        mail.Priority = MailPriority.High;
        SmtpMail.SmtpServer = System.Configuration.ConfigurationManager.AppSettings["MailServer"].ToString(); 
        try
        {
            SmtpMail.Send(mail);
            return true;
        }
        catch (Exception ex)
        {
            return false;
        }
    }
 
      //string mTo, mSubject, tdSalutation, tdInformation, tdHighlightMessage, tdInstruction, tdSender;

      //              // Mail For Teacher Login
      //              mTo = txtEMail.Text;
      //              mSubject = "Teacher Login Information";
                                       
      //              tdSalutation = "Dear " + txtTeacherName.Text + ",";

      //              tdInformation = "You are registered with us now. Your Login Information is as below.";

      //              tdHighlightMessage = "<table align='center'>";
      //              tdHighlightMessage += "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr>";
      //              tdHighlightMessage += "<tr><td>Your Username is</td><td>:</td><td><strong>" + txtUserName.Text + "</strong></td></tr>";
      //              tdHighlightMessage += "<tr><td>Your Password is</td><td>:</td><td><strong>" + tmpPass + "</strong></td></tr>";
      //              tdHighlightMessage += "<tr><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></tr></table>";

      //              tdInstruction = "You are requested to log on using above Username and Password.<br/>You would be automaticaly redirected to Change Password page at your first Login.";

      //              tdSender = "Regards,<br/>";
      //              tdSender += "Administrator<br/>";
      //              tdSender += "Avadh Girl's Degree Collage, Lucknow, U.P.<br/>";
      //              tdSender += "(info@agdc.ac.in)";

      //              SendMail.Sending(mTo, mSubject, tdSalutation, tdInformation, tdHighlightMessage, tdInstruction, tdSender);

    public static string mailBodyReturn(string tdSalutation, string tdInformation, string tdSender)
    {
        string mailBody;
        mailBody = "<html xmlns='http://www.w3.org/1999/xhtml'>";
        mailBody += "<head>";
        mailBody += "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
        mailBody += "<style type='text/css'><!--td{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; color:#525151; }";
        mailBody += ".foot {color: #FFFFFF;	font-size: 10px;text-align:center;}--></style>";
        mailBody += "</head>";
        mailBody += "<body>";
        mailBody += "<form>";
        mailBody += "<table width='489' height='100%' border='0' align='center' cellpadding='0' cellspacing='0'";
        mailBody += "<tr>";
        mailBody += "<td>" + tdSalutation;
        mailBody += "</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td >" + tdInformation;
        mailBody += "</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td style='height: 15px'>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td >" + tdSender;
        mailBody += "</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
         
 
        mailBody += "</table>";
        mailBody += "</form>";
        mailBody += "</body>";
        mailBody += "</html>'";
        return mailBody;
    }

    public static string PassmailBodyReturn(string tdSalutation, string tdInformation,string tdSender)
    {
        string mailBody;
        string path = ConfigurationManager.ConnectionStrings["HttpPath"].ConnectionString.Trim();
        mailBody = "<html xmlns='http://www.w3.org/1999/xhtml'>";
        mailBody += "<head>";
        mailBody += "<link href='"+ path +"App_Themes/Basic/emailStyle.css' rel='stylesheet' type='text/css' />";
        mailBody += "<meta http-equiv='Content-Type' content='text/html; charset=iso-8859-1'>";
        mailBody += "<style type='text/css'><!--td{font-family:Verdana, Arial, Helvetica, sans-serif; font-size:11px; color:#525151; }";
        mailBody += ".foot {color: #FFFFFF;	font-size: 10px;text-align:center;}--></style>";
        mailBody += "</head>";
        mailBody += "<body bgcolor='#FFFFFF' leftmargin='0' topmargin='5' marginwidth='0' marginheight='0'>";
        mailBody += "<table width='489' height='100%' border='0' align='center' cellpadding='0' cellspacing='0'";
        mailBody += "<tr>";
        mailBody += "<td height='66' colspan='3'>";
        mailBody += "<img src='" + path + "App_Themes/Basic/Images/head.jpg' width='489' height='66' alt=''></td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td height='16' colspan='3'>";
        mailBody += "<img src='" + path + "App_Themes/Basic/Images/Dynemic/mailFarch_heading.jpg' width='489' height='16' alt=''></td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td style='background-image: url(" + path + "App_Themes/Basic/Images/Dynemic/mailFarch_L.jpg); background-repeat: repeat-y; width: 12px;'>";
        mailBody += "&nbsp;</td>";
        mailBody += "<td valign='top'>";
        mailBody += "<table width='100%'>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>" + tdSalutation;
        mailBody += "</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td >" + tdInformation;
        mailBody += "</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td style='height: 15px'>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td >" + tdSender;
        mailBody += "</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "</table>";
        mailBody += "</td>";
        mailBody += "<td style='background-image: url(http://lucknowinfo.com/agdconline/App_Themes/Basic/Images/Dynemic/mailFarch_r.jpg); background-repeat: repeat-y;width: 12px;'>";
        mailBody += "&nbsp;</td>";
        mailBody += "</tr>";
        mailBody += "<tr>";
        mailBody += "<td height='23' colspan='3' style='background:#00427C; text-align:center;color:White;'>";       
        mailBody += "* This is a Computer-generated email. please do not reply to this message.</td>";
      
        mailBody += "</tr>";
        mailBody += "</table>";
        mailBody += "</form>";
        mailBody += "</body>";
        mailBody += "</html>'";
        return mailBody;
    }

}

