﻿using System;
using System.Data;
using System.Collections;
using System.Net;
using System.IO;

/// <summary>
/// Summary description for SMS
/// </summary>
public class SMS
{
    public SMS()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static void SMSSend(String Message, String Recipient)
    {
        try
        {
            WebClient Client = new WebClient();
            string baseurl = "";
            //baseurl = "http://india.timessms.com/http-api/receiverall.aspx?username=titus_otpl&getway=premium&password=71919800&sender=OMNINET&cdmasender=9935536634&to=" + Recipient + "&message=" + Message;
            baseurl = "http://india.timessms.com/http-api/receiverall.aspx?username=titus_otpl&password=71919800&sender=OMNINET&cdmasender=9935536635&to=" + Recipient + "&message=" + Message;
            Stream data = Client.OpenRead(baseurl);
            StreamReader reader = new StreamReader(data);
            string s = reader.ReadToEnd();
            data.Close();
            reader.Close();
        }
        catch (Exception ex)
        {
            return;
        }
    }

}
