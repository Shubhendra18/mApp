﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace NOTICEBOARD
{

    public class BaseClass : System.Web.UI.Page
    {
        public BaseClass()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        protected override void OnLoad(EventArgs e)
        {
            if (!String.IsNullOrEmpty(Convert.ToString(Session["UserID"])))
            {
                if (Convert.ToString(Session["OfficeName"]) == "YES")
                {
                    Session.Remove("OfficeName");
                    return; 
                }                
            }
            else
            {
                Response.Redirect("~/frmLogin.aspx");
            }
            base.OnLoad(e);
        }
    }
}