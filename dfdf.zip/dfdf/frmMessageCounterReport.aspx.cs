﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmMessageCounterReport : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGroup();
            fillGrid();
            FillCountDetails();
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void fillGrid()
    {
        DataTable dt = new DataTable();
        dt = Common.getSentAndReceivedStats(Convert.ToInt32(ddlGroup.SelectedValue));
        ViewState["SentAndReceivedStats"] = dt;
        grdRecords.DataSource = dt;
        grdRecords.DataBind();
        lblTotalUser.Text = dt.Rows.Count.ToString();
    }
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupID";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-All-", "0"));
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGridOnSearch();
        //fillGrid();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        fillGridOnSearch();
        //fillGrid();
        FillCountDetails();
    }
    protected void fillGridOnSearch()
    {
        DataTable dt = (DataTable)ViewState["SentAndReceivedStats"];
        if (ddlGroup.SelectedIndex > 0)
        {
            dt.DefaultView.RowFilter = "groupID=" + ddlGroup.SelectedValue;
        }
        lblTotalUser.Text = Convert.ToString(dt.DefaultView.Count);
        grdRecords.DataSource = dt.DefaultView;
        grdRecords.DataBind();
       
    }

    protected void FillCountDetails()
    {
        DataTable dt = Common.getSentAndReceivedTotalCount(Convert.ToInt32(ddlGroup.SelectedValue));
        lblTotalSent.Text = Convert.ToString(dt.Rows[0]["SentCount"]);
        lblreceived.Text = Convert.ToString(dt.Rows[0]["ReceivedCount"]);
    }
}
