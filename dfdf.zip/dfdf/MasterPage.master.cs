﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterClientStartupScript();
        Page.MaintainScrollPositionOnPostBack = true;
        lblUser.Text = Convert.ToString(Session["OfficeName"]);
        if (!IsPostBack)
        {
            DateTime dat = Convert.ToDateTime(Convert.ToString(Session["LASTLOGINON"]));
            string fpart = "Your last login date: " + dat.ToString("dd/MM/yyyy ") + " at " +
                 String.Format("{0:h:mm tt}", dat);
            string lpart = "";
            if (Convert.ToInt16(Session["LOGINEXPIREDAYS"]) <= 30)
            {
                lpart = ", you are suggested to change your password as it will expire in " +
                  Convert.ToString(Session["LOGINEXPIREDAYS"]) + " days.";
            }
            lblLoginDetails.Text = fpart + lpart;
            getUnReadMessages();
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }

    private void RegisterClientStartupScript()
    {
        string path = Page.ResolveUrl("~/Themes/mandi/js/jquery.js");
        ScriptManager sManager = ScriptManager.GetCurrent(this.Page);
        UpdatePanel obj = (UpdatePanel)this.Page.Master.FindControl("UpdatePanel1");
        // ScriptManager sManager = (ScriptManager)this.Page.Master.FindControl("ToolkitScriptManager1");

        if (sManager != null && sManager.IsInAsyncPostBack)
        {
            ScriptManager.RegisterClientScriptInclude(
               obj, typeof(string), "include-js",
               path);
            ScriptManager.RegisterStartupScript(obj, obj.GetType(), "SliderScript",
               "formatRecall();", true);
            //ScriptManager.RegisterClientScriptInclude(
            //   this, typeof(string), "include-js",
            //   path);
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "SliderScript",
            //   "setDatePicker();", true);

        }
        else
        {
            this.Page.ClientScript.RegisterClientScriptInclude("SliderScript", path);
        }
    }
}
