﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;


public partial class frmCompose : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterClientStartupScript();
        forPostBacking();
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGroup();
            fillOnReply();
            chkAll.Visible = false;
            chkAll.Attributes.Add("onchange", "javascript:SelectAll('" + chkAll.ClientID + "')");
        }
    }

    private void fillOnReply()
    {
        if (Session["grpID"] != null)
        {
            ddlGroup.SelectedValue = Convert.ToString(Session["grpID"]);
            //fillUsers();
            userFildset.Visible = true;
            DataTable dt = Common.getGroupUsers(Convert.ToInt32(ddlGroup.SelectedValue));
            dt.DefaultView.RowFilter = "userId <> " + UserLogin.loginUserId;
            ViewState["UserDetail"] = dt.DefaultView.ToTable();
            chkUsers.DataSource = dt.DefaultView;
            chkUsers.DataTextField = "officeName";
            chkUsers.DataValueField = "userId";
            chkUsers.DataBind();
            if (dt.Rows.Count > 0)
            {
                lblUser.Visible = false;
                chkAll.Visible = true;
                chkAll.Checked = false;
                for (int i = 0; i < chkUsers.Items.Count; i++)
                {
                    if (chkUsers.Items[i].Value == Convert.ToString(Session["postBy"]))
                    {
                        chkUsers.Items[i].Selected = true;
                    }
                }
            }
            else
            {
                lblUser.Visible = true;
                chkAll.Visible = false;
                chkAll.Checked = false;
            }
        }
        Session.Remove("grpID");
        Session.Remove("postBy");
    }
    private void RegisterClientStartupScript()
    {
        string path = Page.ResolveUrl("~/Themes/common/js/tiny_mce/tiny_mce_src.js");
        ScriptManager sManager = ScriptManager.GetCurrent(this.Page);
        UpdatePanel obj = (UpdatePanel)this.Page.Master.FindControl("UpdatePanel1");
        // ScriptManager sManager = (ScriptManager)this.Page.Master.FindControl("ToolkitScriptManager1");

        if (sManager != null && sManager.IsInAsyncPostBack)
        {
            ScriptManager.RegisterClientScriptInclude(
               obj, typeof(string), "include-js",
               path);
            ScriptManager.RegisterStartupScript(obj, obj.GetType(), "SliderScript",
               "formatRecall();", true);
            //ScriptManager.RegisterClientScriptInclude(
            //   this, typeof(string), "include-js",
            //   path);
            //ScriptManager.RegisterStartupScript(this, this.GetType(), "SliderScript",
            //   "setDatePicker();", true);

        }
        else
        {
            this.Page.ClientScript.RegisterClientScriptInclude("SliderScript", path);
        }
    }
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupID";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-Select-", "0"));
        ddlGroup.Items.Insert(1, new ListItem("All Group", "-1"));
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void chkAll_CheckedChanged(object sender, EventArgs e)
    {
        for (int i = 0; i < chkUsers.Items.Count; i++)
        {
            chkUsers.Items[i].Selected = chkAll.Checked;
        }
        //pnlGroup_ModalPopupExtender.Show();
        //for (int i = 0; i < grdUsers.Rows.Count; i++)
        //{
        //    CheckBox chk = (CheckBox)grdUsers.Rows[i].FindControl("chkUser");
        //    CheckBox chkAll = (CheckBox)sender;
        //    chk.Checked = chkAll.Checked;
        //}
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Validate();
        if (Page.IsValid)
        {
            String fileName = "";
            if (flAttach.HasFile)
            {
                fileName = flAttach.FileName;
                String ext = System.IO.Path.GetExtension(flAttach.FileName).Trim().ToLower();
                if (ext == ".doc" || ext == ".docx" || ext == ".xlsx" || ext == ".xls" || ext == ".pdf" || ext == ".zip" || ext == ".ppt" || ext == ".jpg" || ext == ".jpeg" || ext == ".txt" || ext == ".gif" || ext == ".rar")
                {
                    flAttach.SaveAs(Server.MapPath("~\\uploaded\\" + Convert.ToString(UserLogin.loginUserId) + "_" + fileName));
                    fileName = Convert.ToString(UserLogin.loginUserId) + "_" + fileName;
                }
                else
                {
                    Messagebox1.Show("Check File type.");
                    return;
                }
            }
            String fileName1 = "";
            if (flAttach1.HasFile)
            {
                fileName1 = flAttach1.FileName;
                String ext = System.IO.Path.GetExtension(flAttach1.FileName).Trim().ToLower();
                if (ext == ".doc" || ext == ".docx" || ext == ".xlsx" || ext == ".xls" || ext == ".pdf" || ext == ".zip" || ext == ".ppt" || ext == ".jpg" || ext == ".jpeg" || ext == ".txt" || ext == ".gif" || ext == ".rar")
                {
                    flAttach1.SaveAs(Server.MapPath("~\\uploaded\\" + Convert.ToString(UserLogin.loginUserId) + "_1_" + fileName1));
                    fileName1 = Convert.ToString(UserLogin.loginUserId) + "_1_" + fileName1;
                }
                else
                {
                    Messagebox1.Show("Check File type.");
                    return;
                }
            }
            String fileName2 = "";
            if (flAttach2.HasFile)
            {
                fileName2 = flAttach2.FileName;
                String ext = System.IO.Path.GetExtension(flAttach2.FileName).Trim().ToLower();
                if (ext == ".doc" || ext == ".docx" || ext == ".xlsx" || ext == ".xls" || ext == ".pdf" || ext == ".zip" || ext == ".ppt" || ext == ".jpg" || ext == ".jpeg" || ext == ".txt" || ext == ".gif" || ext == ".rar")
                {
                    flAttach2.SaveAs(Server.MapPath("~\\uploaded\\" + Convert.ToString(UserLogin.loginUserId) + "_2_" + fileName2));
                    fileName2 = Convert.ToString(UserLogin.loginUserId) + "_2_" + fileName2;
                }
                else
                {
                    Messagebox1.Show("Check File type.");
                    return;
                }
            }
            String fileName3 = "";
            if (flAttach3.HasFile)
            {
                fileName3 = flAttach3.FileName;
                String ext = System.IO.Path.GetExtension(flAttach3.FileName).Trim().ToLower();
                if (ext == ".doc" || ext == ".docx" || ext == ".xlsx" || ext == ".xls" || ext == ".pdf" || ext == ".zip" || ext == ".ppt" || ext == ".jpg" || ext == ".jpeg" || ext == ".txt" || ext == ".gif" || ext == ".rar")
                {
                    flAttach3.SaveAs(Server.MapPath("~\\uploaded\\" + Convert.ToString(UserLogin.loginUserId) + "_3_" + fileName3));
                    fileName3 = Convert.ToString(UserLogin.loginUserId) + "_3_" + fileName3;
                }
                else
                {
                    Messagebox1.Show("Check File type.");
                    return;
                }
            }
            String fileName4 = "";
            if (flAttach4.HasFile)
            {
                fileName4 = flAttach4.FileName;
                String ext = System.IO.Path.GetExtension(flAttach4.FileName).Trim().ToLower();
                if (ext == ".doc" || ext == ".docx" || ext == ".xlsx" || ext == ".xls" || ext == ".pdf" || ext == ".zip" || ext == ".ppt" || ext == ".jpg" || ext == ".jpeg" || ext == ".txt" || ext == ".gif" || ext == ".rar")
                {
                    flAttach4.SaveAs(Server.MapPath("~\\uploaded\\" + Convert.ToString(UserLogin.loginUserId) + "_4_" + fileName4));
                    fileName4 = Convert.ToString(UserLogin.loginUserId) + "_4_" + fileName4;
                }
                else
                {
                    Messagebox1.Show("Check File type.");
                    return;
                }
            }
            bool flg = false;
            String hndUser = "";
            String MobNo = "";
            DataTable dt = (DataTable)ViewState["UserDetail"];
            if (ddlGroup.SelectedValue == "-1")
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    if (dt.Rows[i]["MobileNo"].ToString() != "")
                    {
                        MobNo += dt.Rows[i]["MobileNo"].ToString() + ",";
                    }
                    hndUser += dt.Rows[i]["userId"].ToString() + ",";
                    flg = true;
                }
            }
            else
            {
                for (int i = 0; i < chkUsers.Items.Count; i++)
                {
                    if (chkUsers.Items[i].Selected == true)
                    {
                        dt.DefaultView.RowFilter = "userID=" + chkUsers.Items[i].Value;
                        if (dt.DefaultView.ToTable().Rows[0]["MobileNo"].ToString() != "")
                        {
                            MobNo += dt.DefaultView.ToTable().Rows[0]["MobileNo"].ToString() + ",";
                        }
                        hndUser += chkUsers.Items[i].Value + ",";
                        flg = true;
                    }
                }
            }
            if (hndUser.Length > 1 && hndUser.EndsWith(","))
            {
                hndUser = hndUser.Substring(0, hndUser.Length - 1);
            }
            bool isUrgent = false;
            if (rblIsUrgent.SelectedIndex == 0)
            {
                isUrgent = true;
            }
            ViewState["MobNo"] = MobNo;
            //for (int i = 0; i < grdUsers.Rows.Count; i++)
            //{
            //    CheckBox chk = (CheckBox)grdUsers.Rows[i].FindControl("chkUser");
            //    if (chk.Checked == true)
            //    {
            //        HiddenField hndUser = (HiddenField)grdUsers.Rows[i].FindControl("hndUserId");
            //        Common.SaveMessages(txtSubject.Text, fileName, UserLogin.loginUserId, txtRemarks.Text, Convert.ToString(Session["OfficeName"]), Convert.ToInt32(hndUser.Value), Convert.ToInt32(rdoPriority.SelectedValue));
            //        flg = true;
            //    }
            //}
            if (flg == true)
            {
                Common.SaveMessages(txtSubject.Text, fileName, fileName1, fileName2, fileName3, fileName4, UserLogin.loginUserId, txtRemarks.Text, Convert.ToString(Session["OfficeName"]), hndUser, Convert.ToInt32(rdoPriority.SelectedValue), isUrgent, false);
                sendMessage();
                rblIsUrgent.SelectedIndex = 1;
                txtSubject.Text = "";
                txtRemarks.Text = "";
                ddlGroup.SelectedValue = "0";
                chkUsers.Items.Clear();
                chkAll.Visible = false;
                chkAll.Checked = false;
                Messagebox1.Show("Message sent successfully.");
            }
            else
            {
                Messagebox1.Show("Select user to post the message!");
                try
                {
                    System.IO.File.Delete(Server.MapPath("~\\uploaded\\" + Convert.ToString(UserLogin.loginUserId) + "_" + fileName));
                }
                catch { }
            }
        }
    }

    private void sendMessage()
    {
        try
        {
            if (rblIsUrgent.SelectedIndex == 0)
            {
                string recipient = Convert.ToString(ViewState["MobNo"]);
                if (recipient != "")
                {
                    //string[] remark = txtSubject.Text.Split('>');
                    string msg = "You have received an urgent message (" + txtSubject.Text.Substring(0, 10).ToString() + "...) from " + Session["OfficeName"].ToString() + ".Check your Message Board.";
                    SMS.SMSSend(msg, recipient);
                }
            }
        }
        catch
        {
        }
    }
    //for uplaoding attachment
    public void forPostBacking()
    {
        ScriptManager objSM = (ScriptManager)this.Page.Master.FindControl("ScriptManager1");
        if (objSM != null)
        {
            objSM.RegisterPostBackControl(btnSave);
        }
    }
    protected void ddlGroup_OnSelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlGroup.SelectedValue != "0")
        {
            DataTable dt = new DataTable();
            if (ddlGroup.SelectedValue == "-1")
            {
                userFildset.Visible = false;
                dt = Common.getGroupUsers(0);
                dt.DefaultView.RowFilter = "userId <> " + UserLogin.loginUserId;
                ViewState["UserDetail"] = dt.DefaultView.ToTable();
            }
            else
            {
                userFildset.Visible = true;
                dt = Common.getGroupUsers(Convert.ToInt32(ddlGroup.SelectedValue));
                dt.DefaultView.RowFilter = "userId <> " + UserLogin.loginUserId;
                ViewState["UserDetail"] = dt.DefaultView.ToTable();
                chkUsers.DataSource = dt.DefaultView;
                chkUsers.DataTextField = "officeName";
                chkUsers.DataValueField = "userId";
                chkUsers.DataBind();
                if (dt.Rows.Count > 0)
                {
                    lblUser.Visible = false;
                    chkAll.Visible = true;
                    chkAll.Checked = false;
                }
                else
                {
                    lblUser.Visible = true;
                    chkAll.Visible = false;
                    chkAll.Checked = false;
                }
                //pnlGroup_ModalPopupExtender.Show();
            }
        }
        else
        {
            userFildset.Visible = false;
        }
    }
}
