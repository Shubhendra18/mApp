﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmDeletedMsg : NOTICEBOARD.BaseClass
{
    String subject = "";
    String remark = "";
    String office = "";
    DateTime postDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null);
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            getReceivedMessages();
        }
    }
    protected void getReceivedMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUserDeletedMessages(UserLogin.loginUserId, subject,remark, office, postDate);
        grdRecords.DataSource = dt;
        grdRecords.DataBind();
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        getReceivedMessages();
    }    
    protected void btnSearch_Click(object sender, EventArgs e)
    {        
        if (ddlSearchCond.SelectedValue == "0")
        {
            subject = txtSearch.Text.Trim();
            //remark = txtSearch.Text.Trim();
            //office = txtSearch.Text.Trim();           
        }
        else if (ddlSearchCond.SelectedValue == "1")
        {
            subject = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "2")
        {
            remark = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "3")
        {
            try
            {
                postDate = DateTime.ParseExact(txtSearch.Text.Trim(), "dd/MM/yyyy", null);
            }
            catch { Messagebox1.Show("Invalid Date"); }
        }
        else if (ddlSearchCond.SelectedValue == "4")
        {
            office = txtSearch.Text.Trim();
        }
        getReceivedMessages();
    }
}
