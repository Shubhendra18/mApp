﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmViewMessage : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString["t"] != null)
            {
                btnReply.Visible = true;
            }
            else
            {
                btnReply.Visible = false;
            }
            if (Request.QueryString["p"] != null)
            {
                hndPath.Value = Convert.ToString(Request.QueryString["p"]);
                
            }
            if (Request.QueryString["cd"] != null)
            {
                String msgId = Convert.ToString(Request.QueryString["cd"]);
                DataTable dt = new DataTable();
                dt = Common.GetMsgDetails(Convert.ToInt32(msgId));
                if (dt.Rows.Count > 0)
                {
                    Common.updateMsgViewDetails(Convert.ToInt32(msgId), DateTime.Now);
                    hfdPostBy.Value = Convert.ToString(dt.Rows[0]["postedId"]);
                    hfdGrpID.Value = Convert.ToString(dt.Rows[0]["groupID"]);
                    lblFrom.Text = Convert.ToString(dt.Rows[0]["postedBy"]);
                    lblDate.Text = Convert.ToString(dt.Rows[0]["postedOn"]);
                    lblSubject.Text = Convert.ToString(dt.Rows[0]["description"]);
                    lblPriority.Text = Convert.ToString(dt.Rows[0]["msgPriority"]);
                    lblIsUrgent.Text = Convert.ToString(dt.Rows[0]["isUrgent"]);
                    lblMessage.Text = Convert.ToString(dt.Rows[0]["remark"]);
                    if (dt.Rows[0]["description_file"].ToString() != "")
                    {
                        trAtt1.Visible = true;
                        attachDiv.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["description_file"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["description_file"]) + "</a>";
                    }
                    else
                    {
                        trAtt1.Visible = false;
                    }
                    if (dt.Rows[0]["attachment1"].ToString() != "")
                    {
                        trAtt2.Visible = true;
                        attachDiv2.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment1"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment1"]) + "</a>";
                    }
                    else
                    {
                        trAtt2.Visible = false;
                    }
                    if (dt.Rows[0]["attachment2"].ToString() != "")
                    {
                        trAtt3.Visible = true;
                        attachDiv3.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment2"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment2"]) + "</a>";
                    }
                    else
                    {
                        trAtt3.Visible = false;
                    }
                    if (dt.Rows[0]["attachment3"].ToString() != "")
                    {
                        trAtt4.Visible = true;
                        attachDiv4.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment3"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment3"]) + "</a>";
                    }
                    else
                    {
                        trAtt4.Visible = false;
                    }
                    if (dt.Rows[0]["attachment4"].ToString() != "")
                    {
                        trAtt5.Visible = true;
                        attachDiv5.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment4"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment4"]) + "</a>";
                    }
                    else
                    {
                        trAtt5.Visible = false;
                    }
                    //attachDiv.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["description_file"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["description_file"]) + "</a>";
                    //attachDiv2.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment1"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment1"]) + "</a>";
                    //attachDiv3.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment2"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment2"]) + "</a>";
                    //attachDiv4.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment3"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment3"]) + "</a>";
                    //attachDiv5.InnerHtml = "<a href='uploaded/" + Convert.ToString(dt.Rows[0]["attachment4"]) + "' target='_Blank'>" + Convert.ToString(dt.Rows[0]["attachment4"]) + "</a>";

                    //if (System.IO.File.Exists(Server.MapPath("~\\uploaded\\" + Convert.ToString(dt.Rows[0]["description_file"]))))
                    //{
                    //    Response.Redirect("uploaded\\" + Convert.ToString(dt.Rows[0]["description_file"]));
                    //}
                    //else
                    //{
                    //    Messagebox1.Show("File Not Found");
                    //}
                }
            }
            else
            {
                Response.Redirect("Home.aspx");
            }
            //getUnReadMessages();
        }
    }
    protected void btnReply_click(object sender, EventArgs e)
    {
        Session["grpID"] = Convert.ToInt32(hfdGrpID.Value);
        Session["postBy"] = Convert.ToInt32(hfdPostBy.Value);
        Response.Redirect("frmCompose.aspx");
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        if (hndPath.Value == "euyq7zx")
        {
            Response.Redirect("frmSentMessage.aspx");
        }
        else if (hndPath.Value == "dwebpq")
        {
            Response.Redirect("frmDeletedMsg.aspx");
        }
        else
        {
            Response.Redirect("frmHome.aspx");
        }
    }
    protected void lnkBack_Click(object sender, ImageClickEventArgs e)
    {
        if (Request.QueryString["frm"].ToString() != null)
        {
            string Page = Request.QueryString["ind"].ToString();
            string size = Request.QueryString["pg"].ToString();
            if (Request.QueryString["frm"].ToString() == "sent")
            {
                Response.Redirect("frmSentMessage.aspx?Size=" + size + "&Index=" + Page);
            }
            else if (Request.QueryString["frm"].ToString() == "home")
            {
                Response.Redirect("frmhome.aspx?Size=" + size + "&Index=" + Page);
            }
            else if (Request.QueryString["frm"].ToString() == "arc")
            {
                Response.Redirect("frmArchive.aspx?Size=" + size + "&Index=" + Page);
            }
        }
    }
   
}
