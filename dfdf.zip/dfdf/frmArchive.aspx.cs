﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmArchive : NOTICEBOARD.BaseClass
{
    String subject = "";
    String remark = "";
    String office = "";
    DateTime postDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", null);
    DateTime postToDate = DateTime.ParseExact(DateTime.Now.Date.ToString("dd/MM/yyyy"), "dd/MM/yyyy", null);
    bool isUrgent = false;
    int Index = 0;
    int Size = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterClientStartupScript();
        if (!IsPostBack)
        {
            //getUnReadMessages();
            BindYear();
            ddlYear.SelectedValue = DateTime.Now.Date.Year.ToString();
            Size = string.IsNullOrEmpty(Request["Size"]) ? 50 : Convert.ToInt32(Request["Size"]);
            Index = string.IsNullOrEmpty(Request["Index"]) ? 1 : Convert.ToInt32(Request["Index"]);
            getReceivedMessages();

        }
    }

    public void BindYear()
    {
        int currentYear = DateTime.Now.Date.Year;
        for (int i = currentYear; i >= 2005; i--)
        {
            ddlYear.Items.Add(new ListItem(i.ToString(), i.ToString()));
        }
    }

    private void RegisterClientStartupScript()
    {
        if (ddlSearchCond.SelectedValue == "3")
        {
            string path = Page.ResolveUrl("~/Themes/common/js/jquery-ui.min.js");
            ScriptManager sManager = ScriptManager.GetCurrent(this.Page);
            //UpdatePanel obj = (UpdatePanel)this.Page.Master.FindControl("UpdatePanel1");
            // ScriptManager sManager = (ScriptManager)this.Page.Master.FindControl("ToolkitScriptManager1");

            if (sManager != null && sManager.IsInAsyncPostBack)
            {
                //ScriptManager.RegisterClientScriptInclude(
                //   obj, typeof(string), "include-js",
                //   path);
                //ScriptManager.RegisterStartupScript(obj, obj.GetType(), "SliderScript",
                //   "Recall();", true);
                ScriptManager.RegisterClientScriptInclude(
                   this, typeof(string), "include-js",
                   path);
                ScriptManager.RegisterStartupScript(this, this.GetType(), "SliderScript",
                   "setDatePicker();", true);

            }
            else
            {
                this.Page.ClientScript.RegisterClientScriptInclude("SliderScript", path);
            }
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void getReceivedMessages()
    {
        postToDate = DateTime.Now.AddDays(1);
        string url = ConfigurationManager.AppSettings["URL3"].ToString();
        //string templates for links
        string link = "<a  href='" + url + "?Index=##Index##&amp;Size=##Size##'><span class='page-numbers'>##Text##</span></a>";
        string link_pre = "<a href='" + url + "?Index=##Index##&amp;Size=##Size##'><span class='page-numbers prev'>##Text##</span></a>";
        string link_next = "<a href='" + url + "?Index=##Index##&amp;Size=##Size##'><span class='page-numbers next'>##Text##</span></a>";

        postDate = DateTime.ParseExact("01/01/2000", "dd/MM/yyyy", null);
        DataTable dt = new DataTable();
        dt = Common.getUserReceivedMessages(UserLogin.loginUserId, subject, remark, office, postDate, postToDate, isUrgent, true, Size, Index);
        grdRecords.DataSource = dt;
        grdRecords.DataBind();
        if (grdRecords.Rows.Count > 0)
        {
            btnMoveTop.Visible = true;
            btnMoveBottom.Visible = true;
        }
        else
        {
            btnMoveTop.Visible = false;
            btnMoveBottom.Visible = false;
        }
        if (dt.Rows.Count > 0)
        {
            Double n = Convert.ToDouble(dt.Rows[0]["Pages"]);
            /////////setting page numbers with links
            if (Index != 1)
                lblpre.Text = link_pre.Replace("##Size##", Size.ToString()).Replace("##Index##", (Index - 1).ToString()).Replace("##Text##", "Prev");
            else
                lblpre.Text = "<span class='page-numbers prev'>Prev</span>";
            if (Index != Convert.ToInt32(n))
                lblnext.Text = link_next.Replace("##Size##", Size.ToString()).Replace("##Index##", (Index + 1).ToString()).Replace("##Text##", "Next");
            else
                lblnext.Text = "<span class='page-numbers next'>Next</span>";
            //generate dynamic paging 
            int start;
            if (Index <= 5) start = 1;
            else start = Index - 4;
            for (int i = start; i < start + 20; i++)
            {
                if (i > n) continue;
                //create dynamic HyperLinks 
                HyperLink lnk = new HyperLink();

                lnk.ID = "lnk_" + i.ToString();
                if (i == Index)//current page
                {
                    lnk.CssClass = "page-numbers current";
                    lnk.Text = " " + i.ToString();
                }
                else
                {
                    lnk.Text = " " + i.ToString();
                    lnk.CssClass = "page-numbers";
                    lnk.NavigateUrl = url + "?Index=" + i + "&Size=" + Size + "";
                }
                //add links to page
                this.pl.Controls.Add(lnk);
            }
            //------------------------------------------------------------------
            //set up the ist page and the last page
            if (n > 7)
            {
                if (Index <= Convert.ToInt32(n / 2))
                {
                    lblLast.Visible = true;
                    lblIst.Visible = false;
                    lblLast.Text = link.Replace("##Index##", n.ToString()).Replace("##Size##", Size.ToString()).Replace("##Text##", n.ToString());
                    spDot2.Visible = true;
                    spDot1.Visible = false;
                }
                else
                {
                    lblLast.Visible = false;
                    lblIst.Visible = true;
                    lblIst.Text = link.Replace("##Index##", (n - n + 1).ToString()).Replace("##Size##", Size.ToString()).Replace("##Text##", (n - n + 1).ToString());
                    spDot2.Visible = false;
                    spDot1.Visible = true;
                }
            }
            else
            {
                lblLast.Text = "";
                spDot2.Visible = false;
            }
        }
        getUnReadMessages();
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        getReceivedMessages();
    }
    protected void grdRecords_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        try
        {
            //HiddenField hndTransDate = (HiddenField)e.Row.FindControl("hndTransDate");
            //CheckBox chkbox = (CheckBox)e.Row.FindControl("chkMessage");
            //DateTime dtTrans = Convert.ToDateTime(hndTransDate.Value);
            //if (dtTrans.CompareTo(DateTime.Now) < 0)
            //{
            //    chkbox.Visible = false;
            //}
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                LinkButton lnkMsg = (LinkButton)e.Row.FindControl("lnkMsg");
                Label lblID = (Label)e.Row.FindControl("lblID");
                Label lblisViewed = (Label)e.Row.FindControl("lblisViewed");
                Label lblIsUrg = (Label)e.Row.FindControl("lblIsUrg");
                Label lblImg = (Label)e.Row.FindControl("lblImg");
                lnkMsg.PostBackUrl = "frmViewMessage.aspx?cd=" + lblID.Text + "&p=dsjh4eru&t=1&pg=" + Size + "&ind=" + Index + "&frm=arc";
                if (Convert.ToBoolean(lblisViewed.Text) == true)
                {
                    lnkMsg.Font.Bold = false;
                }
                else
                {
                    lnkMsg.Font.Bold = true;
                    ViewState["CountUnViewedMsg"] = Convert.ToInt32(ViewState["CountUnViewedMsg"]) + 1;
                }
                if (lblIsUrg.Text == "Urgent")
                {
                    lblImg.Visible = true;
                }
                else
                {
                    lblImg.Visible = false;
                }
            }
        }
        catch { }
    }

    protected void btnSearch_Click(object sender, EventArgs e)
    {
        if (ddlSearchCond.SelectedValue == "0")
        {
            subject = txtSearch.Text.Trim();
            //remark = txtSearch.Text.Trim();
            //office = txtSearch.Text.Trim();           
        }
        else if (ddlSearchCond.SelectedValue == "1")
        {
            subject = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "2")
        {
            remark = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "3")
        {
            try
            {
                if (txtSearch2.Text != "")
                {
                    //postDate = DateTime.ParseExact(txtSearch.Text.Trim(), "dd/MM/yyyy", null);
                    postDate = Convert.ToDateTime(txtSearch2.Text);
                }
                if (txtSearch.Text != "")
                {
                    postToDate = Convert.ToDateTime(txtSearch.Text);
                }
            }
            catch { Messagebox1.Show("Invalid Date"); }
        }
        else if (ddlSearchCond.SelectedValue == "4")
        {
            office = txtSearch.Text.Trim();
        }
        else if (ddlSearchCond.SelectedValue == "5")
        {
            isUrgent = true;
        }
        Size = string.IsNullOrEmpty(Request["Size"]) ? 50 : Convert.ToInt32(Request["Size"]);
        Index = string.IsNullOrEmpty(Request["Index"]) ? 1 : Convert.ToInt32(Request["Index"]);
        getReceivedMessages();
    }

    protected void btnMove_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("ID");
        int count = 0;
        string xmlID = String.Empty;
        foreach (GridViewRow gr in grdRecords.Rows)
        {
            Label lblID = (Label)gr.FindControl("lblID");
            CheckBox chkMessage = (CheckBox)gr.FindControl("chkMessage");
            if (chkMessage.Checked == true)
            {
                dt.Rows.Add();
                dt.Rows[count]["ID"] = Convert.ToInt32(lblID.Text);
                count++;
            }
        }
        if (count > 0)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                DataSet ds = new DataSet();
                ds.DataSetName = "Message";
                ds.Tables.Add(dt);
                ds.Tables[0].TableName = "ID";
                xmlID = ds.GetXml();
            }
            bool isArchived = false;
            int retVal = Common.SaveArchieve(xmlID, isArchived);
            if (retVal > 0)
            {
                Messagebox1.Show("Message moved to inbox successfully!");
                getReceivedMessages();
            }
        }
        else
        {
            Messagebox1.Show("Please select the message!");
            return;
        }
    }
}
