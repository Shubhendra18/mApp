﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using AjaxControlToolkit;
public partial class Usercontrol_Messagebox : System.Web.UI.UserControl
{
    //public delegate void AddressEventHandler(object sender, EventArgs e);
    //public event AddressEventHandler Messahe_OK_Click;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //protected void btn_ok_message_Click(object sender, EventArgs e)
    //{
    //    if (Messahe_OK_Click != null)
    //    {
    //        Messahe_OK_Click(this, e);
    //    }
    //}
    public Boolean Show(string Message) 
    {
        lbl_msg.Text = Message;
        ModalPopupExtender2.Show();
        btn_ok_message.Focus();
        return true;
    }
}
