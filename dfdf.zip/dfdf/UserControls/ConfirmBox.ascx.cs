﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;

using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

using AjaxControlToolkit;
public partial class Usercontrol_ConfirmBox : System.Web.UI.UserControl
{
    //Set value for title on title lable.
    public string Title { set { this.lblTitle.Text = value; } }
    //Set value for message on message lable.
    public string Message { set { this.lblMessage.Text = value; } }
    //Set id of target control.
    public string TargetControlId { set { this.popupConfirmBox.TargetControlID = this.btnConfirm.TargetControlID = value; } }
    //set the width for panel
    public int Width { set { this.panelConfirmBox.Width = Unit.Pixel(value); } }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //this.btnPopupClose.OnClientClick = "$find('" + popupConfirmBox.ClientID + "').hide();";
        }
    }
}
