﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_frmAdminLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        //Validate();
        //if (Page.IsValid)
        //{
            if (txtUserName.Text.Length == 0 || txtPassword.Text.Length == 0)
            {
                MessageBox1.Show("Invalid user name/password");
                return;
            }
            DataTable dt = new DataTable();
            dt = UserLogin.checkLogin(txtUserName.Text.Trim(), txtPassword.Text.Trim());
            if (dt.Rows.Count > 0)
            {
                Session["loadJS"] = "1";
                Session["OfficeName"] = txtUserName.Text.Trim();
                Session["UserID"] = Convert.ToString(dt.Rows[0]["userId"]);
                Session["UserType"] = "2";
                //------Login Details( Last Login and Login Expiration)------//
                Session["LASTLOGINON"] = dt.Rows[0]["LastLogin"].ToString();
                Session["LOGINEXPIREDAYS"] = dt.Rows[0]["LoginExpirInDays"].ToString();
                //------------------------//
                UserLogin.updateLastLogin(Convert.ToInt32(dt.Rows[0]["userId"]), DateTime.Now);
                if (dt.Rows[0]["LoginExpired"].ToString() == "true")
                {
                    //pnlChangePwd.Visible = true;
                    //pnlLogin.Visible = false;
                    Session["typ"] = "1";
                    Response.Redirect("~/frmNewLoginChangePassword.aspx");
                    //lblWelHeader.Text = "Welcome: Admin";
                    //lblMsg.Text = "As your password is expired, you are suggested to change your password to proceed further.";
                    //pnlChangePwd_ModalPopupExtender.Show();
                }
                else if (Convert.ToBoolean(dt.Rows[0]["FirstLogin"].ToString()) == false)
                {
                    //pnlChangePwd.Visible = true;
                    //pnlLogin.Visible = true;
                    Session["typ"] = "2";
                    Response.Redirect("~/frmNewLoginChangePassword.aspx");
                    //lblWelHeader.Text = "Welcome: Admin";
                    //lblMsg.Text = "As you have logged in first time, you are suggested to change your password to proceed further.";
                    //pnlChangePwd_ModalPopupExtender.Show();
                }
                else
                {
                    //pnlChangePwd.Visible = false;
                    //pnlLogin.Visible = true;
                    Response.Redirect("~/frmHome.aspx");
                }
            }
            else
            {
                MessageBox1.Show("User name/password not found.");
            }
        //}
    }
    #region save User detail
    protected void btnSave_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt = UserLogin.checkLoginById(UserLogin.loginUserId, txtOldPass.Text.Trim());
        if (dt.Rows.Count > 0)
        {
            Session["LOGINEXPIREDAYS"] = 90;
            UserLogin.changePasswordById(UserLogin.loginUserId, txtNewPassword.Text.Trim());
            Response.Redirect("~/frmHome.aspx");
        }
        else
        {
            pnlChangePwd_ModalPopupExtender.Show();
            MessageBox1.Show("Old password not found");
        }
    }
    #endregion
}
