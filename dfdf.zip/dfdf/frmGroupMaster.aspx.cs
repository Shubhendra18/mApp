﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmGroupMaster : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGrid();
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void fillGrid()
    {
        DataTable dt = new DataTable();
        dt = GroupMaster.getGroup(0, "");
        grdRecord.DataSource = dt;
        grdRecord.DataBind();
        int Rows = grdRecord.Rows.Count;
        if (Rows > 1)
        {
            (grdRecord.Rows[0].FindControl("imgBtnUp")).Visible = false;
            (grdRecord.Rows[Rows - 1].FindControl("imgBtnDown")).Visible = false;
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Validate();
        if (Page.IsValid)
        {
            int transId = 0;
            try
            {
                transId = Convert.ToInt32(hndTransId.Value);
            }
            catch { }
            GroupMaster.SaveUpdateRecord(transId, txtName.Text.Trim());
            if (btnSave.Text == "Update")
            {
                Message1.Show("Record Successfully Updated!");
            }
            else
            {
                Message1.Show("Record Successfully saved!");
            }
            resetForm();
            fillGrid();
        }
    }
    private void resetForm()
    {
        hndTransId.Value = "0";
        txtName.Text = "";
        btnSave.Text = "Save";
    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        Response.Redirect("frmGroupMaster.aspx");
    }
    protected void grdRecord_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "EDI")
        {
            DataTable dt = new DataTable();
            dt = GroupMaster.getGroup(Convert.ToInt32(e.CommandArgument), "");
            if (dt.Rows.Count > 0)
            {
                txtName.Text = Convert.ToString(dt.Rows[0]["groupName"]);
                hndTransId.Value = Convert.ToString(dt.Rows[0]["groupId"]);
                btnSave.Text = "Update";
            }
        }
        if (e.CommandName == "DEL")
        {
            DataTable dt = new DataTable();
            dt = Common.getGroupUsers(Convert.ToInt32(e.CommandArgument));
            if (dt.Rows.Count > 0)
            {
                Message1.Show("Group Cannot delete. It has users.");
                return;
            }
            else
            {
                GroupMaster.deleteRecord(Convert.ToInt32(e.CommandArgument));
                fillGrid();
                Message1.Show("Group Successfully deleted");
            }
        }
        if (e.CommandName == "UP")
        {
            GridViewRow row = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
            Label lblOrderIdForUP = (Label)row.FindControl("lblOrderIdForUP");
            GroupMaster.updateOrder(Convert.ToInt32(e.CommandArgument), Convert.ToInt32(lblOrderIdForUP.Text), "UP");
            fillGrid();
        }
        if (e.CommandName == "Down")
        {
            GridViewRow row = (GridViewRow)(((ImageButton)e.CommandSource).NamingContainer);
            Label lblOrderIdForDown = (Label)row.FindControl("lblOrderIdForDown");
            GroupMaster.updateOrder(Convert.ToInt32(e.CommandArgument), Convert.ToInt32(lblOrderIdForDown.Text), "Down");
            fillGrid();
        }
    }
    protected void grdRecord_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecord.PageIndex = e.NewPageIndex;
        fillGrid();
    }
    
}
