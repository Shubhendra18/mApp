﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmNewLoginChangePassword : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            lblWelHeader.Text = Session["OfficeName"].ToString();
            if (Session["typ"].ToString() == "1")
            {
                lblMsg.Text = "As your password is expired, you are suggested to change your password to proceed further.";
            }
            else
            {
                lblMsg.Text = "As you have logged in first time, you are suggested to change your password to proceed further.";
            }
        }
    }
    #region save User detail
    protected void btnSave_Click(object sender, EventArgs e)
    {
        DataTable dt = new DataTable();
        dt = UserLogin.checkLoginById(UserLogin.loginUserId, txtOldPass.Text.Trim());
        if (dt.Rows.Count > 0)
        {
            Session["LOGINEXPIREDAYS"] = 90;
            UserLogin.changePasswordById(UserLogin.loginUserId, txtNewPassword.Text.Trim());
            Response.Redirect("~/frmHome.aspx");
        }
        else
        {
            MessageBox1.Show("Old password not found");
        }
    }
    protected void btnCancel_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/frmLogin.aspx");
    }
    #endregion
}
