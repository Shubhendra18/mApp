﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class frmManageuserList : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGroup();
            fillGrid();
            String aa = Application["SiteTitle"].ToString();
        }
    }
    //protected void getUnReadMessages()
    //{
    //    DataTable dt = new DataTable();
    //    dt = Common.getUnReadMessages(UserLogin.loginUserId);
    //    if (dt.Rows.Count > 0)
    //    {
    //        lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
    //    }
    //}
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupID";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-All-", "0"));
    }
    protected void fillGrid()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroupUsersForUserList(0);
        ViewState["GroupUsers"] = dt;
        grdRecords.DataSource = dt;
        grdRecords.DataBind();
    }
    protected void fillGridByViewState()
    {
        DataTable dt = (DataTable)ViewState["GroupUsers"];
        if (ddlGroup.SelectedIndex > 0)
        {
            dt.DefaultView.RowFilter = "GroupID=" + ddlGroup.SelectedValue;
        }
        grdRecords.DataSource = dt.DefaultView;
        grdRecords.DataBind();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        grdRecords.EditIndex = -1;
        fillGridByViewState();
        //fillGrid();
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGridByViewState();
        //fillGrid();
    }
    protected void grdRecords_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        grdRecords.EditIndex = -1;
        fillGridByViewState();
        //fillGrid();
    }
    protected void grdRecords_RowEditing(object sender, GridViewEditEventArgs e)
    {
        grdRecords.EditIndex = e.NewEditIndex;
        fillGridByViewState();
        //fillGrid();
    }
    protected void grdRecords_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        Label lblUserID = (Label)grdRecords.Rows[e.RowIndex].FindControl("lblUserID");
        TextBox txtUserName = (TextBox)grdRecords.Rows[e.RowIndex].FindControl("txtUserName");
        TextBox txtMobNo = (TextBox)grdRecords.Rows[e.RowIndex].FindControl("txtMobNo");
        if (txtUserName.Text != "")
        {
            int i = Common.updateUserMaster(Convert.ToInt32(lblUserID.Text), txtUserName.Text.Trim(), txtMobNo.Text.Trim());
            grdRecords.EditIndex = -1;
            if (i > 0)
            {
                DataTable dt = (DataTable)ViewState["GroupUsers"];
                dt.DefaultView.RowFilter = "userId<>" + lblUserID.Text;
                DataTable dt1 = dt.DefaultView.ToTable();
                dt.DefaultView.RowFilter = "userId=" + lblUserID.Text;
                DataTable dt2 = dt.DefaultView.ToTable();
                dt2.Rows[0]["officeName"] = txtUserName.Text.Trim();
                dt2.Rows[0]["mobileNo"] = txtMobNo.Text.Trim();
                dt1.ImportRow(dt2.Rows[0]);
                //DataTable dt = Common.getGroupUsersForUserList(0);
                dt1.DefaultView.Sort = "GroupID ASC, userID ASC";
                ViewState["GroupUsers"] = dt1.DefaultView.ToTable();
                fillGridByViewState();
                //fillGrid();
                Messagebox1.Show("User successfully updated!");
            }
        }
        else
        {
            Messagebox1.Show("Please enter required data!");
        }
    }
    protected void grdRecords_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "ActivateDeactivate")
        {
            int userID = Convert.ToInt32(e.CommandArgument);
            GridViewRow row = (GridViewRow)(((LinkButton)e.CommandSource).NamingContainer);
            int index = row.RowIndex;
            LinkButton lnkActivDeactivUser = (LinkButton)grdRecords.Rows[index].FindControl("lnkActivDeactivUser");
            Label lblUserID = (Label)grdRecords.Rows[index].FindControl("lblUserID");
            DataTable dt = (DataTable)ViewState["GroupUsers"];
            dt.DefaultView.RowFilter = "userId<>" + lblUserID.Text;
            DataTable dt1 = dt.DefaultView.ToTable();
            dt.DefaultView.RowFilter = "userId=" + lblUserID.Text;
            DataTable dt2 = dt.DefaultView.ToTable();
            if (lnkActivDeactivUser.Text.Trim() == "Activate")
            {
                int i = Common.updateActivateDeactivateUserMaster(Convert.ToInt32(lblUserID.Text), "A");
                if (i > 0)
                {
                    //lnkActivDeactivUser.Text = "Deactivate";
                    dt2.Rows[0]["recflag"] = "A";
                    //dt2.Columns["ActivateDeactivate"].DataType = typeof(string);
                    dt2.Columns["ActivateDeactivate"].ReadOnly = false;
                    dt2.Rows[0]["ActivateDeactivate"] = "Deactivate";
                    dt1.ImportRow(dt2.Rows[0]);
                    Messagebox1.Show("User successfully Activated!");
                }
                else
                {
                    //lnkActivDeactivUser.Text = "Activate";
                    dt2.Rows[0]["recflag"] = "D";
                    //dt2.Columns["ActivateDeactivate"].DataType = typeof(string);
                    dt2.Columns["ActivateDeactivate"].ReadOnly = false;
                    dt2.Rows[0]["ActivateDeactivate"] = "Activate";
                    dt1.ImportRow(dt2.Rows[0]);
                    Messagebox1.Show("Error: User not Activated!");
                }
            }
            else
            {
                int i = Common.updateActivateDeactivateUserMaster(Convert.ToInt32(lblUserID.Text), "D");
                if (i > 0)
                {
                    //lnkActivDeactivUser.Text = "Activate";
                    dt2.Rows[0]["recflag"] = "D";
                    //dt2.Columns["ActivateDeactivate"].DataType = typeof(string);
                    dt2.Columns["ActivateDeactivate"].ReadOnly = false;
                    dt2.Rows[0]["ActivateDeactivate"] = "Activate";
                    dt1.ImportRow(dt2.Rows[0]);
                    Messagebox1.Show("User successfully Deactivated!");
                }
                else
                {
                    //lnkActivDeactivUser.Text = "Deactivate";
                    dt2.Rows[0]["recflag"] = "A";
                    //dt2.Columns["ActivateDeactivate"].DataType = typeof(string);
                    dt2.Columns["ActivateDeactivate"].ReadOnly = false;
                    dt2.Rows[0]["ActivateDeactivate"] = "Deactivate";
                    dt1.ImportRow(dt2.Rows[0]);
                    Messagebox1.Show("Error: User not Deactivated!");
                }
            }
            //DataTable dt = Common.getGroupUsersForUserList(0);
            dt1.DefaultView.Sort = "GroupID ASC, userID ASC";
            ViewState["GroupUsers"] = dt1.DefaultView.ToTable();
            fillGridByViewState();
        }
    }
    //protected void grdRecords_RowDataBound(object sender, GridViewRowEventArgs e)
    //{
    //    if (e.Row.RowType == DataControlRowType.DataRow)
    //    {
    //        LinkButton lnkActivDeactivUser = (LinkButton)e.Row.FindControl("lnkActivDeactivUser");
    //        Label lblUserID = (Label)e.Row.FindControl("lblUserID");
    //        if (lblUserID.Text.Trim() == "1")
    //        {
    //            lnkActivDeactivUser.Visible = false;
    //        }
    //    }
    //}
}
