﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.IO;

public partial class ms_admin_frmTheme : System.Web.UI.Page
{    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillGrid();
        }
    }
    protected void fillGrid()
    {
        DataTable dt = new DataTable();
        dt = Common.getAllThemes("");
        grdRecords.DataSource = dt;
        grdRecords.DataBind();
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        fillGrid();
    }
    protected void grdRecords_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Image img = (Image)e.Row.FindControl("imgPreview");
            Label lbl = (Label)e.Row.FindControl("lblStatus");
            LinkButton lnk = (LinkButton)e.Row.FindControl("lnkBtn");
            if (File.Exists(Server.MapPath("~/Themes/" + e.Row.Cells[2].Text.ToLower() + "/preview.jpg")))
            {
                img.ImageUrl = "../Themes/" + e.Row.Cells[2].Text.ToLower() + "/preview.jpg";
            }
            else
            {
                img.ImageUrl = "../Themes/common/nopreview.jpg";
            }
            if (NoticeBoardConfigure.CurrentTheme == e.Row.Cells[2].Text.ToLower())
            {
                lbl.Text = "<strong>Active Theme</strong>";
                lnk.Visible = false;
            }
            else
            {
                lnk.Visible = true ;
            }
        }
    }
    protected void grdRecords_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "SetTheme")
        {
            String theme = e.CommandArgument.ToString().ToLower().Trim();
            if (Directory.Exists(Server.MapPath("~/Themes/" + theme)))
            {
                UserLogin.updateSiteTheme(theme);
                Application["SiteTheme"] = theme;
                Response.Redirect("frmTheme.aspx");
            }
            else
            {
                Messagebox1.Show("Theme not found.");
            }
            
        }
    }
}
