﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ms_admin_index : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            fillRecord();
        }
    }
    protected void fillRecord()
    {
        DataTable dt = new DataTable();
        dt = UserLogin.getSiteConfig();
        if (dt.Rows.Count > 0)
        {
            txtTitle.Text = Convert.ToString(dt.Rows[0]["siteTitle"]);
            txtSubTitle.Text = Convert.ToString(dt.Rows[0]["siteSubTitle"]);
            txtModule.Text = Convert.ToString(dt.Rows[0]["moduleName"]);
            txtbaseUrl.Text = Convert.ToString(dt.Rows[0]["baseUrl"]);
            txtAdminMail.Text = Convert.ToString(dt.Rows[0]["adminMail"]);
            txtKeywords.Text = Convert.ToString(dt.Rows[0]["metaKeyWords"]);
        }
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        Validate();
        if (Page.IsValid)
        {
            String fileName = "";
            if (flAttach.HasFile)
            {
                fileName = flAttach.FileName;
                String ext = System.IO.Path.GetExtension(flAttach.FileName).Trim().ToLower();
                if (ext == ".jpg" || ext == ".png" || ext == ".gif" || ext == ".swf")
                {
                    flAttach.SaveAs(Server.MapPath("~\\uploaded\\" + fileName));
                }
                else
                {
                    Messagebox1.Show("only .jpg, .png, .gif, .swf file ");
                    return;
                }
            }
            UserLogin.updateSiteConfig(txtTitle.Text.Trim(), txtSubTitle.Text.Trim(), txtModule.Text.Trim(), txtbaseUrl.Text.Trim(), txtAdminMail.Text.Trim(), txtKeywords.Text.Trim(), fileName);
            Application["SiteTitle"] = txtTitle.Text.Trim();
            Application["SiteSubTitle"] = txtSubTitle.Text.Trim();
            Application["SiteModule"] = txtModule.Text.Trim();
            Application["AdminMail"] = txtAdminMail.Text.Trim();
            Application["SiteMetaKeyWord"] = txtKeywords.Text.Trim();
            Application["SiteURL"] = txtbaseUrl.Text.Trim();
            Application["SiteLogo"] = fileName.Trim();
            Messagebox1.Show("Configuration updated successfully");
        }
    }
}
