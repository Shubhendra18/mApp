﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class ms_admin_frmLogin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
        }
    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Validate();
        if (Page.IsValid)
        {
            if (txtPassword.Text == "" || txtUser.Text=="")
            {
                MessageBox1.Show("INvalid User name/password.");
            }

        }
    }
}
