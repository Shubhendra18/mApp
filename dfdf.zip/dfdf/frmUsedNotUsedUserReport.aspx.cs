﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;
using System.IO;


public partial class frmUsedNotUsedUserReport : NOTICEBOARD.BaseClass
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //ForReport();
        if (!IsPostBack)
        {
            //getUnReadMessages();
            fillGroup();
            //fillGrid();
            fillGridOnSearch();
            String aa = Application["SiteTitle"].ToString();
        }
    }
    private void ForReport()
    {
        ScriptManager objSM = (ScriptManager)this.Page.Master.FindControl("ScriptManager1");
        if (objSM != null)
        {
            //objSM.RegisterPostBackControl(lblTagLink);
            objSM.RegisterPostBackControl(imgPrint);
        }
    }
    protected void getUnReadMessages()
    {
        DataTable dt = new DataTable();
        dt = Common.getUnReadMessages(UserLogin.loginUserId);
        if (dt.Rows.Count > 0)
        {
            //lblUnViewed.Text = dt.Rows[0]["UnViewedMsg"].ToString();
        }
    }
    protected void fillGroup()
    {
        DataTable dt = new DataTable();
        dt = Common.getGroup(0, "");
        ddlGroup.DataSource = dt;
        ddlGroup.DataTextField = "groupName";
        ddlGroup.DataValueField = "groupID";
        ddlGroup.DataBind();
        ddlGroup.Items.Insert(0, new ListItem("-All-", "0"));
    }
    protected void fillGrid()
    {
        DataTable dt = new DataTable();
        if (rblUsedNotUsed.SelectedIndex == 0)
        {
            dt = Common.getUsedUserListReport(Convert.ToInt32(ddlGroup.SelectedValue));
        }
        else
        {
            dt = Common.getNotUsedUserListReport(Convert.ToInt32(ddlGroup.SelectedValue));
        }
        ViewState["UsedNotUsedReport"] = dt;
        //grdRecords.DataSource = dt;
        //grdRecords.DataBind();
    }
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //fillGrid();
        fillGridOnSearch();
    }
    /////////////////////// Grid Head
    string ghead(DataTable dt1)
    {
        String s1 = "";
        for (int i = 0; i < dt1.Columns.Count; i++)
        {
            s1 = s1 + "<th>";
            s1 = s1 + dt1.Columns[i].ColumnName;
            s1 = s1 + "</th>";
        }
        return s1;
    }
    /////////
    //protected void fillGridOnSearch()
    //{
    //    int pageNo = 0;
    //    DataTable dt = new DataTable();
    //    if (rblUsedNotUsed.SelectedIndex == 0)
    //    {
    //        dt = Common.getUsedUserListReport(Convert.ToInt32(ddlGroup.SelectedValue));
    //    }
    //    else
    //    {
    //        dt = Common.getNotUsedUserListReport(Convert.ToInt32(ddlGroup.SelectedValue));
    //    }
    //    string[] totPageNos = Convert.ToDecimal((dt.Rows.Count) / 38.0M).ToString("0.00").Split('.');
    //    int totPageNo = Convert.ToInt16(totPageNos[0]);
    //    if (Convert.ToInt16(totPageNos[1]) > 0)
    //    {
    //        totPageNo = totPageNo + 1;
    //    }

    //    //ViewState["UsedNotUsedReport"] = dt;
    //    //DataTable dt = (DataTable)ViewState["UsedNotUsedReport"];

    //    //if (ddlGroup.SelectedIndex > 0)
    //    //{
    //    //    dt.DefaultView.RowFilter = "groupID=" + ddlGroup.SelectedValue;
    //    //}
    //    //grdRecords.DataSource = dt.DefaultView;
    //    //grdRecords.DataBind();
    //    string stitle = "";
    //    if (rblUsedNotUsed.SelectedValue == "0")
    //    {
    //        stitle = "User List who have used Message Board";
    //    }
    //    else
    //    {
    //        stitle = "User List who have not used Message Board";
    //    }
    //    string date = "Report As On : " + DateTime.Now.Date.ToString("dd/MM/yyyy");
    //    String s = "";
    //    s = "<table width='100%'><tr><td align='right' width='27%' style='padding-right:10px;'><img src='Themes/common/images/logo.gif' Width='75px' Height='75px'> </td>" +
    //                       "<td valign='middle' align='left' style='font-weight:bold; font-size:22px;'>MANDI PARISHAD MESSAGE BOARD</td></tr>" +
    //                       "<tr><td colspan='2' style='font-weight:bold; font-size:16px; text-align:center;'>&nbsp;&nbsp;&nbsp;" + stitle + " </td> </tr>" +
    //                        "<tr><td> </td><td valign='middle' align='right'>" + date + " </td> </tr></table>";
    //    s = s + "<table width='100%' border=\"1\" bordercolor='gray' align='center' cellpadding=\"0\" cellspacing=\"0\" class=\"gridnew\"><tr>";


    //    for (int i = 0; i < dt.Columns.Count; i++)
    //    {
    //        s = s + "<th>";
    //        s = s + dt.Columns[i].ColumnName;
    //        s = s + "</th>";
    //    }
    //    s = s + "</tr>";
    //    for (int i = 0; i < dt.Rows.Count; i++)
    //    {
    //        s = s + "<tr>";
    //        for (int j = 0; j < dt.Columns.Count; j++)
    //        {
    //            s = s + "<td style='padding-left:5px'>";
    //            if (j == 0)
    //            {
    //                s = s + "<center>" + dt.Rows[i][j].ToString() + "</center>";
    //            }
    //            else if (j == 1)
    //            {
    //                s = s + dt.Rows[i][j].ToString();
    //            }
    //            else if (j == 2)
    //            {
    //                s = s + dt.Rows[i][j].ToString();
    //            }
    //            else
    //            {
    //                if (dt.Rows[i][j].ToString() != "")
    //                {
    //                    s = s + dt.Rows[i][j].ToString();
    //                }
    //                else
    //                {
    //                    s = s + "&nbsp;";
    //                }
    //            }
    //            s = s + "</td>";
    //        }
    //        s = s + "</tr>";
    //        if (i == 37)
    //        {
    //            pageNo++;
    //            s = s + "</table><table align='center' width='100%'><tr><td colspan='3' style='text-align:center;' valign='bottom' width='80%'>Report developed by Mandi Parishad Message Board software</td><td valign='bottom' style='text-align:right;' width='20%'>Page " + pageNo + " of <b>" + totPageNo + "</b></td></tr></table>";
    //            s = s + "<table width='100%'><tr><td align='right' width='27%' style='padding-right:10px;'><img src='Themes/common/images/logo.gif' Width='75px' Height='75px'> </td>" +
    //                       "<td valign='middle' align='left' style='font-weight:bold; font-size:22px;'>MANDI PARISHAD MESSAGE BOARD</td></tr>" +
    //                       "<tr><td colspan='2' style='font-weight:bold; font-size:16px; text-align:center;'>&nbsp;&nbsp;&nbsp;" + stitle + " </td> </tr>" +
    //                        "<tr><td> </td><td valign='middle' align='right'>" + date + " </td> </tr></table>";
    //            s = s + "<div style='page-break-after: always'></div>";
    //            s = s + "<table width='100%' border=\"1\" bordercolor='gray' align='center' cellpadding=\"0\" cellspacing=\"0\" class=\"gridnew\"><tr>";
    //            s = s + ghead(dt);
    //            s = s + "</tr>";
    //        }
    //        else if (i % 37 == 0 && i != 40 && i != 0 && i != dt.Columns.Count - 1)
    //        {
    //            pageNo++;
    //            s = s + "</table><table align='center' width='100%'><tr><td colspan='3' style='text-align:center;' valign='bottom' width='80%'>Report developed by Mandi Parishad Message Board software</td><td style='text-align:right;' valign='bottom' width='20%'>Page " + pageNo + " of <b>" + totPageNo + "</b></td></tr></table>";
    //            s = s + "<table width='100%'><tr><td align='right' width='27%' style='padding-right:10px;'><img src='Themes/common/images/logo.gif' Width='75px' Height='75px'> </td>" +
    //                       "<td valign='middle' align='left' style='font-weight:bold; font-size:22px;'>MANDI PARISHAD MESSAGE BOARD</td></tr>" +
    //                       "<tr><td colspan='2' style='font-weight:bold; font-size:16px; text-align:center;'>&nbsp;&nbsp;&nbsp;" + stitle + " </td> </tr>" +
    //                        "<tr><td> </td><td valign='middle' align='right'>" + date + " </td> </tr></table>";
    //            s = s + "<div style='page-break-after: always'></div>";
    //            s = s + "<table width='100%' border=\"1\" bordercolor='gray' align='center' cellpadding=\"0\" cellspacing=\"0\" class=\"gridnew\"><tr>";
    //            s = s + ghead(dt);
    //            s = s + "</tr>";
    //        }
    //    }
    //    pageNo++;
    //    s = s + "</table><table align='center' width='100%'><tr><td colspan='3' style='text-align:center;' height='60' valign='bottom' width='80%'>Report developed by Mandi Parishad Message Board software</td><td height='60' valign='bottom' style='text-align:right;' width='20%'>Page " + pageNo + " of <b>" + totPageNo + "</b></td></tr></table>";
    //    ViewState["ptable"] = s;
    //}

    protected void fillGridOnSearch()
    {
        int pageNo = 0;
        DataTable dt = new DataTable();
        if (rblUsedNotUsed.SelectedIndex == 0)
        {
            dt = Common.getUsedUserListReport(Convert.ToInt32(ddlGroup.SelectedValue));
        }
        else
        {
            dt = Common.getNotUsedUserListReport(Convert.ToInt32(ddlGroup.SelectedValue));
        }
        string[] totPageNos = Convert.ToDecimal((dt.Rows.Count) / 33.0M).ToString("0.00").Split('.');
        int totPageNo = Convert.ToInt16(totPageNos[0]);
        if (Convert.ToInt16(totPageNos[1]) > 0)
        {
            totPageNo = totPageNo + 1;
        }
        string stitle = "";
        if (rblUsedNotUsed.SelectedValue == "0")
        {
            stitle = "User List who have used Message Board";
        }
        else
        {
            stitle = "User List who have not used Message Board";
        }
        string date = "Report As On : " + DateTime.Now.Date.ToString("dd/MM/yyyy");
        String s = "";
        s = "<table width='100%'><tr><td align='right' width='27%' style='padding-right:10px;'><img src='Themes/common/images/logo.gif' Width='75px' Height='75px'> </td>" +
                           "<td valign='middle' align='left' style='font-weight:bold; font-size:22px;'>MANDI PARISHAD MESSAGE BOARD</td></tr>" +
                           "<tr><td colspan='2' style='font-weight:bold; font-size:16px; text-align:center;'>&nbsp;&nbsp;&nbsp;" + stitle + " </td> </tr>" +
                            "<tr><td> </td><td valign='middle' align='right'>" + date + " </td> </tr></table>";
        s = s + "<table width='100%' border=\"1\" bordercolor='gray' align='center' cellpadding=\"0\" cellspacing=\"0\" class=\"gridnew\"><tr>";


        for (int i = 0; i < dt.Columns.Count; i++)
        {
            s = s + "<th>";
            s = s + dt.Columns[i].ColumnName;
            s = s + "</th>";
        }
        s = s + "</tr>";
        for (int i = 0; i < dt.Rows.Count; i++)
        {
            s = s + "<tr>";
            for (int j = 0; j < dt.Columns.Count; j++)
            {
                s = s + "<td style='padding-left:5px'>";
                if (j == 0)
                {
                    s = s + "<center>" + dt.Rows[i][j].ToString() + "</center>";
                }
                else if (j == 1)
                {
                    s = s + dt.Rows[i][j].ToString();
                }
                else if (j == 2)
                {
                    s = s + dt.Rows[i][j].ToString();
                }
                else
                {
                    if (dt.Rows[i][j].ToString() != "")
                    {
                        s = s + dt.Rows[i][j].ToString();
                    }
                    else
                    {
                        s = s + "&nbsp;";
                    }
                }
                s = s + "</td>";
            }
            s = s + "</tr>";
            //if (i == 37)
            //{
            //    pageNo++;
            //    s = s + "</table><br style='page-break-after: always'><table align='center' width='100%'><tr><td colspan='3' style='text-align:center;' valign='bottom' width='80%'>Report developed by Mandi Parishad Message Board software</td><td valign='bottom' style='text-align:right;' width='20%'>Page " + pageNo + " of <b>" + totPageNo + "</b></td></tr></table>";
            //    s = s + "<table width='100%'><tr><td align='right' width='27%' style='padding-right:10px;'><img src='Themes/common/images/logo.gif' Width='75px' Height='75px'> </td>" +
            //               "<td valign='middle' align='left' style='font-weight:bold; font-size:22px;'>MANDI PARISHAD MESSAGE BOARD</td></tr>" +
            //               "<tr><td colspan='2' style='font-weight:bold; font-size:16px; text-align:center;'>&nbsp;&nbsp;&nbsp;" + stitle + " </td> </tr>" +
            //                "<tr><td> </td><td valign='middle' align='right'>" + date + " </td> </tr></table>";
            //    s = s + "<div style='page-break-after: always'></div>";
            //    s = s + "<table width='100%' border=\"1\" bordercolor='gray' align='center' cellpadding=\"0\" cellspacing=\"0\" class=\"gridnew\"><tr>";
            //    s = s + ghead(dt);
            //    s = s + "</tr>";
            //}
            //else 
            if (i % 33 == 0 && i != 0 && i != dt.Columns.Count - 1)// && i != 40 )
            {
                if (pageNo <= totPageNo)
                {
                    pageNo++;
                    s = s + "</table><br><br><table align='center' width='100%'><tr><td colspan='3'></td></tr><tr><td colspan='3'></td></tr><tr><td colspan='3' style='text-align:center;' valign='bottom' width='80%'>Report developed by Mandi Parishad Message Board software</td><td style='text-align:right;' valign='bottom' width='20%'>Page " + pageNo + " of <b>" + totPageNo + "</b></td></tr></table>";
                    s = s + "<br style='page-break-after: always'><table width='100%'><tr><td align='right' width='27%' style='padding-right:10px;'><img src='Themes/common/images/logo.gif' Width='75px' Height='75px'> </td>" +
                               "<td valign='middle' align='left' style='font-weight:bold; font-size:22px;'>MANDI PARISHAD MESSAGE BOARD</td></tr>" +
                               "<tr><td colspan='2' style='font-weight:bold; font-size:16px; text-align:center;'>&nbsp;&nbsp;&nbsp;" + stitle + " </td> </tr>" +
                                "<tr><td> </td><td valign='middle' align='right'>" + date + " </td> </tr></table>";
                    //   s = s + "<div style='page-break-after: always'></div>";
                    s = s + "<table width='100%' border=\"1\" bordercolor='gray' align='center' cellpadding=\"0\" cellspacing=\"0\" class=\"gridnew\"><tr>";
                    s = s + ghead(dt);
                    s = s + "</tr>";
                }
            }
        }
        pageNo++;
        s = s + "</table><table align='center' width='100%'><tr><td colspan='3' style='text-align:center;' height='60' valign='bottom' width='80%'>Report developed by Mandi Parishad Message Board software</td><td height='60' valign='bottom' style='text-align:right;' width='20%'>Page " + pageNo + " of <b>" + totPageNo + "</b></td></tr></table>";
        ViewState["ptable"] = s;
    }
    protected void grdRecords_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        grdRecords.PageIndex = e.NewPageIndex;
        //fillGridOnSearch();
        fillGrid();
    }
    protected void imgPrint_Click(object sender, EventArgs e)
    {
        ReportDocument rptdoc = new ReportDocument();
        DataTable dt = (DataTable)ViewState["UsedNotUsedReport"];
        rptdoc.Load(Server.MapPath("~/Reports/rptMPMBUsedOrNotUsedUser.rpt"));
        rptdoc.SetDataSource(dt);
        if (rblUsedNotUsed.SelectedValue == "0")
        {
            rptdoc.SetParameterValue(0, "User List who have used Message Board");
        }
        else
        {
            rptdoc.SetParameterValue(0, "User List who have not used Message Board");
        }
        CrystalReportViewer1.ReportSource = rptdoc;
        CrystalReportViewer1.DataBind();
        ExportOptions exportOpts1 = rptdoc.ExportOptions;
        rptdoc.ExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
        rptdoc.ExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
        rptdoc.ExportOptions.DestinationOptions = new DiskFileDestinationOptions();
        ((DiskFileDestinationOptions)rptdoc.ExportOptions.DestinationOptions).DiskFileName = Server.MapPath("~/Reports/rptMPMBUsedOrNotUsedUser.pdf");
        rptdoc.Export();
        rptdoc.Close();
        rptdoc.Dispose();
        Response.ClearContent();
        Response.ClearHeaders();
        Response.ContentType = "application/pdf";
        Response.AppendHeader("Content-Disposition", "attachment; filename=rptMPMBUsedOrNotUsedUser");
        Response.WriteFile("~/Reports/rptMPMBUsedOrNotUsedUser.pdf");
        Response.Flush();
        Response.Close();
        File.Delete(Server.MapPath("~/Reports/rptMPMBUsedOrNotUsedUser.pdf"));
    }
}
