﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;
using UP_TourismBooking.Models;
using System.Globalization;
using System.Data;
using System.IO;
using System.Xml.Linq;
using System.Configuration;
using System.Web.Hosting;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.Text.RegularExpressions;

namespace UP_TourismBooking.Controllers
{
    [AuthorizeARC]
    public class ARCController : Controller
    {       
        #region Declarations

        BusinessClass objBusinessClass = new BusinessClass();
        private Regex pinCode = new Regex(@"^(\d{6})$", RegexOptions.Compiled);
        private Regex mobileNo = new Regex(@"^(\d{10})$", RegexOptions.Compiled);
        private Regex mobileNoOther = new Regex(@"^[0-9 \.\,]+$", RegexOptions.Compiled);

        #endregion
      
        #region Dashboard
        public ActionResult Dashboard()
        {
            return View();
        }
        #endregion

        #region display advance booking
        [HttpGet]
        public ActionResult CustomerRegistration()
        {
            try
            {
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
                ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
                ViewBag.Nationality = GetNationality();
                ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
                ARCCustomerRegistration model = new ARCCustomerRegistration();               
                return View(model);
            }
            catch
            {
                return View("Error");
            }
        }
        #endregion

        #region save advance booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CustomerRegistration(ARCCustomerRegistration model)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _msg = "Enter a valid 6 digit Pincode!";
                        _isValid = false;
                    }                   
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }

                //ModelState["checkInTime"].Errors.Clear();
                ModelState["checkOutTime"].Errors.Clear();
                /*to be uncommented if staff booking is started*/

                //ModelState["staffGrade"].Errors.Clear();
                //ModelState["staffFacility"].Errors.Clear();
                              
                if (model.customerType == 'B')
                {
                    ModelState["roomType"].Errors.Clear();
                    if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                    {
                    }
                    else
                    {
                        _isValid = false;
                        _msg = "Provide Room Details ";                      
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(Convert.ToString(model.roomType)))
                    {
                        _isValid = false;
                        _msg = "Select Room!! ";                       
                    }
                    /*to be uncommented if staff booking is started*/

                    //if (model.customerType == 'S')
                    //{
                    //    model.isStaff = true;
                    //    if (model.staffId == null)
                    //    {
                    //        _isValid = false;
                    //        _msg = "Enter Staff Id!! ";
                    //        ModelState.AddModelError("", "Enter Staff Id!! ");
                    //    }
                    //    else if (model.staffIdDoc == null)
                    //    {
                    //        _isValid = false;
                    //        _msg = "Upload Staff Identity!! ";
                    //        ModelState.AddModelError("", "Upload Staff Identity!! ");
                    //    }
                    //    else if (model.staffGrade == null || model.staffGrade == 0)
                    //    {
                    //        _isValid = false;
                    //        _msg = "Select Staff Grade!! ";
                    //        ModelState.AddModelError("", "Select Staff Grade!! ");
                    //    }
                    //    else if (model.staffFacility == null || model.staffFacility == 0)
                    //    {
                    //        _isValid = false;
                    //        _msg = "Select Staff Tariff!! ";
                    //        ModelState.AddModelError("", "Select Staff Tariff!! ");
                    //    }
                    //}
                }
                if (ModelState.IsValid && _isValid == true)
                {                   
                    string isValid = IsDateValid(model);
                    if (string.IsNullOrEmpty(isValid))
                    {
                        /*to be uncommented if staff booking is started*/

                        //if (model.staffIdDoc != null)
                        //{
                        //    string ext = Path.GetExtension(model.staffIdDoc.FileName);
                        //    string filename = Path.GetFileName(DateTime.Now.Ticks + ext);

                        //    model.staffIdDocPath = Path.Combine("/Content/writereaddata/Documents", filename);
                        //    var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                        //    model.staffIdDoc.SaveAs(docPath);
                        //}
                        //else
                        //{
                        //    model.staffIdDocPath = "";
                        //    model.staffId = "";
                        //    model.staffGrade = 0;
                        //    model.staffFacility = 0;
                        //}

                        #region changes for bulk booking
                        bool _isExtraBedAvail = true, _chkRoomLimit = true, _isDataChecked = true;
                        int _totalExtraBedRequire = 0;
                        if (model.customerType == 'B')
                        {
                            int _extraBedBulk = 0, _singleBulk = 0, _doubleBulk = 0, _totalRooms = 0, _maxCapacity = 0, _maxAllowedGuest = 0, _singleNonOc = 0;
                            foreach (var item in model.lstBookedRoomDetail)
                            {
                                _singleBulk += item.singleRoom;
                                _doubleBulk += item.doubleRoom;                               
                                _extraBedBulk += item.extrabed;
                                _maxCapacity = _maxCapacity + (item.hasOccupancy == false ? (item.maxCapacity) * (item.singleRoom) : 0);
                                _singleNonOc = _singleNonOc + (item.hasOccupancy == false ? (item.singleRoom) : 0);



                                if (item.hasOccupancy)
                                {
                                    if (item.extrabed > (item.doubleRoom * item.maxExtraBed))
                                    {
                                        _isDataChecked = false;
                                        _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";                                       
                                        break;
                                    }
                                    _maxAllowedGuest += ((item.singleRoom + (item.doubleRoom * 2)) + (item.doubleRoom * item.maxExtraBed));
                                }
                                else
                                {
                                    if (item.extrabed > (item.singleRoom * item.maxExtraBed))
                                    {
                                        _isDataChecked = false;
                                        _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";                                      
                                        break;
                                    }
                                    _maxAllowedGuest += ((item.singleRoom * item.maxCapacity) + (item.singleRoom * item.maxExtraBed));
                                }
                            }
                            if (_isDataChecked == true)
                            {
                                _totalRooms = _singleBulk + _doubleBulk;
                                _totalExtraBedRequire = model.noOfGuests - ((_singleBulk - _singleNonOc) + (_doubleBulk * 2) + _maxCapacity);                              

                                #region max capacity for bulk booking
                                if (_totalRooms > model.noOfGuests)
                                {
                                    _chkRoomLimit = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";                                   
                                }
                                else if (model.noOfGuests > _maxAllowedGuest)
                                {
                                    _chkRoomLimit = false;
                                    _msg = "No. of selected rooms is not sufficient!!";                                   
                                }
                                else if (_extraBedBulk < _totalExtraBedRequire)
                                {
                                    _isExtraBedAvail = false;
                                    _msg = "No. of selected rooms is not sufficient!!";                                  
                                }
                                model.noOfRooms = _totalRooms;
                            }
                                #endregion
                        }
                        else
                        {
                            model.noOfRooms = model.singleRoom + model.doubleRoom;
                            if (model.hasOccupancy)
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Single and Double rooms should be less than equal to No. of Guests!";
                                   
                                }
                                else if (model.extrabed > (model.doubleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";                                   
                                }
                                else if (((model.singleRoom + (model.doubleRoom * 2)) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";                                    
                                }
                            }
                            else
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";                                   
                                }
                                else if (model.extrabed > (model.singleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";                                   
                                }
                                else if (((model.singleRoom * model.maxCapacity) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";                                    
                                }
                            }

                            RoomDetail objRoomList = new RoomDetail();
                            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
                            objRoomList.roomType = model.roomType;
                            objRoomList.roomTypeDisplay = model.roomTypeDisplay;
                            objRoomList.singleRoom = model.singleRoom;
                            objRoomList.doubleRoom = model.doubleRoom;
                            objRoomList.hasOccupancy = model.hasOccupancy;
                            objRoomList.Sno = lstBookedRoom.Count + 1;                           
                            objRoomList.extrabed = model.extrabed;
                            lstBookedRoom.Add(objRoomList);
                            model.lstBookedRoomDetail = lstBookedRoom;
                        }
                       
                        int totalDays = model.checkOutDate.Subtract(model.checkInDate).Days;
                        bool _isRoomAvl = true;
                        int _noOfRooms = 0;
                        decimal reqAdvAmt = GetRequiredAdvanceAmount(model);
                        decimal discount = 0;

                        if (model.discountPercentage > 0)
                        {
                            discount = reqAdvAmt - Convert.ToDecimal((model.discountPercentage * reqAdvAmt) / 100);

                            if (model.advanceAmount == null || model.advanceAmount <= 0 || model.advanceAmount != discount)
                            {
                                _isDataChecked = false;
                                _msg = "You are required to pay Rs. " + discount;
                            }
                        }
                        else
                        {
                            if (model.advanceAmount == null || model.advanceAmount <= 0 || model.advanceAmount != reqAdvAmt)
                            {
                                _isDataChecked = false;
                                _msg = "You are required to pay Rs. " + reqAdvAmt;
                            }
                        }

                        //if (model.advanceAmount == null || model.advanceAmount <= 0 || model.advanceAmount != reqAdvAmt)
                        
                        foreach (var item in model.lstBookedRoomDetail)
                        {
                            int _extrabedAdd = 0;
                            RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                            objRoom.roomTypeId = item.roomType;
                            objRoom.unitId = model.unitID;
                            _noOfRooms = item.singleRoom + item.doubleRoom;                           

                            for (int i = 0; i < totalDays; i++)
                            {
                                objRoom.bookingDate = model.checkInDate.AddDays(i);
                                var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                {
                                    _isRoomAvl = false;
                                    _msg = "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                    break;
                                }
                            }
                            if (_isRoomAvl == false)
                            {
                                break;
                            }
                        }

                        var roomXml = new XElement("booking",
                                     from room in model.lstBookedRoomDetail
                                     select new XElement("customer",
                                                    new XElement("Sno", room.Sno),
                                                    new XElement("roomType", room.roomType),
                                                    new XElement("singleRoom", room.singleRoom),
                                                    new XElement("doubleRoom", room.doubleRoom),
                                                    new XElement("extrabed", room.extrabed)
                                                ));
                        model.bookingXML = roomXml.ToString();
                        #endregion

                        if (_isRoomAvl == true && _isDataChecked == true && _isExtraBedAvail == true && _chkRoomLimit == true)
                        {

                            CustomerRegistration objBooking = SetBookingDetails(model, reqAdvAmt);
                           

                            var user = objBusinessClass.InsertCustomerBooking(objBooking);

                            if (user != null)
                            {
                                #region send mail and sms
                                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(user.docketNo);

                                foreach (var lst in IEContactDetails)
                                {
                                    if (lst.sendTo == "CUSTOMER")
                                    {
                                        SendUnitRoomMail(user.docketNo, "CUSTOMER", lst.Email);
                                        SendUnitBookSms(user.docketNo, lst.MobileNo, "CUSTOMER");
                                    }
                                    else if (lst.sendTo == "UNIT")
                                    {
                                        SendUnitRoomMail(user.docketNo, "UNIT", lst.Email);
                                        SendUnitBookSms(user.docketNo, lst.MobileNo, "UNIT");
                                    }
                                }
                                #endregion
                                SessionManager.UnitID = model.unitID;
                                SessionManager.DocketNo = user.docketNo;

                                return RedirectToAction("RegistrationConfirmation");
                            }
                            else
                            {                              
                                _msg = "Room Not Booked!";
                            }
                        }
                    }
                    else
                    {                       
                        _msg = isValid;
                    }
                }
                else
                {                   
                    _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
                }
            }
            catch(Exception ex)
            {
                _msg = ex.Message;
                //_msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
            }
          
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.RoomType = objBusinessClass.GetRoomType(model.unitID).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            //ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
            //ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        #region check room availability
        [HttpGet]
        public ActionResult CheckAvailability(string checkinDate, string checkoutDate, int roomType, int noofGuest, int singleRoom, int doubleRoom, int extraBed, Int16 maxCapacity, bool hasOccupancy, int maxExtraBed, string roomTypeDisplay, char bookingType, Int64 unitID)
        {
            string _msg = "";
            bool _isValid = true;
            ARCCustomerRegistration model = new ARCCustomerRegistration();
            try
            {
                if (string.IsNullOrEmpty(checkinDate))
                {
                    _isValid = false;
                    _msg = "Select Check In Date!!";
                }
                if (string.IsNullOrEmpty(checkoutDate))
                {
                    _isValid = false;
                    _msg = "Select Check Out Date!! ";
                }
                if (roomType != null && roomType == 0)
                {
                    _isValid = false;
                    _msg = "Select Room!! ";
                }
                if (noofGuest != null && noofGuest == 0)
                {
                    _isValid = false;
                    _msg = "Enter No. of Guests!! ";
                }

                if (_isValid)
                {
                    model.checkInDate = DateTime.ParseExact(checkinDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.checkOutDate = DateTime.ParseExact(checkoutDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.singleRoom = singleRoom;
                    model.doubleRoom = doubleRoom;
                    model.roomType = roomType;
                    model.noOfGuests = noofGuest;
                    model.extrabed = extraBed;
                    model.maxCapacity = maxCapacity;
                    model.maxExtraBed = maxExtraBed;
                    model.hasOccupancy = hasOccupancy;
                    model.roomTypeDisplay = roomTypeDisplay;
                    model.unitID = unitID;
                    model.customerType = bookingType;

                    if (_isValid == true)
                    {
                        string isValid = IsDateValid(model);
                        if (string.IsNullOrEmpty(isValid))
                        {                         
                            bool _isDataChecked = true;

                            model.noOfRooms = model.singleRoom + model.doubleRoom;
                            if (model.hasOccupancy)
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Single and Double rooms should be less than equal to No. of Guests!";
                                }
                                else if (model.extrabed > (model.doubleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                                else if (((model.singleRoom + (model.doubleRoom * 2)) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                            }
                            else
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";

                                }
                                else if (model.extrabed > (model.singleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                                else if (((model.singleRoom * model.maxCapacity) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                            }

                            if (_isDataChecked)
                            {
                                RoomDetail objRoomList = new RoomDetail();
                             
                                objRoomList.roomType = roomType;
                                objRoomList.roomTypeDisplay = model.roomTypeDisplay;
                                objRoomList.singleRoom = singleRoom;
                                objRoomList.doubleRoom = doubleRoom;
                                objRoomList.hasOccupancy = hasOccupancy;
                                objRoomList.extrabed = extraBed;
                              
                                int totalDays = model.checkOutDate.Subtract(model.checkInDate).Days;
                                bool _isRoomAvl = true;
                                int _noOfRooms = 0;
                              
                                RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                                objRoom.roomTypeId = objRoomList.roomType;
                                objRoom.unitId = model.unitID;
                                _noOfRooms = objRoomList.singleRoom + objRoomList.doubleRoom;
                                int availableRooms = _noOfRooms;

                                for (int i = 0; i < totalDays; i++)
                                {
                                    objRoom.bookingDate = model.checkInDate.AddDays(i);
                                    var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                    if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                    {
                                        _isRoomAvl = false;
                                        availableRooms = isAvailable.TotalRoom;                                                                       
                                        break;
                                    }
                                }
                              
                                model.availableRooms = availableRooms;
                                //if (bookingType != 'S')
                                //{
                                    if (availableRooms > 0)
                                    {
                                        model.totalAmountPayable = objBusinessClass.GetTotalUnitRoomPrice(model.checkInDate, model.checkOutDate.AddDays(-1), objRoomList);
                                    }
                                //}
                                if (bookingType != 'B')
                                {                                   
                                    return PartialView("_RoomAvailabilityDetails", model);
                                }
                                else
                                {
                                    _msg = availableRooms + " Room(s) Available";
                                    if (availableRooms > 0)
                                    {
                                        _msg += ", Total Amount - " + model.totalAmountPayable;
                                    }
                                    return Content(_msg);
                                }
                            }                           
                        }
                        else
                        {
                            _msg = isValid;
                        }
                    }
                }
            }
            catch
            {

            }
            return Content(_msg);
        } 
        #endregion

        #region get room tariff details
        [HttpGet]
        public ActionResult GetRoomTariffDetails(string checkinDate, string checkoutDate, int roomType)
        {
            string _msg = "";
            bool _isValid = true;
            ARCCustomerRegistration model = new ARCCustomerRegistration();
            try
            {
                if (string.IsNullOrEmpty(checkinDate))
                {
                    _isValid = false;
                    _msg = "Select Check In Date!!";
                }
                if (string.IsNullOrEmpty(checkoutDate))
                {
                    _isValid = false;
                    _msg = "Select Check Out Date!! ";
                }
                if (roomType != null && roomType == 0)
                {
                    _isValid = false;
                    _msg = "Select Room!! ";
                }

                if (_isValid)
                {
                    model.checkInDate = DateTime.ParseExact(checkinDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.checkOutDate = DateTime.ParseExact(checkoutDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.roomType = roomType;
                    model.unitID = SessionManager.UnitID;
                    if (_isValid == true)
                    {
                        string isValid = IsDateValid(model);
                        if (string.IsNullOrEmpty(isValid))
                        {
                            List<RoomTariffDetails> objRoomTariffList = objBusinessClass.GetRoomTariffDetails(Convert.ToInt32(model.roomType), model.checkInDate, model.checkOutDate.AddDays(-1));
                            return PartialView("_RoomTariff", objRoomTariffList);
                        }
                        else
                        {
                            _msg = isValid;
                        }
                    }
                }
            }
            catch
            {

            }
            return Content(_msg);
        }
        
        #endregion

        #region set booking details
        private CustomerRegistration SetBookingDetails(ARCCustomerRegistration model, decimal amount)
        {
            CustomerRegistration obj = new CustomerRegistration();
            try
            {
                obj.userID = model.unitID;
                obj.roleID = "OCST";
                obj.name = model.name;
                obj.address = model.address ?? string.Empty;
                obj.cityID = model.cityID ?? 0;
                obj.otherCity = model.otherCity ?? string.Empty;
                obj.stateID = model.stateID ?? 0;
                obj.otherState = model.otherState ?? string.Empty;
                obj.countryID = model.countryID;
                obj.pincode = model.pincode;
                obj.email = model.email;
                obj.mobileNo = model.mobileNo;
                obj.ID = model.ID ?? string.Empty;
                obj.unitID = model.unitID;
                obj.checkInDate = model.checkInDate;
                obj.noOfGuests = model.noOfGuests;
                obj.userIP = this.Request.UserHostAddress;
                obj.advanceAmount = model.advanceAmount;
                obj.checkOutDate = model.checkOutDate;
                obj.IdentityType = model.IdentityType;
                obj.isStaff = false;
                obj.staffId = string.Empty;
                obj.staffIdDocPath = string.Empty;
                obj.staffGrade = 0;
                obj.staffFacility = 0;
                obj.bookingXML = model.bookingXML;
                obj.bookingFor = "UNIT";
                obj.receiptNo = model.receiptNo;
                obj.applicantType = model.applicantType;
                obj.nameTitle = model.nameTitle ?? 1;
                obj.bookingBy = "ARC";
                obj.dobDate = model.dobDate;
                obj.dobMonth = model.dobMonth;
                obj.dobYear = model.dobYear;
                obj.age = model.age;

                if (model.dateOfBirth != null)
                {
                    var dob = model.dateOfBirth.Split('/');
                    obj.dobDate = Convert.ToInt32(dob[0]);
                    obj.dobMonth = Convert.ToInt32(dob[1]);
                    obj.dobYear = Convert.ToInt32(dob[2]);

                    if (model.age == 0)
                    {
                        DateTime dt = DateTime.ParseExact(model.dateOfBirth, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        DateTime today = DateTime.Today;
                        int age = today.Year - dt.Year;

                    }
                    else
                    {
                        obj.age = model.age;
                    }
                }
                obj.discountAmount = Convert.ToDouble((model.discountPercentage * amount) / 100);
                obj.discountPercent = Convert.ToDouble(model.discountPercentage);
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return obj;
        } 
        #endregion

        #region advance booking confirmation
        [HttpGet]
        public ActionResult RegistrationConfirmation()
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();
                model.unitID = SessionManager.UnitID;
                model.docketNo = SessionManager.DocketNo;

                return View(model);
            }
            catch
            {
                return View("Error");
            }
        }

        #endregion

        #region methods to validate

        public string IsDateValid(ARCCustomerRegistration model)
        {
            string returnMsg = string.Empty;
            DateTime currDate = DateTime.Now.AddDays(-1);
            DateTime maxCheckInDate = currDate.AddDays(178);
            DateTime maxCheckOutDate = currDate.AddDays(179);
            if (model.checkInDate < currDate)
            {
                returnMsg = "Check In Date could not be past date";
            }
            else if (model.checkOutDate < currDate)
            {
                returnMsg = "Check Out Date could not be past date";
            }
            else if (model.checkOutDate < model.checkInDate)
            {
                returnMsg = "Check Out Date should be greater than Check In Date";
            }
            else if (model.checkInDate > maxCheckInDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            else if (model.checkOutDate > maxCheckOutDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            return returnMsg;
        }

        #endregion

        /* ----------------------------Booking List---------------------------------*/

        #region display booking list
        [HttpGet]
        public ActionResult BookedList()
        {
            try
            {               
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            }
            catch
            {
            }
            return View();

        }
        #endregion

        #region binding booking grid
        public ActionResult GetBookedList(string dtBookingFrom, string dtBookingTo, string docket, Int64 UnitId)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket;
                model.unitID = UnitId;
                model.bookedList = objBusinessClass.GetARCBookingList(model);
            }
            catch
            {

            }
            return PartialView("_BookedListGrid", model.bookedList);
        }
        #endregion

        #region export booking list excel
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookedList(UPTourTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetARCBookingList(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Hotel = e.UnitName, Name = e.name, Docket_No = e.docketNo, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Total_Rooms = e.totalRoom, Booking_Status = e.BookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            obj.bookedList = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(obj);
        }
        #endregion

        #region get booking details
        [HttpGet]
        public ActionResult BookingDetail(string docketNo, int UnitId)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            string _msg = "";
            try
            {

                obj_BookingDetail = objBusinessClass.GetUnitBookingDetailsForARC(docketNo);
               
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.BookedRoomList = objBusinessClass.GetBookedRoomDetails(docketNo, UnitId);
                    return PartialView("_BookedDetails", obj_BookingDetail);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }              
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            return Content("0");
        }
        #endregion

        /* ----------------------------End Booking List---------------------------------*/

        /* ----------------------------Vacancy Status---------------------------------*/

        #region display vacancy status
        [HttpGet]
        public ActionResult VacancyStatus()
        {
            ARCVacancyStatus model = new ARCVacancyStatus();
            try
            {
                model.dtBooking = DateTime.Now;
                model.BookingInTime = DateTime.Now;
                model.unitID = SessionManager.UnitID;
                Int64 _unitId = SessionManager.UnitID;
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                model.bookingStatusList = objBusinessClass.GetARCVacancyStatus(model);
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region get vacancy status
        public ActionResult GetVacancyStatus(string dtBooking, Int64 UnitId, DateTime dtBookingTime)
        {
            ARCVacancyStatus model = new ARCVacancyStatus();
            try
            {
                if (dtBookingTime.Hour < 12)
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                }
                else
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.unitID = UnitId;
                model.bookingStatusList = objBusinessClass.GetARCVacancyStatus(model);
            }
            catch
            {

            }
            return PartialView("_VacancyStatusGrid", model.bookingStatusList);
        }
        #endregion

        /* ----------------------------End Vacancy Status---------------------------------*/

        #region payment details..... added by bramh
        [HttpGet]
        public ActionResult PaymentDetails()
        {
            try
            {
                //if (TempData["msg"] != null && TempData["msg"].ToString() != "")
                //{
                //    ViewBag.Show = TempData["message"];
                //}
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                return View();
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpGet]
        public ActionResult PaymentList(string paymentDateFrom, string paymentDateTo, Int64 UnitId, string docketNo)
        {
            string _msg;
            DateTime _payDateFrom, _payDateTo;
            List<PaymentDetails> objPayment = new List<PaymentDetails>();
            try
            {
                try
                {
                    _payDateFrom = DateTime.ParseExact(paymentDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {

                    _payDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    _payDateTo = DateTime.ParseExact(paymentDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                   _payDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                Int64 _unitId = UnitId;
                objPayment = objBusinessClass.GetPaymentDetailsForARC(_payDateFrom, _payDateTo, _unitId, docketNo);               
             }      
            catch
            {
            }
            return PartialView("_PaymentList", objPayment);
        }
        #endregion

        #region Advance Payment List
        [HttpGet]
        public ActionResult AdvancePaymentList(string docketNo, Int64 UnitID)
        {
            string _msg;
            try
            {

                List<PaymentDetails> objPayment = objBusinessClass.GetAdvancePaymentDetails(docketNo, UnitID);
                if (objPayment != null && objPayment.Count > 0)
                {
                    return PartialView("_AdvancePaymentList", objPayment);
                }
                else
                {
                    _msg = "Details Not Found!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }


        #endregion   


        /* ----------------------------ARC Booking Cancellation---------------------------------*/

        #region Display ARC Booking Cancellation List
        [HttpGet]
        public ActionResult BookingCancellation()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};            
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region binding cancellation grid
        public ActionResult GetCancellationList(string docket, int bookingType, Int64? unitId, string fromDate, string toDate)
        {
            ARCBookingCancellation model = new ARCBookingCancellation();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetARCBookingForCancellation(unitId, bookingType, docket, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_BookingCancellationGrid", model.lstCanceRequest);
        }
        #endregion

        #region export cancel list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingCancellation(ARCBookingCancellation model)
        {
            GridView gv = new GridView();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetARCBookingForCancellation(model.unitID, model.bookingType, model.docketNo,_fromDate, _toDate).ToList();

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, Hotel_Name = e.packageName, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/CancellationList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};            
            return View(model);
        }

        #endregion

        #region cancel arc booking
        //[HttpGet]
        //public ActionResult CancellationConfirmation(string id)
        //{
        //    BookingCancellation model = new BookingCancellation();
        //    model = objBusinessClass.CancelARCBooking(id);
        //    return View("CancellationResponse", model);
        //}
        public ActionResult CancelBooking(string docketNo)
        {
            try
            {
                CRSBookingCancellation model = new CRSBookingCancellation();
                string ipAddress = this.Request.UserHostAddress;
                model = objBusinessClass.CancelCRSBooking(docketNo, ipAddress);
                if (model != null && model.cancelRefNo != null && model.cancelRefNo != "")
                {
                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(docketNo);
                    SendCancelRequestSMS(docketNo, IEContactDetails);
                    SendCancelRequestEMail(docketNo, IEContactDetails, model.cancelRefNo, model.cancelConfirmationDate);
                    return Content(model.cancelRefNo); 
                }
            }
            catch
            { }
            return Content("0");
        }
        #endregion

        /* ----------------------------End ARC Booking Cancellation---------------------------------*/
        #region Method - get nationality
        public IEnumerable<SelectListItem> GetNationality()
        {
            var objNationality = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Indian";
            Temp.Value = "1";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Foreigner";
            Temp.Value = "0";
            objNationality.Add(Temp);

            return objNationality;
        }
        #endregion

        #region to calculate total room rent
        private decimal GetRequiredAdvanceAmount(ARCCustomerRegistration model)
        {
            decimal advAmt = 0, totalAmt = 0;
            try
            {
                if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                {
                    foreach (var item in model.lstBookedRoomDetail)
                    {
                        /*to be uncommented if staff booking is started*/
                        //if (model.customerType == 'S')
                        //{
                        //    totalAmt = (item.singleRoom + item.doubleRoom) * model.staffTariff+ (item.extrabed*((model.staffTariff*15)/100));
                        //}
                        //else
                        //{
                            totalAmt += objBusinessClass.GetTotalUnitRoomPrice(model.checkInDate, model.checkOutDate.AddDays(-1), item);
                       // }
                        advAmt = totalAmt;
                    }                    
                }
            }
            catch
            {
                advAmt = 0;
            }
            return advAmt;
        }
        #endregion

        #region Method to  bind staff tariff
        public JsonResult GetStaffTariff(int gradeId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffGrade().Where(a => a.gradeId == gradeId).Select(a => a.facilityId).FirstOrDefault();
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method to  bind staff Room
        public JsonResult GetStaffRoom(int facilityId, Int64 unitId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffRoom(unitId, facilityId).FirstOrDefault().roomTypeId;
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region to get room occupancy details

        [HttpGet]
        public ActionResult GetRoomOccupancy(int roomId, int UnitID)
        {
            CustomerRegistration model = new CustomerRegistration();
            try
            {
                UnitRooms objRoom = objBusinessClass.GetRoomInfo(roomId, UnitID);
                if (objRoom != null)
                {
                    model.maxCapacity = objRoom.maxCapacity;
                    model.hasOccupancy = objRoom.hasOccupancy;
                    model.maxExtraBed = objRoom.maxExtraBed;
                }
            }
            catch
            {

            }
            return PartialView("_RoomOccupancy", model);
        }
        #endregion

        #region to add booked room details

        [HttpGet]
        public ActionResult GetBookedRoom(CustomerRegistration objCustomer)
        {
            //CustomerRegistration model = new CustomerRegistration();
            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
            if (objCustomer != null && objCustomer.lstBookedRoomDetail != null && objCustomer.lstBookedRoomDetail.Count > 0 && objCustomer.lstBookedRoomDetail[0] != null)
            {
                lstBookedRoom = objCustomer.lstBookedRoomDetail;
            }

            RoomDetail objRoom = new RoomDetail();
            objRoom.roomType = objCustomer.roomType;
            objRoom.roomTypeDisplay = objCustomer.roomTypeDisplay;
            objRoom.singleRoom = objCustomer.singleRoom;
            objRoom.doubleRoom = objCustomer.doubleRoom;
            objRoom.extrabed = objCustomer.extrabed;
            objRoom.hasOccupancy = objCustomer.hasOccupancy;
            objRoom.maxCapacity = objCustomer.maxCapacity;
            objRoom.maxExtraBed = objCustomer.maxExtraBed;
            objRoom.Sno = lstBookedRoom.Count + 1;
            lstBookedRoom.Add(objRoom);
            objCustomer.lstBookedRoomDetail = lstBookedRoom;
            return PartialView("_BookedRoom", objCustomer);
        }
        #region to delete booked room

        [HttpGet]
        public ActionResult DeleteBookedRoom(CustomerRegistration objCustomer)
        {
            var itemsToRemove = objCustomer.lstBookedRoomDetail.Where(m => m.Sno == objCustomer.tempRoomId).ToList();
            int? _roomId = itemsToRemove.FirstOrDefault().roomType;
            string _roomName = itemsToRemove.FirstOrDefault().roomTypeDisplay;
            foreach (var itemToRemove in itemsToRemove)
                objCustomer.lstBookedRoomDetail.Remove(itemToRemove);

            ModelState.Clear();

            objCustomer.tempRoomId2 = Convert.ToInt32(_roomId);
            objCustomer.tempRoomIdName = _roomName;
            return PartialView("_BookedRoom", objCustomer);
        }
        #endregion


        #endregion

        #region get vacancy status details
        public ActionResult GetRoomVacancyDetail(string dtBooking, string roomtypeid, string unitId, DateTime dtBookingTime)
        {
            VacancyStatusDetail model = new VacancyStatusDetail();
            try
            {
                model.RoomTypeId = Convert.ToInt64(roomtypeid);
                try
                {
                    if (dtBookingTime.Hour < 12)
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                    }
                    else
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                }
                catch
                {
                    model.BookingDate = DateTime.Now;
                }

                //model.unitID = SessionManager.UnitID;
                model.unitID = Convert.ToInt64(unitId);
                model = objBusinessClass.GetVacancyStatusDetail(model);
            }
            catch
            {

            }
            return PartialView("_RoomVacancy", model);
        }
        #endregion

        #region to send sms on booking cancellation
        protected void SendCancelRequestSMS(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["CancelBookingSMSByCRS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string concernedPersonSms = ConfigurationManager.AppSettings["CancelBookingSMSByCRSForOthers"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                concernedPersonSms = concernedPersonSms.Replace("[DocketNo]", docketNo);
                string SMSStatus = string.Empty;

                try
                {
                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo.ToUpper() == "CUSTOMER" && !(string.IsNullOrEmpty(lst.MobileNo)))
                            {
                                SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);
                                SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
                            }
                            else
                            {
                                SMSStatus = SMS.SMSSend(concernedPersonSms, lst.MobileNo);
                                SMS.SMSLog(concernedPersonSms, lst.MobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send mail on booking cancellation
        protected void SendCancelRequestEMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails, string cancelRefNo, string cancelDate)
        {
            try
            {
                StreamReader reader;
                string subject = "";
                reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/CancelRequest.html"));
                subject = "UP Tourism Booking Cancellation";

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", docketNo);
                MailBody = MailBody.Replace("[cancellationreferenceno]", cancelRefNo);
                MailBody = MailBody.Replace("[cancellationdate]", cancelDate);

                foreach (var lst in contactDetails)
                {
                    try
                    {
                        if (lst.sendTo.ToUpper() == "CUSTOMER" && !(string.IsNullOrEmpty(lst.Email)))
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                        else
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                    }
                    catch { }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        /* ---------------------------Cancellation List---------------------------------*/

        #region Display cancelled booking list
        [HttpGet]
        public ActionResult CancelledBooking()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};            
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding cancelled booking grid
        public ActionResult GetCancelledBookingList(string docketNo, int bookingType, Int64? unitID, string fromDate, string toDate)
        {
            ARCBookingCancellation model = new ARCBookingCancellation();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetARCCancelledBooking(docketNo, bookingType, unitID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_CancelledBookingGrid", model.lstCanceRequest);
        }
        #endregion

        #region export cancelled booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CancelledBooking(ARCBookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetARCCancelledBooking(model.docketNo, model.bookingType, model.unitID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, Hotel_Name = e.packageName, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Cancellation_Ref_No=e.cancelRefNo, Cancellation_Date=e.cancelConfirmationDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/CancelledBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};            

             return View(model);
        }

        #endregion

        /* ---------------------------End Cancellation List---------------------------------*/

        #region to send unit room booking mail
        protected void SendUnitRoomMail(string docketNo, string type, string mailTo)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                StreamReader reader;
                string subject = "";

                if (type == "CUSTOMER")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/UnitRoomBookingConfirmation_Customer.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/UnitRoomBookingConfirmation_Other.html"));
                    subject = "Room Booking Docket No. " + docketNo + " Booked by ARC.";
                }
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[hotelname]", model.unitName);
                MailBody = MailBody.Replace("[hoteladdress]", model.unitAddress);
                MailBody = MailBody.Replace("[hotelphone]", model.unitMobile);
                MailBody = MailBody.Replace("[roomtype]", model.roomType);
                MailBody = MailBody.Replace("[noofrooms]", model.noOfRooms.ToString());
                MailBody = MailBody.Replace("[extrabed]", model.extraBed.ToString());

                MailBody = MailBody.Replace("[checkindate]", model.checkinDate);
                MailBody = MailBody.Replace("[checkoutdate]", model.checkoutDate);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                if (type != "CUSTOMER")
                {
                    MailBody = MailBody.Replace("[bookedby]", model.bookingBy);
                }
               // MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);

                //MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
               // MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "CUSTOMER")
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send unit booking sms
        protected void SendUnitBookSms(string docketNo, string MobileNo, string type)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                var checkInDate = model.checkinDate;
                var roomInfo = model.noOfRooms + " " + model.roomType;
                var unitName = model.unitName;
                string customerName = model.name;

                string customerSms = ConfigurationManager.AppSettings["UnitBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[CustomerName]", customerName);
                customerSms = customerSms.Replace("[noOfRoomsAndType]", roomInfo);
                customerSms = customerSms.Replace("[UnitName]", unitName);
                customerSms = customerSms.Replace("[CheckinDate]", checkInDate);
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string concernPersonSMS = ConfigurationManager.AppSettings["UnitConcernPersonSMS"].ToString() + " Booked by ARC." + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                concernPersonSMS = concernPersonSMS.Replace("[noOfRoomsAndType]", roomInfo);
                concernPersonSMS = concernPersonSMS.Replace("[UnitName]", unitName);
                concernPersonSMS = concernPersonSMS.Replace("[CheckinDate]", checkInDate);
                concernPersonSMS = concernPersonSMS.Replace("[DocketNo]", docketNo);

                //string nodalOfficerSMS = ConfigurationManager.AppSettings["UnitNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[noOfRoomsAndType]", roomInfo);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[UnitName]", unitName);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[CheckinDate]", checkInDate);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[DocketNo]", docketNo);
                if (!(string.IsNullOrEmpty(MobileNo)))
                {
                    if (type == "CUSTOMER")
                    {
                        string SMSStatus = SMS.SMSSend(customerSms, MobileNo);              // Send SMS to Customer
                        SMS.SMSLog(customerSms, MobileNo, docketNo, SMSStatus);
                    }
                    else
                    {
                        string SMSStatus = SMS.SMSSend(concernPersonSMS, MobileNo);              // Send SMS to Customer
                        SMS.SMSLog(concernPersonSMS, MobileNo, docketNo, SMSStatus);
                    }
                }
                 
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        /*------------------------Package Tour Booking----------------------*/

        #region display package tour booking form
        [HttpGet]
        public ActionResult PackageTourBooking()
        {
            try
            {
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                ViewBag.Category = objBusinessClass.GetPackageTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.Nationality = GetNationality();
                ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
                ViewBag.Packages = Enumerable.Empty<SelectListItem>();
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region bind category wise packages
        [HttpGet]
        public JsonResult getPackageTourList(int packageCategoryID)
        {
            IEnumerable<SelectListItem> obj = null;
            try
            {
                obj = objBusinessClass.getPackageTourList(packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            }
            catch
            {
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region book package tour
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageTourBooking(PackageTourBooking model)
        {
            string _msg = "";
            bool isValid = true;
            try
            {
                if (!Convert.ToBoolean(Request.Form["chkConfirm"]))
                {
                    _msg = "Confirm your payment!";
                    isValid = false;
                }
                else
                {
                    DateTime minDate = DateTime.Now;
                    if (model.ArrivalDate < minDate.Date)
                    {
                        _msg = "Arrival Date should not be Past Date!";
                        isValid = false;
                    }
                    else
                    {
                        if (model.countryID == 98)
                        {
                            ModelState["otherState"].Errors.Clear();
                            ModelState["otherCity"].Errors.Clear();

                            if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                            {
                                _msg = "Enter a valid 6 digit Pincode!";
                                isValid = false;
                            }
                            else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                            {
                                _msg = "Enter a valid 10 digit Mobile No.!";
                                isValid = false;
                            }
                        }
                        else
                        {
                            ModelState["stateID"].Errors.Clear();
                            ModelState["cityID"].Errors.Clear();

                            if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                            {
                                _msg = "Enter a valid Mobile No.!";
                                isValid = false;
                            }
                        }
                        if (string.IsNullOrEmpty(model.email))
                        {
                            ModelState["email"].Errors.Clear();
                        }
                        
                        if (ModelState.IsValid && isValid)
                        {

                            model.roleID = "ARC";
                            model.userIP = this.Request.UserHostAddress;
                            model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                            model.currency = "INR";
                            model.description = "";
                            PackageAvailabilityDetails objPack = new PackageAvailabilityDetails();
                            objPack.arrivalDate = model.ArrivalDate;
                            objPack.noOfGuests = model.noOfGuests;
                            objPack.packageID = model.packageID;

                            var isAvailable = objBusinessClass.ChkPackageTourAvailability(objPack);
                            if (isAvailable.isAvailable != null && isAvailable.isAvailable == false)
                            {
                                _msg = "Package Not Available for date- " + objPack.arrivalDate;
                            }
                            else
                            {
                                model.bookingFor = "PACK";
                                model.bookingBy = "ARC";
                                model.receiptNo = "ARC Payment";

                                ModelState.Clear();

                                if (model.countryID == 98)
                                {
                                    model.otherState = "";
                                    model.otherCity = "";
                                }
                                else
                                {
                                    model.stateID = 0;
                                    model.cityID = 0;
                                }

                                var user = objBusinessClass.savePackageTourBookingDetails(model);
                                if (user != null)
                                {
                                    if (user.docketNo == "")
                                    {
                                        _msg = "Your Package Could Not Be Booked Due To Unavailabiity!";
                                    }
                                    else
                                    {
                                        TempData["DocketNo"] = user.docketNo;
                                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                        SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                                        try
                                        {
                                            SendPackageBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName);
                                            SendPackageTourMail(user.docketNo, model.email, IEContactDetails);
                                        }
                                        catch
                                        { }
                                        return RedirectToAction("PakageTourConfirmation");
                                    }
                                }
                                else
                                {
                                    _msg = "Package Tour Not Booked!";
                                }
                            }
                        }
                    }
                }
            }
            catch
            {
                _msg = "Error in Package Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Packages = objBusinessClass.getPackageTourList(model.packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });

            if (model.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }  

            return View(model);
        }
        #endregion

        #region package tour booking confirmation
        public ActionResult PakageTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
                if (model != null)
                {
                    model.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                }
            }
            catch
            {
            }
            return View(model);
        }
        #endregion


        /*------------------------End Package Tour Booking----------------------*/


        /*----------------------Cycle Tour Booking---------------------------*/

        #region Display Cycle Route Booking
        [HttpGet]
        public ActionResult LkoOnCycleBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>();
 
            return View();
        }
        #endregion

        #region save cycle tour booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoOnCycleBooking(LkoOnCycleBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (!Convert.ToBoolean(Request.Form["chkConfirm"]))
                {
                    _msg = "Confirm your payment!";
                    isValid = false;
                }
                else
                {
                     DateTime minDate = DateTime.Now.AddDays(1);
                     if (model.ArrivalDate < minDate.Date)
                     {
                         _msg = "Arrival Date should be greater than Current Date!";
                         isValid = false;
                     }
                     else
                     {
                         if (model.countryID == 98)
                         {
                             ModelState["otherState"].Errors.Clear();
                             ModelState["otherCity"].Errors.Clear();

                             if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                             {
                                 _msg = "Enter a valid 6 digit Pincode!";
                                 isValid = false;
                             }
                             else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                             {
                                 _msg = "Enter a valid 10 digit Mobile No.!";
                                 isValid = false;
                             }
                         }
                         else
                         {
                             ModelState["stateID"].Errors.Clear();
                             ModelState["cityID"].Errors.Clear();

                             if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                             {
                                 _msg = "Enter a valid Mobile No.!";
                                 isValid = false;
                             }
                         }
                         if (string.IsNullOrEmpty(model.email))
                         {
                             ModelState["email"].Errors.Clear();
                         }

                         ModelState["arrivalTime"].Errors.Clear();

                         if (ModelState.IsValid && isValid)
                         {
                             model.roleID = "ARC";
                             model.userIP = this.Request.UserHostAddress;
                             model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                             model.currency = "INR";
                             model.description = "";
                             //model.bookingFor = "CCYCL";
                             model.bookingFor = "CYCLE";
                             model.bookingBy = "ARC";
                             model.receiptNo = "ARC Payment";

                             ModelState.Clear();

                             if (model.countryID == 98)
                             {
                                 model.otherState = "";
                                 model.otherCity = "";
                             }
                             else
                             {
                                 model.stateID = 0;
                                 model.cityID = 0;
                             }

                             var user = objBusinessClass.saveCycleTourBookingByUPTour(model);
                             if (user != null)
                             {
                                 TempData["DocketNo"] = user.docketNo;

                                 IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                 SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                                 try
                                 {
                                     SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Cycle Tour Booking");
                                     SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "CYCLE");
                                 }
                                 catch
                                 { }
                                 return RedirectToAction("CycleTourConfirmation");
                             }
                             else
                             {
                                 _msg = "Cycle Tour Not Booked!";
                             }
                         }
                     }
                }
            }
            catch
            {
                _msg = "Error in Cycle Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>(); 

            if (model.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }

            return View(model);
        }
        #endregion

        #region cycle tour booking confirmation
        public ActionResult CycleTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);               
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End Cycle Tour Booking---------------------------*/

        /*----------------------Tonga Ride Booking---------------------------*/

        #region Display Tonga Ride by UP Tours
        public ActionResult LkoTongaRideBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LTR", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantTypeNew = objBusinessClass.GetCycleApplicantType("LTR").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            LkoTongaRideBooking model = new LkoTongaRideBooking();
            model.noOfGuests = 4;
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>();

            return View(model);
        }
        #endregion

        #region get route fare
        [HttpGet]
        public ActionResult GetTongaRideFare(Int32 packageID, Int32 applicantTypeId)
        {
            return Json(objBusinessClass.GetTongaRideFare(packageID, applicantTypeId), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Save Tonga Ride by UP Tours
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoTongaRideBooking(LkoTongaRideBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (!Convert.ToBoolean(Request.Form["chkConfirm"]))
                {
                    _msg = "Confirm your payment!";
                    isValid = false;
                }
                else
                {
                     DateTime minDate = DateTime.Now.AddDays(1);
                     if (model.ArrivalDate < minDate.Date)
                     {
                         _msg = "Arrival Date should be greater than Current Date!";
                         isValid = false;
                     }
                     else
                     {
                         if (model.countryID == 98)
                         {
                             ModelState["otherState"].Errors.Clear();
                             ModelState["otherCity"].Errors.Clear();

                             if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                             {
                                 _msg = "Enter a valid 6 digit Pincode!";
                                 isValid = false;
                             }
                             else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                             {
                                 _msg = "Enter a valid 10 digit Mobile No.!";
                                 isValid = false;
                             }
                         }
                         else
                         {
                             ModelState["stateID"].Errors.Clear();
                             ModelState["cityID"].Errors.Clear();

                             if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                             {
                                 _msg = "Enter a valid Mobile No.!";
                                 isValid = false;
                             }
                         }
                         if (string.IsNullOrEmpty(model.email))
                         {
                             ModelState["email"].Errors.Clear();
                         }

                         ModelState["arrivalTime"].Errors.Clear();

                         if (ModelState.IsValid && isValid)
                         {
                             model.roleID = "ARC";
                             model.userIP = this.Request.UserHostAddress;
                             model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                             model.currency = "INR";
                             model.description = "";
                             //model.bookingFor = "CTONG";
                             model.bookingFor = "TONGA";
                             model.bookingBy = "ARC";
                             model.receiptNo = "ARC Payment";

                             ModelState.Clear();

                             if (model.countryID == 98)
                             {
                                 model.otherState = "";
                                 model.otherCity = "";
                             }
                             else
                             {
                                 model.stateID = 0;
                                 model.cityID = 0;
                             }

                             var user = objBusinessClass.saveLkoTongaRideBookingByUPTour(model);
                             if (user != null)
                             {
                                 TempData["DocketNo"] = user.docketNo;

                                 IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                 SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                                 try
                                 {
                                     SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Tonga Ride Booking");
                                     SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "TONGA");
                                 }
                                 catch
                                 { }
                                 return RedirectToAction("LkoTongaRideConfirmation");
                             }
                             else
                             {
                                 ModelState.AddModelError("", "Lucknow Tonga Ride Not Bookeed!");
                                 _msg = "Lucknow Tonga Ride Not Booked!";
                             }
                         }
                     }
                }
            }
            catch
            {
                ModelState.AddModelError("", "Error in Lucknow Tonga Ride Booking!");
                _msg = "Error in Lucknow Tonga Ride Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LTR", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantTypeNew = objBusinessClass.GetCycleApplicantType("LTR").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            if (model.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }
            return View(model);
        }
        #endregion

        #region Tonga Ride Booking Confirmation by UP Tours
        public ActionResult LkoTongaRideConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);               
                model = objBusinessClass.GetUPTBookingDetails(docketNo);               
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End Tonga Ride Booking---------------------------*/

        /*----------------------Heritage Walk Booking---------------------------*/

        #region Display Heritage Walk by UPTour
        public ActionResult LkoHeritageWalkBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("HTW", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("HTW").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>();

            return View(); 
        }
        #endregion

        #region Save Heritage Walk Booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoHeritageWalkBooking(LkoHTWBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (!Convert.ToBoolean(Request.Form["chkConfirm"]))
                {
                    _msg = "Confirm your payment!";
                    isValid = false;
                }
                else
                {
                     DateTime minDate = DateTime.Now.AddDays(1);
                     if (model.ArrivalDate < minDate.Date)
                     {
                         _msg = "Arrival Date should be greater than Current Date!";
                         isValid = false;
                     }
                     else
                     {
                         if (model.countryID == 98)
                         {
                             ModelState["otherState"].Errors.Clear();
                             ModelState["otherCity"].Errors.Clear();

                             if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                             {
                                 _msg = "Enter a valid 6 digit Pincode!";
                                 isValid = false;
                             }
                             else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                             {
                                 _msg = "Enter a valid 10 digit Mobile No.!";
                                 isValid = false;
                             }
                         }
                         else
                         {
                             ModelState["stateID"].Errors.Clear();
                             ModelState["cityID"].Errors.Clear();

                             if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                             {
                                 _msg = "Enter a valid Mobile No.!";
                                 isValid = false;
                             }
                         }

                         ModelState["arrivalTime"].Errors.Clear();

                         if (ModelState.IsValid && isValid)
                         {
                             model.roleID = "ARC";
                             model.userIP = this.Request.UserHostAddress;
                             model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                             model.currency = "INR";
                             model.description = "";
                             model.bookingFor = "WALK";
                             model.bookingBy = "ARC";
                             model.receiptNo = "ARC Payment";

                             ModelState.Clear();

                             if (model.countryID == 98)
                             {
                                 model.otherState = "";
                                 model.otherCity = "";
                             }
                             else
                             {
                                 model.stateID = 0;
                                 model.cityID = 0;
                             }

                             var user = objBusinessClass.saveHTWBookingByUPTour(model);
                             if (user != null)
                             {
                                 TempData["DocketNo"] = user.docketNo;

                                 IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                 SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                                 try
                                 {
                                     SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Heritage Walk Booking");
                                     SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "WALK");
                                 }
                                 catch
                                 { }
                                 return RedirectToAction("HeritageWalkConfirmation");
                             }
                             else
                             {
                                 _msg = "Heritage walk Not Booked!";
                             }
                         }
                     }
                }
            }
            catch
            {
                _msg = "Error in Lucknow Heritage walk Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("HTW", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("HTW").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            if (model.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }
            return View(model);
        }
        #endregion

        #region Heritage Walk Booking Confirmation
        public ActionResult HeritageWalkConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);              
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End Heritage Walk Booking---------------------------*/


        /*----------------------One Day Tour Booking---------------------------*/

        #region Display One Day Tour Booking
        public ActionResult OnDayTourBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>();
            ViewBag.Packages = Enumerable.Empty<SelectListItem>();

            return View();
        }
        #endregion 

        #region get city tour list
        [HttpGet]
        public JsonResult getCityTourList(int packageCategoryID)
        {
            IEnumerable<SelectListItem> obj = objBusinessClass.getCityTourList(packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Save One Day Tour Booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnDayTourBooking(OneDayTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (!Convert.ToBoolean(Request.Form["chkConfirm"]))
                {
                    _msg = "Confirm your payment!";
                    isValid = false;
                }
                else
                {
                    DateTime minDate = DateTime.Now;
                    if (model.ArrivalDate < minDate.Date)
                    {
                        _msg = "Arrival Date should not be Past Date!";
                        isValid = false;
                    }
                    else
                    {
                        if (model.countryID == 98)
                        {
                            ModelState["otherState"].Errors.Clear();
                            ModelState["otherCity"].Errors.Clear();

                            if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                            {
                                _msg = "Enter a valid 6 digit Pincode!";
                                isValid = false;
                            }
                            else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                            {
                                _msg = "Enter a valid 10 digit Mobile No.!";
                                isValid = false;
                            }
                        }
                        else
                        {
                            ModelState["stateID"].Errors.Clear();
                            ModelState["cityID"].Errors.Clear();

                            if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                            {
                                _msg = "Enter a valid Mobile No.!";
                                isValid = false;
                            }
                        }

                        if (string.IsNullOrEmpty(model.email))
                        {
                            ModelState["email"].Errors.Clear();
                        }

                        if (ModelState.IsValid && isValid)
                        {

                            model.roleID = "ARC";
                            model.userIP = this.Request.UserHostAddress;
                            model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                            model.currency = "INR";
                            model.description = "";
                            //model.bookingFor = "CCITY";
                            model.bookingFor = "CITY";
                            model.bookingBy = "ARC";
                            model.receiptNo = "ARC Payment";

                            ModelState.Clear();

                            if (model.countryID == 98)
                            {
                                model.otherState = "";
                                model.otherCity = "";
                            }
                            else
                            {
                                model.stateID = 0;
                                model.cityID = 0;
                            }
                            var user = objBusinessClass.saveOneDayTourBookingDetails(model);
                            if (user != null)
                            {
                                if (user.docketNo == "NA")
                                {
                                    _msg = "This One Day Tour is not available on " + model.ArrivalDate.DayOfWeek + "!";
                                }
                                else if (user.docketNo == "NB")
                                {
                                    _msg = "One Day Tour Not Booked!";
                                }
                                else
                                {
                                    TempData["DocketNo"] = user.docketNo;
                                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                    SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(user.docketNo);
                                    try
                                    {
                                        SendOneDayBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "One Day Tour Booking");
                                        SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "CITY");
                                    }
                                    catch
                                    { }
                                    return RedirectToAction("OneDayTourConfirmation");
                                }
                            }
                            else
                            {
                                _msg = "One Day Tour Not Booked!";
                            }
                        }
                    }
                }
            }
            catch
            {
                _msg = "Error in One Day Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Packages = objBusinessClass.getCityTourList(model.packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });

            if (model.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }
            return View(model);
        }
        #endregion

        #region One Day Tour Booking Confirmation
        public ActionResult OneDayTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
                if (model != null)
                {
                    model.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                }
            }
            catch
            {
            }
            return View(model);
        }

        #endregion

        /*----------------------End One Day Tour Booking---------------------------*/


        /*----------------------AC Bus Tour Booking---------------------------*/

        #region AC Bus Tour Booking
        [HttpGet]
        public ActionResult ACBusTourBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.getACBusTourList().Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>();
           
            return View();
        }
        #endregion

        #region Get AC Bus tour total amount
        [HttpGet]
        public ActionResult GetACBusTourTotalAmount(Int32 packageID, Int32 isIndian)
        {
            return Json(objBusinessClass.GetACBusTourTotalAmount(packageID, isIndian), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Save AC Bus tour booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ACBusTourBooking(ACBusTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (!Convert.ToBoolean(Request.Form["chkConfirm"]))
                {
                    _msg = "Confirm your payment!";
                    isValid = false;
                }
                else
                {
                    DateTime minDate = DateTime.Now;
                    if (model.ArrivalDate < minDate.Date)
                    {
                        _msg = "Arrival Date should not be Past Date!";
                        isValid = false;
                    }
                    else
                    {
                        if (model.countryID == 98)
                        {
                            ModelState["otherState"].Errors.Clear();
                            ModelState["otherCity"].Errors.Clear();

                            if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                            {
                                _msg = "Enter a valid 6 digit Pincode!";
                                isValid = false;
                            }
                            else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                            {
                                _msg = "Enter a valid 10 digit Mobile No.!";
                                isValid = false;
                            }
                        }
                        else
                        {
                            ModelState["stateID"].Errors.Clear();
                            ModelState["cityID"].Errors.Clear();

                            if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                            {
                                _msg = "Enter a valid Mobile No.!";
                                isValid = false;
                            }
                        }
                        if (string.IsNullOrEmpty(model.email))
                        {
                            ModelState["email"].Errors.Clear();
                        }

                        if (ModelState.IsValid && isValid)
                        {
                            model.roleID = "ARC";
                            model.userIP = this.Request.UserHostAddress;
                            model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                            model.currency = "INR";
                            model.description = "";
                            //model.bookingFor = "CBUS";
                            model.bookingFor = "ACBUS";
                            model.bookingBy = "ARC";
                            model.receiptNo = "ARC Payment";
                            ModelState.Clear();

                            if (model.countryID == 98)
                            {
                                model.otherState = "";
                                model.otherCity = "";
                            }
                            else
                            {
                                model.stateID = 0;
                                model.cityID = 0;
                            }

                            var user = objBusinessClass.saveACBusTourBookingDetails(model);
                            if (user != null)
                            {
                                if (user.docketNo == "NA")
                                {
                                    _msg = "This AC Bus Tour is not available on " + model.ArrivalDate.DayOfWeek + "!";
                                }
                                else if (user.docketNo == "NB")
                                {
                                    _msg = "AC Bus Tour Not Booked!";
                                }
                                else
                                {
                                    TempData["DocketNo"] = user.docketNo;
                                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                    SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(user.docketNo);
                                    try
                                    {
                                        SendOneDayBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "AC Bus Tour Booking");
                                        SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "ACBUS");
                                    }
                                    catch
                                    { }
                                    return RedirectToAction("ACBusTourConfirmation");
                                }
                            }
                            else
                            {
                                _msg = "AC Bus Tour Not Booked!";
                            }
                        }
                    }
                }
            }
            catch
            {
                _msg = "Error in AC Bus Tour Booking!";
            }

            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.getACBusTourList().Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            if (model.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }
            return View(model);
        }
        #endregion

        #region AC Bus tour booking confirmation
        public ActionResult ACBusTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End AC Bus Tour Booking---------------------------*/

        /*-----------------------Common-------------------------*/

        #region Calculate tour total amount for package and city tours
        [HttpGet]
        public ActionResult GetTourTotalAmount(Int32 packageID, Int32 isIndian, Int32 noOfPersons)
        {
            return Json(objBusinessClass.GetTourTotalAmount(packageID, isIndian, noOfPersons), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Route Fare
        [HttpGet]
        public ActionResult GetSpecialPackegeFare(Int32 packageID, Int32 applicantTypeId)
        {
            return Json(objBusinessClass.GetSpecialPackegeFare(packageID, applicantTypeId), JsonRequestBehavior.AllowGet);
        }
        #endregion

        /*-----------------------End Common-------------------------*/


        /*------------------------Special Package Booking List----------------------*/

        #region Display special package booking list
        [HttpGet]
        public ActionResult SpecialBookedList()
        {
            return View();
        }
        #endregion

        #region bind special package booking grid
        public ActionResult GetSpecialBookedList(string dtBookingFrom, string dtBookingTo, string docket, string bookingType)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket;
                model.type = bookingType.Trim();
                model.bookedList = objBusinessClass.GetSpecialBookingForARC(model);
            }
            catch
            {

            }
            return PartialView("_SpecialBookedListGrid", model.bookedList);
        }
        #endregion

        #region special package details
        [HttpGet]
        public ActionResult SpecialBookingDetail(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            string _msg = "";
            try
            {
                obj_BookingList = objBusinessClass.GetSpecialDetailsForARC(docketNo);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            return PartialView("_SpecialBookedDetails", obj_BookingDetail);
        }
        #endregion

        #region export special booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SpecialBookedList(UPTourTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }

            try
            {
                if (string.IsNullOrEmpty(obj.type.ToString()))
                {
                    obj.type = "";
                }
            }
            catch
            {
                obj.type = "";
            }

            var dtresult = objBusinessClass.GetSpecialBookingForARC(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Docket_No = e.docketNo, Mobile_No = e.mobileNo, Booking_Date = e.checkInDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/SpecialPackagesBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookedList = dtresult;
            return View(obj);
        }

        #endregion

        /*------------------------End Special Package Booking List----------------------*/

        /*------------------------Special Package Payment List----------------------*/
        #region Special booking payment list by Roop Kanwar
        [HttpGet]
        public ActionResult SpecialBookingPaymentList()
        {
            return View();
        }

        public ActionResult GetSpecialBookingPaymentList(string dtBookingFrom, string dtBookingTo, string docket, string bookingType)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket;

                model.type = bookingType.Trim().TrimEnd().TrimStart();
                model.paymentList = objBusinessClass.GetPaymentDetailsDateWiseForSpclForARC(model);
            }
            catch
            {

            }
            return PartialView("_SpecialBookingPaymentListGrid", model.paymentList);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SpecialBookingPaymentList(UPTourTotalBooking model)
        {
            GridView gv = new GridView();
            ModelState.Clear();

            var dtresult = objBusinessClass.GetPaymentDetailsDateWiseForSpclForARC(model).ToList();

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Amount = e.Amount, Mode = e.Mode, Booking_Type = e.bookingType, Guest_Name = e.name, Mobile_No = e.mobileNo }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/SpecialPackagePaymentList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.paymentList = objBusinessClass.GetPaymentDetailsDateWiseForSpclForARC(model);
            return View(model);
        }
        #endregion

        /*------------------------End Special Package Payment List----------------------*/

        #region Generate Receipt
        [HttpGet]
        public ActionResult GenerateCheckoutReceipt(string docketNo)
        {

            CheckOutBillDetails objDetails = new CheckOutBillDetails();
            try
            {
                //string docketNo = SessionManager.DocketNo;              
                decimal totalAmount = 0, discountedAmount = 0, billAmount = 0, luxuryTax = 0, luxuryTaxAmt = 0, ServiceTax = 0, serviceTaxAmt = 0, netAmount = 0, advanceAmount = 0, discount = 0, discountAmount = 0, netpayableAmount = 0, privilegeAmt = 0, privilegeDist = 0;
                var objDetailsList = objBusinessClass.GetCheckOutBillDetailsUPT(docketNo).ToList();
                ViewBag.details = objDetailsList;
                objDetails.discountedAmount = objDetailsList.FirstOrDefault().discountedAmount;
                ServiceTax = objDetailsList.FirstOrDefault().serviceTax;
                serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.discountPer = objDetailsList.FirstOrDefault().discountPer;
                Int64 _unitId = objDetailsList.FirstOrDefault().unitID;
                foreach (var i in objDetailsList)
                {
                    netAmount += i.Amount;
                }
                //netAmount = netAmount + objDetailsList.FirstOrDefault().fAndBAmt + objDetailsList.FirstOrDefault().laundryAmt + objDetailsList.FirstOrDefault().roomServiceAmt + objDetailsList.FirstOrDefault().otherAmt;
                //String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                //if (!String.IsNullOrEmpty(_privilegeDist))
                //    privilegeDist = Convert.ToDecimal(_privilegeDist);
                //else
                //    privilegeDist = 15;

                //if (objDetails.isPrivilegeVerified == true)
                //{
                //    privilegeAmt = (netAmount * privilegeDist) / 100;
                //    netAmount = (netAmount - privilegeAmt);
                //    //objDetails.totalAmount = (objDetails.isPrivilegeVerified == true) ? (objDetails.totalAmount - privilegeAmt) : objDetails.totalAmount;
                //    objDetails.privilegeAmt = privilegeAmt;
                //}
                //discountedAmount = (netAmount - discountAmount);
                //billAmount = discountedAmount;
                //objDetails.billAmount = discountedAmount; 
                objDetails.serviceTax = objDetailsList.FirstOrDefault().serviceTax;
                objDetails.serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                objDetails.luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                objDetails.luxuryTaxDisplay = objDetailsList.FirstOrDefault().luxuryTax.ToString();
                objDetails.luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                // totalAmount = billAmount + serviceTaxAmt + luxuryTaxAmt;

                //if (totalAmount > advanceAmount)
                //{
                //    netpayableAmount = Math.Ceiling(totalAmount - advanceAmount);
                //}
                //else
                //{
                //    netpayableAmount = Math.Ceiling(advanceAmount - totalAmount);
                //}
                objDetails.netpayableAmount = objDetailsList.FirstOrDefault().netpayableAmount;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                //objDetails.totalAmount = totalAmount;
                objDetails.discountAmount = objDetailsList.FirstOrDefault().discountAmount;
                objDetails.netAmount = netAmount;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.AdvRecNo = objDetailsList.FirstOrDefault().AdvRecNo;
                objDetails.arrivalDate = objDetailsList.FirstOrDefault().arrivalDate;
                objDetails.arrivalTime = objDetailsList.FirstOrDefault().arrivalTime;
                objDetails.BillDate = objDetailsList.FirstOrDefault().BillDate;
                objDetails.BillDetail = objDetailsList.FirstOrDefault().BillDetail;
                objDetails.billNo = objDetailsList.FirstOrDefault().billNo;
                objDetails.bookedThrough = objDetailsList.FirstOrDefault().bookedThrough;
                objDetails.CheckoutDate = objDetailsList.FirstOrDefault().CheckoutDate;
                objDetails.CheckoutTime = objDetailsList.FirstOrDefault().CheckoutTime;
                objDetails.guestName = objDetailsList.FirstOrDefault().guestName;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.nationality = objDetailsList.FirstOrDefault().nationality;
                objDetails.docketNo = objDetailsList.FirstOrDefault().docketNo;
                objDetails.roomNo = objDetailsList.FirstOrDefault().roomNo;
                objDetails.unitAddress = objDetailsList.FirstOrDefault().unitAddress;
                objDetails.UnitName = objDetailsList.FirstOrDefault().UnitName;
                objDetails.tinNo = objDetailsList.FirstOrDefault().tinNo;
                objDetails.tanNo = objDetailsList.FirstOrDefault().tanNo;
                objDetails.panNo = objDetailsList.FirstOrDefault().panNo;
                objDetails.serTaxNo = objDetailsList.FirstOrDefault().serTaxNo;
                objDetails.fAndBAmt = objDetailsList.FirstOrDefault().fAndBAmt;
                objDetails.laundryAmt = objDetailsList.FirstOrDefault().laundryAmt;
                objDetails.roomServiceAmt = objDetailsList.FirstOrDefault().roomServiceAmt;
                objDetails.otherAmt = objDetailsList.FirstOrDefault().otherAmt;
                objDetails.totalPayable = objDetailsList.FirstOrDefault().totalPayable;
                objDetails.roundOffValue = objDetailsList.FirstOrDefault().roundOffValue;
                objDetails.spclDiscount = objDetailsList.FirstOrDefault().spclDiscount;
                objDetails.SpclDiscountName = objDetailsList.FirstOrDefault().SpclDiscountName;
                objDetails.isPrivilegeVerified = objDetailsList.FirstOrDefault().isPrivilegeVerified;
                objDetails.privilegeCardNo = objDetailsList.FirstOrDefault().privilegeCardNo;
                objDetails.privilegeCardDate = objDetailsList.FirstOrDefault().privilegeCardDate;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                objDetails.privilegeDist = objDetailsList.FirstOrDefault().privilegeDist;
                objDetails.unitContact = objDetailsList.FirstOrDefault().unitContact;
                String _UnitForTax = System.Configuration.ConfigurationManager.AppSettings["UnitForTax"].ToString();
                //bool _isExtraTax = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? true : false;
                objDetails.luxuryTaxDisplay = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? objDetailsList.FirstOrDefault().luxuryTax.ToString() + " / 10.00" : objDetailsList.FirstOrDefault().luxuryTax.ToString();

            }
            catch
            { }
            return View(objDetails);
        }
        #endregion

        /*---------------------Methods------------------------------------*/

        #region to send package tour booking mail
        protected void SendPackageTourMail(string docketNo, string mailTo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                PackageTransactionDetail model = objBusinessClass.GetPackageBookingDetails(docketNo);
                model.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(model.packageID);

                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/PackageBookingConfirmation_Customer.html"));
                string subjectCust = "UP Tourism Booking Confirmation";

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/PackageBookingConfirmation_Other.html"));
                string subjectOthers = "Booking Docket No. " + docketNo;

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);
                MailBody = MailBody.Replace("[duration]", model.duration);
                MailBody = MailBody.Replace("[noofpersons]", model.noOfTourists);
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);
                MailBody = MailBody.Replace("[meetingpoint]", model.meetingPoint);
                MailBody = MailBody.Replace("[amount]", model.amount.ToString());
                MailBody = MailBody.Replace("[bookingdate]", model.bookingDate);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);

                string accomStr = "";
                if (model.IEPackageAccomodation != null && model.IEPackageAccomodation.Count() > 0)
                {
                    accomStr = "<table>";

                    foreach (var accom in model.IEPackageAccomodation)
                    {
                        accomStr += "<tr><td colspan='2' style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.daySequence + "</td></tr>" +
                                     "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>City Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.cityname + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Unit Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitName + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Address</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitAddress + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Room Type</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.roomType + "</td></tr>";
                    }
                    accomStr += "</table>";
                }

                MailBody = MailBody.Replace("[accomodationdetails]", accomStr);


                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", model.docketNo);
                MailBodyOthers = MailBodyOthers.Replace("[packagename]", model.packageName);
                MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", model.subPackage);
                MailBodyOthers = MailBodyOthers.Replace("[duration]", model.duration);
                MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", model.noOfTourists);
                MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", model.arrivalDate);
                MailBodyOthers = MailBodyOthers.Replace("[meetingpoint]", model.meetingPoint);
                MailBodyOthers = MailBodyOthers.Replace("[amount]", model.amount.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[bookingdate]", model.bookingDate);
                MailBodyOthers = MailBodyOthers.Replace("[bookedby]", model.bookingBy);

                MailBodyOthers = MailBodyOthers.Replace("[customername]", model.name);
                MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", model.customerMobile);
                MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", model.customerAddress);
                MailBodyOthers = MailBodyOthers.Replace("[accomodationdetails]", accomStr);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subjectCust, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subjectCust, MailBody);

                        foreach (var lst in contactDetails)
                        {
                            try
                            {

                                //if (lst.sendTo == "UNIT" || lst.sendTo == "NODAL" || lst.sendTo == "UPTOURS")
                                //{
                                //    MailService.EmailData objMailOthers = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subjectOthers, toemail = lst.Email };
                                //    objService.sendMail(objMailOthers);

                                //}
                                SendMail.SendMailNew(lst.Email, subjectOthers, MailBodyOthers);
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send package tour booking sms
        protected void SendPackageBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["PackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[PackageName]", spclPack.packageName);

                string ConcernPersonSMS = ConfigurationManager.AppSettings["PackageConcernPersonSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                ConcernPersonSMS = ConcernPersonSMS.Replace("[DocketNo]", docketNo);
                ConcernPersonSMS = ConcernPersonSMS.Replace("[PackageName]", spclPack.packageName);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["PackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.packageName);

                string UPTourSMS = ConfigurationManager.AppSettings["PackageUPTourSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.packageName);


                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "UNIT")
                            {
                                SMSStatus = SMS.SMSSend(ConcernPersonSMS, lst.MobileNo);    // Send SMS to Unit
                                SMS.SMSLog(ConcernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch
                        {
                        }
                    }
                }
                catch
                {

                }
            }
            catch
            {

            }
        }
        #endregion

        #region to send one day tour booking sms
        protected void SendOneDayBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack, string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["OneDayBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace(" [PackageName]", spclPack.packageName);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["OneDayNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace(" [PackageName]", spclPack.packageName);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["OneDayUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace(" [PackageName]", spclPack.packageName);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send special package booking mail
        protected void SendSpecialPackageMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails, string mailTo, string bookingType)
        {
            try
            {
                SpecialBookedDetail model = objBusinessClass.GetUPTBookingDetails(docketNo);

                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/SpecialPackBookingConfirmation_Customer.html"));
                string subjectCust = "UP Tourism Booking Confirmation";

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/SpecialPackBookingConfirmation_Other.html"));
                string subjectOthers = "Booking Docket No. " + docketNo;

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);
                MailBody = MailBody.Replace("[noofpersons]", model.noOfPerson.ToString());
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);
                MailBody = MailBody.Replace("[amount]", model.advanceAmount.ToString());
                MailBody = MailBody.Replace("[bookingdate]", model.bookingDate);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);

                string arrivalTime = "";
                if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                {
                    arrivalTime = "<tr>";
                    arrivalTime += "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Arrival Time</td>" +
                             "<td style='font-size: 12px; font-weight: 500; padding: 8px; color: #464646;'>" + model.arrivalTime.ToShortTimeString() + "</td>";
                    arrivalTime += "</tr>";
                }

                MailBody = MailBody.Replace("[arrivaltime]", arrivalTime);

                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", model.docketNo);
                MailBodyOthers = MailBodyOthers.Replace("[packagename]", model.packageName);
                MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", model.subPackage);
                MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", model.noOfPerson.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", model.arrivalDate);
                MailBodyOthers = MailBodyOthers.Replace("[amount]", model.advanceAmount.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[bookingdate]", model.bookingDate);
                MailBodyOthers = MailBodyOthers.Replace("[bookedby]", model.bookingBy);

                MailBodyOthers = MailBodyOthers.Replace("[customername]", model.name);
                MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", model.mobileNo);
                MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", model.customerAddress);

                MailBodyOthers = MailBodyOthers.Replace("[arrivaltime]", arrivalTime);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subjectCust, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subjectCust, MailBody);

                        foreach (var lst in contactDetails)
                        {
                            try
                            {

                                if (lst.sendTo == "NODAL" || lst.sendTo == "UPTOURS")
                                {
                                    //MailService.EmailData objMailOthers = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subjectOthers, toemail = lst.Email };
                                    //objService.sendMail(objMailOthers);
                                    SendMail.SendMailNew(lst.Email, subjectOthers, MailBodyOthers);

                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {

                    }
                }

            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send special tour booking sms
        protected void SendSpecialBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack, string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["SplPackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[PackageName]", spclPack.packageName);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["SplPackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.packageName);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["SplPackageUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.packageName);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion
    }
}
