﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;

namespace UP_TourismBooking.Controllers
{
    //[AuthorizeAdmin]
    public class AdminController : Controller
    {
        #region declarations

        BusinessClass objBusinessClass = new BusinessClass();

        #endregion

        public ActionResult Test()
        {
            return View();
        }

        #region admin dashboard
        public ActionResult Index()
        {
            return View();
        }
        
        #endregion

        #region package category main display
        [HttpGet]
        public ActionResult PackageCategory()
        {
            PackageCategory model = new PackageCategory();
            try
            {
                model.IEPackageCategory = objBusinessClass.GetPackageCategoryList();
                return View(model);
            }
            catch
            {
                return RedirectToAction("Error", "Admin");
            }
        } 
        #endregion

        #region add package category

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddPackageCategory(PackageCategory model)
        {
            try
            {
                int result = objBusinessClass.InsertUpdatePackageCategory(model);

                if (result > 0)
                {
                    ViewBag.Message = (model.PackageCategoryID > 0) ? Message.Update : Message.Add;

                    ModelState.Clear();

                    return PartialView("_PackageCategoryTask", new PackageCategory());
                }
                else
                {
                    ViewBag.Message = (model.PackageCategoryID > 0) ? Message.ErrorUpdate : Message.ErrorAdd;  
                }
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }
            return PartialView("_PackageCategoryTask", model);

        } 

        #endregion

        #region bind package category grid
        [HttpGet]
        public ActionResult BindPackageCategoryGrid()
        {
            PackageCategory model = new PackageCategory();
            try
            {
                model.IEPackageCategory = objBusinessClass.GetPackageCategoryList().ToList();
            }
            catch
            { }
            return PartialView("_PackageCategoryGrid", model.IEPackageCategory);
        } 
        #endregion

        #region edit package category
        public ActionResult EditPackageCategory(int packageCategoryID)
        {
            PackageCategory model = new PackageCategory();
            try
            {
                model = objBusinessClass.GetPackageCategoryDetails(packageCategoryID);
            }
            catch
            { }
            return PartialView("_PackageCategoryTask", model);
        } 
        #endregion

        #region delete package category
        public ActionResult DeletePackageCategory(int packageCategoryID)
        {
            PackageCategory model = new PackageCategory();
            try
            {
                int result = objBusinessClass.DeletePackageCategory(packageCategoryID);
                if (result > 0)
                {
                    ViewBag.Message = Message.Delete;
                }
                else
                {
                    ViewBag.Message = Message.ErrorDelete;
                }
                model.IEPackageCategory = objBusinessClass.GetPackageCategoryList().ToList();

                return PartialView("_PackageCategoryGrid", model.IEPackageCategory);
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }

        }
        
        #endregion

        #region package main display
        [HttpGet]
        public ActionResult Package()
        {
            Package model = new Package();
            try
            {
                ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                model.IEPackage = objBusinessClass.GetPackageList().ToList();

                return View(model);
            }
            catch
            {
                return RedirectToAction("Error", "Admin");
            }
        }
        #endregion

        #region add package 

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult AddPackage(Package model)
        //{
        //    try
        //    {
        //        int result =  0;
        //        Package objPackage = objBusinessClass.InsertPackage(model);
        //        ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });

        //        if (result > 0)
        //        {
        //            ModelState.Clear();

        //            if (model.PackageID > 0)
        //            {
        //                ViewBag.Message = Message.Update;
        //                ModelState.Clear();

        //                return PartialView("_PackageTask", new Package());
        //            }
        //            else
        //            {
        //                Package objPackage = objBusinessClass.InsertPackage(model);
                        
        //                 TempData["Message"] = Message.Add;
        //                 return RedirectToAction("PackageDetails", "Admin", new { Id = model.PackageID });                                           
        //            } 

        //        }
        //        else
        //        {
        //            ViewBag.Message =(model.PackageID > 0) ?  Message.ErrorUpdate : Message.ErrorAdd;

        //            return PartialView("_PackageTask", model);
        //        }   



        //        ////if (model.PackageID > 0)
        //        ////{
        //        ////    int result = objBusinessClass.UpdatePackage(model);
        //        ////    if (result > 0)
        //        ////    {
        //        ////        ViewBag.Message = (model.PackageID > 0) ? Message.Update : Message.Add;

        //        ////        ModelState.Clear();

        //        ////        return PartialView("_PackageTask", new Package());
        //        ////    }
        //        ////    else
        //        ////    {
        //        ////        ViewBag.Message = Message.ErrorUpdate;
        //        ////        ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });

        //        ////        return PartialView("_PackageTask", model);
        //        ////    }                   
        //        ////}
        //        ////else
        //        ////{
        //        ////    ModelState.Clear();
        //        ////    Package objPackage = objBusinessClass.InsertPackage(model);
        //        ////    if (objPackage != null && objPackage.PackageID > 0)
        //        ////    {
        //        ////        TempData["Message"] = Message.Add;

        //        ////        return RedirectToAction("PackageDetails", "Admin", new { Id = model.PackageID });
        //        ////    }
        //        ////    else
        //        ////    {
        //        ////        ViewBag.Message = Message.ErrorAdd;
        //        ////        ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });

        //        ////        return PartialView("_PackageTask", model);
        //        ////    }
        //        ////}             
        //    }
        //    catch
        //    {
        //        return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
        //    }
        //}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddPackage(Package model)
        {
            try
            {
                int result = objBusinessClass.InsertUpdatePackage(model);
                ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });

                if (result > 0)
                {
                    ViewBag.Message = (model.PackageID > 0) ? Message.Update : Message.Add;

                    ModelState.Clear();

                    return PartialView("_PackageTask", new Package());
                }
                else
                {
                    ViewBag.Message = (model.PackageID > 0) ? Message.ErrorUpdate : Message.ErrorAdd;

                    return PartialView("_PackageTask", model);
                }
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }
        }

        #endregion

        #region bind package grid
        [HttpGet]
        public ActionResult BindPackageGrid()
        {
            Package model = new Package();
            try
            {
                model.IEPackage = objBusinessClass.GetPackageList().ToList();
            }
            catch
            { }
            return PartialView("_PackageGrid", model.IEPackage);
        }
        #endregion

        #region edit package 
        public ActionResult EditPackage(int packageID)
        {
            Package model = new Package();
            try
            {
                ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                model = objBusinessClass.GetPackageDetails(packageID);
            }
            catch
            { }
            return PartialView("_PackageTask", model);
        }
        #endregion

        #region delete package 
        public ActionResult DeletePackage(int packageID)
        {
            Package model = new Package();
            try
            {
                int result = objBusinessClass.DeletePackage(packageID);
                if (result > 0)
                {
                    ViewBag.Message = Message.Delete;
                }
                else
                {
                    ViewBag.Message = Message.ErrorDelete;
                }
                model.IEPackage = objBusinessClass.GetPackageList().ToList();

                return PartialView("_PackageGrid", model.IEPackage);
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }

        }

        #endregion

        #region package details 
        [HttpGet]
        public ActionResult PackageDetails(int Id)
        {
            PackageDetails model = new PackageDetails();
            try
            {
                model = objBusinessClass.GetPackageCompleteDetails(Id);
                if (TempData["Message"] != null)
                {
                    ViewBag.Message = TempData["Message"];
                }
                return View(model);
            }
            catch
            {
                return RedirectToAction("Error", "Admin");
            }
        }
        #endregion

        #region package contact 
        [HttpGet]
        public ActionResult Contact(int Id)
        {
            Contact model = new Contact();
            try
            {
                model.PackageID = Id;
                ViewBag.Units = objBusinessClass.GetAllUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

                model.IEContact = objBusinessClass.GetPackageContacts(Id);
                return PartialView("_Contact",model);
            }
            catch
            {
                return RedirectToAction("Error", "Admin");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Contact(Contact model)
        {
            try
            {              
                int result = objBusinessClass.InsertUpdateContact(model);
                ViewBag.Units = objBusinessClass.GetAllUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                
                if (result > 0)
                {
                    ViewBag.Message = (model.ContactID > 0) ? Message.Update : Message.Add;
                     
                    ModelState.Clear();

                    Contact objContact = new Contact();
                    //objContact.IEContact = objBusinessClass.GetPackageContacts(model.PackageID);
                    objContact.PackageID = model.PackageID;

                    return PartialView("_ContactTask", objContact);
                }
                else
                {
                    ViewBag.Message = (model.ContactID > 0) ? Message.ErrorUpdate : Message.ErrorAdd;                            
                }
                return PartialView("_ContactTask", model);
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }
        }

        #endregion

        #region edit contact
        public ActionResult EditContact(int packageID, Int64 contactID)
        {
            Contact model = new Contact();
            try
            {
                ViewBag.Units = objBusinessClass.GetAllUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                model = objBusinessClass.GetPackageContactDetails(packageID, contactID);
            }
            catch
            { }
            return PartialView("_ContactTask", model);
        }
        #endregion

        #region delete contact
        public ActionResult DeleteContact(int packageID, Int64 contactID)
        {
            Contact model = new Contact();
            try
            {
                int result = objBusinessClass.DeleteContact(packageID, contactID);
                if (result > 0)
                {
                    ViewBag.Message = Message.Delete;
                }
                else
                {
                    ViewBag.Message = Message.ErrorDelete;
                }
                model.IEContact = objBusinessClass.GetPackageContacts(packageID).ToList();

                return PartialView("_ContactGrid", model.IEContact);
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }

        }

        #endregion

        #region bind contact grid
        [HttpGet]
        public ActionResult BindContactGrid(int Id)
        {
            Contact model = new Contact();
            try
            {
                model.IEContact = objBusinessClass.GetPackageContacts(Id).ToList();
            }
            catch
            { }
            return PartialView("_ContactGrid", model.IEContact);
        }
        #endregion

        #region terms n condition
        [HttpGet]
        public ActionResult TermsCondition(int Id)
        {
            TermCondition model = new TermCondition();
            try
            {
                var termsCondition = objBusinessClass.GetTermsConditionsDetails(Id);
                if(termsCondition != null)
                {
                    model = termsCondition;
                }
                model.PackageID = Id;

                return PartialView("_TermsCondition", model);
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }
        }
        #endregion

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TermsCondition(TermCondition model)
        {
            try
            {
                int result = objBusinessClass.InsertUpdateTermsCondition(model);
               
                if (result > 0)
                {
                   ViewBag.Message = (model.TermID > 0) ? Message.Update : Message.Add;

                   ModelState.Clear();
                   
                   TermCondition objTerms = new TermCondition();

                   var termsCondition = objBusinessClass.GetTermsConditionsDetails(model.PackageID);
                   if(termsCondition != null)
                   {
                        objTerms = termsCondition;
                   }
                  objTerms.PackageID = model.PackageID;
                
                return PartialView("_TermsCondition", objTerms);
                }
                else
                {
                    ViewBag.Message = (model.TermID > 0) ? Message.ErrorUpdate : Message.ErrorAdd;
                }
                return PartialView("_TermsCondition", model);
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }
        }


        #region overview
        [HttpGet]
        public ActionResult Overview(int Id)
        {
            Overview model = new Overview();
            try
            {
                //var termsCondition = objBusinessClass.GetTermsConditionsDetails(Id);
                //if (termsCondition != null)
                //{
                //    model = termsCondition;
                //}
                //model.PackageID = Id;
                ViewBag.Destinations = objBusinessClass.GetDestinations().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });

                return PartialView("_Overview", model);
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }
        }
        #endregion


        #region Error
        public ActionResult Error()
        {
            return View();
        } 
        #endregion
    }
}
