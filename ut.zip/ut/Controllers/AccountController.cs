﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;
using OTPL_Imp;
using UP_TourismBooking.Models;
using System.Web.Hosting;
using System.Web.Security;
using System.Text;
using System.IO;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Globalization;


namespace UP_TourismBooking.Controllers
{
    public class AccountController : Controller
    {
        #region declarations

        BusinessClass objBusinessClass = new BusinessClass();
        private Regex pinCode = new Regex(@"^(\d{6})$", RegexOptions.Compiled);
        private Regex mobileNo = new Regex(@"^(\d{10})$", RegexOptions.Compiled);
        #endregion

        //#region login
        //[HttpGet]
        //public ActionResult Login()
        //{
        //    try
        //    {
        //        var res = FormsAuthentication.HashPasswordForStoringInConfigFile("$arcsecureKK123", "MD5");

        //        ModelState.Clear();
        //        SessionManager.RemoveSession();

        //        Random rd = new Random();
        //        string seed = rd.Next(100000, 999999).ToString();
        //        SessionManager.SeedValue = seed;

        //        Login model = new Login();
        //        model.seed = seed;

        //        return View(model);
        //    }
        //    catch
        //    {
        //        return RedirectToAction("Login", "Account");
        //    }
        //}

        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Login(Login model)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            string oldseed = model.seed.ToString();
        //            Random rd = new Random();
        //            string seed = rd.Next(100000, 999999).ToString();
        //            SessionManager.SeedValue = seed;
        //            model.seed = seed;

        //            string encUserLoginID = OTPL_Imp.CustomCryptography.Encrypt(model.UserLoginID);
        //            var user = objBusinessClass.VerifyLogin(encUserLoginID);

        //            if (user != null)
        //            {
        //                if (model.Password.ToString().ToUpper().Trim() == FormsAuthentication.HashPasswordForStoringInConfigFile(user.Password.ToUpper() + oldseed.ToUpper(), "MD5").ToUpper().Trim())
        //                {
        //                    //FormsAuthentication.SetAuthCookie(model.UserLoginID.ToString(), false);
        //                    SessionManager.UserID = user.UserID;
        //                    SessionManager.RoleID = user.RoleID;

        //                    if (user.RoleID == "ADM")
        //                    {
        //                        return RedirectToAction("Index", "Admin");
        //                    }
        //                }
        //            }
        //            else
        //            {
        //                ViewBag.ErrorMessage = "Incorrect user name or password!";
        //            }
        //        }
        //        return View(model);
        //    }
        //    catch
        //    {
        //        return RedirectToAction("Login", "Account");
        //    }
        //}
        //#endregion

        #region logout
        [HttpGet]
        public ActionResult Logout()
        {
            try
            {
                ModelState.Clear();
                SessionManager.RemoveSession();

                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(20);
                }
                if (Request.Cookies["AuthToken"] != null)
                {
                    Response.Cookies["AuthToken"].Value = string.Empty;
                    Response.Cookies["AuthToken"].Expires = DateTime.Now.AddMonths(-20);
                }

                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
                Response.Cache.SetNoStore();
                Response.Cookies.Clear();
                Response.Cache.SetMaxAge(new TimeSpan(0, 0, 30));

                return View();
            }
            catch
            {
                return View("Error");
            }
        }
        #endregion

        //#region error
        //public ActionResult Error()
        //{
        //    return View();
        //}
        //#endregion

        #region online customer registration
        public ActionResult Registration()
        {
            try
            {
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });

                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();
                SessionManager.SeedValue = seed;

                Registration model = new Registration();
                model.seed = seed;

                return PartialView("_Registration", model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterCustomer(Registration model)
        {
            try
            {
                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!pinCode.IsMatch(model.pincode))
                        {
                            return Json(new { result = false, message = "Enter a valid 6 digit Pincode!" }, JsonRequestBehavior.AllowGet);
                        }
                        else if (!mobileNo.IsMatch(model.mobileNo))
                        {
                            return Json(new { result = false, message = "Enter a valid 10 digit Mobile No.!" }, JsonRequestBehavior.AllowGet);
                        }

                        model.otherState = "";
                        model.otherCity = "";
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();

                        model.stateID = 0;
                        model.cityID = 0;
                    }

                    ModelState["password"].Errors.Clear();

                    if (ModelState.IsValid)
                    {
                        model.roleID = "CST";
                        var user = objBusinessClass.InsertUser(model);

                        if (user != null)
                        {
                            SessionManager.UserID = user.userID;
                            SessionManager.Username = user.email;
                            SessionManager.DisplayName = user.name;
                            SessionManager.CustomerMobile = user.mobileNo;
                            SessionManager.RoleID = model.roleID;

                            if (Session["bookingType"] != null)
                            {

                                if (Session["bookingType"].ToString() == "PACK")
                                {
                                    return Json(new { result = true, url = Url.Action("PackageTourPayment", "UPTourism") });
                                }
                                else if (Session["bookingType"].ToString() == "UNIT")
                                {
                                    return Json(new { result = true, url = Url.Action("UnitPayment", "UPTourism") });
                                }
                                else if (Session["bookingType"].ToString() == "CITY")
                                {
                                    return Json(new { result = true, url = Url.Action("CityTourPayment", "UPTourism") });
                                }
                                else if (Session["bookingType"].ToString() == "ACBUS")
                                {
                                    return Json(new { result = true, url = Url.Action("ACBusTourPayment", "UPTourism") });
                                }
                                else if (Session["bookingType"].ToString() == "CYCLE")
                                {
                                    return Json(new { result = true, url = Url.Action("CycleTourPayment", "UPTourism") });
                                }
                                else if (Session["bookingType"].ToString() == "TONGA")
                                {
                                    return Json(new { result = true, url = Url.Action("TongaRidePayment", "UPTourism") });
                                }
                                else if (Session["bookingType"].ToString() == "WALK")
                                {
                                    return Json(new { result = true, url = Url.Action("HeritageWalkPayment", "UPTourism") });
                                }
                                else if (Session["bookingType"].ToString() == "BUS" || Session["bookingType"].ToString() == "TAXI")
                                {
                                    return Json(new { result = true, url = Url.Action("TaxiBusPayment", "UPTourism") });
                                }
                            }
                            else
                            {
                                if (model.registerFrom == "FL")
                                {
                                    return Json(new { result = true, url = "" });
                                }
                                else
                                {
                                    return Json(new { result = true, url = Url.Action("BookingHistory", "UPTourism") });
                                }
                            }
                        }
                    }
                }
                else
                {
                    return Json(new { result = false, message = "Captcha Text did not Match!" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            { }
            return Json(new { result = false, message = "Error in registration!" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region customer login
        public ActionResult UserLogin()
        {
            try
            {
                ModelState.Clear();

                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();
                SessionManager.SeedValue = seed;

                UserLogin model = new UserLogin();
                model.seed = seed;

                return PartialView("_UserLogin", model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ValidateUserLogin(UserLogin model)
        {
            try
            {
                 if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (ModelState.IsValid)
                    {
                        string oldseed = model.seed.ToString();
                        Random rd = new Random();
                        string seed = rd.Next(100000, 999999).ToString();
                        SessionManager.SeedValue = seed;
                        model.seed = seed;

                        var user = objBusinessClass.VerifyUserLogin(model.email);

                        if (user != null)
                        {
                            if (model.password.ToString().ToUpper().Trim() == FormsAuthentication.HashPasswordForStoringInConfigFile(user.password.ToUpper() + oldseed, "MD5").ToUpper().Trim())
                            {

                                //
                                bool isAllow = false;

                                var attemptDetails = objBusinessClass.GetAttemptDetails(model.email, "Invalid Username/Password");
                                if (attemptDetails != null)
                                {
                                    DateTime _wrongAttemptDate = Convert.ToDateTime(attemptDetails.attemptTime);
                                    DateTime _currentDate = DateTime.Now;

                                    double _diff = (_currentDate).Subtract(_wrongAttemptDate).TotalMinutes;
                                    if (_diff < 1440 && user.wrongAttemptsCount > 9)
                                    {
                                        isAllow = false;
                                    }
                                    else
                                    {
                                        isAllow = true;
                                    }
                                }
                                else
                                {
                                    isAllow = true;
                                }

                                if (isAllow)
                                {
                                    //
                                    objBusinessClass.ResetLoginAttempts(model.email);

                                    //FormsAuthentication.SetAuthCookie(model.UserLoginID.ToString(), false);
                                    SessionManager.UserID = user.userID;
                                    SessionManager.RoleID = user.roleID;
                                    SessionManager.Username = user.email;
                                    SessionManager.DisplayName = user.name;
                                    SessionManager.CustomerMobile = user.mobileNo;
                                    string guid = Guid.NewGuid().ToString();
                                    //set Auth Cookies
                                    Session["AuthToken"] = guid;
                                    Response.Cookies.Add(new HttpCookie("AuthToken", guid));

                                    //return Json(new { result = true, url = Url.Action("PackageTourPayment", "UPTourism") });

                                    if (Session["bookingType"] != null)
                                    {
                                        if (Session["bookingType"].ToString() == "PACK")
                                        {
                                            return Json(new { result = true, url = Url.Action("PackageTourPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "UNIT")
                                        {
                                            return Json(new { result = true, url = Url.Action("UnitPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "CITY")
                                        {
                                            return Json(new { result = true, url = Url.Action("CityTourPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "ACBUS")
                                        {
                                            return Json(new { result = true, url = Url.Action("ACBusTourPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "CYCLE")
                                        {
                                            return Json(new { result = true, url = Url.Action("CycleTourPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "TONGA")
                                        {
                                            return Json(new { result = true, url = Url.Action("TongaRidePayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "WALK")
                                        {
                                            return Json(new { result = true, url = Url.Action("HeritageWalkPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "BUS" || Session["bookingType"].ToString() == "TAXI")
                                        {
                                            return Json(new { result = true, url = Url.Action("TaxiBusPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "bustaxi")
                                        {
                                            return Json(new { result = true, url = Url.Action("BusTaxiPayment", "UPTourism") });
                                        }
                                        else if (Session["bookingType"].ToString() == "LAWN" || Session["bookingType"].ToString() == "BANQUET")
                                        {
                                            return Json(new { result = true, url = Url.Action("LawnBanqPayment", "UPTourism") });
                                        }
                                    }
                                    else
                                    {
                                        if (model.loginFrom == "FL")
                                        {
                                            return Json(new { result = true, url = "" });
                                        }
                                        else
                                        {
                                            return Json(new { result = true, url = Url.Action("BookingHistory", "UPTourism") });
                                        }
                                    }
                                }
                                else
                                {
                                    objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "This account is locked because of wrong password attempt.", 0);
                                    return Json(new { result = false, message = "This account is locked because of wrong password attempts!" }, JsonRequestBehavior.AllowGet);
                                }
                            }
                            else
                            {
                                objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                                return Json(new { result = false, message = "Incorrect username or password!" }, JsonRequestBehavior.AllowGet);
                            }
                        }
                        else
                        {
                            objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                            return Json(new { result = false, message = "Incorrect username or password!" }, JsonRequestBehavior.AllowGet);
                        }
                    }
                    return Json(new { result = false, message = "Incorrect username or password!" }, JsonRequestBehavior.AllowGet);
                }
                else
                {
                    return Json(new { result = false, message = "Captcha Text did not Match!" }, JsonRequestBehavior.AllowGet);

                }
            }
            catch
            {
                return Json(new { result = false, message = "Error in process!" }, JsonRequestBehavior.AllowGet);
            }

        }
        #endregion

        #region display user forgot password
        public ActionResult UserForgotPassword()
        {

            //   return View();
            return PartialView("_UserForgotPassword");

        }
        #endregion

        #region send user forgot password
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SendUserForgotPassword(UserForgetPassword model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var user = objBusinessClass.GetUserDetails(model.email);

                    if (user != null)
                    {
                        Random rd = new Random();
                        string password = rd.Next(100000, 999999).ToString();
                        user.password = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "MD5");
                        int result = objBusinessClass.UpdateCustomerPassword(user);

                        if (result > 0)
                        {
                            try
                            {
                                SendForgotPasswordSMS(password, user.mobileNo);
                            }
                            catch
                            {
                                //ViewBag.SuccessMessage = "Password has been updated. Unable to send sms!";
                                //return View(model);
                                return Json(new { result = true, message = "Password has been updated. Unable to send sms!" }, JsonRequestBehavior.AllowGet);

                            }
                            try
                            {
                                SendForgotPasswordEmail(password, user.email, user.name);
                            }
                            catch
                            {
                                //ViewBag.SuccessMessage = "Password has been updated. Unable to send email!";
                                //return View(model);
                                return Json(new { result = true, message = "Password has been updated. Unable to send email!" }, JsonRequestBehavior.AllowGet);

                            }

                            return Json(new { result = true, message = "Password has been sent to your registered mobile no. and email id!" }, JsonRequestBehavior.AllowGet);
                            //ViewBag.SuccessMessage = "Password has been sent to your registered mobile no. and email id!";
                            //return View(model);
                        }
                        else
                        {
                            //ViewBag.ErrorMessage = "Unable to generate password!";
                            return Json(new { result = false, message = "Unable to generate password!" }, JsonRequestBehavior.AllowGet);
                        }
                    }
                    else
                    {
                        //ViewBag.ErrorMessage = "This email id is not registered with us!";
                        return Json(new { result = false, message = "This email id is not registered with us!" }, JsonRequestBehavior.AllowGet);
                    }
                }
                else
                {
                    return Json(new { result = false, message = "Enter valid email id!" }, JsonRequestBehavior.AllowGet);
                }
            }
            catch
            {
                // ViewBag.ErrorMessage = "Error in process!";
                return Json(new { result = false, message = "Error in process!" }, JsonRequestBehavior.AllowGet);
            }
        }

        #endregion

        #region display change password
        [HttpGet]
        [AuthorizeUnit]
        public ActionResult UserChangePassword()
        {
            UserChangePassword model = new UserChangePassword();
            try
            {
                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();

                model.seedChangePassword = seed;
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region save changed password
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthorizeUnit]
        public ActionResult UserChangePassword(UserChangePassword model)
        {
            try
            {
                if (ModelState.ContainsKey("newPassword"))
                    ModelState["newPassword"].Errors.Clear();

                if (ModelState.IsValid)
                {
                    string oldseed = model.seedChangePassword.ToString();
                    Random rd = new Random();
                    string newSeed = rd.Next(100000, 999999).ToString();
                    model.seedChangePassword = newSeed;
                    model.email = SessionManager.Username;
                    model.userId = SessionManager.UserID;

                    var user = objBusinessClass.VerifyUnitLogin(model.email);

                    var encPassword = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(user.password.ToUpper() + oldseed, "MD5").ToUpper().Trim();

                    if (encPassword == model.oldPassword.ToUpper().Trim())
                    {
                        if (model.newPassword.ToUpper().Trim() == user.password.ToUpper().Trim())
                        {
                            ViewBag.ErrorMessage = "Old password and new password must not be same!";
                        }
                        else
                        {
                            if (user != null)
                            {
                                if (model.newPassword == model.confirmPassword)
                                {
                                    int result = objBusinessClass.ChangeUserPassword(model);

                                    if (result > 0)
                                    {
                                        var changeDate = objBusinessClass.GetChangePasswordDate(model).passwordChangedOn;
                                        try
                                        {
                                            SendChangePasswordSMS(changeDate, user.mobileNo);
                                        }
                                        catch
                                        {
                                        }
                                        try
                                        {
                                            //SendChangePasswordEmail(changeDate, user.email, user.name,model.email);
                                        }
                                        catch
                                        {
                                        }
                                        return RedirectToAction("ChangePasswordConfirmUnit", "Account");

                                    }
                                    else
                                    {
                                        ViewBag.ErrorMessage = "Password not changed!";
                                    }
                                }
                                else
                                {
                                    ViewBag.ErrorMessage = "Password and confirm password do not match!";
                                }
                            }
                            else
                            {
                                ViewBag.ErrorMessage = "Incorrect old password!";
                            }
                        }
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "Incorrect old password!";
                    }
                }
            }
            catch { }

            return View(model);
        }

        [HttpGet]
        public ActionResult ConfirmChange()
        {
            ModelState.Clear();
            SessionManager.RemoveSession();
            ViewBag.SuccessMessage = "Password changed successfully. Login again to continue!";

            return View();
        }
        #endregion

        #region user change password confirmation
        public ActionResult UserChangePasswordConfirm()
        {
            return View();
        }
        #endregion

        #region unit login
        [HttpGet]
        public ActionResult UnitLogin()
        {
            try
            {
                ModelState.Clear();
                Session.Abandon();
                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();
                SessionManager.SeedValue = seed;

                UnitLogin model = new UnitLogin();
                model.seed = seed;

                return View(model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UnitLogin(UnitLogin model)
        {
            try
            {
                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (ModelState.IsValid)
                    {
                        string oldseed = model.seed.ToString();
                        Random rd = new Random();
                        string seed = rd.Next(100000, 999999).ToString();
                        SessionManager.SeedValue = seed;
                        model.seed = seed;

                        var user = objBusinessClass.VerifyUnitLogin(model.email);

                        if (user != null)
                        {
                            if (model.password.ToString().ToUpper().Trim() == FormsAuthentication.HashPasswordForStoringInConfigFile(user.password.ToUpper() + oldseed.ToUpper(), "MD5").ToUpper().Trim())
                            {
                                bool isAllow = false;

                                var attemptDetails = objBusinessClass.GetAttemptDetails(model.email, "Invalid Username/Password");
                                if (attemptDetails != null)
                                {
                                    //DateTime _wrongAttemptDate = DateTime.ParseExact(Convert.ToString(attemptDetails.attemptTime), "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                    DateTime _wrongAttemptDate = attemptDetails.attemptTime;
                                    DateTime _currentDate = DateTime.Now;

                                    double _diff = (_currentDate).Subtract(_wrongAttemptDate).TotalMinutes;
                                    if (_diff < 1440 && user.wrongAttemptsCount > 9)
                                    {
                                        isAllow = false;
                                    }
                                    else
                                    {
                                        isAllow = true;
                                    }
                                }
                                else
                                {
                                    isAllow = true;
                                }
                                if (isAllow)
                                {
                                    //
                                    objBusinessClass.ResetLoginAttempts(model.email);

                                    SessionManager.UserID = user.userID;
                                    SessionManager.RoleID = user.roleID;
                                    SessionManager.Username = user.email;
                                    SessionManager.DisplayName = user.name;
                                    SessionManager.CustomerMobile = user.mobileNo;
                                    SessionManager.UnitID = user.unitID;
                                    string guid = Guid.NewGuid().ToString();
                                    //set Auth Cookies
                                    Session["AuthToken"] = guid;
                                    Response.Cookies.Add(new HttpCookie("AuthToken", guid));

                                    //return Json(new { result = true, url = Url.Action("Dashboard", "Unit") });
                                    if (user.roleID == "UNT")
                                    {
                                        return RedirectToAction("Dashboard", "Unit");
                                    }
                                    else
                                    {
                                        return RedirectToAction("Dashboard", "UPTourism");
                                    }
                                }
                                else
                                {
                                    objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "This account is locked because of wrong password attempt.", 0);
                                    ViewBag.ErrorMessage = "This account is locked because of wrong password attempts!";
                                }
                            }
                            else
                            {
                                objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                                ViewBag.ErrorMessage = "Incorrect username or password!";
                            }
                        }
                        else
                        {
                            objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                            ViewBag.ErrorMessage = "Incorrect username or password!";
                        }
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "Incorrect Image Text!";
                }
            }
            catch
            {
                ViewBag.ErrorMessage = "Error in Login!";
            }
            return View(model);
        }
        #endregion

        #region unit logout
        [HttpGet]
        public ActionResult UnitLogout()
        {
            try
            {
                ModelState.Clear();
                SessionManager.RemoveSession();

                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(20);
                }
                if (Request.Cookies["AuthToken"] != null)
                {
                    Response.Cookies["AuthToken"].Value = string.Empty;
                    Response.Cookies["AuthToken"].Expires = DateTime.Now.AddMonths(-20);
                }

                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
                Response.Cache.SetNoStore();
                Response.Cookies.Clear();
                Response.Cache.SetMaxAge(new TimeSpan(0, 0, 30));

                return View();
            }
            catch
            {
                return View("Error");
            }
        }
        #endregion

        #region Method - check email existence
        [HttpPost]
        public JsonResult CheckEmailExistence(string email)
        {
            var user = objBusinessClass.CheckEmailExistence(email);
            bool isExisting = user.isExists == 0;
            return Json(isExisting);
        }
        #endregion

        #region Added By Samreen on 10092015
        #region Forget Password
        public ActionResult ForgetPassword()
        {
            ForgetPassword obj = new ForgetPassword();
            return View(obj);
        }

        // [HttpPost]
        //public JsonResult ForgetPassword(string secQues, string secQuesId, string email)
        //{

        //    String msgText = "", NewPassword = "", NewPasswordToUser="";
        //    var user = objBusinessClass.VerifyUserForForgetPassword(secQues, Convert.ToInt32(secQuesId), email);
        //    if (user != null)
        //    {
        //        NewPasswordToUser = GeneratePassword();
        //        NewPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(NewPasswordToUser, "MD5");
        //        UnitLogin model = new UnitLogin();
        //        model.userID = user.userID;
        //        model.password = NewPassword;
        //        int result = objBusinessClass.UpdatePassword(model);
        //        if (result > 0)
        //        {
        //           // SendUpdatePasswordMail(NewPasswordToUser, user.name, user.email);
        //            msgText = "Your Password has been send to your registered mail id";
        //        }
        //        else
        //        {
        //            msgText = "Details you provided are invalid, Please check once";
        //        }
        //    }
        //    else
        //    {
        //        msgText = "Details you provided are invalid, Please check once";
        //    }

        //    return Json(msgText);
        //}

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ForgetPassword(ForgetPassword obj, string Command)
        {
            String msgText = "", NewPassword = "", NewPasswordToUser = "";
            //ModelState["email"].Errors.Clear();
            //ModelState["password"].Errors.Clear();
            ////ModelState["UserID"].Errors.Clear();

            if (ModelState.IsValid)
            {
                if (Command == "submit")
                {
                    var user = objBusinessClass.VerifyUserForForgetPassword(obj.secAns, obj.secQues, obj.userName);
                    if (user != null)
                    {
                        string otp = GenerateOTP(user.mobileNo);
                        ModelState.Clear();
                        obj.sentotp = otp;
                        obj.userID = Convert.ToInt64(user.userID);
                        obj.msgText = "Please see one time password sent in your mobile !";
                        return View(obj);
                    }
                    else
                    {
                        msgText = "Details you provided are invalid, Please check once !";
                        obj.msgText = msgText;
                        return View(obj);
                    }

                }
                else if (Command == "VerifyOTP")
                {
                    if (obj.recvotp == obj.sentotp)
                    {
                        ModelState.Clear();
                        NewPasswordToUser = GeneratePassword();
                        NewPassword = FormsAuthentication.HashPasswordForStoringInConfigFile(NewPasswordToUser, "MD5");
                        ForgetPassword model = new ForgetPassword();
                        model.sentotp = obj.sentotp;
                        model.userID = obj.userID;
                        model.password = NewPassword;
                        int result = objBusinessClass.UpdatePassword(model);
                        if (result > 0)
                        {
                            SendUpdatePasswordMail(NewPasswordToUser, obj.name, obj.email);
                            obj.msgText = "Your Password has been send to your registered mail id !";
                        }
                        else
                        {
                            obj.msgText = "Password not changed try again !";
                        }
                    }
                    else
                    {
                        obj.msgText = "Your one time password is wrong !";
                    }
                }
            }

            return View(obj);
        }
        #endregion
        public string GeneratePassword()
        {
            try
            {
                string def = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                Random rnd = new Random();
                StringBuilder ret = new StringBuilder();
                for (int i = 0; i < 6; i++)
                    ret.Append(def.Substring(rnd.Next(def.Length), 1));
                return ret.ToString();
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        #region to send updated password mail
        protected void SendUpdatePasswordMail(string password, string name, string mailTo)
        {
            try
            {

                StreamReader reader;
                string subject = "";

                reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/ForgetPassword.html"));
                subject = "Forget Password";

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[password]", password);
                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    // SendMail.Send(mailTo, subject, MailBody);
                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                    //objService.sendMail(objMail);
                    SendMail.SendMailNew(mailTo, subject, MailBody, false);
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion
        #region Generate OTP
        private string GenerateOTP(string mobNo)
        {
            if (mobNo.Trim() != "")
            {
                Random randomobj = new Random();
                string otp = randomobj.Next(10000000, 99999999).ToString();
                string Sms = "Your One time Password for to update password is " + otp;
                SMS.SMSSend(Sms, mobNo);
                return otp;
            }
            else
            {
                return "";
            }
        }
        #endregion
        //#region UPTour login
        //[HttpGet]
        //public ActionResult UPTourLogin()
        //{
        //    try
        //    {
        //        ModelState.Clear();

        //        Random rd = new Random();
        //        string seed = rd.Next(100000, 999999).ToString();
        //        SessionManager.SeedValue = seed;

        //        UPToursLogin model = new UPToursLogin();
        //        model.seed = seed;

        //        return View(model);
        //    }
        //    catch
        //    {
        //        return PartialView("_ErrorPagePartialWebsite");
        //    }
        //}

        //[HttpPost]
        //public ActionResult UPTourLogin(UPToursLogin model)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            string oldseed = model.seed.ToString();
        //            Random rd = new Random();
        //            string seed = rd.Next(100000, 999999).ToString();
        //            SessionManager.SeedValue = seed;
        //            model.seed = seed;

        //            var user = objBusinessClass.VerifyUPTourLogin(model.email);

        //            if (user != null)
        //            {
        //                if (model.password.ToString().ToUpper().Trim() == FormsAuthentication.HashPasswordForStoringInConfigFile(user.password.ToUpper() + oldseed.ToUpper(), "MD5").ToUpper().Trim())
        //                {
        //                    SessionManager.UnitUserID = user.userID;
        //                    SessionManager.RoleID = user.roleID;
        //                    SessionManager.Username = user.email;
        //                    SessionManager.DisplayName = user.name;
        //                    SessionManager.CustomerMobile = user.mobileNo;
        //                    //SessionManager.UnitID = user.unitID;
        //                    //return Json(new { result = true, url = Url.Action("Dashboard", "Unit") });
        //                    return RedirectToAction("Dashboard", "UPTours");
        //                }
        //                else
        //                {

        //                    ViewBag.ErrorMessage = "Incorrect username or password!";
        //                }
        //            }
        //            else
        //            {
        //                ViewBag.ErrorMessage = "Incorrect username or password!";
        //            }
        //        }
        //    }
        //    catch
        //    {
        //        ViewBag.ErrorMessage = "Error in Login!";
        //    }
        //    return View(model);
        //}
        //#endregion

        //#region unit logout
        //[HttpGet]
        //public ActionResult UPTourLogout()
        //{
        //    try
        //    {
        //        ModelState.Clear();
        //        SessionManager.RemoveSession();

        //        return View();
        //    }
        //    catch
        //    {
        //        return View("_ErrorPageWebsite");
        //    }
        //}
        //#endregion
        #endregion

        #region send forgot password sms
        private void SendForgotPasswordSMS(string password, string mobileNo)
        {
            string smsContent = ConfigurationManager.AppSettings["ForgotPasswordSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
            smsContent = smsContent.Replace("[Password]", password);
            try
            {
                string SMSStatus = SMS.SMSSend(smsContent, mobileNo);
                SMS.SMSLog(smsContent, mobileNo, "ForgotPassword", SMSStatus);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region send forgot password email
        private void SendForgotPasswordEmail(string password, string email, string name)
        {
            StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/ForgotPassword.html"));
            string subject = "Forgot Password";

            try
            {
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[Password]", password);
                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(email)))
                {
                    //SendMail.Send(email, subject, MailBody);
                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = email };
                    //objService.sendMail(objMail);
                    SendMail.SendMailNew(email, subject, MailBody,false);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region send change password sms
        private void SendChangePasswordSMS(string date, string mobileNo)
        {
            string smsContent = ConfigurationManager.AppSettings["ChangeUnitPasswordSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
            smsContent = smsContent.Replace("[ChangeDate]", date);
            try
            {
                string SMSStatus = SMS.SMSSend(smsContent, mobileNo);
                SMS.SMSLog(smsContent, mobileNo, "ChangePassword", SMSStatus);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region send change password email
        private void SendChangePasswordEmail(string date, string email, string name, string LogEmail)
        {
            StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/ChangePassword.html"));
            string subject = "Change Password";

            try
            {
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[Date]", date);
                MailBody = MailBody.Replace("[EmailID]", LogEmail);
                MailBody = MailBody.Replace("[UnitName]", SessionManager.DisplayName);
                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(email)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = email };
                    //objService.sendMail(objMail);
                    SendMail.SendMailNew(email, subject, MailBody, false);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region UP-Tourism Users Login (Common Login for Users)
        [HttpGet]
        public ActionResult UPTUsersLogin()
        {
            try
            {
                ModelState.Clear();
                Session.Abandon();
                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();
                SessionManager.SeedValue = seed;

                UPToursLogin model = new UPToursLogin();
                model.seed = seed;

                return View(model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UPTUsersLogin(UPToursLogin model)
        {
            try
            {
                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (ModelState.IsValid)
                    {
                        string oldseed = model.seed.ToString();
                        Random rd = new Random();
                        string seed = rd.Next(100000, 999999).ToString();
                        SessionManager.SeedValue = seed;
                        model.seed = seed;

                        var user = objBusinessClass.VerifyUPTourLogin(model.email);

                        if (user != null)
                        {
                            if (model.password.ToString().ToUpper().Trim() == FormsAuthentication.HashPasswordForStoringInConfigFile(user.password.ToUpper() + oldseed.ToUpper(), "MD5").ToUpper().Trim())
                            {
                                bool isAllow = false;

                                var attemptDetails = objBusinessClass.GetAttemptDetails(model.email, "Invalid Username/Password");
                                if (attemptDetails != null)
                                {
                                    DateTime _wrongAttemptDate = attemptDetails.attemptTime;
                                    DateTime _currentDate = DateTime.Now;

                                    double _diff = (_currentDate).Subtract(_wrongAttemptDate).TotalMinutes;
                                    if (_diff < 1440 && user.wrongAttemptsCount > 9)
                                    {
                                        isAllow = false;
                                    }
                                    else
                                    {
                                        isAllow = true;
                                    }
                                }
                                else
                                {
                                    isAllow = true;
                                }
                                if (isAllow)
                                {
                                    //
                                    objBusinessClass.ResetLoginAttempts(model.email);

                                    SessionManager.UserID = user.userID;
                                    SessionManager.RoleID = user.roleID;
                                    SessionManager.Username = user.email;
                                    SessionManager.DisplayName = user.name;
                                    SessionManager.CustomerMobile = user.mobileNo;
                                    SessionManager.PackageCategoryID = user.packageCategoryID;
                                    string guid = Guid.NewGuid().ToString();
                                    //set Auth Cookies
                                    Session["AuthToken"] = guid;
                                    Response.Cookies.Add(new HttpCookie("AuthToken", guid));

                                    //return Json(new { result = true, url = Url.Action("Dashboard", "Unit") });
                                    if (user.roleID == "CRS")
                                    {
                                        return RedirectToAction("Dashboard", "UPTours");
                                    }
                                    else if (user.roleID == "UPT")
                                    {
                                        return RedirectToAction("Dashboard", "UPT");
                                    }
                                    else if (user.roleID == "ARC")
                                    {
                                        return RedirectToAction("Dashboard", "ARC");
                                    }
                                    else if (user.roleID == "HQ")
                                    {
                                        return RedirectToAction("Dashboard", "MasterEntry");
                                    }
                                    else if (user.roleID == "HQ2")
                                    {
                                        return RedirectToAction("Dashboard", "HeadQuarter");
                                    }
                                    else
                                    {
                                        ViewBag.ErrorMessage = "Incorrect username or password!";
                                    }
                                }
                                else
                                {
                                    objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "This account is locked because of wrong password attempt.", 0);
                                    ViewBag.ErrorMessage = "This account is locked because of wrong password attempts!";
                                }
                            }
                            else
                            {
                                objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                                ViewBag.ErrorMessage = "Incorrect username or password!";
                            }
                        }
                        else
                        {
                            objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                            ViewBag.ErrorMessage = "Incorrect username or password!";
                        }
                    }
                }
                else
                {
                    ViewBag.ErrorMessage = "Captcha Text did not Match!";
                }
            }
            catch
            {
                ViewBag.ErrorMessage = "Error in Login!";
            }
            return View(model);
        }

        #region UPTUSER logout
        [HttpGet]
        public ActionResult UPTUsersLogout()
        {
            try
            {
                ModelState.Clear();
                SessionManager.RemoveSession();

                if (Request.Cookies["ASP.NET_SessionId"] != null)
                {
                    Response.Cookies["ASP.NET_SessionId"].Value = string.Empty;
                    Response.Cookies["ASP.NET_SessionId"].Expires = DateTime.Now.AddMonths(20);
                }
                if (Request.Cookies["AuthToken"] != null)
                {
                    Response.Cookies["AuthToken"].Value = string.Empty;
                    Response.Cookies["AuthToken"].Expires = DateTime.Now.AddMonths(-20);
                }

                Response.Cache.SetCacheability(HttpCacheability.NoCache);
                Response.Cache.SetExpires(DateTime.Now.AddDays(-1));
                Response.Cache.SetNoStore();
                Response.Cookies.Clear();
                Response.Cache.SetMaxAge(new TimeSpan(0, 0, 30));

                return View();
            }
            catch
            {
                return View("Error");
            }
        }
        #endregion
        #endregion

        #region Change password for AllUsers Users
        #region display change password
        [HttpGet]
        [AuthorizeAllUser]
        public ActionResult ChangePassword()
        {
            UserChangePassword model = new UserChangePassword();
            try
            {
                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();

                model.seedChangePassword = seed;
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region save changed password
        [HttpPost]
        [ValidateAntiForgeryToken]
        [AuthorizeAllUser]
        public ActionResult ChangePassword(UserChangePassword model)
        {
            try
            {
                if (ModelState.ContainsKey("newPassword"))
                    ModelState["newPassword"].Errors.Clear();

                if (ModelState.IsValid)
                {
                    string oldseed = model.seedChangePassword.ToString();
                    Random rd = new Random();
                    string newSeed = rd.Next(100000, 999999).ToString();
                    model.seedChangePassword = newSeed;
                    model.email = SessionManager.Username;
                    model.userId = SessionManager.UserID;
                    model.roleID = SessionManager.RoleID;

                    //change this procedure as it is used for login
                    var user = objBusinessClass.verifyuserforPasswordChange(model.email, model.roleID);

                    var encPassword = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(user.password.ToUpper() + oldseed, "MD5").ToUpper().Trim();

                    if (encPassword == model.oldPassword.ToUpper().Trim())
                    {
                        if (model.newPassword.ToUpper().Trim() == user.password.ToUpper().Trim())
                        {
                            ViewBag.ErrorMessage = "Old password and new password must not be same!";
                        }
                        else
                        {
                            if (user != null)
                            {
                                if (model.newPassword == model.confirmPassword)
                                {
                                    int result = objBusinessClass.ChangeAllUserPassword(model);

                                    if (result > 0)
                                    {
                                        var changeDate = objBusinessClass.GetChangePasswordDate(model).passwordChangedOn;
                                        try
                                        {
                                            SendChangePasswordSMS(changeDate, user.mobileNo);
                                        }
                                        catch
                                        {
                                        }
                                        try
                                        {
                                            SendChangePasswordEmail(changeDate, user.email, user.name, model.email);
                                        }
                                        catch
                                        {
                                        }
                                        TempData["roleID"] = SessionManager.RoleID;

                                        return RedirectToAction("ChangePasswordConfirm", "Account");

                                    }
                                    else
                                    {
                                        ViewBag.ErrorMessage = "Password not changed!";
                                    }
                                }
                                else
                                {
                                    ViewBag.ErrorMessage = "Password and confirm password do not match!";
                                }
                            }
                            else
                            {
                                ViewBag.ErrorMessage = "Incorrect old password!";
                            }
                        }
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "Incorrect old password!";
                    }
                }
            }
            catch { }

            return View(model);
        }

        //[HttpGet]
        //public ActionResult ConfirmChangePassword()
        //{
        //    ModelState.Clear();
        //    SessionManager.RemoveSession();
        //    ViewBag.SuccessMessage = "Password changed successfully. Login again to continue!";

        //    return View();
        //}
        public ActionResult ChangePasswordConfirmUnit()
        {
            ModelState.Clear();
            SessionManager.RemoveSession();
            ViewBag.SuccessMessage = "Password changed successfully. Login again to continue!";

            return View();

        }
        public ActionResult ChangePasswordConfirm()
        {
            ModelState.Clear();
            SessionManager.RemoveSession();
            ViewBag.SuccessMessage = "Password changed successfully. Login again to continue!";
            TempData.Peek("roleID");

            return View();
        }
        #endregion
        #endregion


        /*------------update customer profile---------------*/

        #region display online customer profile
        [AuthorizeUser]
        public ActionResult MyProfile()
        {
            OnlineCustomer obj_Customer = new OnlineCustomer();
            try
            {
                if (TempData["message"] != null && Convert.ToString(TempData["message"]) != "")
                {
                    ViewBag.Success = Convert.ToString(TempData["message"]);
                }
                obj_Customer = objBusinessClass.GetAnonymousCustomerDetails(SessionManager.Username);

                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });

                if (obj_Customer != null && obj_Customer.countryID == 98)
                {
                    ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(obj_Customer.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                    if (obj_Customer.stateID > 0)
                    {
                        ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(obj_Customer.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                    }
                    else
                    {
                        ViewBag.City = Enumerable.Empty<SelectListItem>();
                    }
                }
                else
                {
                    ViewBag.State = Enumerable.Empty<SelectListItem>();
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            catch
            {
            }
            return View(obj_Customer);
        }
        #endregion

        #region Update customer details
        [AuthorizeUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult MyProfile(OnlineCustomer model)
        {
            try
            {
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });

                if (model != null && model.countryID > 0 && model.countryID == 98)
                {
                    ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                    if (model.stateID > 0)
                    {
                        ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                    }
                    else
                    {
                        ViewBag.City = Enumerable.Empty<SelectListItem>();
                    }

                }
                else
                {
                    ViewBag.State = Enumerable.Empty<SelectListItem>();
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }

                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!pinCode.IsMatch(model.pincode))
                    {
                        ViewBag.Error = "Enter a valid 6 digit Pincode!";
                        return View(model);
                    }
                    else if (!mobileNo.IsMatch(model.mobileNo))
                    {
                        ViewBag.Error = "Enter a valid 10 digit Mobile No.!";
                        return View(model);
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }


                if (ModelState.IsValid)
                {
                    model.ipAddress = this.Request.UserHostAddress;
                    int result = objBusinessClass.UpdateAnonymousCustomerProfile(model);

                    if (result > 0)
                    {
                        ModelState.Clear();
                        TempData["message"] = "Profile Updated Successfully!";

                        return RedirectToAction("MyProfile", "Account");
                    }
                    else
                    {
                        ViewBag.Error = "Customer Details Not Updated!";
                    }
                }
            }
            catch
            {
                ViewBag.Error = "Error in Updating Profile!";
            }
            return View(model);
        }
        #endregion

        /*------------end update customer profile---------------*/


        public ActionResult Index()
        {
            Login model = new Login();
            var url = ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + "UPTourism/TaxiBusQuotation/" + Server.UrlEncode(Server.HtmlEncode(EncryptionDecryption.Encrypt("ENQ16000029")));
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(Login model)
        {
            ModelState.Clear();
            model.Password = FormsAuthentication.HashPasswordForStoringInConfigFile(model.UserLoginID, "MD5");
            return View(model);
        }

        #region (ANURAG) Forget Password Work

        public ActionResult ForgotPassword()
        {

            ForgotPassword obj = new ForgotPassword();
            return View(obj);
        }

        [HttpPost]
        public ActionResult ForgotPassword(ForgotPassword model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (model.captcha == Convert.ToString(Session["capimagetextForgot"]))
                    {
                        Random randomobj = new Random();
                        model.randomNo = Convert.ToInt32(randomobj.Next().ToString().Substring(0, 6));

                        model = objBusinessClass.GetUserDetailsForPasswordReset(model);

                        if (model.verifyBy)
                        {
                            if (!string.IsNullOrEmpty(model.userMobileNo))
                            {
                                bool result = sendOTP(model.userMobileNo);
                                if (result)
                                {
                                    TempData["userId"] = model.userID;
                                    return RedirectToAction("OtpVerification");
                                }
                                else
                                {
                                    ViewBag.ErrorMessage = "OTP not send. Please try again!";
                                }
                            }
                            else
                            {
                                ViewBag.ErrorMessage = "Details not found!";
                            }
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(model.userEmail))
                            {
                                string EncriptedURL = encriptURL(model.userID.ToString(), model.randomNo.ToString(), model.userEmail);
                                SendForgotPasswordEmaillink(model.name, EncriptedURL, model.userEmail);
                                ViewBag.SuccessMessage = "A Password Reset Link is sent on your Registered Email Id.";
                            }
                            else
                            {
                                ViewBag.ErrorMessage = "Details not found!";
                            }
                        }

                        //string verifyType = obj.frgUserDetails[0].verifyBy;
                        //if (verifyType == "Both")
                        //{

                        //    string EncriptedURL = encriptURL( obj.frgUserDetails[0].userID.ToString() ,rn,  obj.frgUserDetails[0].USeremail.ToString()  ,obj.frgUserDetails[0].USerMobile.ToString() );
                        //    SendForgotPasswordEmaillink(obj.frgUserDetails[0].name, EncriptedURL, obj.frgUserDetails[0].USeremail);
                        //    bool res = sendOTP(obj.frgUserDetails[0].USerMobile);

                        //    if (res)
                        //    {
                        //        TempData["Use_Id"] = obj.frgUserDetails[0].userID;
                        //        return RedirectToAction("OtpVerification");
                        //    }
                        //    else
                        //    {
                        //        obj.msgText = "A Password Reset Link is sent on your Registered Email Id. and  Some thing went wrong during OTP sent.";
                        //        ViewBag.MSG = "A Password Reset Link is sent on your Registered Email Id. and  Some thing went wrong during OTP sent.";
                        //    }
                        //}
                        //else if (verifyType == "Mobile")
                        //{
                        //    bool resut = sendOTP(obj.frgUserDetails[0].Mobileno);

                        //    if (resut)
                        //    {
                        //        TempData["Use_Id"] = obj.frgUserDetails[0].userID;
                        //        return RedirectToAction("OtpVerification");
                        //    }
                        //    else
                        //    {
                        //        obj.msgText = "Some thing went wrong during OTP sent. please try again later";
                        //        ViewBag.MSG = "Some thing went wrong during OTP sent. please try again later";
                        //    }
                        //}
                        //else if (verifyType == "Email")
                        //{
                        //    string EncriptedURL = encriptURL(obj.frgUserDetails[0].userID.ToString(), rn, obj.frgUserDetails[0].USeremail.ToString(), obj.frgUserDetails[0].USerMobile.ToString());
                        //    SendForgotPasswordEmaillink(obj.frgUserDetails[0].name, EncriptedURL, obj.frgUserDetails[0].USeremail);
                        //    ViewBag.MSG = "A Password Reset Link is sent on your Registered Email Id.";
                        //}                   
                    }
                    else
                    {
                        ViewBag.ErrorMessage = "Enter correct captcha text!";
                    }
                }
            }
            catch
            { }
            return View(model);
        }

        public string encriptURL(string userId, string RanNum, string encrEmailID)
        {
            string UserId = EncryptionDecryption.Encrypt(userId);
            DateTime datetime = DateTime.Now;
            string Encriptdatetime = EncryptionDecryption.Encrypt(datetime.ToString());

            //string decStr = EncryptionDecryption.Decrypt(Encriptdatetime);

            string EncriptRanNum = EncryptionDecryption.Encrypt(RanNum);
            string EncriptEmailID = EncryptionDecryption.Encrypt(encrEmailID);
           // string EncriptMobileNumber = EncryptionDecryption.Encrypt(encrMobileNo);

            string ResetUrl = ConfigurationManager.AppSettings["ResetUrl"];
            //string encrptUrl = ResetUrl + "Account/changepasswordbylink?RL=" + UserId + "$" + Encriptdatetime + "$" + EncriptRanNum + "$" + EncriptEmailID;
            string encrptUrl = string.Format(ResetUrl + "Account/changepasswordbylink?RL=" + Server.UrlEncode(Server.HtmlEncode(UserId + "$" + Encriptdatetime + "$" + EncriptRanNum + "$" + EncriptEmailID)));

            return encrptUrl;
        }

        private void SendForgotPasswordEmaillink(string UserName, string link, string UserEmailId)
        {
            StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/ResetPwdLink.html"));
            string subject = "Reset Password link";

            try
            {
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[userName]", UserName);
                MailBody = MailBody.Replace("[resetLink]", link);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(UserEmailId)))
                {                  
                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = UserEmailId };
                    //objService.sendMail(objMail);
                    SendMail.SendMailNew(UserEmailId, subject, MailBody, false);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpGet]
        public ActionResult changepasswordbylink()
        {
            changepwdByLink obj = new changepwdByLink();
            try
            {
                bool alldetailsvalid = false;
                if (Request.QueryString["RL"] != null)
                {
                    string value = Server.HtmlDecode(Server.UrlDecode(Request.QueryString["RL"].ToString()));
                    //string[] data = Request.QueryString["RL"].ToString().Split('$');
                    string[] data = value.Split('$');
                    string userId = EncryptionDecryption.Decrypt(data[0].ToString());
                    string aa = data[1].ToString().Replace(" ", "+");
                    string resetdatetime = EncryptionDecryption.Decrypt(aa);
                    string RandomNo = EncryptionDecryption.Decrypt(data[2].ToString());
                    //string EmailId = EncryptionDecryption.Decrypt(data[3].ToString());
                    string EmailId = EncryptionDecryption.Decrypt(data[3].ToString().Replace(" ", "+"));
                    //string MobNo = EncryptionDecryption.Decrypt(data[4].ToString());
                    string validTimeSpan = ConfigurationManager.AppSettings["ResetLinkTime"];
                    
                    //obj.frgUserDetails = objBusinessClass.getuserDetailsforchangingPwd(userId).ToList();

                    obj = objBusinessClass.GetUserDetailsforChangingPwd(userId);
                    if (obj != null)
                    {
                        //TimeSpan time = DateTime.Now - Convert.ToDateTime(resetdatetime).AddMinutes(Convert.ToDouble(validTimeSpan));
                        //if (Convert.ToDateTime(resetdatetime) <= DateTime.Now.AddMinutes(Convert.ToDouble(validTimeSpan)))
                        if (DateTime.Now <= Convert.ToDateTime(resetdatetime).AddMinutes(Convert.ToDouble(validTimeSpan)))
                        {
                            if (obj.randomNo.ToString() == RandomNo)
                            {
                                alldetailsvalid = true;
                                if (obj.userEmail == EmailId)
                                {
                                    alldetailsvalid = true;
                                }
                                else
                                {
                                    alldetailsvalid = false;
                                    TempData["ErrorText"] = "Invalid Details!";
                                }

                            }
                            else
                            {
                                alldetailsvalid = false;
                                TempData["ErrorText"] = "Invalid Link";
                            }
                        }
                        else
                        {
                            alldetailsvalid = false;
                            TempData["ErrorText"] = "Linked has Expired!";
                        }
                    }
                    else
                    {
                        alldetailsvalid = false;
                        TempData["ErrorText"] = "Invalid Details!";
                    }                }
                else
                {
                    if (Session["ChUId"] != null)
                    {
                        alldetailsvalid = true;
                        String userId = Convert.ToString(Session["ChUId"]);
                       // obj.frgUserDetails = objBusinessClass.getuserDetailsforchangingPwd(userId).ToList();
                        obj = objBusinessClass.GetUserDetailsforChangingPwd(userId);
                    }
                    else
                    {
                        TempData["ErrorText"] = "Unknown request cannot be processed !";                        
                    }
                }
                if (alldetailsvalid == true)
                {
                    return View(obj);
                }
                else if (alldetailsvalid == false)
                {
                    alldetailsvalid = false;
                    return RedirectToAction("ChangePasswordError");
                }
                return View(obj);

            }
            catch (Exception ex)
            {
                TempData["ErrorText"] = ex.Message;
                return RedirectToAction("ChangePasswordError");
            }
        }

        [HttpPost]
        public ActionResult changepasswordbylink(changepwdByLink obj, string test)
        {

            string newpwd = obj.NewPassword;
            Int64 userid = obj.userID;
            if (obj.NewPassword == obj.ConfirmPassword)
            {
                int res = objBusinessClass.UpdateUserPassword(userid, obj.NewPassword.ToUpper());
                if (res > 0)
                {
                    return RedirectToAction("PassSuccess");
                }
                else
                {
                    TempData["ErrorText"] = "Some thing went wrong please try again later!";
                    return RedirectToAction("ChangePasswordError");
                }
            }
            else
            {
                ViewBag.msg = "Password and Confirm Password Did not match";
            }
            return View();
        }

        public bool sendOTP(string MobileNo)
        {
            bool res = false;
            string OTP = CreateOTP_Numeric();
            string ScreenNo = RandomScreen();
            TempData["Otp"] = OTP;
            TempData["screen"] = ScreenNo;

            string Msg = "One Time Password(OTP) to Reset your Password for Screen No. " + ScreenNo + " is : " + OTP;
            string status = SMS.SMSSend(Msg, MobileNo);
            if (status == "Success")
            {
                res = true;
            }

            SMS.SMSLog(Msg, MobileNo, "Reset Password", status);
            return res;
        }

        public ActionResult OtpVerification()
        {
            OtpVerification otp = new OtpVerification();
            if (TempData["userId"] != null && TempData["Otp"] != null && TempData["screen"] != null)
            {
                otp.userid = Convert.ToInt64(TempData["userId"]);
                otp.orgOtp = EncryptionDecryption.Encrypt(Convert.ToString(TempData["Otp"]));
                otp.screenNo = Convert.ToString(TempData["screen"]);
            }

            otp.InfoText = "OTP is sent to your registered Mobile No. Please verify OTP.";
            return View(otp);
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult OtpVerification(OtpVerification model)
        {
            string decOtp = EncryptionDecryption.Decrypt(model.orgOtp);
            if (decOtp == model.Otp)
            {
                Session["ChUId"] = model.userid;
                return RedirectToAction("changepasswordbylink");
            }
            else
            {
                model.InfoText = "OTP you have entered is not valid please enter valid OTP.";
            }
            return View(model);
        }

        public ActionResult ChangePasswordError()
        {
            return View();
        }

        public ActionResult PassSuccess()
        {
            return View();
        }


        #region generate OTP and Screen NUMBER

        public string CreateOTP_Numeric()
        {

            Random random = new Random();

            int Size = 6;
            string input = "1234567890";
            StringBuilder builder = new StringBuilder();
            char ch;
            for (int i = 0; i < Size; i++)
            {
                ch = input[random.Next(0, input.Length)];
                builder.Append(ch);
            }
            return builder.ToString();

        }

        public string RandomScreen()
        {
            Random random = new Random();

            int Size = 4;
            string input = "0987654321";
            StringBuilder builder = new StringBuilder();
            char ch;
            for (int i = 0; i < Size; i++)
            {
                ch = input[random.Next(0, input.Length)];
                builder.Append(ch);
            }
            return builder.ToString();
        }

        #endregion
        #endregion


        [HttpGet]
        public ActionResult UserRegistration()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UserRegistration(UserRegistration ur)
        {
            if (ur.countryID == 98)
            {
                ModelState.Remove("otherState");
                ModelState.Remove("otherCity");
            }
            else
            {
                ModelState.Remove("stateID");
                ModelState.Remove("cityID");
            }
            string r = (string)Session["capimagetext"];
            if(Convert.ToString(Session["capimagetext"])!=ur.Captcha)
            {
                ModelState.AddModelError("Captcha", "Captcha Text did not Match!");
            }
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            if (ModelState.IsValid)
            {
                int i = objBusinessClass.InsertUserRegistration(ur, this.Request.UserHostAddress);
                if (i > 0)
                {
                    TempData["succeededReg"] = 1;
                    return RedirectToAction("UserRegistrationSucceeded");
                }
                else
                {
                    ViewBag.msg = "You are not registered. Try again.";
                }
            }
            return View();
        }

        public ActionResult UserRegistrationSucceeded()
        {
            ViewBag.succeededReg = TempData["succeededReg"];
            return View();
        }

        public JsonResult CheckEmailExistenceforUserReg(string email)
        {
            var user = objBusinessClass.CheckEmailExistenceforUserReg(email);
            bool isExisting = user == 1 ? false : true;
            return Json(isExisting);
        }

        public JsonResult CheckMobileNoExistenceforUserReg(string mobileno)
        {
            var user = objBusinessClass.CheckMoblieNoExistenceforUserReg(mobileno);
            bool isExisting = user == 1 ? false : true;
            return Json(isExisting);
        }

        public JsonResult Matchcaptcha(string Captcha)
        {
            bool cap = Convert.ToString(Session["capimagetext"]) != Captcha ? false : true;
            return Json(cap);
        }
    }
}
