﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models.ProcessClasses;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models;
using System.Globalization;
using System.Data;
using System.IO;
using System.Xml.Linq;
using System.Configuration;
using System.Web.Hosting;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text.RegularExpressions;
using System.Data.SqlClient;

namespace UP_TourismBooking.Controllers
{
    [AuthorizeUPTour]
    public class UPTController : Controller
    {
        #region Declarations

        BusinessClass objBusinessClass = new BusinessClass();
        Common objCommonClass = new Common();
        private Regex pinCode = new Regex(@"^(\d{6})$", RegexOptions.Compiled);
        private Regex mobileNo = new Regex(@"^(\d{10})$", RegexOptions.Compiled);
        private Regex mobileNoOther = new Regex(@"^[0-9 \.\,]+$", RegexOptions.Compiled);
        #endregion

        #region Display dashboard
        public ActionResult Dashboard()
        {
            return View();
        }
        #endregion

        /*----------------------Vacancy Status------------- --------------*/

        #region display vacancy status
        [HttpGet]
        public ActionResult VacancyStatus()
        {
            ARCVacancyStatus model = new ARCVacancyStatus();
            try
            {
                model.dtBooking = DateTime.Now;
                model.BookingInTime = DateTime.Now;
                ViewBag.UnitList = objBusinessClass.GetUnitListPackageWiseByPackagecatId().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region get vacancy status
        public ActionResult GetVacancyStatus(string dtBooking, Int64 UnitId, DateTime dtBookingTime)
        {
            ARCVacancyStatus model = new ARCVacancyStatus();
            try
            {
                if (dtBookingTime.Hour < 12)
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                }
                else
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.unitID = UnitId;
                model.bookingStatusList = objBusinessClass.GetARCVacancyStatus(model);
            }
            catch
            {

            }
            return PartialView("_VacancyStatusGrid", model.bookingStatusList);
        }
        #endregion


        #region Print Vacancy Status
        public ActionResult PrintVacancyStatus(string dtBooking, Int64 UnitId)
        {
            ARCVacancyStatus model = new ARCVacancyStatus();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBooking) ? "-" : dtBooking;
            try
            {
                model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.unitID = UnitId;
                model.bookingStatusList = objBusinessClass.GetARCVacancyStatus(model);
                return View(model.bookingStatusList);
            }
            catch
            {

            }
            return View();
        }
        #endregion


        #region get vacancy status details
        public ActionResult GetRoomVacancyDetail(string dtBooking, string roomtypeId, string unitId, DateTime dtBookingTime)
        {
            VacancyStatusDetail model = new VacancyStatusDetail();
            try
            {
                model.RoomTypeId = Convert.ToInt64(roomtypeId);
                try
                {
                    if (dtBookingTime.Hour < 12)
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                    }
                    else
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                }
                catch
                {
                    model.BookingDate = DateTime.Now;
                }
                model.unitID = Convert.ToInt64(unitId);
                model = objBusinessClass.GetVacancyStatusDetail(model);
            }
            catch
            {

            }
            return PartialView("_RoomVacancy", model);
        }
        #endregion

        #region Export vacancy status list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult VacancyStatus(UnitVacancyStatus obj)
        {
            ModelState.Clear();

            UnitVacancyStatus objR = new UnitVacancyStatus();
            objR.BookingInTime = obj.BookingInTime;
            if (objR.BookingInTime.Hour < 12)
            {
                objR.dtBooking = obj.dtBooking.AddDays(-1);
            }
            else
            {
                objR.dtBooking = obj.dtBooking;
            }
            objR.unitID = obj.unitID;
            objR.bookingStatusList = obj.bookingStatusList;

            GridView gv = new GridView();

            var dtresult = objBusinessClass.GetUnitVacancyStatus(objR);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Room_Type = e.roomType, Total_Rooms = e.totalRoom, Online_Booking = e.onlineBooked, Package_Tours_Booking = e.packageBooked, UP_Tours_Booking = e.upTourBooked, ARC_Booking = e.arcBooked, CRS_Booking = e.crsBooked, Counter_Booking = e.counterBooked, Out_of_Service = e.OutS, Hold = e.blocked, Vacant = e.vacant }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/VacancyStatus.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookingStatusList = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitListPackageWiseByPackagecatId().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(obj);
        }
        #endregion

        /*----------------------End Vacancy Status---------------------------*/

        /*---------------------- Booking List---------------------------*/

        #region display booking list
        [HttpGet]
        public ActionResult BookedList()
        {
            try
            {
                //ViewBag.UnitList = objBusinessClass.GetUnitListPackageWiseByPackagecatId().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBookedList(string dtBookingFrom, string dtBookingTo, string docket)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.docketNo = docket.Trim();

                model.bookedList = objBusinessClass.GetUPTBookingStatus(model);
            }
            catch
            {

            }
            return PartialView("_BookedListGrid", model.bookedList);
        }
        #endregion

        #region Print Booking Done by Syed
        public ActionResult PrintBookingDone(string dtBookingDateFrom, string dtBookingDateTo, string docketNo)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBookingDateFrom) ? "-" : dtBookingDateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dtBookingDateTo) ? "-" : dtBookingDateTo;
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.docketNo = docketNo.Trim();

                model.bookedList = objBusinessClass.GetUPTBookingStatus(model);
                return View(model.bookedList);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export booking list to excel
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookedList(UPTourTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetUPTBookingStatus(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Package_Name = e.packageName, Name = e.name, Docket_No = e.docketNo, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, No_of_Rooms = e.noofRooms, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Booking_Status = e.BookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            obj.bookedList = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitListPackageWiseByPackagecatId().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(obj);
        }
        #endregion

        #region get booking details
        [HttpGet]
        public ActionResult GetBookingDetail(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            try
            {
                obj_BookingDetail = objBusinessClass.GetUPTBookingDetails(docketNo);
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                    return PartialView("_SpecialBookedDetails", obj_BookingDetail);
                }
            }
            catch
            {
            }
            return Content("");
        }
        #endregion

        /*---------------------- End Booking List---------------------------*/


        /*---------------------- Package Tour Booking---------------------------*/

        #region Display Package Tour Booking
        [HttpGet]
        public ActionResult PackageTourBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Packages = objBusinessClass.getPackageTourList(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>();

            return View();
        }
        #endregion

        //#region Get category wise package list
        //[HttpGet]
        //public JsonResult GetPackageTourList(int packageCategoryID)
        //{
        //    IEnumerable<SelectListItem> obj = objBusinessClass.getPackageTourList(packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
        //    return Json(obj, JsonRequestBehavior.AllowGet);
        //} 
        //#endregion

        #region save package tour booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageTourBooking(PackageTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                DateTime minDate = DateTime.Now;
                if (model.ArrivalDate < minDate.Date)
                {
                    _msg = "Arrival Date should not be Past Date!";
                    isValid = false;
                }
                else
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                        {
                            _msg = "Enter a valid 6 digit Pincode!";
                            isValid = false;
                        }
                        else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid 10 digit Mobile No.!";
                            isValid = false;
                        }
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid Mobile No.!";
                            isValid = false;
                        }
                    }

                    if (string.IsNullOrEmpty(model.email))
                    {
                        ModelState["email"].Errors.Clear();
                    }

                    if (ModelState.IsValid && isValid)
                    {
                        model.roleID = "UOCST";
                        model.userIP = this.Request.UserHostAddress;
                        model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                        model.currency = "INR";
                        model.description = "";
                        PackageAvailabilityDetails objPack = new PackageAvailabilityDetails();
                        objPack.arrivalDate = model.ArrivalDate;
                        objPack.noOfGuests = model.noOfGuests;
                        objPack.packageID = model.packageID;
                        var isAvailable = objBusinessClass.ChkPackageTourAvailability(objPack);
                        if (isAvailable.isAvailable != null && isAvailable.isAvailable == false)
                        {
                            _msg = "Package Not Available for date- " + objPack.arrivalDate;
                            ModelState.AddModelError("", "Package Not Available for date- " + objPack.arrivalDate.ToShortDateString());
                        }
                        else
                        {
                            model.bookingFor = "PACK";
                            model.bookingBy = "UPT";
                            model.receiptNo = "UPT Payment";

                            if (model.countryID == 98)
                            {
                                model.otherState = "";
                                model.otherCity = "";
                            }
                            else
                            {
                                model.stateID = 0;
                                model.cityID = 0;
                            }

                            var user = objBusinessClass.savePackageTourBookingDetails(model);
                            if (user != null)
                            {
                                if (string.IsNullOrEmpty(user.docketNo))
                                {
                                    _msg = "Package Tour Not Available!";
                                }
                                else
                                {
                                    TempData["DocketNo"] = user.docketNo;

                                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                    SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                                    try
                                    {
                                        SendPackageBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName);
                                        SendPackageTourMail(user.docketNo, model.email, IEContactDetails);
                                    }
                                    catch
                                    { }
                                    return RedirectToAction("PakageTourConfirmation");
                                }
                            }
                            else
                            {
                                _msg = "Package Tour Not Booked!";
                            }
                        }
                    }
                }
            }
            catch
            {
                _msg = "Error in Package Tour Booking!";
            }

            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Packages = objBusinessClass.getPackageTourList(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });

            if (model.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }

            return View(model);
        }
        #endregion

        #region package tour booking confirmation
        public ActionResult PakageTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
                if (model != null)
                {
                    model.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                }
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End Package Tour Booking---------------------------*/


        /*----------------------Cycle Tour Booking---------------------------*/

        #region Display Cycle Route Booking
        [HttpGet]
        public ActionResult LkoOnCycleBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.State = Enumerable.Empty<SelectListItem>();
            ViewBag.City = Enumerable.Empty<SelectListItem>();
            ViewBag.Packages = Enumerable.Empty<SelectListItem>();

            return View();
        }
        #endregion

        #region save cycle tour booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoOnCycleBooking(LkoOnCycleBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (model.ArrivalDate < minDate.Date)
                {
                    _msg = "Arrival Date should be greater than Current Date!";
                    isValid = false;
                }
                else
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                        {
                            _msg = "Enter a valid 6 digit Pincode!";
                            isValid = false;
                        }
                        else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid 10 digit Mobile No.!";
                            isValid = false;
                        }
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid Mobile No.!";
                            isValid = false;
                        }
                    }
                    if (string.IsNullOrEmpty(model.email))
                    {
                        ModelState["email"].Errors.Clear();
                    }

                    ModelState["arrivalTime"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {
                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "CCYCL";
                    model.bookingFor = "CYCLE";
                    model.bookingBy = "UPT";
                    model.receiptNo = "UPT Payment";

                    var user = objBusinessClass.saveCycleTourBookingByUPTour(model);
                    if (user != null)
                    {
                        TempData["DocketNo"] = user.docketNo;
                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                        SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                        try
                        {
                            SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Cycle Tour Booking");
                            SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "CYCLE");
                        }
                        catch
                        { }
                        return RedirectToAction("CycleTourConfirmation");
                    }
                    else
                    {
                        _msg = "Cycle Tour Not Booked!";
                    }
                }
            }
            catch
            {
                _msg = "Error in Cycle Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region cycle tour booking confirmation
        public ActionResult CycleTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End Cycle Tour Booking---------------------------*/

        /*----------------------Tonga Ride Booking---------------------------*/

        #region Display Tonga Ride by UP Tours
        public ActionResult LkoTongaRideBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LTR", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LTR").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            LkoTongaRideBooking model = new LkoTongaRideBooking();
            model.noOfGuests = 4;

            return View(model);
        }
        #endregion

        #region get route fare
        [HttpGet]
        public ActionResult GetTongaRideFare(Int32 packageID, Int32 applicantTypeId)
        {
            return Json(objBusinessClass.GetTongaRideFare(packageID, applicantTypeId), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Save Tonga Ride by UP Tours
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoTongaRideBooking(LkoTongaRideBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (model.ArrivalDate < minDate.Date)
                {
                    _msg = "Arrival Date should be greater than Current Date!";
                    isValid = false;
                }
                else
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                        {
                            _msg = "Enter a valid 6 digit Pincode!";
                            isValid = false;
                        }
                        else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid 10 digit Mobile No.!";
                            isValid = false;
                        }
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNoOther.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid Mobile No.!";
                            isValid = false;
                        }
                    }
                    if (string.IsNullOrEmpty(model.email))
                    {
                        ModelState["email"].Errors.Clear();
                    }

                    ModelState["arrivalTime"].Errors.Clear();
                }
                if (ModelState.IsValid && isValid)
                {
                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "CTONG";
                    model.bookingFor = "TONGA";
                    model.bookingBy = "UPT";
                    model.receiptNo = "UPT Payment";

                    var user = objBusinessClass.saveLkoTongaRideBookingByUPTour(model);
                    if (user != null)
                    {
                        TempData["DocketNo"] = user.docketNo;

                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                        SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                        try
                        {
                            SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Tonga Ride Booking");
                            SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "TONGA");
                        }
                        catch
                        { }
                        return RedirectToAction("LkoTongaRideConfirmation");
                    }
                    else
                    {
                        _msg = "Lucknow Tonga Ride Not Booked!";
                    }
                }
            }
            catch
            {
                ModelState.AddModelError("", "Error in Lucknow Tonga Ride Booking!");
                _msg = "Error in Lucknow Tonga Ride Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LTR", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LTR").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region Tonga Ride Booking Confirmation by UP Tours
        public ActionResult LkoTongaRideConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
                if (model != null)
                {
                    model.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                }
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End Tonga Ride Booking---------------------------*/

        /*----------------------Heritage Walk Booking---------------------------*/

        #region Display Heritage Walk by UPTour
        public ActionResult LkoHeritageWalkBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("HTW", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("HTW").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View();
        }
        #endregion

        #region Save Heritage Walk Booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoHeritageWalkBooking(LkoHTWBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (model.ArrivalDate < minDate.Date)
                {
                    _msg = "Arrival Date should be greater than Current Date!";
                    isValid = false;
                }
                else
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                        {
                            _msg = "Enter a valid 6 digit Pincode!";
                            isValid = false;
                        }
                        else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid 10 digit Mobile No.!";
                            isValid = false;
                        }
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();
                    }
                    if (string.IsNullOrEmpty(model.email))
                    {
                        ModelState["email"].Errors.Clear();
                    }

                    ModelState["arrivalTime"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {
                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "CWALK";
                    model.bookingFor = "WALK";
                    model.bookingBy = "UPT";
                    model.receiptNo = "UPT Payment";

                    var user = objBusinessClass.saveHTWBookingByUPTour(model);
                    if (user != null)
                    {
                        TempData["DocketNo"] = user.docketNo;

                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                        SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                        try
                        {
                            SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Heritage Walk Booking");
                            SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "WALK");
                        }
                        catch
                        { }

                        return RedirectToAction("HeritageWalkConfirmation");
                    }
                    else
                    {
                        _msg = "Heritage walk Not Booked!";
                    }
                }
            }
            catch
            {
                _msg = "Error in Lucknow Heritage walk Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("HTW", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("HTW").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageTourCategoryForUPT().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region Heritage Walk Booking Confirmation
        public ActionResult HeritageWalkConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End Heritage Walk Booking---------------------------*/


        /*----------------------One Day Tour Booking---------------------------*/

        #region Display One Day Tour Booking
        public ActionResult OnDayTourBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList(SessionManager.PackageCategoryID, "CITY").Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.Packages = objBusinessClass.getCityTourList(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View();
        }
        #endregion

        //[HttpGet]
        //public JsonResult getCityTourList(int packageCategoryID)
        //{
        //    IEnumerable<SelectListItem> obj = objBusinessClass.getCityTourList(packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
        //    return Json(obj, JsonRequestBehavior.AllowGet);
        //}

        #region Save One Day Tour Booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnDayTourBooking(OneDayTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _msg = "Enter a valid 6 digit Pincode!";
                        isValid = false;
                    }
                    else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                    {
                        _msg = "Enter a valid 10 digit Mobile No.!";
                        isValid = false;
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {
                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "CCITY";
                    model.bookingFor = "CITY";
                    model.bookingBy = "UPT";
                    model.receiptNo = "UPT Payment";

                    var user = objBusinessClass.saveOneDayTourBookingDetails(model);
                    if (user != null)
                    {
                        if (user.docketNo == "NA")
                        {
                            _msg = "This One Day Tour is not available on " + model.ArrivalDate.DayOfWeek + "!";
                        }
                        else if (user.docketNo == "NB")
                        {
                            _msg = "One Day Tour Not Booked!";
                        }
                        else
                        {
                            TempData["DocketNo"] = user.docketNo;

                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                            SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(user.docketNo);
                            try
                            {
                                SendOneDayBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "One Day Tour Booking");
                                SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "CITY");
                            }
                            catch
                            { }
                            return RedirectToAction("OneDayTourConfirmation");
                        }
                    }
                    else
                    {
                        _msg = "One Day Tour Not Booked!";
                    }
                }

            }
            catch
            {
                _msg = "Error in One Day Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList(SessionManager.PackageCategoryID, "CITY").Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.Packages = objBusinessClass.getCityTourList(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region One Day Tour Booking Confirmation
        public ActionResult OneDayTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
            }
            catch
            {
            }
            return View(model);
        }

        #endregion

        /*----------------------End One Day Tour Booking---------------------------*/


        /*----------------------AC Bus Tour Booking---------------------------*/

        #region AC Bus Tour Booking
        [HttpGet]
        public ActionResult ACBusTourBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Packages = objBusinessClass.GetACBusTourForUPT(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList(SessionManager.PackageCategoryID, "ACBUS").Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View();
        }
        #endregion

        #region Get AC Bus tour total amount
        [HttpGet]
        public ActionResult GetACBusTourTotalAmount(Int32 packageID, Int32 isIndian)
        {
            return Json(objBusinessClass.GetACBusTourTotalAmount(packageID, isIndian), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Save AC Bus tour booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ACBusTourBooking(ACBusTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _msg = "Enter a valid 6 digit Pincode!";
                        isValid = false;
                    }
                    else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                    {
                        _msg = "Enter a valid 10 digit Mobile No.!";
                        isValid = false;
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {

                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "CBUS";
                    model.bookingFor = "ACBUS";
                    model.bookingBy = "UPT";
                    model.receiptNo = "UPT Payment";

                    var user = objBusinessClass.saveACBusTourBookingDetails(model);
                    if (user != null)
                    {
                        if (user.docketNo == "NA")
                        {
                            _msg = "This AC Bus Tour is not available on " + model.ArrivalDate.DayOfWeek + "!";
                        }
                        else if (user.docketNo == "NB")
                        {
                            _msg = "AC Bus Tour Not Booked!";
                        }
                        else
                        {
                            TempData["DocketNo"] = user.docketNo;

                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                            SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(user.docketNo);
                            try
                            {
                                SendOneDayBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "AC Bus Tour Booking");
                                SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "ACBUS");
                            }
                            catch
                            { }
                            return RedirectToAction("ACBusTourConfirmation");
                        }
                    }
                    else
                    {
                        _msg = "AC Bus Tour Not Booked!";
                    }
                }
            }
            catch
            {
                _msg = "Error in AC Bus Tour Booking!";
            }

            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.Packages = objBusinessClass.GetACBusTourForUPT(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList(SessionManager.PackageCategoryID, "ACBUS").Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region AC Bus tour booking confirmation
        public ActionResult ACBusTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                var docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetUPTBookingDetails(docketNo);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        /*----------------------End AC Bus Tour Booking---------------------------*/

        /*----------------------Payment Details---------------------------*/

        #region Display payment list
        [HttpGet]
        public ActionResult PaymentDetails()
        {
            return View();
        }
        #endregion

        #region Get payment list
        [HttpGet]
        public ActionResult GetBookingPaymentList(string dtBookingFrom, string dtBookingTo, string docket, string bookingType)
        {
            UPTPaymentDetails model = new UPTPaymentDetails();
            try
            {
                if (string.IsNullOrEmpty(dtBookingFrom))
                {
                    dtBookingFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dtBookingTo))
                {
                    dtBookingTo = "01/01/1900";
                }

                model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.docketNo = docket;
                model.type = bookingType.Trim();

                model.paymentList = objBusinessClass.GetPaymentDetailsForUPT(model);
            }
            catch
            {

            }
            return PartialView("_PaymentDetails", model.paymentList);
        }
        #endregion

        #region Get advance amount
        [HttpGet]
        public ActionResult AdvancePaymentList(string docketNo)
        {
            string _msg;
            try
            {
                List<PaymentDetails> objPayment = objBusinessClass.GetAdvancePaymentForUPT(docketNo);

                if (objPayment != null && objPayment.Count > 0)
                {
                    return PartialView("_AdvancePaymentList", objPayment);
                }
                else
                {
                    _msg = "Details Not Found!!";
                }
            }
            catch
            {
                _msg = "Error in Process!";
            }
            ViewBag.Show = _msg;

            return Content("");
        }
        #endregion

        //[HttpGet]
        //public ActionResult PaymentList(string paymentDateFrom, string paymentDateTo, Int64 UnitId, string docketNo)
        //{
        //    string _msg;
        //    DateTime _payDateFrom, _payDateTo;
        //    try
        //    {
        //        try
        //        {
        //            _payDateFrom = DateTime.ParseExact(paymentDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
        //        }
        //        catch
        //        {
        //            //model.dtBookingDateFrom = null;
        //            _payDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
        //        }
        //        try
        //        {
        //            _payDateTo = DateTime.ParseExact(paymentDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
        //        }
        //        catch
        //        {
        //            //model.dtBookingDateTo = null;
        //            _payDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
        //        }

        //        Int64 _unitId = UnitId;
        //        //  _payDateFrom = Convert.ToDateTime(paymentDateFrom);
        //        //   _payDateTo = Convert.ToDateTime(paymentDateTo);
        //        List<PaymentDetails> objPayment = objBusinessClass.GetPackagePaymentDetailsForUPT(_payDateFrom, _payDateTo, _unitId, docketNo);
        //        if (objPayment != null && objPayment.Count > 0)
        //        {
        //            return PartialView("_PaymentList", objPayment);
        //        }
        //        else
        //        {
        //            _msg = "Details Not Found!!";
        //        }
        //    }
        //    catch
        //    {
        //        //return PartialView("_ErrorPagePartialWebsite");
        //        _msg = "Details Not Found!!";
        //    }
        //    ViewBag.Show = _msg;
        //    TempData["msg"] = _msg;
        //    return Json(new { result = true, message = "Unable to process!" });
        //}        

        /*----------------------End Payment Details---------------------------*/

        #region Added By Bramh


        /*----------------------Accept online cancellations---------------------------*/

        #region Display cancellation request by out Anonymous User------------ by Bramh
        [HttpGet]
        public ActionResult CancellationRequest()
        {
            //    BookingCancellation model = new BookingCancellation();
            try
            {
                //  Int64 _unitId = SessionManager.UnitID;
                //if (TempData["message"] != null && TempData["message"].ToString() != "")
                //{
                //    ViewBag.Show = TempData["message"];
                //}
                //model.lstCanceRequest = objBusinessClass.GetPackageCancilationRequestatUPT((docketNo == null) ? "" : docketNo);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region Get online cancelled requests
        [HttpGet]
        public ActionResult CancellationRequestFiltered(string docketNo, string fromDate, string toDate)
        {
            BookingCancellation model = new BookingCancellation();
            try
            {
                if (string.IsNullOrEmpty(fromDate))
                {
                    fromDate = "01/01/1900";
                }
                if (string.IsNullOrEmpty(toDate))
                {
                    toDate = "01/01/1900";
                }

                DateTime dateFrom = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                DateTime dateTo = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                model.lstCanceRequest = objBusinessClass.GetPackageCancilationRequestatUPT(docketNo, dateFrom, dateTo);
            }
            catch
            {

            }
            return PartialView("_cancelRequestGrid", model.lstCanceRequest);
        }
        #endregion

        #region Accept booking cancellation
        public ActionResult CancellationRequestConfirmation(string id)
        {
            int status = objBusinessClass.InsertCancellationConfirmation(id, this.Request.UserHostAddress);
            if (status > 0)
            {
                #region send mail and sms to user and concern authority
                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.GetContactForUPTours(id);
                SendAcceptanceSMS(id, IEContactDetails);
                SendAcceptanceEMail(id, IEContactDetails);
                #endregion

                return Content("1");
            }
            else
            {
                ViewBag.Show = "Unable to Accept!";
            }
            return Content("0");
        }
        #endregion

        #region to send sms on booking cancellation
        protected void SendAcceptanceSMS(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["AcceptCancelBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string customerOthers = ConfigurationManager.AppSettings["AcceptCancelBookingSMSOther"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerOthers = customerOthers.Replace("[DocketNo]", docketNo);
                try
                {
                    string SMSStatus = "";

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;

                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(customerOthers, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(customerOthers, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "CUSTOMER")
                            {
                                SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);     // Send SMS to Customer
                                SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UNIT")
                            {
                                SMSStatus = SMS.SMSSend(customerOthers, lst.MobileNo);     // Send SMS to concern unit
                                SMS.SMSLog(customerOthers, lst.MobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send mail on booking cancellation
        protected void SendAcceptanceEMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string subject = "UP Tourism Booking Cancellation Status";
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/AcceptCancelRequest.html"));
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", docketNo);

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/AcceptCancelRequest.html"));
                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);

                foreach (var lst in contactDetails)
                {
                    try
                    {
                        if (lst.sendTo == "UNIT")  // Send Email to Unit
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                        if (lst.sendTo == "NODAL")       // Send Email to Nodal Officer
                        {
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                        }
                        if (lst.sendTo == "CUSTOMER")       // Send Email to Nodal Officer
                        {
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                        }
                    }
                    catch { }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        //public ActionResult GetBookingDetail(string docketNo)
        //{
        //    SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
        //    //List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();

        //    try
        //    {

        //        obj_BookingDetail = objBusinessClass.GetCancilledBookingDetailsatUPT(docketNo, SessionManager.UnitID).FirstOrDefault();               
        //        if (obj_BookingDetail != null)
        //        {
        //            obj_BookingDetail.BookedRoomList = objBusinessClass.GetpackagedetailUnitwise(docketNo, SessionManager.UnitID);
        //        }

        //    }
        //    catch
        //    {

        //    }
        //    return PartialView("_BookingListDetails", obj_BookingDetail);

        //}     

        /*----------------------End Accept online cancellations---------------------------*/


        #endregion

        /* ----------------------------UP Tour Booking Cancellation---------------------------------*/

        #region Display CRS Booking Cancellation List
        [HttpGet]
        public ActionResult BookingCancellation()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding cancellation grid
        public ActionResult GetCancellationList(string docketNo, int bookingType, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetUPToursBookingForCancellation(docketNo, bookingType, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_BookingCancellationGrid", model.lstCanceRequest);
        }
        #endregion

        #region Print Booking Cancellation by Syed
        public ActionResult PrintBookingCancellation(string docketNo, int bookingType, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            DateTime _fromDate, _toDate;
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetUPToursBookingForCancellation(docketNo, bookingType, _fromDate, _toDate).ToList();
                return View(model.lstCanceRequest);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export cancel list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingCancellation(CRSBookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetUPToursBookingForCancellation(model.docketNo, model.bookingType, _fromDate, _toDate).ToList();

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, Package_Name = e.packageName, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate.ToShortDateString(), Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingCancellation.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};

            return View(model);
        }

        #endregion

        #region cancel CRS booking
        [HttpGet]
        public ActionResult CancelBooking(string docketNo)
        {
            try
            {
                CRSBookingCancellation model = new CRSBookingCancellation();
                string ipAddress = this.Request.UserHostAddress;
                model = objBusinessClass.CancelCRSBooking(docketNo, ipAddress);
                if (model != null && model.cancelRefNo != null && model.cancelRefNo != "")
                {
                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(docketNo);
                    //SendCancelRequestSMS(docketNo, IEContactDetails);
                    //SendCancelRequestEMail(docketNo, IEContactDetails, model.cancelRefNo, model.cancelConfirmationDate);
                    return Content(model.cancelRefNo);
                }
            }
            catch
            { }
            return Content("0");
        }
        #endregion

        /* ----------------------------End UP Tour Booking Cancellation---------------------------------*/



        /*-----------------------Common-------------------------*/

        #region Calculate tour total amount for package and city tours
        [HttpGet]
        public ActionResult GetTourTotalAmount(Int32 packageID, Int32 isIndian, Int32 noOfPersons)
        {
            return Json(objBusinessClass.GetTourTotalAmount(packageID, isIndian, noOfPersons), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Route Fare
        [HttpGet]
        public ActionResult GetSpecialPackegeFare(Int32 packageID, Int32 applicantTypeId)
        {
            return Json(objBusinessClass.GetSpecialPackegeFare(packageID, applicantTypeId), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method - get nationality
        public IEnumerable<SelectListItem> GetNationality()
        {
            var objNationality = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Indian";
            Temp.Value = "1";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Foreigner";
            Temp.Value = "0";
            objNationality.Add(Temp);

            return objNationality;
        }
        #endregion

        #region to send package tour booking mail
        protected void SendPackageTourMail(string docketNo, string mailTo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                PackageTransactionDetail model = objBusinessClass.GetPackageBookingDetails(docketNo);
                model.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(model.packageID);

                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/PackageBookingConfirmation_Customer.html"));
                string subjectCust = "UP Tourism Booking Confirmation";

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/PackageBookingConfirmation_Other.html"));
                string subjectOthers = "Booking Docket No. " + docketNo;

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);
                MailBody = MailBody.Replace("[duration]", model.duration);
                MailBody = MailBody.Replace("[noofpersons]", model.noOfTourists);
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);
                MailBody = MailBody.Replace("[meetingpoint]", model.meetingPoint);
                MailBody = MailBody.Replace("[amount]", model.amount.ToString());
                MailBody = MailBody.Replace("[bookingdate]", model.bookingDate);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);

                string accomStr = "";
                if (model.IEPackageAccomodation != null && model.IEPackageAccomodation.Count() > 0)
                {
                    accomStr = "<table>";

                    foreach (var accom in model.IEPackageAccomodation)
                    {
                        accomStr += "<tr><td colspan='2' style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.daySequence + "</td></tr>" +
                                     "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>City Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.cityname + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Unit Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitName + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Address</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitAddress + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Room Type</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.roomType + "</td></tr>";
                    }
                    accomStr += "</table>";
                }

                MailBody = MailBody.Replace("[accomodationdetails]", accomStr);


                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", model.docketNo);
                MailBodyOthers = MailBodyOthers.Replace("[packagename]", model.packageName);
                MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", model.subPackage);
                MailBodyOthers = MailBodyOthers.Replace("[duration]", model.duration);
                MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", model.noOfTourists);
                MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", model.arrivalDate);
                MailBodyOthers = MailBodyOthers.Replace("[meetingpoint]", model.meetingPoint);
                MailBodyOthers = MailBodyOthers.Replace("[amount]", model.amount.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[bookingdate]", model.bookingDate);
                MailBodyOthers = MailBodyOthers.Replace("[bookedby]", model.bookingBy);

                MailBodyOthers = MailBodyOthers.Replace("[customername]", model.name);
                MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", model.customerMobile);
                MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", model.customerAddress);
                MailBodyOthers = MailBodyOthers.Replace("[accomodationdetails]", accomStr);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subjectCust, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subjectCust, MailBody);

                        foreach (var lst in contactDetails)
                        {
                            try
                            {

                                if (lst.sendTo == "UNIT" || lst.sendTo == "NODAL" || lst.sendTo == "UPTOURS")
                                {
                                    //MailService.EmailData objMailOthers = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subjectOthers, toemail = lst.Email };
                                    //objService.sendMail(objMailOthers);
                                    SendMail.SendMailNew(lst.Email, subjectOthers, MailBodyOthers);
                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send package tour booking sms
        protected void SendPackageBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["PackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[PackageName]", spclPack.packageName);

                string ConcernPersonSMS = ConfigurationManager.AppSettings["PackageConcernPersonSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                ConcernPersonSMS = ConcernPersonSMS.Replace("[DocketNo]", docketNo);
                ConcernPersonSMS = ConcernPersonSMS.Replace("[PackageName]", spclPack.packageName);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["PackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.packageName);

                string UPTourSMS = ConfigurationManager.AppSettings["PackageUPTourSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.packageName);


                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "UNIT")
                            {
                                SMSStatus = SMS.SMSSend(ConcernPersonSMS, lst.MobileNo);    // Send SMS to Unit
                                SMS.SMSLog(ConcernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch
                        {
                        }
                    }
                }
                catch
                {

                }
            }
            catch
            {

            }
        }
        #endregion

        #region to send one day tour booking sms
        protected void SendOneDayBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack, string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["OneDayBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace(" [PackageName]", spclPack.packageName);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["OneDayNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace(" [PackageName]", spclPack.packageName);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["OneDayUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace(" [PackageName]", spclPack.packageName);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send special package booking mail
        protected void SendSpecialPackageMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails, string mailTo, string bookingType)
        {
            try
            {
                SpecialBookedDetail model = objBusinessClass.GetUPTBookingDetails(docketNo);

                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/SpecialPackBookingConfirmation_Customer.html"));
                string subjectCust = "UP Tourism Booking Confirmation";

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/SpecialPackBookingConfirmation_Other.html"));
                string subjectOthers = "Booking Docket No. " + docketNo;

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);
                MailBody = MailBody.Replace("[noofpersons]", model.noOfPerson.ToString());
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);
                MailBody = MailBody.Replace("[amount]", model.advanceAmount.ToString());
                MailBody = MailBody.Replace("[bookingdate]", model.bookingDate);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);

                string arrivalTime = "";
                if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                {
                    arrivalTime = "<tr>";
                    arrivalTime += "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Arrival Time</td>" +
                             "<td style='font-size: 12px; font-weight: 500; padding: 8px; color: #464646;'>" + model.arrivalTime.ToShortTimeString() + "</td>";
                    arrivalTime += "</tr>";
                }

                MailBody = MailBody.Replace("[arrivaltime]", arrivalTime);

                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", model.docketNo);
                MailBodyOthers = MailBodyOthers.Replace("[packagename]", model.packageName);
                MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", model.subPackage);
                MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", model.noOfPerson.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", model.arrivalDate);
                MailBodyOthers = MailBodyOthers.Replace("[amount]", model.advanceAmount.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[bookingdate]", model.bookingDate);
                MailBodyOthers = MailBodyOthers.Replace("[bookedby]", model.bookingBy);

                MailBodyOthers = MailBodyOthers.Replace("[customername]", model.name);
                MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", model.mobileNo);
                MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", model.customerAddress);

                MailBodyOthers = MailBodyOthers.Replace("[arrivaltime]", arrivalTime);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subjectCust, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subjectCust, MailBody);
                        foreach (var lst in contactDetails)
                        {
                            try
                            {

                                if (lst.sendTo == "NODAL" || lst.sendTo == "UPTOURS")
                                {
                                    //MailService.EmailData objMailOthers = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subjectOthers, toemail = lst.Email };
                                    //objService.sendMail(objMailOthers);
                                    SendMail.SendMailNew(lst.Email, subjectOthers, MailBodyOthers);
                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {

                    }
                }

            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send special tour booking sms
        protected void SendSpecialBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack, string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["SplPackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[PackageName]", spclPack.packageName);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["SplPackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.packageName);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["SplPackageUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.packageName);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send special package booking mail
        protected void SendReplyMail(BusTaxiEnquiryReply model)
        {
            try
            {
                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BusTaxiEnquiryReply.html"));
                string subject = "Quotation for UP Tourism " + model.enquiryType + " Booking.";

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[name]", model.name);
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[enquiryno]", model.enquiryNo);
                MailBody = MailBody.Replace("[amount]", model.amount.ToString());
                MailBody = MailBody.Replace("[remark]", model.remark);
                MailBody = MailBody.Replace("[document]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + model.documentPath);
                MailBody = MailBody.Replace("[url]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + "UPTourism/TaxiBusQuotation/" + Server.UrlEncode(EncryptionDecryption.EncodeTo64(model.enquiryNo)));

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(model.email)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        SendMail.SendMailNew(model.email, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.email };
                        //objService.sendMail(objMail);

                        //MailService.EmailData objMailNew = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMailNew);
                    }
                    catch
                    {

                    }
                }

            }
            catch (Exception)
            {
            }
        }
        #endregion

        /*--------------------End Common------------------------*/


        [HttpGet]
        public ActionResult GetBookingDetailOldRoomType(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            string _msg = "";
            try
            {

                obj_BookingList = objBusinessClass.GetUnitBookingDetailsOldRoomType(docketNo, SessionManager.UnitID);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.BookedRoomList = objBusinessClass.GetBookedRoomDetailsOldRoomType(docketNo, SessionManager.UnitID);
                    return PartialView("_BookingListDetailsOldRoomType", obj_BookingDetail);
                }
                //if (obj_BookingDetail != null)
                //{
                //    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                //    return PartialView("_BookingListDetails", obj_BookingDetail);
                //}
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }

        /* ---------------------------Cancellation List---------------------------------*/

        #region Display cancelled booking list
        [HttpGet]
        public ActionResult CancelledBooking()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding cancelled booking grid
        public ActionResult GetCancelledBookingList(string docketNo, int bookingType, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCancelledBookingUPT(docketNo.Trim(), bookingType, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_CancelledBookingGrid", model.lstCanceRequest);
        }
        #endregion

        #region Print Cancellations by Syed
        public ActionResult PrintCancellations(string docketNo, int bookingType, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            DateTime _fromDate, _toDate;
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCancelledBookingUPT(docketNo.Trim(), bookingType, _fromDate, _toDate).ToList();
                return View(model.lstCanceRequest);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export cancelled booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CancelledBooking(CRSBookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetCancelledBookingUPT(model.docketNo, model.bookingType, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, Package_Name = e.packageName, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate.ToShortDateString(), Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Cancellation_Ref_No = e.cancelRefNo, Cancellation_Date = e.cancelConfirmationDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/CancelledBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Cancellation List---------------------------------*/

        /*------------------Online Bus/Taxi Enquiries Report----------------*/

        #region display online bus taxi enquiry list
        [HttpGet]
        public ActionResult OnlineBusTaxiEnquiry()
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            try
            {
                ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.uptourId = SessionManager.PackageCategoryID;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBusTaxiEnquiryList(string dateFrom, string dateTo, string enquiryNo)
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.uptourId = SessionManager.PackageCategoryID;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineBusTaxiEnquiry", model.busTaxiEnquiryList);
        }
        #endregion

        #region Print Online Bus Enquiry Details by Syed
        public ActionResult PrintOnlineBusEnquiryDetails(string dateFrom, string dateTo, string enquiryNo)
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.uptourId = SessionManager.PackageCategoryID;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
                return View(model.busTaxiEnquiryList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export bus/ taxi enquiry list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineBusTaxiEnquiry(BusTaxiEnquiryReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);
            model.uptourId = SessionManager.PackageCategoryID;

            var dtresult = objBusinessClass.GetBusTaxiEnquiryList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Enquiry_Date = e.enquiryDate, Enquiry_Type = e.enquiryType, Pickup_Date = e.pickupDate.ToString("dd/MM/yyyy"), Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Status = e.bookingStatus, Booked_By = e.bookingBySlug }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineBusTaxiEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.busTaxiEnquiryList = dtresult;
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });

            return View(model);
        }
        #endregion

        #region get bus/ taxi enquiry details
        [HttpGet]
        public ActionResult GetBusTaxiEnquiryDetail(string enquireNo)
        {
            BusTaxiEnquiry model = new BusTaxiEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetTaxiBusEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineBusTaxiEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        #region display reply screen
        [HttpGet]
        public ActionResult ReplyBusTaxiEnquiry(string id)
        {
            BusTaxiEnquiryReply model = new BusTaxiEnquiryReply();
            try
            {
                if (TempData["message"] != null)
                {
                    ViewBag.Message = TempData["message"];
                }
                model = objBusinessClass.GetTaxiBusEnquiryDetails(id);
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region save reply
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReplyBusTaxiEnquiry(BusTaxiEnquiryReply model)
        {
            string returnMessage = "";
            try
            {
                if (ModelState.IsValid)
                {
                    model.userIP = this.Request.UserHostAddress;
                    model.userID = SessionManager.UserID;
                    string documentPath = "";
                    string res = objCommonClass.ValidateFile(model.document);
                    if (res != "Valid")
                    {
                        returnMessage = res;
                        return View(model);
                    }
                    else
                    {
                        documentPath = SaveDocument(model.document);
                        model.documentPath = documentPath;
                    }

                    var user = objBusinessClass.SaveBusTaxiEnquiryReply(model);
                    if (user > 0)
                    {
                        model = objBusinessClass.GetTaxiBusEnquiryDetails(model.enquiryNo);
                        if (model != null)
                        {
                            model.documentPath = documentPath;
                            try
                            {
                                SendReplyMail(model);
                                TempData["message"] = "Reply successfully done to Enquiry No. " + model.enquiryNo;
                                return RedirectToAction("ReplyBusTaxiEnquiry");
                            }
                            catch
                            {
                                returnMessage = "Mail not sent.";
                            }
                        }
                        else
                        {
                            returnMessage = "Mail not sent.";
                        }
                    }
                    else
                    {
                        returnMessage = "Error in sending reply.";
                    }
                    ViewBag.Message = returnMessage;
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region Save uploaded document
        public string SaveDocument(HttpPostedFileBase document)
        {
            string documentPath = "";
            try
            {
                if (document != null)
                {
                    string ext = Path.GetExtension(document.FileName);
                    string filename = Path.GetFileName("Quotation" + DateTime.Now.Ticks + ext);

                    documentPath = Path.Combine("Content/writereaddata/Documents", filename);
                    var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                    document.SaveAs(docPath);
                }
            }
            catch
            { }
            return documentPath;
        }
        #endregion


        /*-----------------End Online Bus/Taxi Enquiries Report-------------*/

        /*------------------Counter Bus/Taxi Enquiries Booking----------------*/

        #region Display bus/ taxi booking
        [HttpGet]
        public ActionResult TaxiBusBooking()
        {
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).Where(m => m.Value == SessionManager.PackageCategoryID.ToString());
            return View();
        }
        #endregion

        #region save bus/ taxi enquiry
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusBooking(BusTaxiBooking model)
        {
            string returnMessage = "";

            try
            {
                ModelState["pickupTime"].Errors.Clear();
                ModelState["Captcha"].Errors.Clear();
                ModelState["message"].Errors.Clear();
                if (ModelState.IsValid)
                {
                    model.ipAddress = this.Request.UserHostAddress;
                    model.bookingBy = "UPT";
                    if (model.document != null)
                    {
                        string documentPath = "";
                        string res = objCommonClass.ValidateFile(model.document);
                        if (res != "Valid")
                        {
                            returnMessage = res;
                            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).Where(m => m.Value == SessionManager.PackageCategoryID.ToString());
                            return View(model);
                        }
                        else
                        {
                            documentPath = SaveDocument(model.document);
                            model.documentPath = documentPath;
                        }
                    }
                    BusTaxiBooking result = objBusinessClass.InsertBusTaxiBooking(model);
                    if (result != null)
                    {
                        try
                        {
                            ModelState.Clear();
                            TempData["docketNo"] = result.docketNo;
                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(result.docketNo);
                            var bookingType = IEContactDetails.Select(m => m.BookingFor).FirstOrDefault();
                          
                            string smsfor = bookingType == "BUS" ? "Bus Booking" : "Taxi Booking";
                            SendBusTaxiBookSms(result.docketNo, model.mobileNo, IEContactDetails, smsfor, model.pickupDate.ToString("dd/MM/yyyy"), Convert.ToDateTime(model.pickupTime));
                            SendBusTaxiMail(result.docketNo, "cust", model.email, bookingType);
                            foreach (var lst in IEContactDetails)
                            {
                                SendBusTaxiMail(result.docketNo, "upt", lst.Email, bookingType);
                            }
                           
                            return RedirectToAction("TaxiBusBookingConfirmation");
                        }
                        catch
                        { }
                        ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).Where(m => m.Value == SessionManager.PackageCategoryID.ToString());
                        return View(model);
                    }
                }

            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region taxi/bus booking confirmation
        public ActionResult TaxiBusBookingConfirmation()
        {
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            try
            {               
                if (TempData.Peek("docketNo") != null)
                {
                    model = objBusinessClass.GetTaxiBusCounterBookingDetails(TempData.Peek("docketNo").ToString());
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region to send bus/taxi booking sms
        protected void SendBusTaxiBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string smsFor, string pickupDate, DateTime pickupTime)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["BusTaxiBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[PickupDate]", pickupDate);
                customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                string NodalOfficerSMS = ConfigurationManager.AppSettings["BusTaxiNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PickupDate]", pickupDate);
                customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                string UPTourSMS = ConfigurationManager.AppSettings["BusTaxiUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PickupDate]", pickupDate);
                customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send bus/taxi booking mail
        protected void SendBusTaxiMail(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                BusTaxiBookingDetails model = objBusinessClass.GetTaxiBusCounterBookingDetails(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/TaxiBusCounterBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/TaxiBusCounterBookingConfirmation.html"));
                    subject = "Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[fromcity]", model.fromCityName);
                MailBody = MailBody.Replace("[tocity]", model.toCity);
                MailBody = MailBody.Replace("[journeydate]", model.dateOfJourney);
                MailBody = MailBody.Replace("[returndate]", model.dateOfReturn);
                MailBody = MailBody.Replace("[pickupdate]", model.pickupDate);
                MailBody = MailBody.Replace("[pickuptime]", model.pickupTime.ToShortTimeString());
                MailBody = MailBody.Replace("[pickupaddress]", model.pickupAddress);
                MailBody = MailBody.Replace("[amount]", model.transactionAmount);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);               

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);

                    }
                    else
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        /*-----------------End Counter Bus/Taxi Booking-------------*/


        /*------------------Taxi/Bus Booking List ----------------*/

        #region display Taxi/Bus booking list
        [HttpGet]
        public ActionResult TaxiBusBookedList()
        {
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetTaxiBusBookedList(string dateFrom, string dateTo, string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }               
               
                model.docketNo = docketNo.Trim();
                model.uptourId = SessionManager.PackageCategoryID;
                model.busTaxiBookingList = objBusinessClass.GetTaxiBusBookingList(model);
            }
            catch
            {
            }
            return PartialView("_TaxiBusBookedList", model.busTaxiBookingList);
        }
        #endregion

        #region Print Bus Booking Details by Syed
        public ActionResult PrintBusBookingDetails(string dateFrom, string dateTo, string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                ViewBag.fromdate = model.dateFrom == null ? "-" : ((DateTime)model.dateFrom).ToString("dd/MM/yyyy");
                ViewBag.todate = model.dateTo == null ? "-" : ((DateTime)model.dateTo).ToString("dd/MM/yyyy");
                model.uptourId = SessionManager.PackageCategoryID;
                model.docketNo = docketNo.Trim();
                var dtresult = objBusinessClass.GetTaxiBusBookingList(model);
                return View(dtresult);
            }
            catch { }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusBookedList(BusTaxiBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            model.uptourId = SessionManager.PackageCategoryID;
            var dtresult = objBusinessClass.GetTaxiBusBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Booking_Date = e.bookingDate, Booking_Type = e.bookingType, Pickup_Date = e.pickupDate, Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity,  Amount = e.transactionAmount, Booked_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.busTaxiBookingList = dtresult;
            return View(model);
        }
        #endregion


        #region get bus/ taxi booking details
        [HttpGet]
        public ActionResult GetBusTaxiBookingDetail(string docketNo)
        {
            BusTaxiBookingReport objSearch = new BusTaxiBookingReport();
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            string _msg = "";
            try
            {
                objSearch.docketNo = docketNo;
                objSearch.uptourId = SessionManager.PackageCategoryID;

                model = objBusinessClass.GetTaxiBusBookingList(objSearch).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_TaxiBusBookedDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        /*-----------------End Taxi/Bus Booking Guest Wise Report-------------*/

        /*------------------Taxi/Bus Booking List by Bramh ----------------*/

        #region display real Time Bus/Taxi booking list
        [HttpGet]
        public ActionResult BusTaxiBookedList()
        {
            return View();
        }
        #endregion


        [HttpGet]
        public ActionResult ReleasedTaxiList()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReleasedTaxiList(BusTaxiBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            model.uptourId = SessionManager.PackageCategoryID;
            var dtresult = objBusinessClass.GetReleasedListTaxi(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Booking_Date = e.bookingDate, Booking_Type = e.bookingType, Pickup_Date = e.dateOfJourney, Drop_Date = e.dropDate, Duration = e.Duration, Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Amount = e.billAmount, Booked_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.busTaxiBookingList = dtresult;
            return View(model);
        }

        public ActionResult GetReleasedTaxiList(string dateFrom, string dateTo, string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.uptourId = SessionManager.PackageCategoryID;
                model.busTaxiBookingList = objBusinessClass.GetReleasedListTaxi(model);
            }
            catch
            {
            }
            return PartialView("_TaxiReleasedList", model.busTaxiBookingList);
        }

        #region Print Taxi Released List
        public ActionResult PrintTaxiReleasedList(string dateFrom, string dateTo, string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.uptourId = SessionManager.PackageCategoryID;
                model.busTaxiBookingList = objBusinessClass.GetReleasedListTaxi(model);
                return View(model.busTaxiBookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        public ActionResult GetTaxiReleasedDetail(string docketNo)
        {
            BusTaxiBookingReport objSearch = new BusTaxiBookingReport();
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            string _msg = "";
            try
            {
                objSearch.docketNo = docketNo;
                objSearch.uptourId = SessionManager.PackageCategoryID;

                model = objBusinessClass.GetReleasedListTaxi(objSearch).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_BusTaxiBookedListDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }

        #region bind booking grid
        public ActionResult GetBusTaxiBookedList(string dateFrom, string dateTo, string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.uptourId = SessionManager.PackageCategoryID;
                model.busTaxiBookingList = objBusinessClass.GetBookingListBusTaxi(model);
            }
            catch
            {
            }
            return PartialView("_BusTaxiBookedList", model.busTaxiBookingList);
        }
        #endregion

        #region Print Taxi Booking Details by Syed
        public ActionResult PrintTaxiBookingDetails(string dateFrom, string dateTo, string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                ViewBag.fromdate = model.dateFrom == null ? "-" : ((DateTime)model.dateFrom).ToString("dd/MM/yyyy");
                ViewBag.todate = model.dateTo == null ? "-" : ((DateTime)model.dateTo).ToString("dd/MM/yyyy");
                model.uptourId = SessionManager.PackageCategoryID;
                model.docketNo = docketNo.Trim();
                var dtresult = objBusinessClass.GetBookingListBusTaxi(model);
                return View(dtresult);
            }
            catch { }
            return View();

        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BusTaxiBookedList(BusTaxiBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            model.uptourId = SessionManager.PackageCategoryID;
            var dtresult = objBusinessClass.GetBookingListBusTaxi(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Booking_Date = e.bookingDate, Booking_Type = e.bookingType, Pickup_Date = e.dateOfJourney, Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Amount = e.transactionAmount, Booked_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.busTaxiBookingList = dtresult;
            return View(model);
        }
        #endregion


        #region get bus/ taxi booking details
        [HttpGet]
        public ActionResult GetTaxiBusBookingDetail(string docketNo)
        {
            BusTaxiBookingReport objSearch = new BusTaxiBookingReport();
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            string _msg = "";
            try
            {
                objSearch.docketNo = docketNo;
                objSearch.uptourId = SessionManager.PackageCategoryID;

                model = objBusinessClass.GetBookingListBusTaxi(objSearch).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_BusTaxiBookedListDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        /*-----------------End Taxi/Bus Booking Guest Wise Report-------------*/


        [HttpGet]
        public ActionResult BusTaxiBooking()
        {
            UP_TourismConnection db = new UP_TourismConnection();

            ViewBag.bus = objBusinessClass.GetBusTaxiNameList("B", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            ViewBag.taxi = objBusinessClass.GetBusTaxiNameList("T", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();

            ViewBag.departuretime = GetTimeList();
            ViewBag.UPTourCity = objBusinessClass.GetFromCityBusTaxiListByUpToursId(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).ToList();
            ViewBag.UPTourDestinationCity = objBusinessClass.GetDestinationCityBusTaxiList().Select(e => new SelectListItem() { Text=e.label,Value=e.value.ToString()});
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text=e.countryName,Value=e.countryID.ToString()}).ToList();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() }).ToList();
            ViewBag.Nationality=GetNationality();
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() }).ToList();
            UPTBusTaxibooking bustaxibooking = new UPTBusTaxibooking();
            bustaxibooking.duration = 0;
            bustaxibooking.distance = 0;
            bustaxibooking.noofpersons = 0;
            bustaxibooking.age = 0;
            bustaxibooking.noofvehicles = 0;
            return View(bustaxibooking);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BusTaxiBooking(UPTBusTaxibooking bustaxibooking)
        {
            //ModelState["packagecategory"].Errors.Clear();
            
            UP_TourismConnection db = new UP_TourismConnection();

            ViewBag.bus = objBusinessClass.GetBusTaxiNameList("B",SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            ViewBag.taxi = objBusinessClass.GetBusTaxiNameList("T",SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();

            ViewBag.departuretime = GetTimeList();
            ViewBag.UPTourCity = objBusinessClass.GetFromCityBusTaxiListByUpToursId(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).ToList();
            ViewBag.UPTourDestinationCity = objBusinessClass.GetDestinationCityBusTaxiList().Select(e => new SelectListItem() { Text = e.label, Value = e.value.ToString() });
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text=e.countryName,Value=e.countryID.ToString()}).ToList();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() }).ToList();
            ViewBag.Nationality = GetNationality();
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() }).ToList();
            if (bustaxibooking.duration == 0)
            {
                ModelState.AddModelError("duration", "Value cannot be 0!");
            }
            if (bustaxibooking.distance == 0)
            {
                ModelState.AddModelError("distance", "Value cannot be 0!");
            }
            if (bustaxibooking.noofpersons == 0)
            {
                ModelState.AddModelError("noofpersons", "Value cannot be 0!");
            }
            if (bustaxibooking.busortaxi == "B" && bustaxibooking.busid == null)
            {
                ModelState.AddModelError("busid", "Select Bus!");
            }
            else if (bustaxibooking.busortaxi == "T" && bustaxibooking.taxiid == null)
            {
                ModelState.AddModelError("taxiid", "Select Taxi!");
            }
            if (bustaxibooking.countryID==98)
            {
                if (bustaxibooking.stateID == null)
                {
                    ModelState.AddModelError("stateID", "Select State!");
                }
                if (bustaxibooking.cityID == null)
                {
                    ModelState.AddModelError("cityID", "Select City!");
                }
            }
            if (bustaxibooking.advanceamount != null)
            {
                if (string.IsNullOrEmpty(bustaxibooking.receiptno))
                {
                    ModelState.AddModelError("receiptno", "Enter Receipt No.");
                }
                if (bustaxibooking.paymentdate == null)
                {
                    ModelState.AddModelError("paymentdate", "Enter Payment Date");
                }
            }
            if (bustaxibooking.bookingtype == "local")
            {
                bustaxibooking.toCity = bustaxibooking.fromCity;
                bustaxibooking.toCityId = bustaxibooking.fromCityId;
            }
            else
            {
                if (bustaxibooking.toCityId == null)
                {
                    ModelState.AddModelError("toCityId", "Select To City!");
                }
            }
            if (ModelState.IsValid)
            {   
                string docketno= objBusinessClass.insertbustaxibookingdetails(bustaxibooking, this.Request.UserHostAddress);
                Session["docket"] = docketno;
                return RedirectToAction("BusTaxiBookingConfirmation", "UPT");
           }
            return View(bustaxibooking);
        }


        #region Method - get Time Value in List
        public IEnumerable<SelectListItem> GetTimeList()
        {

            string Time24 = "";
            string Time12 = "";

            var objTimeList = new List<SelectListItem>();
            SelectListItem Temp;
            int SpanValue = 00;
            for (int i = 0; i < 96; i++)
            {
                TimeSpan spanetst = TimeSpan.FromMinutes(SpanValue);
                DateTime time = DateTime.Today + spanetst;
                Time12 = time.ToString("hh:mm tt");

                DateTime getTime24 = DateTime.Parse(Time12);
                getTime24.ToString("HH:mm");
                Time24 = getTime24.TimeOfDay.ToString();

                Temp = new SelectListItem();
                Temp.Text = Time12;
                Temp.Value = Time24;
                objTimeList.Add(Temp);
                SpanValue = SpanValue + 15;
            }

            return objTimeList;
        }
        #endregion


        public JsonResult getTariff(Int64? bustaxiid, int? duration, int? km, string bookingtype, string departuretime, decimal? guidetariff, int? noofvehicles)
        {
            guidetariff = guidetariff ?? 0;
            noofvehicles = noofvehicles ?? 0;
            List<string> tariff = new List<string>();
            string servicetaxper = ConfigurationManager.AppSettings["ServiceTaxBusTaxi"];
            List<decimal> basetariff = objBusinessClass.getBusTaxitariff(bustaxiid, duration, km, bookingtype, departuretime).ToList();
            tariff.Add(servicetaxper);
            //decimal? guidetarifftotal = guidetariff * duration;
            tariff.Add((basetariff.FirstOrDefault() * noofvehicles).ToString());
            tariff.Add(guidetariff.ToString());
            return Json(tariff);
        }

        public JsonResult getguidetariff(int? noofperson, int? duration = 0)
        {
            string servicetaxper = ConfigurationManager.AppSettings["ServiceTaxBusTaxi"];
            decimal? guideperday = objBusinessClass.getguidetariffbynoofperson(noofperson);
            decimal? guide = guideperday * duration;
            List<string> guidetf = new List<string>();
            guidetf.Add(servicetaxper);
            guidetf.Add(guide.ToString());
            return Json(guidetf);
        }

        public ActionResult BusTaxiBookingConfirmation()
        {
            UP_TourismConnection db=new UP_TourismConnection();
            bustaxibookingconfirm bustaxiconfirm = null;
            if (Session["docket"] != null)
            {
                string docket = (string)Session["docket"];
                //string docket = "BUS16000025";
                List<bustaxibookingconfirm> detail = objBusinessClass.getbustaxibookingconfirmation(docket).ToList();
                if (detail != null)
                {
                    bustaxiconfirm = detail.FirstOrDefault();
                }
            }
            return View(bustaxiconfirm);
        }




        /*----------------------Relese Bus Taxi-------------------------------*/
        [HttpGet]
        public ActionResult ReleseTaxiPre()
        {
            ReleseBusTaxi model = new ReleseBusTaxi();

            return View(model);

        }

        public ActionResult GetBusTaxiBookingDetails(string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            ReleseBusTaxi mod = new ReleseBusTaxi();
            try
            {
                model.docketNo = docketNo.Trim();
                model.uptourId = SessionManager.PackageCategoryID;
                mod.busTaxiBookingList = objBusinessClass.GetBookingListBusTaxi(model).ToList();
                mod.busTaxiDetails = objBusinessClass.GetBusTaxiDetail(SessionManager.PackageCategoryID, mod.busTaxiBookingList[0].BusTaxiId).ToList();
                mod.ReleseDate = DateTime.Now.Date;
                mod.DocketNo = docketNo;
                if (mod.busTaxiBookingList.Count > 0)
                {
                    if (mod.busTaxiDetails.Count > 0)
                    {
                        return PartialView("_BusTaxiReleseDetails", mod);
                    }
                    else
                    {
                        return PartialView("NA");
                    }
                }
                else
                {
                    return PartialView("C");
                }
            }
            catch
            {
                return PartialView("NA");
            }
           
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReleseTaxiPre(ReleseBusTaxi model)
        {
            decimal total = 0, balanceamt = 0;
            
            if (ModelState.IsValid)
            {
                try
                {
                    ModelState.Clear();
                    BusTaxiBookingReport mo = new BusTaxiBookingReport();
                    mo.docketNo = model.DocketNo.Trim();
                    mo.uptourId = SessionManager.PackageCategoryID;
                    var details = objBusinessClass.GetBookingListBusTaxi(mo).ToList().FirstOrDefault();
                    balanceamt = details.BalanceAmount;
                    model.BusTaxiId = details.BusTaxiId;
                    model.RequestId = details.RequestId;

                    total = model.ExtraKmCharges + model.ExtraNightHaltCharges + model.ExtrHoursCharges + balanceamt + model.OtherAmount;
                    model.NetPaybal = total;
                    var a = objBusinessClass.InsertBillDetails(model);
                    if (a != null)
                    {
                        SessionManager.BillNo = a.billNo;
                        SessionManager.DocketNo = a.DocketNo;
                        return RedirectToAction("ReleseConfirmation");
                    }
                    else
                    {
                        TempData["usMsg"] = "Fail to Relese BusTaxi.";
                        return RedirectToAction("ReleseTaxiPre");
                    }
                }
                catch(Exception ex)
                {
                    TempData["usMsg"] = ex.Message;
                    return RedirectToAction("ReleseTaxiPre");
                }
                
            }
            TempData["usMsg"] = "Model State is Not Valid";
            return RedirectToAction("ReleseTaxiPre");

        }
        /*----------------------End Relese Bus Taxi-------------------------------*/

        public ActionResult ReleseConfirmation()
        {
            ReleseBusTaxi model = new ReleseBusTaxi();
            model.DocketNo = SessionManager.DocketNo;
            model.billNo = SessionManager.BillNo;
            return View(model);
        }

        public ActionResult ReleseBill(string docketNo)
        {
            if (string.IsNullOrEmpty(docketNo))
            {
                return RedirectToAction("ReleseConfirmation");
            }
            else
            {
                BusTaxiBillDetails model = objBusinessClass.GetBusTaxiBillDetail(docketNo);
                if (model != null)
                {
                    return View(model);
                }
                else
                {
                    return RedirectToAction("ReleseConfirmation");
                }
            }
           
        }

        public ActionResult TaxiReleseBill(string docketNo)
        {
            if (string.IsNullOrEmpty(docketNo))
            {
                return RedirectToAction("ReleseConfirmation");
            }
            else
            {
                BusTaxiBillDetails model = objBusinessClass.GetBusTaxiBillDetail(docketNo);
                if (model != null)
                {
                    if (DateTime.ParseExact(model.ArrivalDate, "dd/MM/yyyy", null) < new DateTime(2017, 07, 1))
                    {
                        return View(model);
                    }
                    else
                    {
                        return RedirectToAction("TaxiReleseBillGST", new { @docketNo =docketNo});
                    }
                }
                else
                {
                    return RedirectToAction("ReleseConfirmation");
                }
            }

        }

        public ActionResult TaxiReleseBillGST(string docketNo)
        {
            if (string.IsNullOrEmpty(docketNo))
            {
                return RedirectToAction("ReleseConfirmation");
            }
            else
            {
                BusTaxiBillDetails model = objBusinessClass.GetBusTaxiBillDetail(docketNo);
                if (model != null)
                {
                    return View(model);
                }
                else
                {
                    return RedirectToAction("ReleseConfirmation");
                }
            }

        }
        

    }
}
