﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Mvc;
using UP_TourismBooking.Models.ProcessClasses;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models;
using System.Globalization;
using System.Data;
using System.IO;
using System.Xml.Linq;
using System.Configuration;
using System.Web.Hosting;

namespace UP_TourismBooking.Controllers
{
    [AuthorizeHeadQuarter]
    public class HeadQuarterController : Controller
    {

        public ActionResult Dashboard()
        {
            return View();
        }
        #region Declarations
        BusinessClass objBusinessClass = new BusinessClass();
        Common objCommonClass = new Common();
        #endregion                     

        /* ---------------------------Daily Sale  Report---------------------------------*/

        public ActionResult ViewDailySaleReport()
        {
            return View();
        }

        public ActionResult GetDailySalereport(string date)
        {
            FillSaleReport model = new FillSaleReport();
            IFormatProvider dfor = new CultureInfo("en-GB").DateTimeFormat;
            DateTime dateto = DateTime.ParseExact(date, "dd/MM/yyyy", dfor);

            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            model.CurrentMonthYear = "From " + System.Environment.NewLine + "01/" + Convert.ToString(dateto.Month) + "/" + Convert.ToString(dateto.Year) + System.Environment.NewLine + " To " + System.Environment.NewLine + dateto.ToString("dd/MM/yyyy");
            model.TotalRevenueHQPreviousYear = dt.AddYears(-1).ToString("dd/MM/yyyy");

            model.DalySalelist = objBusinessClass.GetDalySaleReportforView(0, DateTime.Now, dateto, 2);

            model.DalySalelist.ToList().FirstOrDefault().CurrentMonthYear = model.CurrentMonthYear;
            model.DalySalelist.ToList().FirstOrDefault().TotalRevenueHQPreviousYear = model.TotalRevenueHQPreviousYear;

            return View("_DailySaleReportGrid", model.DalySalelist);
        }

        public ActionResult printDailySaleReport(string date)
        {
            ViewBag.Date = date;
            FillSaleReport model = new FillSaleReport();
            IFormatProvider dfor = new CultureInfo("en-GB").DateTimeFormat;
            DateTime dateto = DateTime.ParseExact(date, "dd/MM/yyyy", dfor);

            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            model.CurrentMonthYear = "From " + System.Environment.NewLine + "01/" + Convert.ToString(dateto.Month) + "/" + Convert.ToString(dateto.Year) + System.Environment.NewLine + " To " + System.Environment.NewLine + dateto.ToString("dd/MM/yyyy");
            model.TotalRevenueHQPreviousYear = dt.AddYears(-1).ToString("dd/MM/yyyy");

            model.DalySalelist = objBusinessClass.GetDalySaleReportforView(0, DateTime.Now, dateto, 2);

            model.DalySalelist.ToList().FirstOrDefault().CurrentMonthYear = model.CurrentMonthYear;
            model.DalySalelist.ToList().FirstOrDefault().TotalRevenueHQPreviousYear = model.TotalRevenueHQPreviousYear;

            return View(model.DalySalelist);

        }

        /* ---------------------------End Daily Sale  Report---------------------------------*/

    }
}
