﻿using SRVTextToImage;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models;
using UP_TourismBooking.Models.DataModels;

namespace UP_TourismBooking.Controllers
{
    public class SpecialBookingsController : Controller
    {

        BusinessClass objBusinessClass = new BusinessClass();
        private Regex pinCode = new Regex(@"^(\d{6})$", RegexOptions.Compiled);
        private Regex mobileNo = new Regex(@"^(\d{10})$", RegexOptions.Compiled);
        //
        // GET: /SpecialBookings/

        public ActionResult ParamotorBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.StateDATA = Enumerable.Empty<SelectListItem>();
            ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
            ViewBag.RideDateList = Enumerable.Empty<SelectListItem>();
            return View();
        }


        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ParamotorBooking(ParamotorBookingModel model)
        {
            #region Manage DropDown
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            if (model != null && model.countryID == 98)
            {
                ViewBag.StateDATA = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.CityDATA = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.StateDATA = Enumerable.Empty<SelectListItem>();
                ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
            }
            #endregion

            ModelState["Captcha"].Errors.Clear();
            ModelState["isAmountCalculated"].Errors.Clear();
            if (model.countryID == 98)
            {
                ModelState["otherState"].Errors.Clear();
                ModelState["otherCity"].Errors.Clear();

                if (!pinCode.IsMatch(model.pincode))
                {
                    TempData["ErrorMsg"] = "Enter a valid 6 digit Pincode!";
                }
                else if (!mobileNo.IsMatch(model.mobileNo))
                {
                    TempData["ErrorMsg"] = "Enter a valid 10 digit Mobile No.!";
                }

                model.otherState = "";
                model.otherCity = "";
            }
            else
            {
                ModelState["stateID"].Errors.Clear();
                ModelState["cityID"].Errors.Clear();

                model.stateID = 0;
                model.cityID = 0;
            }
            if (ModelState.IsValid)
            {
                if (!model.isAmountCalculated)
                {
                    Decimal perPerAmountTwoTwoMin = string.IsNullOrEmpty(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForTwoMinParamotorRide"])) ? 0 : Convert.ToDecimal(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForTwoMinParamotorRide"].ToString());
                    Decimal perPerAmountForFourMin = string.IsNullOrEmpty(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForFourMinParamotorRide"])) ? 0 : Convert.ToDecimal(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForFourMinParamotorRide"].ToString());
                    if (model.noOfGuestforTwoMinRide > 0 || model.noOfGuestforFourMinRide > 0)
                    {
                        ModelState.Clear();
                        model.AmountforFourMinRide = model.noOfGuestforFourMinRide * perPerAmountForFourMin;
                        model.AmountforTwoMinRide = model.noOfGuestforTwoMinRide * perPerAmountTwoTwoMin;
                        model.amount = model.AmountforFourMinRide + model.AmountforTwoMinRide;
                        model.isAmountCalculated = true;
                    }
                    else
                    {
                        TempData["ErrorMsg"] = "Enter No of Person for At lest one Ride";

                    }
                    return View(model);
                }
                else
                {
                    if (Convert.ToString(Session["capimagetextReg"]) == model.Captcha)
                    {
                        model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                        model.currency = "INR";
                        model.description = "";
                        model.userIP = Common.GetIPAddress();
                        model.unitRateForTwoMinRide = string.IsNullOrEmpty(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForTwoMinParamotorRide"])) ? 0 : Convert.ToDecimal(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForTwoMinParamotorRide"].ToString());
                        model.unitRateforFourMinRide = string.IsNullOrEmpty(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForFourMinParamotorRide"])) ? 0 : Convert.ToDecimal(System.Configuration.ConfigurationManager.AppSettings["perPersonAmountForFourMinParamotorRide"].ToString());
                        if (model.noOfGuestforTwoMinRide > 0 || model.noOfGuestforFourMinRide > 0)
                        {
                            model.AmountforFourMinRide = model.noOfGuestforFourMinRide * model.unitRateforFourMinRide;
                            model.AmountforTwoMinRide = model.noOfGuestforTwoMinRide * model.unitRateForTwoMinRide;
                            model.amount = model.AmountforFourMinRide + model.AmountforTwoMinRide;
                            var result = objBusinessClass.InsertParamotorBookRequest(model);

                            if (result != null)
                            {
                                if (result.requestId == 0 || result.docketNo == null || result.docketNo == "")
                                {
                                    TempData["unavailableMessage"] = "Room Could Not Be Booked Due To Unavailability!";
                                    return RedirectToAction("Unavailable", "UPTourism");
                                }
                                else
                                {
                                    var reqID = HashValue(result.requestId.ToString());
                                    var docNo = HashValue(result.requestId.ToString());

                                    return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                                }
                            }
                        }
                        else
                        {
                            TempData["ErrorMsg"] = "Enter No of Person for At lest one Ride";

                        }
                    }
                    else
                    {
                        TempData["ErrorMsg"] = "Captcha is not valid";
                    }
                }
            }
            else
            {
                TempData["ErrorMsg"] = "Fill all Required Fields";
            }

            return View(model);
        }

        #region Method - hash value
        public string HashValue(string value)
        {
            return (Convert.ToInt64(value)).ToString("X");

        }
        #endregion

        #region Manish 07/01/2018
        public ActionResult HotAirBaloonBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
            ViewBag.StateDATA = Enumerable.Empty<SelectListItem>();
            HotAirBaloonBookingDetailsModel model = new HotAirBaloonBookingDetailsModel();

            return View(model);
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult HotAirBaloonBooking(HotAirBaloonBookingDetailsModel model)
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });

            if (model != null && model.countryID == 98)
            {
                ViewBag.StateDATA = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (model.stateID > 0)
                {
                    ViewBag.CityDATA = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.StateDATA = Enumerable.Empty<SelectListItem>();
                ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
            }
            if (model.countryID == 98)
            {
                ModelState["otherState"].Errors.Clear();
                ModelState["otherCity"].Errors.Clear();

                model.otherState = "";
                model.otherCity = "";
            }
            else
            {
                ModelState["stateID"].Errors.Clear();
                ModelState["cityID"].Errors.Clear();

                model.stateID = 0;
                model.cityID = 0;
            }

            ModelState["captchaCode"].Errors.Clear();
            if (ModelState.IsValid)
            {
                if (!model.isAuthenticated)
                {
                    ModelState.Clear();
                    Decimal BaloonRideAmount = string.IsNullOrEmpty(ConfigurationManager.AppSettings["HotBaloonRideAmount"].ToString()) ? 0 : Convert.ToDecimal(ConfigurationManager.AppSettings["HotBaloonRideAmount"].ToString());
                    if (model.NoofPersons > 0)
                    {
                        model.RideAmount = BaloonRideAmount * model.NoofPersons;
                        model.AmountForDisplay = BaloonRideAmount + " * " + model.NoofPersons + " = " + model.RideAmount;
                        model.isAuthenticated = true;
                        model.UnitRate = BaloonRideAmount;

                    }
                    else
                    {
                        TempData["ErrorMsg"] = "Please Enter no of Persons";

                    }
                }
                else
                {
                    if (Convert.ToString(Session["capimagetextReg"]) == model.captchaCode)
                    {
                        model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                        model.currency = "INR";
                        model.description = "";
                        model.ipAddress = Common.GetIPAddress();
                        model.UnitRate = string.IsNullOrEmpty(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["HotBaloonRideAmount"])) ? 0 : Convert.ToDecimal(System.Configuration.ConfigurationManager.AppSettings["HotBaloonRideAmount"].ToString());
                        if (model.NoofPersons > 0)
                        {
                            model.RideAmount = model.RideAmount;
                            model.name = model.name.ToUpper();
                            var result = objBusinessClass.InsertHotAirBaloonRideBookRequest(model);

                            if (result != null)
                            {
                                if (result.Flag > 0)
                                {
                                    if (result.requestId == 0 || result.docketNo == null || result.docketNo == "")
                                    {
                                        TempData["unavailableMessage"] = "Room Could Not Be Booked Due To Unavailability!";
                                        return RedirectToAction("Unavailable", "UPTourism");
                                    }
                                    else
                                    {
                                        var reqID = HashValue(result.requestId.ToString());
                                        var docNo = HashValue(result.requestId.ToString());

                                        return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                                    }
                                }
                                else
                                {
                                    TempData["ErrorMsg"] = result.msg;
                                }
                            }
                        }
                        else
                        {
                            TempData["ErrorMsg"] = "Enter No of Person for At lest one Ride";
                        }

                    }
                    else
                    {
                        TempData["ErrorMsg"] = "Captcha is Not Valid.";

                    }
                }
            }
            else
            {
                TempData["ErrorMsg"] = "Please fill all Mandatory Fields";
            }
            return View(model);
        }

        public FileResult GetCaptchaimageReg()
        {
            CaptchaRandomImage ci = new CaptchaRandomImage();
            this.Session["capimagetextReg"] = ci.GetRandomString(5).ToUpper();
            ci.GenerateImage(this.Session["capimagetextReg"].ToString(), 150, 40, Color.Black, Color.White);
            MemoryStream stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            return new FileStreamResult(stream, "image/png");

        }
        public ActionResult SuccessHotAirBaloon(string DocketNo)
        {

            var res = objBusinessClass.GetHotAirBaloonRideView(DocketNo);
            if (res != null && !string.IsNullOrEmpty(res.docketNo))
            {
                return View(res);
            }
            else
            {
                res = null;
                ViewBag.Msg = DocketNo;
                return View(res);
            }

        }
        public ActionResult SuccessParamotor(string DocketNo)
        {
            var result = objBusinessClass.GetParaMotorView(DocketNo);
            if (result != null && !string.IsNullOrEmpty(result.docketNo))
            {
                return View(result);
            }
            else
            {
                result = null;
                ViewBag.Msg = DocketNo;
                return View(result);
            }
        }

        [HttpGet]
        public ActionResult CheckParamotorBookingDetails()
        {
            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CheckParamotorBookingDetails(CheckStatus model)
        {
            if (ModelState.IsValid)
            {
                var result = objBusinessClass.GetParaMotorByMobileNoView(model);
                if (result != null && !string.IsNullOrEmpty(result.docketNo))
                {
                    return RedirectToAction("SuccessParamotor", new { DocketNo = result.docketNo });
                }
                else
                {
                    result = null;
                    TempData["ErrorMsg"] = "Not Valid Details.";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }

        public ActionResult CheckHotBaloonRideBookingDetails()
        {
            return View();
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult CheckHotBaloonRideBookingDetails(CheckStatus model)
        {
            if (ModelState.IsValid)
            {
                var result = objBusinessClass.GetHotAirBaloonRideByMobileNoView(model);
                if (result != null && !string.IsNullOrEmpty(result.docketNo))
                {
                    return RedirectToAction("SuccessHotAirBaloon", new { DocketNo = result.docketNo });
                }
                else
                {

                    TempData["ErrorMsg"] = "Not Valid Details.";
                    return View();
                }
            }
            else
            {
                return View();
            }
        }
        #endregion
    }
}
