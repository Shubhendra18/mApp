﻿using PaymentUtility;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Hosting;
using System.Web.Mvc;
using System.Xml;
using UP_TourismBooking.Models;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;

namespace UP_TourismBooking.Controllers
{
    public class PaymentController : Controller
    {
        string hashData = "";
        string secureHash = "";
        string paymentStatus = "";
        internal SortedDictionary<string, string> confirmData = new SortedDictionary<string, string>();
        private RequestResponceExecution reqResExec = new RequestResponceExecution();

        #region Declarations
        BusinessClass objBusinessClass = new BusinessClass();
        #endregion

       
        public ActionResult ResponceFromGateway()
        {
            string mrefno = "";
            try
            {                
                if (!string.IsNullOrEmpty(Request["secretkey"]))
                    Session["SECRET_KEY"] = Request["secretkey"];
                else
                    Session["SECRET_KEY"] = Common.GetAppConfig("SECRET_KEY", "");

                hashData = (Session["SECRET_KEY"] + "").ToString();

                NameValueCollection nameValue = (Request.QueryString.Count > 0) ? Request.QueryString : Request.Form;

                mrefno = Convert.ToString(Request["MerchantRefNo"]);

                //Create sorted dictionary to sort the request query string
                //uses linq extension
                //SortedDictionary<string, string> sortedDict = new SortedDictionary<string, string>(nameValue.AllKeys.ToDictionary(k => k, k => nameValue[k]));
                //uses non linq function

                SortedDictionary<string, string> sortedDict = Common.SortNameValueCollection(nameValue);
                foreach (KeyValuePair<string, string> p in sortedDict)
                {
                    if (p.Value.ToString() != null && p.Value.ToString().Length > 0 && p.Key.ToString().ToLower() != "secretkey" && p.Key.ToString() != "SecureHash" && p.Key.ToString() != "submitted" && !p.Key.ToString().ToLower().StartsWith("__"))
                    {
                        hashData += "|" + p.Value.ToString();
                    }
                }

                if (!string.IsNullOrEmpty(hashData) && hashData.Length > 0)
                {
                    secureHash = Crypto.GenerateHashString(hashData, Common.GetConfigAlgorithm("Algorithm"), Crypto.EncodingType.HEX).ToUpper();
                    if (secureHash == Request["SecureHash"])
                    {
                        if (!string.IsNullOrEmpty(Request["ResponseCode"]))
                        {
                            int ResponseCode = -1;
                            int.TryParse(Request["ResponseCode"], out ResponseCode);
                            if (ResponseCode == 0)
                            {
                                ViewBag.IsSuccess = true;
                                // update response and the order's payment status as SUCCESS in to database
                                
                                //for demo purpose, its stored in session
                                paymentStatus = "SUCCESS";
                               // Session["paymentResponse"] = Request;
                            }
                            else
                            {
                                ViewBag.IsSuccess = false;
                                paymentStatus = "FAILED";
                                //Session["paymentResponse"] = Request;
                            }
                            //for demo purpose, its stored in session
                            Session["paymentStatus"] = paymentStatus;
                            Session["PaymentID"] = (Request["PaymentID"] + "").ToString();
                                               
                            int result = UpdateTransaction(sortedDict);
                            if (result == 1)
                            {
                                Payment objPay = PaymentConfirmation(Convert.ToString(Request["MerchantRefNo"]), Convert.ToString(Request["PaymentID"]));
                                if (objPay.BookingFor == "HotAirBaloon" || objPay.BookingFor == "Paramotor")
                                {
                                    return View("PaymentConfirmationSpecialBooking", objPay);
                                }
                                return View("PaymentConfirmation", objPay);
                            }
                            if (result == 2)
                            {
                               ViewBag.ErrorMessage = "Duplicate Response!";
                            }                            
                        }
                        else
                        {
                            //ViewBag.ErrorMessage = "No response received!";
                            ViewBag.ErrorMessage = "Invalid response!";
                        }
                    }
                    else
                    {
                        //ViewBag.ErrorMessage = "Hash validation failed!";   
                        ViewBag.ErrorMessage = "Invalid response!";                      
                    }
                }
                else
                {                   
                   ViewBag.ErrorMessage ="Invalid response!";
                }              
            }
            catch(Exception ex)
            {
                ViewBag.ErrorMessage = "Error in process!";
                ExceptionHandler.LogExceptionPayment("PaymentController", "ResponceFromGateway", ex.Message + " " + mrefno + " PayFail1");
                throw ex;                
            }
            return View("PaymentConfirmation");
        }

        //public ActionResult PaymentPost()
        //{
        //    PostPaymentData obj_PostPaymentData = new PostPaymentData();
        //    obj_PostPaymentData = objBusinessClass.GetPackagePostData(Convert.ToInt64(Session["RequestID"]), Session["docketNo"].ToString());

        //    var reqArr = new Dictionary<string, string>();
        //    reqArr["channel"] = ConfigurationManager.AppSettings["Channel"] != null ? ConfigurationManager.AppSettings["Channel"].ToString() : "<Channel>";
        //    reqArr["secretkey"] = ConfigurationManager.AppSettings["SECRET_KEY"] != null ? ConfigurationManager.AppSettings["SECRET_KEY"].ToString() : "<SecrectKeyRequire>";
        //    reqArr["account_id"] = ConfigurationManager.AppSettings["ACCOUNT_ID"] != null ? ConfigurationManager.AppSettings["ACCOUNT_ID"].ToString() : "<AccountID>";
        //    reqArr["reference_no"] = obj_PostPaymentData.docketNo;//reqFormat.reference_no;
        //    reqArr["amount"] = obj_PostPaymentData.amount.ToString();
        //    reqArr["mode"] = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
        //    reqArr["display_currency"] = obj_PostPaymentData.currency;
        //    reqArr["display_currency_rates"] = "1";
        //    reqArr["description"] = "";//string.IsNullOrEmpty(reqFormat.description) ? "UPT Product" : reqFormat.description;
        //    reqArr["return_url"] = ConfigurationManager.AppSettings["RETURN_URL"] != null ? ConfigurationManager.AppSettings["RETURN_URL"].ToString() : "<ReturnPageRequrie>";
        //    reqArr["name"] = obj_PostPaymentData.name;//reqFormat.name;
        //    reqArr["address"] = obj_PostPaymentData.address;// reqFormat.address;
        //    reqArr["city"] = obj_PostPaymentData.city;//reqFormat.city;
        //    reqArr["state"] = obj_PostPaymentData.state;//reqFormat.state;
        //    reqArr["country"] = obj_PostPaymentData.country;
        //    reqArr["postal_code"] = obj_PostPaymentData.postalCode;//reqFormat.postal_code;
        //    reqArr["phone"] = obj_PostPaymentData.phone;//reqFormat.phone;
        //    reqArr["email"] = obj_PostPaymentData.email;//reqFormat.email;
        //    reqArr["ship_address"] = obj_PostPaymentData.shipAddress;
        //    reqArr["ship_name"] = obj_PostPaymentData.shipName;
        //    reqArr["ship_city"] = obj_PostPaymentData.shipCity;
        //    reqArr["ship_state"] = obj_PostPaymentData.shipState;
        //    reqArr["ship_postal_code"] = obj_PostPaymentData.shipPostalCode;
        //    reqArr["ship_country"] = obj_PostPaymentData.shipCountry;
        //    reqArr["ship_phone"] = obj_PostPaymentData.shipPhone;
        //    reqArr["payment_mode"] = string.Empty;
        //    reqArr["card_brand"] = string.Empty;
        //    reqArr["payment_option"] = string.Empty;
        //    reqArr["bank_code"] = string.Empty;
        //    reqArr["emi"] = string.Empty;
        //    reqArr["page_id"] = string.Empty;
        //    var sortDic = reqArr.OrderBy(m => m.Key).ToDictionary(m => m.Key, m => m.Value);
        //    var hashData = string.Empty;

        //    foreach (KeyValuePair<string, string> p in sortDic)
        //    {
        //        if (p.Value.ToString() != null && p.Value.ToString().Length > 0 && p.Key.ToString().ToLower() != "secretkey" && p.Key.ToString() != "submitted" && !p.Key.ToString().ToLower().StartsWith("__"))
        //        {
        //            hashData += "|" + p.Value.ToString();
        //        }
        //    }
        //    if (hashData != null && hashData.Length > 0)
        //    {
        //        ViewBag.SecureHash = Crypto.GenerateHashString(hashData, Common.GetConfigAlgorithm("Algorithm"), Crypto.EncodingType.HEX).ToUpper();
        //    }
        //    return View(sortDic);
        //}

        //private void SetPageNoCache()
        //{
        //    Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //    Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
        //    Response.Cache.SetAllowResponseInBrowserHistory(false);
        //    Response.Cache.SetNoStore();
        //}

        #region change reponse to string
        private string ReponseToString(SortedDictionary<string, string> sortedDict)
        {
            var paymentInfo = new StringBuilder();
            foreach (var item in sortedDict)
            {
                paymentInfo.Append("<" + item.Key + ">" + item.Value + "</" + item.Key + ">");
            }
            return paymentInfo.ToString();
        }
        #endregion

        #region update transaction and send mail
        private int UpdateTransaction(SortedDictionary<string, string> sortedDict)
        {
            string mrefno = "";
            try
            {
                var transactionId = sortedDict["TransactionID"].ToString();
                var refNo = sortedDict["MerchantRefNo"].ToString();
                var responseString = ReponseToString(sortedDict);

                mrefno = refNo;

                decimal paidAmount = string.IsNullOrEmpty(sortedDict["Amount"].ToString()) ? 0 : Convert.ToDecimal(sortedDict["Amount"].ToString());
                decimal payableAmount = objBusinessClass.GetPayableAmountByDocketNo(refNo).amount;

                int response = new BusinessClass().PROC_UPDATE_PAYMENT_RESPONCE(refNo, transactionId, responseString);

                if (response != null)
                {
                    if (response == 1  && (paidAmount == payableAmount))
                    {
                        try
                        {
                            string customerMobileNo = sortedDict["BillingPhone"].ToString();
                            string customerName = sortedDict["BillingName"].ToString();
                            string customerEmail = sortedDict["BillingEmail"].ToString();

                            CustomerDetails objCustomer = objBusinessClass.GetCustomerDetails(refNo);
                            if (objCustomer != null)
                            {
                                customerMobileNo = objCustomer.mobileNo;
                                customerName = objCustomer.name;
                                customerEmail = objCustomer.email;
                            }

                            //OfficerContactDetails objOfficerMobileNo = new OfficerContactDetails();
                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(refNo);
                            var bookingType = IEContactDetails.Select(m => m.BookingFor).FirstOrDefault();
                            
                            SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(refNo);                            
                           
                            if (bookingType == "PACK")
                            {
                                SendPackageBookSms(refNo, customerMobileNo, IEContactDetails, objSpclPackName);
                                SendPackageTourMail(refNo, "cust", customerEmail);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendPackageTourMail(refNo, "unit", lst.Email);
                                }
                            }
                            else if (bookingType == "UNIT")
                            {
                                SendUnitBookSms(refNo, customerMobileNo, IEContactDetails, customerName);
                                SendUnitRoomMail(refNo, "cust", customerEmail);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendUnitRoomMail(refNo, "unit", lst.Email);
                                }
                            }
                            else if (bookingType == "CITY" || bookingType == "ACBUS")
                            {
                                string smsfor = bookingType == "CITY" ? "One Day Tour Booking" : "AC Bus Tour Booking";
                                SendOneDayBookSms(refNo, customerMobileNo, IEContactDetails, objSpclPackName, smsfor);
                                SendSpecialPackageMail(refNo, "cust", customerEmail, bookingType);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendSpecialPackageMail(refNo, "unit", lst.Email, bookingType);
                                }
                            }
                            else if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                            {
                                string smsfor = bookingType == "CYCLE" ? "Cycle Tour Booking" : (bookingType == "TONGA" ? "Tonga Ride Booking" : "Heritage Walk Booking");
                                SendSpecialBookSms(refNo, customerMobileNo, IEContactDetails, objSpclPackName, smsfor);
                                SendSpecialPackageMail(refNo, "cust", customerEmail, bookingType);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendSpecialPackageMail(refNo, "unit", lst.Email, bookingType);
                                }
                            }
                            else if (bookingType == "BUS" || bookingType == "TAXI")
                            {
                                string smsfor = bookingType == "BUS" ? "Bus Booking" : "Taxi Booking";
                                SendBusTaxiBookSms(refNo, customerMobileNo, IEContactDetails, smsfor, objCustomer.pickupDate, Convert.ToDateTime(objCustomer.pickupTime));
                                SendBusTaxiMail(refNo, "cust", customerEmail, bookingType);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendBusTaxiMail(refNo, "upt", lst.Email, bookingType);
                                }
                            }

                            else if (bookingType == "Taxi" || bookingType == "Bus")
                            {
                                string smsfor = bookingType == "Bus" ? "Bus Booking" : "Taxi Booking";
                                SendBusTaxiBookSms(refNo, customerMobileNo, IEContactDetails, smsfor, objCustomer.pickupDate, Convert.ToDateTime(objCustomer.pickupTime));
                                SendBusTaxiMail(refNo, "cust", customerEmail, bookingType);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendBusTaxiMail(refNo, "upt", lst.Email, bookingType);
                                }
                            }

                            else if (bookingType.ToUpper() == "BANQUET" || bookingType.ToUpper() == "LAWN")
                            {
                                string smsfor = bookingType.ToUpper() == "BANQUET" ? "Banquet Booking" : "Lawn Booking";

                                SendLawnBanquetBookSms(refNo, customerMobileNo, IEContactDetails, smsfor, objCustomer.pickupDate, Convert.ToDateTime(objCustomer.pickupTime));
                                SendLawnBanquetMail(refNo, "cust", customerEmail, bookingType);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendLawnBanquetMail(refNo, "upt", lst.Email, bookingType);
                                }
                            }

                            else if (bookingType.ToUpper() == "Paramotor")
                            {
                                string smsfor = "Paramotor Booking";

                                SendParamotorBookSms(refNo, customerMobileNo, IEContactDetails, smsfor, objCustomer.pickupDate, Convert.ToDateTime(objCustomer.pickupTime));
                                SendParamotorMail(refNo, "cust", customerEmail, bookingType);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendParamotorMail(refNo, "upt", lst.Email, bookingType);
                                }
                            }

                            else if (bookingType.ToUpper() == "HotAirBaloon")
                            {
                                string smsfor = "Hot Air Balloon Booking";

                                SendHotAirBaloonBookSms(refNo, customerMobileNo, IEContactDetails, smsfor, objCustomer.pickupDate, Convert.ToDateTime(objCustomer.pickupTime));
                                SendHotAirBaloonMail(refNo, "cust", customerEmail, bookingType);

                                foreach (var lst in IEContactDetails)
                                {
                                    SendHotAirBaloonMail(refNo, "upt", lst.Email, bookingType);
                                }
                            }

                        }
                        catch
                        {

                        }                        
                    }
                    else if (response == 6)
                    {
                        return 2;
                    }                   
                    return 1;
                }
                else
                {
                    return 3;
                    //ViewBag.ErrorMessage = "Error in process!";
                }      
            }  
            catch (Exception ex)
            {
                ExceptionHandler.LogExceptionPayment("PaymentController", "UpdateTransaction", ex.Message + " " + mrefno + " PayFail2");
                return 4;
                //
            }

            
        }
        #endregion

        #region to send unit room booking mail 
        protected void SendUnitRoomMail(string docketNo, string type, string mailTo)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetails(docketNo);
                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/UnitRoomBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/UnitRoomBookingConfirmation.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[hotelname]", model.unitName);
                MailBody = MailBody.Replace("[hoteladdress]", model.unitAddress);
                MailBody = MailBody.Replace("[hotelphone]", model.unitMobile);
                MailBody = MailBody.Replace("[roomtype]", model.roomType);
                MailBody = MailBody.Replace("[noofrooms]", model.noOfRooms.ToString());
                MailBody = MailBody.Replace("[extrabed]", model.extraBed.ToString());

                MailBody = MailBody.Replace("[checkindate]", model.checkinDate);
                MailBody = MailBody.Replace("[checkoutdate]", model.checkoutDate);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);

                MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[banrefno]", model.bankRefNo);
                //MailBody = MailBody.Replace("[invoiceno]", "");
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);
                MailBody = MailBody.Replace("[DNote]", model.Note);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {                  
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send package tour booking mail 
        protected void SendPackageTourMail(string docketNo, string type, string mailTo)
        {
            try
            {
                PackageTransactionDetail model = objBusinessClass.GetPackageTransactionDetails(docketNo);
                model.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(model.packageID);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/PackageBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/PackageBookingConfirmation.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);
                MailBody = MailBody.Replace("[duration]", model.duration);
                MailBody = MailBody.Replace("[noofpersons]", model.noOfTourists);        
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);
                MailBody = MailBody.Replace("[meetingpoint]", model.meetingPoint);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);

                MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[banrefno]", model.bankRefNo);
                //MailBody = MailBody.Replace("[invoiceno]", "");
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);

                string accomStr = "";
                if (model.IEPackageAccomodation != null && model.IEPackageAccomodation.Count() > 0)
                { 
                    accomStr = "<table>";

                    foreach(var accom in model.IEPackageAccomodation)
                    {
                        accomStr += "<tr><td colspan='2' style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.daySequence + "</td></tr>" +
                                     "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>City Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.cityname + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Unit Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitName + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Address</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitAddress + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Room Type</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.roomType+"</td></tr>";
                    }                
                     accomStr += "</table>";
                }

                MailBody = MailBody.Replace("[accomodationdetails]", accomStr);

                MailBody = MailBody.Replace("[UPToursName]", model.UptoursName);
                MailBody = MailBody.Replace("[UPTAddress]", model.UPToursAddress);
                MailBody = MailBody.Replace("[UPtPhone]", model.PhoneNo);
                MailBody = MailBody.Replace("[UPTMobile]", model.managerMobileNo);
                MailBody = MailBody.Replace("[UPTEmail]", model.managerEmail);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //SendMail.Send(mailTo, subject, MailBody);
                    //MailService.Service1 objService = new MailService.Service1();

                    if (type == "cust")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }                    
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send special package booking mail
        protected void SendSpecialPackageMail(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                SpecialPackageTransactionDetail model = objBusinessClass.GetSplPackageTransactionDetails(docketNo, bookingType);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/SplPackageBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/SplPackageBookingConfirmation.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);               
                MailBody = MailBody.Replace("[noofpersons]", model.noOfTourists);               
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);

                string arrivalTime = "";
                if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                {
                    arrivalTime = "<tr>";
                    arrivalTime += "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Arrival Time</td>" +
                             "<td style='font-size: 12px; font-weight: 500; padding: 8px; color: #464646;'>" + model.arrivalTime.ToShortTimeString()+ "</td>";                       
                    arrivalTime += "</tr>";
                }

                MailBody = MailBody.Replace("[arrivaltime]", arrivalTime);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);

                MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[banrefno]", model.bankRefNo);                
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);

                MailBody = MailBody.Replace("[UPToursName]", model.UptoursName);
                MailBody = MailBody.Replace("[UPTAddress]", model.UPToursAddress);
                MailBody = MailBody.Replace("[UPtPhone]", model.PhoneNo);
                MailBody = MailBody.Replace("[UPTMobile]", model.managerMobileNo);
                MailBody = MailBody.Replace("[UPTEmail]", model.managerEmail);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {                    
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send package tour booking sms 
        protected void SendPackageBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["PackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[PackageName]", spclPack.packageName);

                string ConcernPersonSMS = ConfigurationManager.AppSettings["PackageConcernPersonSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                ConcernPersonSMS = ConcernPersonSMS.Replace("[DocketNo]", docketNo);
                ConcernPersonSMS = ConcernPersonSMS.Replace("[PackageName]", spclPack.packageName);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["PackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.packageName);

                string UPTourSMS = ConfigurationManager.AppSettings["PackageUPTourSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.packageName);


                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "UNIT")
                            {
                                SMSStatus = SMS.SMSSend(ConcernPersonSMS, lst.MobileNo);    // Send SMS to Unit
                                SMS.SMSLog(ConcernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                 SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                 SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                         }
                        catch  { 
                            //ExceptionHandler.LogException("PaymentController", "SendPackageBookSms - send sms to concerned authority", ex.Message); 
                        }                        
                    }
                }
                catch { 
                   // ExceptionHandler.LogException("PaymentController", "SendPackageBookSms - send sms to customer", ex.Message);
                }
            }
            catch 
            {
                //ExceptionHandler.LogException("PaymentController", "SendPackageBookSms", ex.Message);
            }
        }
        #endregion

        #region to send unit booking sms 
        protected void SendUnitBookSms(string docketNo, string customerMobileNo, IEnumerable<OfficerContactDetails> contactDetails, string customerName)
        {
            try
            {
                var checkInDate = contactDetails.Select(m => m.checkInDate).FirstOrDefault();
                var roomInfo = contactDetails.Select(m => m.roomInfo).FirstOrDefault();
                var unitName = contactDetails.Where(m=>m.sendTo == "UNIT").Select(m => m.UnitName).FirstOrDefault();

                string customerSms = ConfigurationManager.AppSettings["UnitBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[CustomerName]", customerName);
                customerSms = customerSms.Replace("[noOfRoomsAndType]", roomInfo);
                customerSms = customerSms.Replace("[UnitName]", unitName);
                customerSms = customerSms.Replace("[CheckinDate]", checkInDate);
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string concernPersonSMS = ConfigurationManager.AppSettings["UnitConcernPersonSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                concernPersonSMS = concernPersonSMS.Replace("[noOfRoomsAndType]", roomInfo);
                concernPersonSMS = concernPersonSMS.Replace("[UnitName]", unitName);
                concernPersonSMS = concernPersonSMS.Replace("[CheckinDate]", checkInDate);
                concernPersonSMS = concernPersonSMS.Replace("[DocketNo]", docketNo);

                string nodalOfficerSMS = ConfigurationManager.AppSettings["UnitNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                nodalOfficerSMS = nodalOfficerSMS.Replace("[noOfRoomsAndType]", roomInfo);
                nodalOfficerSMS = nodalOfficerSMS.Replace("[UnitName]", unitName);
                nodalOfficerSMS = nodalOfficerSMS.Replace("[CheckinDate]", checkInDate);
                nodalOfficerSMS = nodalOfficerSMS.Replace("[DocketNo]", docketNo);                

                string SMSStatus = SMS.SMSSend(customerSms, customerMobileNo);              // Send SMS to Customer
                    SMS.SMSLog(customerSms, customerMobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        SMSStatus = string.Empty;
                        if (lst.sendTo == "UNIT")
                        {
                            SMSStatus = SMS.SMSSend(concernPersonSMS, lst.MobileNo);         // Send SMS to Unit
                            SMS.SMSLog(concernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                        }
                       if (lst.sendTo == "NODAL")
                       {
                           SMSStatus = SMS.SMSSend(nodalOfficerSMS, lst.MobileNo);          // Send SMS to Nodal Officer
                           SMS.SMSLog(nodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                       }
                    }                       
            }    
            catch (Exception ex)
            {
                throw ex;
            }
        }
       #endregion

        #region to send special tour booking sms
        protected void SendSpecialBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack, string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["SplPackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[PackageName]", spclPack.routeType);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["SplPackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.routeType);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["SplPackageUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.routeType);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);
                    
                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;                            
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }                     
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send one day tour booking sms
        protected void SendOneDayBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails,SpecialPackageName spclPack,string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["OneDayBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace(" [PackageName]", spclPack.packageName);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["OneDayNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace(" [PackageName]", spclPack.packageName);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["OneDayUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace(" [PackageName]", spclPack.packageName);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }                   
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send bus/taxi booking sms
        protected void SendBusTaxiBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string smsFor, string pickupDate, DateTime pickupTime)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["BusTaxiBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);              
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[PickupDate]", pickupDate);
                customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());                

                string NodalOfficerSMS = ConfigurationManager.AppSettings["BusTaxiNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);               
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PickupDate]", pickupDate);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                string UPTourSMS = ConfigurationManager.AppSettings["BusTaxiUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);              
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PickupDate]", pickupDate);
                UPTourSMS = UPTourSMS.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send bus/taxi booking mail
        protected void SendBusTaxiMail(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                BusTaxiBookingDetails model = objBusinessClass.GetTaxiBusBookingDetails(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/TaxiBusBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/TaxiBusBookingConfirmation.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[fromcity]", model.fromCityName);
                MailBody = MailBody.Replace("[tocity]", model.toCity);
                MailBody = MailBody.Replace("[journeydate]", model.dateOfJourney);
                MailBody = MailBody.Replace("[returndate]", model.dateOfReturn );
                MailBody = MailBody.Replace("[pickupdate]", model.pickupDate);
                MailBody = MailBody.Replace("[pickuptime]", model.pickupTime.ToShortTimeString());
                MailBody = MailBody.Replace("[pickupaddress]", model.pickupAddress);
                
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);

                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[banrefno]", model.bankRefNo);
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);
                MailBody = MailBody.Replace("[GuideFacOpt]", model.IsGuideOpted);
                
                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region Payment Confirmation By Roop Kanwar On 19/09/2014

        public Payment PaymentConfirmation(string merchantRefNo, string paymentId)
        {
            Payment objPay = new Payment();
            try
            {                
                objPay = objBusinessClass.GetDetailsAfterPayment(merchantRefNo, paymentId);
                if (objPay != null)
                {
                    objPay.bookingType = objPay.BookingFor;

                    if (objPay.BookingFor == "PACK")
                    {
                        objPay.BookingFor = "Package";
                    }
                    else if (objPay.BookingFor == "UNIT")
                    {
                        objPay.BookingFor = "Hotel";
                    }
                    else if (objPay.BookingFor == "CITY")
                    {
                        objPay.BookingFor = "One Day Tour";
                    }
                    else if (objPay.BookingFor == "ACBUS" || objPay.BookingFor == "CYCLE" || objPay.BookingFor == "TONGA" || objPay.BookingFor == "WALK")
                    {
                       
                        objPay.BookingFor = "Special Package";
                    }
                    else if (objPay.BookingFor == "BANQU")
                    {

                        objPay.BookingFor = "Banquet";
                    }
                    if (objPay.packageID != null && objPay.packageID > 0)
                    {
                        objPay.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(objPay.packageID);
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionHandler.LogExceptionPayment("PaymentController", "UpdateTransaction", ex.Message + " " + merchantRefNo + " PayFail2");
                throw ex;
            }
           
            return objPay;
        }
        #endregion

        //private void AccessOtherServerPage(string docketNo, string userType, string mailTo,string mailType)
        //{

        //    WebRequest request = WebRequest.Create(string.Format("{0}?docketNo={1}&userType={2}&mailTo={3}&mailType={4}", ConfigurationManager.AppSettings["mailURL"].ToString(), docketNo, userType, mailTo, mailType));
        //    // If required by the server, set the credentials.
        //    request.Credentials = CredentialCache.DefaultCredentials;
        //    // Get the response.
        //    WebResponse response = request.GetResponse();
        //    // Display the status.
        //    //Console.WriteLine(((HttpWebResponse)response).StatusDescription);
        //    // Get the stream containing content returned by the server.
        //    Stream dataStream = response.GetResponseStream();
        //    // Open the stream using a StreamReader for easy access.
        //    StreamReader reader = new StreamReader(dataStream);
        //    // Read the content.
        //    string responseFromServer = reader.ReadToEnd();
        //    // Display the content.
        //   // Console.WriteLine(responseFromServer);
        //    // Clean up the streams and the response.
        //    reader.Close();
        //    response.Close();
        //}

        #region send mail to manually updated bookings
        [HttpGet]
        public ActionResult SendMailToUpdatedBooking()
        {
            return View();
        }
        #endregion

        #region send mail to manually updated bookings
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SendMailToUpdatedBooking(Payment model)
        {
            try
            {               

                CustomerDetails objCustomer = objBusinessClass.GetCustomerDetails(model.MerchantRefNo);
                if (objCustomer != null)
                {
                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(model.MerchantRefNo);
                    SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(model.MerchantRefNo);
                    var bookingType = IEContactDetails.Select(m => m.BookingFor).FirstOrDefault();

                    if (bookingType == "PACK")
                    {
                        SendPackageBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName);
                        SendPackageTourMail(model.MerchantRefNo, "cust", objCustomer.email);

                        foreach (var lst in IEContactDetails)
                        {
                            SendPackageTourMail(model.MerchantRefNo, "unit", lst.Email);
                        }
                    }
                    else if (bookingType == "UNIT")
                    {
                        SendUnitBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objCustomer.name);
                        SendUnitRoomMail(model.MerchantRefNo, "cust", objCustomer.email);

                        foreach (var lst in IEContactDetails)
                        {
                            SendUnitRoomMail(model.MerchantRefNo, "unit", lst.Email);
                        }
                    }
                    else if (bookingType == "CITY" || bookingType == "ACBUS")
                    {
                        string smsfor = bookingType == "CITY" ? "One Day Tour Booking" : "AC Bus Tour Booking";
                        SendOneDayBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName, smsfor);
                        SendSpecialPackageMail(model.MerchantRefNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendSpecialPackageMail(model.MerchantRefNo, "unit", lst.Email, bookingType);
                        }
                    }
                    else if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                    {
                        string smsfor = bookingType == "CYCLE" ? "Cycle Tour Booking" : (bookingType == "TONGA" ? "Tonga Ride Booking" : "Heritage Walk Booking");
                        SendSpecialBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName, smsfor);
                        SendSpecialPackageMail(model.MerchantRefNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendSpecialPackageMail(model.MerchantRefNo, "unit", lst.Email, bookingType);
                        }
                    }

                    else if (bookingType == "Taxi" || bookingType == "Bus")
                    {
                        string smsfor = bookingType == "Bus" ? "Bus Booking" : "Taxi Booking";
                        SendBusTaxiBookSmsmanually(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, smsfor, objCustomer.pickupDate, Convert.ToDateTime(objCustomer.pickupTime));
                        //SendBusTaxiMail(model.MerchantRefNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendBusTaxiMailmanually(model.MerchantRefNo, "upt", lst.Email, bookingType);
                        }
                    }
                }                
            }          
            catch
            {              
            }

            return View();
        }
        #endregion

        #region send mail afater updated Responce
        
        public int SendMailAfterUpdatedBooking()
        {
            string docket=SessionManager.DocketNo;
            Payment model = new Payment();
            model.MerchantRefNo = docket;
            try
            {
                
                CustomerDetails objCustomer = objBusinessClass.GetCustomerDetails(model.MerchantRefNo);
                if (objCustomer != null)
                {
                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(model.MerchantRefNo);
                    SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(model.MerchantRefNo);
                    var bookingType = IEContactDetails.Select(m => m.BookingFor).FirstOrDefault();

                    if (bookingType == "PACK")
                    {
                        SendPackageBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName);
                        SendPackageTourMail(model.MerchantRefNo, "cust", objCustomer.email);

                        foreach (var lst in IEContactDetails)
                        {
                            SendPackageTourMail(model.MerchantRefNo, "unit", lst.Email);
                        }
                    }
                    else if (bookingType == "UNIT")
                    {
                        SendUnitBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objCustomer.name);
                        SendUnitRoomMail(model.MerchantRefNo, "cust", objCustomer.email);

                        foreach (var lst in IEContactDetails)
                        {
                            SendUnitRoomMail(model.MerchantRefNo, "unit", lst.Email);
                        }
                    }
                    else if (bookingType == "CITY" || bookingType == "ACBUS")
                    {
                        string smsfor = bookingType == "CITY" ? "One Day Tour Booking" : "AC Bus Tour Booking";
                        SendOneDayBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName, smsfor);
                        SendSpecialPackageMail(model.MerchantRefNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendSpecialPackageMail(model.MerchantRefNo, "unit", lst.Email, bookingType);
                        }
                    }
                    else if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                    {
                        string smsfor = bookingType == "CYCLE" ? "Cycle Tour Booking" : (bookingType == "TONGA" ? "Tonga Ride Booking" : "Heritage Walk Booking");
                        SendSpecialBookSms(model.MerchantRefNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName, smsfor);
                        SendSpecialPackageMail(model.MerchantRefNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendSpecialPackageMail(model.MerchantRefNo, "unit", lst.Email, bookingType);
                        }
                    }
                }
                return 1;
            }
            catch
            {
                return 0;
            }

            
        }
        #endregion


        #region to send Lawn Banquet booking sms
        protected void SendLawnBanquetBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string smsFor, string pickupDate, DateTime pickupTime)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["BanquetLawnBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ForDate]", pickupDate);
                

                string NodalOfficerSMS = ConfigurationManager.AppSettings["BanquetLawnNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ForDate]", pickupDate);
               

                string UPTourSMS = ConfigurationManager.AppSettings["BanquetLawnUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[ForDate]", pickupDate);
               

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send Lawn Banquet booking mail
        protected void SendLawnBanquetMail(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                LawnBanquitBookingDetails model = objBusinessClass.GetLawnBanquetBookingDetails(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/LawnBanquitBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/LawnBanquitBookingConfirmation.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);               
                MailBody = MailBody.Replace("[UnitName]", model.UnitName);
                MailBody = MailBody.Replace("[ForDate]", model.ForDate);
                MailBody = MailBody.Replace("[functionName]", model.functionName);
                MailBody = MailBody.Replace("[noOfTourists]", model.noOfTourists);
              
               

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);

                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[banrefno]", model.PaymentID);
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate.ToString());
              

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion


        #region to send bus/taxi booking mail Manually
        protected void SendBusTaxiMailmanually(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                BusTaxiBookingDetails model = objBusinessClass.GetTaxiBusBookingDetails(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/TaxiBusBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/TaxiBusBookingConfirmation.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[fromcity]", model.fromCityName);
                MailBody = MailBody.Replace("[tocity]", model.toCity);
                MailBody = MailBody.Replace("[journeydate]", model.dateOfJourney);
                MailBody = MailBody.Replace("[returndate]", model.dateOfReturn);
                MailBody = MailBody.Replace("[pickupdate]", model.pickupDate);
                MailBody = MailBody.Replace("[pickuptime]", model.pickupTime.ToShortTimeString());
                MailBody = MailBody.Replace("[pickupaddress]", model.pickupAddress);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);

                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[banrefno]", model.bankRefNo);
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);
                MailBody = MailBody.Replace("[GuideFacOpt]", model.IsGuideOpted);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send bus/taxi booking sms manually
        protected void SendBusTaxiBookSmsmanually(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string smsFor, string pickupDate, DateTime pickupTime)
        {
            try
            {
                //string customerSms = ConfigurationManager.AppSettings["BusTaxiBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                //customerSms = customerSms.Replace("[DocketNo]", docketNo);
                //customerSms = customerSms.Replace("[BookingFor]", smsFor);
                //customerSms = customerSms.Replace("[PickupDate]", pickupDate);
                //customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                string NodalOfficerSMS = ConfigurationManager.AppSettings["BusTaxiNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PickupDate]", pickupDate);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                string UPTourSMS = ConfigurationManager.AppSettings["BusTaxiUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PickupDate]", pickupDate);
                UPTourSMS = UPTourSMS.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                try
                {
                    string SMSStatus = ""; //SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    //SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        #region send mail to manually updated bookings
        [HttpGet]
        public ActionResult SendMailCustomeFun()
        {
            
            return View();
        }
        #endregion

        #region send mail to manually updated bookings
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SendMailCustomeFun(Payment model)
        {
            try
            {
                if (!string.IsNullOrEmpty(model.email) && !string.IsNullOrEmpty(model.MerchantRefNo))
                {

                    CustomerDetails objCustomer = objBusinessClass.GetCustomerDetails(model.MerchantRefNo);
                    if (objCustomer != null)
                    {
                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(model.MerchantRefNo);
                        SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(model.MerchantRefNo);
                        var bookingType = IEContactDetails.Select(m => m.BookingFor).FirstOrDefault();

                        if (bookingType == "PACK")
                        {

                            SendPackageTourMail(model.MerchantRefNo, "cust", model.email);

                            foreach (var lst in IEContactDetails)
                            {
                                SendPackageTourMail(model.MerchantRefNo, "unit", model.email);
                            }
                        }
                        else if (bookingType == "UNIT")
                        {

                            SendUnitRoomMail(model.MerchantRefNo, "cust", model.email);

                            foreach (var lst in IEContactDetails)
                            {
                                SendUnitRoomMail(model.MerchantRefNo, "unit", model.email);
                            }
                        }
                        else if (bookingType == "CITY" || bookingType == "ACBUS")
                        {
                            string smsfor = bookingType == "CITY" ? "One Day Tour Booking" : "AC Bus Tour Booking";

                            SendSpecialPackageMail(model.MerchantRefNo, "cust", model.email, bookingType);

                            foreach (var lst in IEContactDetails)
                            {
                                SendSpecialPackageMail(model.MerchantRefNo, "unit", model.email, bookingType);
                            }
                        }
                        else if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                        {
                            string smsfor = bookingType == "CYCLE" ? "Cycle Tour Booking" : (bookingType == "TONGA" ? "Tonga Ride Booking" : "Heritage Walk Booking");

                            SendSpecialPackageMail(model.MerchantRefNo, "cust", model.email, bookingType);

                            foreach (var lst in IEContactDetails)
                            {
                                SendSpecialPackageMail(model.MerchantRefNo, "unit", model.email, bookingType);
                            }
                        }

                        else if (bookingType == "Taxi" || bookingType == "Bus")
                        {
                            string smsfor = bookingType == "Bus" ? "Bus Booking" : "Taxi Booking";



                            foreach (var lst in IEContactDetails)
                            {
                                SendBusTaxiMailmanually(model.MerchantRefNo, "upt", model.email, bookingType);
                            }
                        }
                        @TempData["msg"] = "Success";
                    }
                    else
                    {
                        @TempData["msg"] = "Invalid Docket No.";
                    }
                }
                else
                {
                    @TempData["msg"] = "Enter Details";
                }
            }
            catch(Exception ex)
            {
                 @TempData["msg"]=ex.Message;
            }

            return View();
        }
        #endregion


        #region PAYMENT RECONSILE FOR BOOKING
        public ActionResult PaymentReconcile(string refNo)
        {
            string docketNo = OTPL_Imp.CustomCryptography.Decrypt(refNo);
            string msg = "";
           var result= paymentReconcileAPIImplementation(docketNo);

           if (string.IsNullOrEmpty(result.errorCode))
           {
               TempData["msg"] = result.message;
           }
           else
           {
               TempData["msg"] = result.error;
           }
            return RedirectToAction("BookingHistory","UPTourism");
        }
        #endregion

        string SendMailAfterReconcileBooking(string docketNo)
        {
            try
            {

                CustomerDetails objCustomer = objBusinessClass.GetCustomerDetails(docketNo);
                if (objCustomer != null)
                {
                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(docketNo);
                    SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(docketNo);
                    var bookingType = IEContactDetails.Select(m => m.BookingFor).FirstOrDefault();

                    if (bookingType == "PACK")
                    {
                        SendPackageBookSms(docketNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName);
                        SendPackageTourMail(docketNo, "cust", objCustomer.email);

                        foreach (var lst in IEContactDetails)
                        {
                            SendPackageTourMail(docketNo, "unit", lst.Email);
                        }
                    }
                    else if (bookingType == "UNIT")
                    {
                        SendUnitBookSms(docketNo, objCustomer.mobileNo, IEContactDetails, objCustomer.name);
                        SendUnitRoomMail(docketNo, "cust", objCustomer.email);

                        foreach (var lst in IEContactDetails)
                        {
                            SendUnitRoomMail(docketNo, "unit", lst.Email);
                        }
                    }
                    else if (bookingType == "CITY" || bookingType == "ACBUS")
                    {
                        string smsfor = bookingType == "CITY" ? "One Day Tour Booking" : "AC Bus Tour Booking";
                        SendOneDayBookSms(docketNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName, smsfor);
                        SendSpecialPackageMail(docketNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendSpecialPackageMail(docketNo, "unit", lst.Email, bookingType);
                        }
                    }
                    else if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                    {
                        string smsfor = bookingType == "CYCLE" ? "Cycle Tour Booking" : (bookingType == "TONGA" ? "Tonga Ride Booking" : "Heritage Walk Booking");
                        SendSpecialBookSms(docketNo, objCustomer.mobileNo, IEContactDetails, objSpclPackName, smsfor);
                        SendSpecialPackageMail(docketNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendSpecialPackageMail(docketNo, "unit", lst.Email, bookingType);
                        }
                    }

                    else if (bookingType == "Taxi" || bookingType == "Bus")
                    {
                        string smsfor = bookingType == "Bus" ? "Bus Booking" : "Taxi Booking";
                        SendBusTaxiBookSmsmanually(docketNo, objCustomer.mobileNo, IEContactDetails, smsfor, objCustomer.pickupDate, Convert.ToDateTime(objCustomer.pickupTime));
                        //SendBusTaxiMail(model.MerchantRefNo, "cust", objCustomer.email, bookingType);

                        foreach (var lst in IEContactDetails)
                        {
                            SendBusTaxiMailmanually(docketNo, "upt", lst.Email, bookingType);
                        }
                    }
                }

                return "success";
            }
            catch
            {
                return "fails";
            }
        }

        public ReconcileApiValues paymentReconcileAPIImplementation(string docketNo)
        {

            ReconcileApiValues model = new ReconcileApiValues();
            try
            {
               
                // Create a request using a URL that can receive a post. 
                WebRequest request = WebRequest.Create(ConfigurationManager.AppSettings["EnquiryByRef_URL"]);
                // Set the Method property of the request to POST.
                request.Method = "POST";

                string postData = "Action=statusByRef&AccountID=" + ConfigurationManager.AppSettings["ACCOUNT_ID"] + "&SecretKey=" + ConfigurationManager.AppSettings["SECRET_KEY"]
                    + "&RefNo=" + docketNo;

                byte[] byteArray = Encoding.UTF8.GetBytes(postData);
                // Set the ContentType property of the WebRequest.
                request.ContentType = "application/x-www-form-urlencoded";
                // Set the ContentLength property of the WebRequest.
                request.ContentLength = byteArray.Length;

                // Get the request stream.
                Stream dataStream = request.GetRequestStream();
                // Write the data to the request stream.
                dataStream.Write(byteArray, 0, byteArray.Length);
                // Close the Stream object.
                dataStream.Close();

                // Get the response.
                WebResponse response = request.GetResponse();
                // Display the status.
                //Response.Write(((HttpWebResponse)response).StatusDescription);
                // Get the stream containing content returned by the server.
                dataStream = response.GetResponseStream();
                // Open the stream using a StreamReader for easy access.
                StreamReader reader = new StreamReader(dataStream);
                // Read the content.
                string responseFromServer = reader.ReadToEnd();
                // Display the content.

                // Clean up the streams.
                reader.Close();
                dataStream.Close();
                response.Close();

                System.Xml.XmlDocument xmlDoc = new System.Xml.XmlDocument();

                xmlDoc.LoadXml(responseFromServer);
               

                //string s = xmlDoc.DocumentElement.Attributes["paymentId"].Value;
                foreach (XmlAttribute Attr in xmlDoc.DocumentElement.Attributes)
                {
                    if (Attr.Name == "transactionId")
                    {
                        model.transactionId = Attr.Value;
                    }
                    else if (Attr.Name == "paymentId")
                    {
                        model.paymentId = Attr.Value;
                    }

                    else if (Attr.Name == "amount")
                    {
                        model.amount = Convert.ToDecimal(Attr.Value);
                    }

                    else if (Attr.Name == "dateTime")
                    {
                        model.dateTime = Convert.ToDateTime(Attr.Value);
                    }

                    else if (Attr.Name == "mode")
                    {
                        model.mode = Attr.Value;
                    }

                    else if (Attr.Name == "referenceNo")
                    {
                        model.referenceNo = Attr.Value;
                    }

                    else if (Attr.Name == "transactionType")
                    {
                        model.transactionType = Attr.Value;
                    }

                    else if (Attr.Name == "status")
                    {
                        model.status = Attr.Value;
                    }

                    else if (Attr.Name == "errorCode")
                    {
                        model.errorCode = Attr.Value;
                    }

                    else if (Attr.Name == "error")
                    {
                        model.error = Attr.Value;
                    }

                    model.docketNo=docketNo;

                }

                if (string.IsNullOrEmpty(model.errorCode))
                {
                    bool IsPaymentDone = false;
                    string Msg = "";
                    if (model.transactionType == "AuthFailed" && model.status == "Processed")
                    {
                        IsPaymentDone=false;
                        Msg = "Transaction Failed";
                    }
                    else if (model.transactionType == "Incompleted")
                    {
                        IsPaymentDone = false;
                        Msg = "Transaction Incomplete";
                    }
                    else if (model.transactionType == "Authorized" && model.status == "Processed")
                    {
                        IsPaymentDone = true;
                        Msg = "Successful Transaction";
                    }

                    if (IsPaymentDone)
                    {
                        var res = objBusinessClass.UpdateFailPaymentByAPI(model);
                        if (res != null)
                        {
                            model.message = res.msg;
                            if (res.flag == 0)
                            {
                                SendMailAfterReconcileBooking(model.docketNo);
                            }
                        }
                        else
                        {
                            model.errorCode = "PF";
                            model.error = "Error Occurred during updating payment Please try again later !";
                        }
                        
                    }
                    else
                    {
                        model.errorCode = "PF";
                        model.error = Msg;
                    }
                }



            }
            catch (Exception ex)
            {
                model.errorCode = "000";
                model.error = ex.Message;
            }

            return model;
        }


        #region to send Paramotor booking sms
        protected void SendParamotorBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string smsFor, string pickupDate, DateTime pickupTime)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["ParamotorBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ForDate]", pickupDate);


                string NodalOfficerSMS = ConfigurationManager.AppSettings["ParamotorNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ForDate]", pickupDate);            


                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                           
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send Paramotor booking mail
        protected void SendParamotorMail(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                ParamotorBookingModel model = objBusinessClass.GetParaMotorView(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/SpecialBooking/ParamotorBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/SpecialBooking/ParamotorBookingConfirmationForNodal.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[ridedate]", model.rideDate);
                MailBody = MailBody.Replace("[NoOfPersonForTwoMinRide]", Convert.ToString(model.noOfGuestforTwoMinRide));
                MailBody = MailBody.Replace("[NoOfPersonForFourMinRide]", Convert.ToString(model.noOfGuestforFourMinRide));



                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[address]", model.address);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);

                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                MailBody = MailBody.Replace("[transactionid]", model.TransactionID);
                MailBody = MailBody.Replace("[banrefno]", model.PaymentID);
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate.ToString());


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                       
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                    else
                    {
                       
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send Hot Air Baloon booking sms
        protected void SendHotAirBaloonBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string smsFor, string pickupDate, DateTime pickupTime)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["HotAirBaloonBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ForDate]", pickupDate);


                string NodalOfficerSMS = ConfigurationManager.AppSettings["HotAirBaloonNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ForDate]", pickupDate);


                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                           
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send Hot Air Baloon booking mail
        protected void SendHotAirBaloonMail(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                HotAirBaloonBookingDetailsModel model = objBusinessClass.GetHotAirBaloonRideView(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/SpecialBooking/HotAirBaloonBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/SpecialBooking/HotAirBaloonBookingConfirmationForNodal.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[ridedate]", model.RideDate);
                MailBody = MailBody.Replace("[NoOfPerson]", model.NoofPersons.ToString());
               



                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[address]", model.address);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);

                MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                MailBody = MailBody.Replace("[transactionid]", model.TransactionID);
                MailBody = MailBody.Replace("[banrefno]", model.PaymentID);
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate.ToString());


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

    }

  
}
