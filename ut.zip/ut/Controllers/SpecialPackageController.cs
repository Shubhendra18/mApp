﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;

namespace UP_TourismBooking.Controllers
{
    public class SpecialPackageController : Controller
    {
        BusinessClass objBusinessClass = new BusinessClass();
        //
        // GET: /SpecialPackage/

        public ActionResult Index()
        {
            ClearSession();
            return View();
        }

        public ActionResult SpecialHotelPackage()
        {
            ClearSession();
            return View();
        }
       [HttpGet]
        public ActionResult SpecialHotelsInfo()
        {
            ViewBag.Units = objBusinessClass.GetallSpecialUnits(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
          
            ViewBag.FunctionType = objBusinessClass.GetFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });
            return PartialView("_SpecialHotelsInfo");
        }

      


        [HttpPost]
        public ActionResult SpecialHotelsInfo(SpecialUnitBooking model)
        {
            try
            {

                if (ModelState.IsValid)
                {
                    if (!IsDateValid(model.checkInDate, model.checkOutDate, "UNIT"))
                    {
                        return RedirectToAction("SpecialHotelPackage", "SpecialPackage");
                    }
                   
                    Session["unitID"] = model.unitID;
                    Session["checkInDate"] = model.checkInDate;
                    Session["checkOutDate"] = model.checkOutDate.AddDays(-1);
                    Session["noOfGuests"] = model.noOfGuests;
                    Session["noOfRooms"] = model.noOfRooms;
                    var result = objBusinessClass.getDestination(model);
                    Session["destinationName"] = result.destinationName;
                    return RedirectToAction("SpecialUnitDetails", "SpecialPackage",new{Id=Session["unitID"]} );
                }
                return RedirectToAction("SpecialHotelPackage", "SpecialPackage");
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }

        #region display unit details
        [HttpGet]
        public ActionResult SpecialUnitDetails(int Id)
        {
            try
            {
                if (SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("checkOutDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("noOfRooms"))
                {
                    Session["unitID"] = Id;

                    SpecialUnitDetails obj_unit = new SpecialUnitDetails();
                    obj_unit = objBusinessClass.GetSpecialUnitDisplayinfo(Id);
                    obj_unit.IEAmenities = objBusinessClass.GetUnitWiseAmenitiesList(Id);
                    obj_unit.IERooms = objBusinessClass.GetSpecialUnitRoomList(Id, Convert.ToDateTime(Session["checkInDate"].ToString()), Convert.ToDateTime(Session["checkOutDate"].ToString()), Convert.ToInt32(Session["noOfRooms"].ToString()));

                    obj_unit.IEImages = objBusinessClass.GetUnitImageList(Id);

                    return View(obj_unit);
                }
                else
                {
                    return RedirectToAction("SpecialHotelsInfo", "SpecialPackage");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region check for valid date

        public bool IsDateValid(DateTime dtCheckin, DateTime dtCheckout, string type)
        {
            bool returnMsg = true;
            DateTime currDate = new DateTime(2019, 01, 14);
            DateTime maxCheckInDate = new DateTime(2019, 03, 04);
            DateTime maxCheckOutDate = new DateTime(2019, 03, 06);
            DateTime minChekin = new DateTime(2019, 01, 15);

            if (type == "UNIT")
            {
                if ((dtCheckin < currDate.Date) || (dtCheckout < currDate) || (dtCheckout < dtCheckin) || (dtCheckin > maxCheckInDate) || (dtCheckout > maxCheckOutDate))
                {
                    returnMsg = false;
                }
            }
           
            return returnMsg;
        }
        #endregion
        #region Method - to clear session
        private void ClearSession()
        {
            Session.Remove("destination");
            Session.Remove("checkInDate");
            Session.Remove("checkOutDate");
            Session.Remove("noOfGuests");
            Session.Remove("noOfRooms");
            Session.Remove("destinationName");
            Session.Remove("unitID");
            Session.Remove("singleRoom");
            Session.Remove("doubleRoom");
            Session.Remove("roomID");
            Session.Remove("extraBed");
            Session.Remove("privilegecard");
            Session.Remove("bookingType");
            Session.Remove("tourDestination");
            Session.Remove("arrivalDate");
            Session.Remove("noOfTourists");
            Session.Remove("isIndian");
            Session.Remove("packageID");
            Session.Remove("acbusArrivalDate");
            Session.Remove("acbusNoOfTourists");
            Session.Remove("acbusIsIndian");
            Session.Remove("acbusPackageID");
            Session.Remove("packageName");
            Session.Remove("totalAmount");
            Session.Remove("nationality");
            Session.Remove("ApplicantType");
            Session.Remove("paymentStatus");
            Session.Remove("PaymentID");
            Session.Remove("functionType");
            Session.Remove("enquiryNo");
        }
        #endregion
    }
}
