﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Mvc;
using UP_TourismBooking.Models.ProcessClasses;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models;
using System.Globalization;
using System.Data;
using System.IO;
using System.Xml.Linq;
using System.Configuration;
using System.Web.Hosting;
using System.Text.RegularExpressions;
// Module Name- CRS Login
namespace UP_TourismBooking.Controllers
{
    [AuthorizeCRS]
    public class UPToursController : Controller
    {
        #region Declarations
        BusinessClass objBusinessClass = new BusinessClass();
        Common objCommonClass = new Common();
        private Regex pinCode = new Regex(@"^(\d{6})$", RegexOptions.Compiled);
        private Regex mobileNo = new Regex(@"^(\d{10})$", RegexOptions.Compiled);

        #endregion

        #region Dashboard page
        [HttpGet]
        public ActionResult Dashboard()
        {
            return View();
        }
        #endregion

        /*--------------------Vacancy Status---------------------------*/

        #region display vacancy status
        [HttpGet]
        public ActionResult VacancyStatus()
        {
            UPTourVacancyStatus model = new UPTourVacancyStatus();
            try
            {
                model.dtBooking = DateTime.Now;
                model.BookingInTime = DateTime.Now;
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region bind vacancy status grid
        public ActionResult GetVacancyStatus(string dtBooking, Int64 unitID, DateTime dtBookingTime)
        {
            UPTourVacancyStatus model = new UPTourVacancyStatus();
            try
            {
                if (dtBookingTime.Hour < 12)
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                }
                else
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.unitID = unitID;
                model.bookingStatusList = objBusinessClass.GetUPTourVacancyStatus(model);
            }
            catch
            {

            }
            return PartialView("_VacancyStatusGrid", model.bookingStatusList);
        }
        #endregion

        #region Print Vacancy Status
        public ActionResult PrintVacancyStatus(string dtBooking, Int64 UnitId, DateTime dtBookingTime)
        {
            UPTourVacancyStatus model = new UPTourVacancyStatus();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBooking) ? "-" : dtBooking;
            try
            {
                if (dtBookingTime.Hour < 12)
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                }
                else
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.unitID = UnitId;
                model.bookingStatusList = objBusinessClass.GetUPTourVacancyStatus(model);
                return View(model.bookingStatusList);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export vacancy status excel
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult VacancyStatus(UnitVacancyStatus obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            UnitVacancyStatus objR = new UnitVacancyStatus();
            objR.BookingInTime = obj.BookingInTime;
            if (objR.BookingInTime.Hour < 12)
            {
                objR.dtBooking = obj.dtBooking.AddDays(-1);
            }
            else
            {
                objR.dtBooking = obj.dtBooking;
            }
            objR.unitID = obj.unitID;
            objR.bookingStatusList = obj.bookingStatusList;

            var dtresult = objBusinessClass.GetUnitVacancyStatus(objR);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Room_Type = e.roomType, Total_Rooms = e.totalRoom, Online_Booking = e.onlineBooked, Package_Tours_Booking = e.packageBooked, UP_Tours_Booking = e.upTourBooked, ARC_Booking = e.arcBooked, CRS_Booking = e.crsBooked, Counter_Booking = e.counterBooked, Out_of_Service = e.OutS, Hold = e.blocked, Vacant = e.vacant }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/VacancyStatus.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookingStatusList = dtresult;
            return View(obj);
        }
        #endregion

        /*--------------------End Vacancy Status---------------------------*/

        /*------------------------Booking List----------------------*/

        #region display booking list
        [HttpGet]
        public ActionResult BookedList()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBookedList(string dtBookingFrom, string dtBookingTo, string docket, Int64 UnitId)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket.Trim();
                model.unitID = UnitId;
                model.bookedList = objBusinessClass.GetUPTourBookingStatus(model);
            }
            catch
            {
            }
            return PartialView("_BookedListGrid", model.bookedList);
        }
        #endregion

        #region Print Booking Done by Syed
        public ActionResult PrintBookingDone(string dtBookingDateFrom, string dtBookingDateTo, string docketNo, Int64? unitID)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBookingDateFrom) ? "-" : dtBookingDateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dtBookingDateTo) ? "-" : dtBookingDateTo;
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                unitID = unitID ?? 0;
                model.docketNo = docketNo.Trim();
                model.unitID = unitID;
                model.bookedList = objBusinessClass.GetUPTourBookingStatus(model);
                return View(model.bookedList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookedList(UPTourTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetUPTourBookingStatus(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Mobile_No = e.mobileNo, Email_Id = e.email, Date_Of_Birth = e.DateofBirth, Anniversary_Date = e.AnniversaryDate, City_Name = e.cityName, Country_Name = e.countryName, stateName = e.stateName, Docket_No = e.docketNo, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Total_Room = e.totalRoom, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Booking_Status = e.BookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookedList = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(obj);
        }
        #endregion

        /*------------------------End Booking List----------------------*/

        #region Display payment details
        [HttpGet]
        public ActionResult PaymentDetails()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                return View();
            }
            catch
            {
                return View("Error");
            }
        }
        #endregion

        #region Get payment details
        [HttpGet]
        public ActionResult PaymentList(string paymentDateFrom, string paymentDateTo, Int64 UnitId, string docketNo)
        {
            DateTime _payDateFrom, _payDateTo;
            List<PaymentDetails> objPayment = new List<PaymentDetails>();
            try
            {
                try
                {
                    _payDateFrom = DateTime.ParseExact(paymentDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    _payDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    _payDateTo = DateTime.ParseExact(paymentDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    _payDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                Int64 _unitId = UnitId;

                objPayment = objBusinessClass.GetPaymentDetails(_payDateFrom, _payDateTo, _unitId, docketNo.Trim());
            }
            catch
            {
            }
            return PartialView("_PaymentList", objPayment);
        }
        #endregion

        #region Print Payment Details by Syed
        public ActionResult PrintPaymentDetails(string paymentDateFrom, string paymentDateTo, Int64 UnitId, string docketNo)
        {
            DateTime _payDateFrom, _payDateTo;
            List<PaymentDetails> objPayment = new List<PaymentDetails>();
            ViewBag.fromdate = string.IsNullOrEmpty(paymentDateFrom) ? "-" : paymentDateFrom;
            ViewBag.todate = string.IsNullOrEmpty(paymentDateTo) ? "-" : paymentDateTo;
            try
            {
                try
                {
                    _payDateFrom = DateTime.ParseExact(paymentDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    _payDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    _payDateTo = DateTime.ParseExact(paymentDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    _payDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                Int64 _unitId = UnitId;

                objPayment = objBusinessClass.GetPaymentDetails(_payDateFrom, _payDateTo, _unitId, docketNo.Trim());
                return View(objPayment);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region Advance Payment List
        [HttpGet]
        public ActionResult AdvancePaymentList(string docketNo, Int64 UnitID)
        {
            string _msg;
            try
            {

                List<PaymentDetails> objPayment = objBusinessClass.GetAdvancePaymentDetails(docketNo, UnitID);
                if (objPayment != null && objPayment.Count > 0)
                {
                    return PartialView("_AdvancePaymentList", objPayment);
                }
                else
                {
                    _msg = "Details Not Found!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }


        #endregion

        /*------------------------Special Package Booking List----------------------*/

        #region Display special package booking list
        [HttpGet]
        public ActionResult SpecialBookedList()
        {
            return View();
        }
        #endregion

        #region bind special package booking grid
        public ActionResult GetSpecialBookedList(string dtBookingFrom, string dtBookingTo, string docket, string bookingType)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket.Trim();
                model.type = bookingType.Trim();
                model.bookedList = objBusinessClass.GetUPTourSpecialBookingStatus(model);
            }
            catch
            {

            }
            return PartialView("_SpecialBookedListGrid", model.bookedList);
        }
        #endregion

        #region Print Special Packages Booking Done by Syed
        public ActionResult PrintSpecialPackagesBookingDone(string dtBookingDateFrom, string dtBookingDateTo, string docketNo, string type)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBookingDateFrom) ? "-" : dtBookingDateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dtBookingDateTo) ? "-" : dtBookingDateTo;
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.type = type.Trim();
                model.bookedList = objBusinessClass.GetUPTourSpecialBookingStatus(model);
                return View(model.bookedList);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region special package details
        [HttpGet]
        public ActionResult SpecialBookingDetail(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            string _msg = "";
            try
            {
                obj_BookingList = objBusinessClass.GetUPTourSpecialDetails(docketNo, 0);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            return PartialView("_SpecialBookedDetails", obj_BookingDetail);
        }
        #endregion

        #region export special booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SpecialBookedList(UPTourTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }

            try
            {
                if (string.IsNullOrEmpty(obj.type.ToString()))
                {
                    obj.type = "";
                }
            }
            catch
            {
                obj.type = "";
            }

            var dtresult = objBusinessClass.GetUPTourSpecialBookingStatus(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Docket_No = e.docketNo, Mobile_No = e.mobileNo, Booking_Date = e.checkInDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Booking_Status = e.BookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/SpecialPackagesBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookedList = dtresult;
            return View(obj);
        }

        #endregion

        /*------------------------End Special Package Booking List----------------------*/


        /*------------------------Package Tour Booking----------------------*/

        #region display package tour booking form
        [HttpGet]
        public ActionResult PackageTourBooking()
        {
            try
            {
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                ViewBag.Category = objBusinessClass.GetPackageTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.Nationality = GetNationality();
                ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region bind category wise packages
        [HttpGet]
        public JsonResult getPackageTourList(int packageCategoryID)
        {
            IEnumerable<SelectListItem> obj = null;
            try
            {
                obj = objBusinessClass.getPackageTourList(packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            }
            catch
            {
            }
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region book package tour
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageTourBooking(PackageTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _msg = "Enter a valid 6 digit Pincode!";
                        isValid = false;
                    }
                    else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                    {
                        _msg = "Enter a valid 10 digit Mobile No.!";
                        isValid = false;
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {

                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    PackageAvailabilityDetails objPack = new PackageAvailabilityDetails();
                    objPack.arrivalDate = model.ArrivalDate;
                    objPack.noOfGuests = model.noOfGuests;
                    objPack.packageID = model.packageID;

                    var isAvailable = objBusinessClass.ChkPackageTourAvailability(objPack);
                    if (isAvailable.isAvailable != null && isAvailable.isAvailable == false)
                    {
                        _msg = "Package Not Available for date- " + objPack.arrivalDate;
                    }
                    else
                    {
                        model.bookingFor = "PACK";
                        model.bookingBy = "CRS";
                        model.receiptNo = "CRS Payment";

                        var user = objBusinessClass.savePackageTourBookingDetails(model);
                        if (user != null)
                        {
                            if (user.docketNo == "")
                            {
                                _msg = "Your Package Could Not Be Booked Due To Unavailabiity!";
                            }
                            else
                            {
                                TempData["DocketNo"] = user.docketNo;

                                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                                SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(user.docketNo);
                                try
                                {
                                    SendPackageBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName);
                                    SendPackageTourMail(user.docketNo, model.email, IEContactDetails);
                                }
                                catch
                                { }
                                return RedirectToAction("PakageTourConfirmation");
                            }
                        }
                        else
                        {
                            _msg = "Package Tour Not Booked!";
                        }
                    }
                }
            }
            catch
            {
                _msg = "Error in Package Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region package tour booking confirmation
        public ActionResult PakageTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                model.docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetCRSBookingDetails(model.docketNo);
                if (model != null)
                {
                    model.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(model.docketNo);
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion


        /*------------------------End Package Tour Booking----------------------*/

        #region for cancellation request process
        [HttpGet]
        public ActionResult CancellationRequest(string docketNo)
        {
            //BookingCancellation model = new BookingCancellation();
            //model.docketNo = docketNo;
            //try
            //{
            //    if (TempData["message"] != null && TempData["message"].ToString() != "")
            //    {
            //        ViewBag.Show = TempData["message"];
            //    }
            //    model.lstCanceRequest = objBusinessClass.GetCancelRequestForPackages(model);
            //}
            //catch
            //{

            //}
            //return View(model);
            return View();
        }

        [HttpGet]
        public ActionResult CancellationRequestFiltered(string docketNo, string fromDate, string toDate)
        {
            BookingCancellation model = new BookingCancellation();
            try
            {
                model.FromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", null);
            }
            catch
            {
                model.FromDate = null;
            }
            try
            {
                model.ToDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", null);
            }
            catch
            {
                model.ToDate = null;
            }
            model.docketNo = docketNo;
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCancelRequestForPackages(model);
            }
            catch
            {

            }
            return PartialView("_cancelRequestGrid", model.lstCanceRequest);
        }

        [HttpGet]
        public ActionResult CancellationRequestConfirmation(string id)
        {
            //  int status = objBusinessClass.InsertCancellationConfirmation(id);
            //var CancelDetails = objBusinessClass.InsertCancellationConfirmationByCRS(id);
            //if (!string.IsNullOrEmpty(CancelDetails.cancelRefNo) && !string.IsNullOrEmpty(CancelDetails.BookingFor))
            //{
            //    //if (status > 0)
            //    //{
            //    //Send Email
            //    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmail(id);
            //    // Send SMS to customer
            //    SendAcceptanceSMS(id, IEContactDetails, CancelDetails.BookingFor);
            //    SendAcceptanceEMail(id, IEContactDetails, CancelDetails.BookingFor);
            //    TempData["message"] = "Request Accepted Successfully.";
            //    return RedirectToAction("CancellationRequest", "UPTours");
            //}
            //else
            //{
            //    ViewBag.Show = "Request Not Cancelled.";
            //}
            //return View("CancellationRequest");


            int status = objBusinessClass.InsertCancellationConfirmation(id.Trim(), Common.GetIPAddress());
            if (status > 0)
            {
                #region send mail and sms to user and nodal officer
                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.GetOfficerMobileNoForUnit(id.Trim());
                SendAcceptanceSMS(id, IEContactDetails);
                SendAcceptanceEMail(id, IEContactDetails);
                #endregion
                return Content("1");
            }
            //else
            //{
            //    ViewBag.Show = "Request Not Cancelled.";
            //}
            return Content("0");
        }

        [HttpGet]
        public ActionResult CancelledRequest(string docketNo)
        {
            BookingCancellation model = new BookingCancellation();
            model.docketNo = docketNo;
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCancelRequestForPackages(model);
            }
            catch
            {

            }
            return View(model.lstCanceRequest);
        }
        #endregion

        #region To add customer registration details

        #region customer registration
        [HttpGet]
        public ActionResult CustomerRegistration()
        {
            try
            {
                //  Int64 _unitId = SessionManager.UnitID;
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                //     ViewBag.RoomType = objBusinessClass.GetRoomType(_unitId).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
                ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
                ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
                ViewBag.Nationality = GetNationality();
                ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
                CustomerRegistration model = new CustomerRegistration();
                //   model.unitID = _unitId;
                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CustomerRegistration(CustomerRegistration model)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                #region Validate Uploaded Doc
                if (model.staffIdDoc != null)
                {
                    string ext = Path.GetExtension(model.staffIdDoc.FileName);
                    string filename = Path.GetFileName("StaffDoc_" + DateTime.Now.Ticks + ext);
                    string res = objCommonClass.ValidateImageWithCusomSize(model.staffIdDoc, 400);
                    if (res.Trim() != "Valid")
                    {
                        _isValid = false;
                        _msg = res;
                    }
                    else
                    {
                        model.staffIdDocPath = Path.Combine("~/Content/writereaddata/PrivilegeCard/", filename);
                        var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/PrivilegeCard/"), filename);
                        model.staffIdDoc.SaveAs(docPath);
                    }
                }

                #endregion
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                ModelState["checkInTime"].Errors.Clear();
                ModelState["checkOutTime"].Errors.Clear();
                ModelState["staffGrade"].Errors.Clear();
                ModelState["staffFacility"].Errors.Clear();
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.pincode))
                {
                    ModelState["pincode"].Errors.Clear();
                }
                //if (string.IsNullOrEmpty(Convert.ToString(model.advanceAmount)))
                //{
                //    ModelState["advanceAmount"].Errors.Clear();
                //}
                if (model.customerType == 'B')
                {
                    ModelState["roomType"].Errors.Clear();
                    if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                    {
                    }
                    else
                    {
                        _isValid = false;
                        _msg = "Provide Room Details ";
                        ModelState.AddModelError("", "Provide Room Details ");
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(Convert.ToString(model.roomType)))
                    {
                        _isValid = false;
                        _msg = "Select Room!! ";
                        ModelState.AddModelError("", "Select Room!! ");
                    }
                    if (model.customerType == 'S')
                    {
                        model.isStaff = true;
                        if (model.staffId == null)
                        {
                            _isValid = false;
                            _msg = "Enter Staff Id!! ";
                            ModelState.AddModelError("", "Enter Staff Id!! ");
                        }
                        else if (model.staffIdDoc == null)
                        {
                            _isValid = false;
                            _msg = "Upload Staff Identity!! ";
                            ModelState.AddModelError("", "Upload Staff Identity!! ");
                        }
                        else if (model.staffGrade == null || model.staffGrade == 0)
                        {
                            _isValid = false;
                            _msg = "Select Staff Grade!! ";
                            ModelState.AddModelError("", "Select Staff Grade!! ");
                        }
                        else if (model.staffFacility == null || model.staffFacility == 0)
                        {
                            _isValid = false;
                            _msg = "Select Staff Tariff!! ";
                            ModelState.AddModelError("", "Select Staff Tariff!! ");
                        }
                    }
                }
                if (ModelState.IsValid && _isValid == true)
                {
                    model.roleID = "OCST";
                    model.userIP = this.Request.UserHostAddress;
                    string isValid = IsDateValid(model);
                    if (string.IsNullOrEmpty(isValid))
                    {
                        if (model.staffIdDoc != null)
                        {
                            string ext = Path.GetExtension(model.staffIdDoc.FileName);
                            string filename = Path.GetFileName(DateTime.Now.Ticks + ext);

                            model.staffIdDocPath = Path.Combine("/Content/writereaddata/Documents", filename);
                            var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                            model.staffIdDoc.SaveAs(docPath);
                        }
                        else
                        {
                            model.staffIdDocPath = "";
                            model.staffId = "";
                            model.staffGrade = 0;
                            model.staffFacility = 0;
                        }

                        #region changes for bulk booking
                        bool _isExtraBedAvail = true, _chkRoomLimit = true, _isDataChecked = true;
                        int _totalExtraBedRequire = 0;
                        if (model.customerType == 'B')
                        {
                            int _extraBedBulk = 0, _singleBulk = 0, _doubleBulk = 0, _totalRooms = 0, _maxCapacity = 0, _maxAllowedGuest = 0, _singleNonOc = 0;
                            foreach (var item in model.lstBookedRoomDetail)
                            {
                                _singleBulk += item.singleRoom;
                                _doubleBulk += item.doubleRoom;
                                //_extraBedBulk = _extraBedBulk + (item.hasOccupancy == true ? 1 * (item.doubleRoom) : 0);
                                _extraBedBulk += item.extrabed;
                                _maxCapacity = _maxCapacity + (item.hasOccupancy == false ? (item.maxCapacity) * (item.singleRoom) : 0);
                                _singleNonOc = _singleNonOc + (item.hasOccupancy == false ? (item.singleRoom) : 0);



                                if (item.hasOccupancy)
                                {
                                    if (item.extrabed > (item.doubleRoom * item.maxExtraBed))
                                    {
                                        _isDataChecked = false;
                                        _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";
                                        ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                        break;
                                    }
                                    _maxAllowedGuest += ((item.singleRoom + (item.doubleRoom * 2)) + (item.doubleRoom * item.maxExtraBed));
                                }
                                else
                                {
                                    if (item.extrabed > (item.singleRoom * item.maxExtraBed))
                                    {
                                        _isDataChecked = false;
                                        _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";
                                        ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                        break;
                                    }
                                    _maxAllowedGuest += ((item.singleRoom * item.maxCapacity) + (item.singleRoom * item.maxExtraBed));
                                }
                            }
                            if (_isDataChecked == true)
                            {
                                _totalRooms = _singleBulk + _doubleBulk;
                                _totalExtraBedRequire = model.noOfGuests - ((_singleBulk - _singleNonOc) + (_doubleBulk * 2) + _maxCapacity);
                                //_maxAllowedGuest = _singleBulk + (_doubleBulk * 2) + _extraBedBulk + (_maxCapacity - _singleNonOc); ;

                                #region max capacity for bulk booking
                                if (_totalRooms > model.noOfGuests)
                                {
                                    _chkRoomLimit = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                                }
                                else if (model.noOfGuests > _maxAllowedGuest)
                                {
                                    _chkRoomLimit = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                else if (_extraBedBulk < _totalExtraBedRequire)
                                {
                                    _isExtraBedAvail = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                model.noOfRooms = _totalRooms;
                            }
                                #endregion
                        }
                        else
                        {
                            model.noOfRooms = model.singleRoom + model.doubleRoom;
                            if (model.hasOccupancy)
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Single and Double rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Single and Double rooms should be less than equal to No. of Guests!");
                                }
                                else if (model.extrabed > (model.doubleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                else if (((model.singleRoom + (model.doubleRoom * 2)) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                            }
                            else
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                                }
                                else if (model.extrabed > (model.singleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                else if (((model.singleRoom * model.maxCapacity) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                            }

                            RoomDetail objRoomList = new RoomDetail();
                            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
                            objRoomList.roomType = model.roomType;
                            objRoomList.roomTypeDisplay = model.roomTypeDisplay;
                            objRoomList.singleRoom = model.singleRoom;
                            objRoomList.doubleRoom = model.doubleRoom;
                            objRoomList.hasOccupancy = model.hasOccupancy;
                            objRoomList.Sno = lstBookedRoom.Count + 1;

                            //if (model.hasOccupancy)
                            //{
                            //    model.extrabed = model.noOfGuests - (model.singleRoom + (model.doubleRoom * 2));
                            //    model.extrabed = (model.extrabed > 0) ? model.extrabed : 0;
                            //}
                            //else
                            //{
                            //    model.extrabed = 0;
                            //}
                            objRoomList.extrabed = model.extrabed;
                            lstBookedRoom.Add(objRoomList);
                            model.lstBookedRoomDetail = lstBookedRoom;
                        }
                        //model.noOfRooms = model.singleRoom + model.doubleRoom;
                        int totalDays = model.checkOutDate.Subtract(model.checkInDate).Days;
                        bool _isRoomAvl = true;
                        int _noOfRooms = 0;
                        decimal reqAdvAmt = GetRequiredAdvanceAmount(model);
                        if (model.customerType == 'B' && (model.advanceAmount == null || model.advanceAmount <= 0 || (model.advanceAmount < reqAdvAmt)))
                        {
                            _isDataChecked = false;
                            _msg = "Insufficient Advance Amount. Minimum Advance Amount " + reqAdvAmt;
                            ModelState.AddModelError("", "Insufficient Advance Amount. Minimum Advance Amount " + reqAdvAmt);
                        }
                        foreach (var item in model.lstBookedRoomDetail)
                        {
                            int _extrabedAdd = 0;
                            RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                            objRoom.roomTypeId = item.roomType;
                            objRoom.unitId = model.unitID;
                            _noOfRooms = item.singleRoom + item.doubleRoom;
                            //if (model.customerType == 'B' && _totalExtraBedRequire > 0)
                            //{
                            //    _extrabedAdd = item.hasOccupancy == true ? 1 * (item.doubleRoom) : 0;
                            //    if (_extrabedAdd > 0 && _extrabedAdd > _totalExtraBedRequire)
                            //    {
                            //        //_extrabedAdd = _extrabedAdd - _totalExtraBedRequire;
                            //        item.extrabed = _totalExtraBedRequire;
                            //        _totalExtraBedRequire = 0;
                            //    }
                            //    else
                            //    {
                            //        item.extrabed = _extrabedAdd;
                            //        //   _extrabedAdd = _totalExtraBedRequire - _extrabedAdd;
                            //        _totalExtraBedRequire = _totalExtraBedRequire - _extrabedAdd;
                            //    }

                            //}

                            for (int i = 0; i < totalDays; i++)
                            {
                                objRoom.bookingDate = model.checkInDate.AddDays(i);
                                var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                {
                                    _isRoomAvl = false;
                                    _msg = "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                    ModelState.AddModelError("", "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy"));
                                    break;
                                }
                            }
                            if (_isRoomAvl == false)
                            {
                                break;
                            }
                        }

                        var roomXml = new XElement("booking",
                                     from room in model.lstBookedRoomDetail
                                     select new XElement("customer",
                                                    new XElement("Sno", room.Sno),
                                                    new XElement("roomType", room.roomType),
                                                    new XElement("singleRoom", room.singleRoom),
                                                    new XElement("doubleRoom", room.doubleRoom),
                                                    new XElement("extrabed", room.extrabed)
                                                ));
                        model.bookingXML = roomXml.ToString();
                        #endregion
                        if (_isRoomAvl == true && _isDataChecked == true && _isExtraBedAvail == true && _chkRoomLimit == true)
                        {
                            model.userID = model.unitID;
                            //model.bookingFor = "UCNTU";
                            model.bookingFor = "UNIT";
                            model.bookingBy = "CRS";
                            var user = objBusinessClass.InsertCustomerBooking(model);

                            if (user != null)
                            {
                                #region send mail and sms
                                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(user.docketNo);

                                foreach (var lst in IEContactDetails)
                                {
                                    if (lst.sendTo == "CUSTOMER")
                                    {
                                        SendUnitRoomMail(user.docketNo, "CUSTOMER", lst.Email);
                                        SendUnitBookSms(user.docketNo, lst.MobileNo, "CUSTOMER");
                                    }
                                    else if (lst.sendTo == "UNIT")
                                    {
                                        SendUnitRoomMail(user.docketNo, "UNIT", lst.Email);
                                        SendUnitBookSms(user.docketNo, lst.MobileNo, "UNIT");
                                    }
                                }
                                #endregion
                                SessionManager.UnitID = model.unitID;
                                SessionManager.DocketNo = user.docketNo;
                                return RedirectToAction("RegistrationConfirmation");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Room Not Booked!");
                                _msg = "Room Not Booked!";
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", isValid);
                        _msg = isValid;
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Error in CustomerRegistration!");
                    _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
                }
            }
            catch
            {
                ModelState.AddModelError("", "Error in CustomerRegistration!");
                _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
            }
            //Int64 _unitId = SessionManager.UnitID;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
            ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        #region customer registration Confirmation
        [HttpGet]
        public ActionResult RegistrationConfirmation()
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();
                model.unitID = SessionManager.UnitID;
                model.docketNo = SessionManager.DocketNo;

                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        #endregion
        #endregion

        #region Special Packages Booking through UPTour
        #region Tonga Rode Booking through UPTour
        [HttpGet]
        public ActionResult LkoOnTonga()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            LkoOnTonga model = new LkoOnTonga();
            model.noOfGuests = 4;
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoOnTonga(LkoOnTonga model)
        {
            string _msg = "";
            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }

                if (ModelState.IsValid)
                {
                    if (model.staffIdDoc != null)
                    {
                        string ext = Path.GetExtension(model.staffIdDoc.FileName);
                        string filename = Path.GetFileName(DateTime.Now.Ticks + ext);

                        model.staffIdDocPath = Path.Combine("/Content/writereaddata/Documents", filename);
                        var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                        model.staffIdDoc.SaveAs(docPath);
                    }
                    else
                    {
                        model.staffIdDocPath = "";
                        model.staffId = "";
                    }

                    model.roleID = "UPTT";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    model.routeType = model.RouteFare == 600 ? "Package 1-Heritage Ride on Tonga" : (model.RouteFare == 1000 ? "Package 2-Kaiserbagh Ki Sair on Tonga with Guide" : "Package 3-Lucknow Darshan- Old City Tour on Tonga with Guide");
                    var user = objBusinessClass.saveTongaBookingDetails(model);
                    if (user != null)
                    {
                        if (user.docketNo == "")
                        {
                            _msg = "Your Tonga Ride Could Not Be Booked Due To Unavailabiity!";
                        }
                        else
                        {
                            SessionManager.DocketNo = user.docketNo;
                            return RedirectToAction("TongaRideConfirmation");
                        }
                    }
                    else
                    {
                        _msg = "Tonga Ride Not Booked!";
                    }

                }

            }

            catch
            {
                _msg = "Error in Tonga Ride Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            model.noOfGuests = 4;
            return View(model);
        }

        public ActionResult TongaRideConfirmation()
        {
            LkoOnTonga model = new LkoOnTonga();
            model.docketNo = SessionManager.DocketNo;

            return View(model);
        }
        #endregion

        #region Cycle Tour Booking through UPTour
        [HttpGet]
        public ActionResult LkoOnCycle()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            LkoOnCycle model = new LkoOnCycle();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoOnCycle(LkoOnCycle model)
        {
            string _msg = "";
            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }

                if (ModelState.IsValid)
                {
                    if (model.staffIdDoc != null)
                    {
                        string ext = Path.GetExtension(model.staffIdDoc.FileName);
                        string filename = Path.GetFileName(DateTime.Now.Ticks + ext);

                        model.staffIdDocPath = Path.Combine("/Content/writereaddata/Documents", filename);
                        var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                        model.staffIdDoc.SaveAs(docPath);
                    }
                    else
                    {
                        model.staffIdDocPath = "";
                        model.staffId = "";
                    }

                    model.roleID = "UPTC";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    model.totalAmount = model.RouteFare * model.noOfGuests;
                    var user = objBusinessClass.saveCycleTourBookingDetails(model);
                    if (user != null)
                    {
                        //SessionManager.UserID = user.userID;
                        SessionManager.DocketNo = user.docketNo;

                        return RedirectToAction("CycleTourConfirmation");
                    }
                    else
                    {
                        ModelState.AddModelError("", "Cycle Tour Not Bookeed!");
                        _msg = "Cycle Tour Not Booked!";
                    }
                }

            }

            catch
            {
                ModelState.AddModelError("", "Error in Cycle Tour Booking!");
                _msg = "Error in Cycle Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            model.noOfGuests = 4;
            return View(model);
        }

        #endregion
        #endregion

        #region to send sms on booking cancellation
        protected void SendAcceptanceSMS(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["AcceptCancelBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string customerOthers = ConfigurationManager.AppSettings["AcceptCancelBookingSMSOther"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerOthers = customerOthers.Replace("[DocketNo]", docketNo);

                try
                {
                    string SMSStatus = "";

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "UNIT")
                            {
                                SMSStatus = SMS.SMSSend(customerOthers, lst.MobileNo);    // Send SMS to Unit
                                SMS.SMSLog(customerOthers, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(customerOthers, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(customerOthers, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(customerOthers, lst.MobileNo);    // Send SMS to Unit
                                SMS.SMSLog(customerOthers, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "CUSTOMER")
                            {
                                SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);     // Send SMS to Customer
                                SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            //    string customerSms = ConfigurationManager.AppSettings["AcceptCancelBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
            //    customerSms = customerSms.Replace("[DocketNo]", docketNo);

            //    try
            //    {
            //        string SMSStatus = "";

            //        foreach (var lst in contactDetails)
            //        {
            //            try
            //            {
            //                SMSStatus = string.Empty;
            //                if (bookingFor == "UNIT")
            //                {
            //                    if (lst.sendTo == "NODAL")
            //                    {
            //                        SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);     // Send SMS to Nodal Officer
            //                        SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
            //                    }
            //                }
            //                if (lst.sendTo == "CUSTOMER")
            //                {
            //                    SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);     // Send SMS to Customer
            //                    SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
            //                }

            //            }
            //            catch { }
            //        }
            //    }
            //    catch { }
            //}
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send mail on booking cancellation
        protected void SendAcceptanceEMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string subject = "UP Tourism Booking Cancellation Status";
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/AcceptCancelRequest.html"));
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", docketNo);

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/AcceptCancelRequest.html"));
                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);

                foreach (var lst in contactDetails)
                {
                    try
                    {
                        if (lst.sendTo == "UNIT")  // Send Email to Unit
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                        if (lst.sendTo == "NODAL")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                        if (lst.sendTo == "UPTOURS")
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                        if (lst.sendTo == "CUSTOMER")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }

                    }
                    catch { }
                }

                //string subject = "UP Tourism Booking Cancellation Status";
                //StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/AcceptCancelRequest.html"));
                //string MailBody = reader.ReadToEnd();
                //MailBody = MailBody.Replace("[docketno]", docketNo);

                //StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/AcceptCancelRequest.html"));
                //string MailBodyOthers = readerOthers.ReadToEnd();
                //MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);

                //foreach (var lst in contactDetails)
                //{
                //    try
                //    {
                //        if (bookingFor == "UNIT")
                //        {
                //            if (lst.sendTo == "NODAL")       // Send Email to Nodal Officer (CRS)
                //            {
                //                MailService.Service1 objService = new MailService.Service1();
                //                MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                //                objService.sendMail(objMail);
                //            }
                //        }
                //        if (lst.sendTo == "CUSTOMER")       // Send Email to Nodal Officer
                //        {
                //            MailService.Service1 objService = new MailService.Service1();
                //            MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                //            objService.sendMail(objMail);
                //        }

                //    }
                //    catch { }
                //}
            }
            catch (Exception)
            {
            }
        }
        #endregion

        //#region Cancellation Acceptance
        //[HttpGet]
        //public ActionResult AcceptedCancelledRequestDetails(string docketNo)
        //{
        //    BookingCancellation model = new BookingCancellation();
        //    try
        //    {
        //        if (TempData["message"] != null && TempData["message"].ToString() != "")
        //        {
        //            ViewBag.Show = TempData["message"];
        //        }
        //        model.lstCanceRequest = objBusinessClass.getAcceptedCancelledRequestDetails((docketNo == null) ? "" : docketNo);
        //    }
        //    catch
        //    {

        //    }
        //    return View(model);
        //}

        //[HttpGet]
        //public ActionResult AcceptedRequestFiltered(string docketNo)
        //{
        //    BookingCancellation model = new BookingCancellation();
        //    try
        //    {
        //        model.lstCanceRequest = objBusinessClass.getAcceptedCancelledRequestDetails((docketNo == null) ? "" : docketNo);
        //    }
        //    catch
        //    {

        //    }
        //    return PartialView("_AcceptedCancelRequestGrid", model.lstCanceRequest);
        //}
        //#endregion

        /*------------------------One Day Tour Booking----------------------*/

        #region Display One Day Tour Booking
        public ActionResult OnDayTourBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View();
        }
        #endregion

        #region get city tour list
        [HttpGet]
        public JsonResult getCityTourList(int packageCategoryID)
        {
            IEnumerable<SelectListItem> obj = objBusinessClass.getCityTourList(packageCategoryID).Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Book One Day Tour
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnDayTourBooking(OneDayTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _msg = "Enter a valid 6 digit Pincode!";
                        isValid = false;
                    }
                    else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                    {
                        _msg = "Enter a valid 10 digit Mobile No.!";
                        isValid = false;
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {

                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "UCITY";
                    model.bookingFor = "CITY";
                    model.bookingBy = "CRS";
                    model.receiptNo = "CRS Payment";

                    var user = objBusinessClass.saveOneDayTourBookingDetails(model);
                    if (user != null)
                    {
                        if (user.docketNo == "NA")
                        {
                            _msg = "This One Day Tour is not available on " + model.ArrivalDate.DayOfWeek + "!";
                        }
                        else if (user.docketNo == "NB")
                        {
                            _msg = "One Day Tour Not Booked!";
                        }
                        else
                        {
                            TempData["DocketNo"] = user.docketNo;

                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                            SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(user.docketNo);
                            try
                            {
                                SendOneDayBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "One Day Tour Booking");
                                SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "CITY");
                            }
                            catch
                            { }

                            return RedirectToAction("OneDayTourConfirmation");
                        }
                    }
                    else
                    {
                        _msg = "One Day Tour Not Booked!";
                    }
                }
            }
            catch
            {
                _msg = "Error in One Day Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.GetCityTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region One Tour Booking Confirmation
        public ActionResult OneDayTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                model.docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetCRSBookingDetails(model.docketNo);

            }
            catch
            { }

            return View(model);
            //OneDayTourBooking model = new OneDayTourBooking();
            //model.docketNo = Convert.ToString(TempData["DocketNo"]);
            //return View(model);
        }
        #endregion

        /*------------------------End One Day Tour Booking----------------------*/

        #region Method - get nationality
        public IEnumerable<SelectListItem> GetNationality()
        {
            var objNationality = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Indian";
            Temp.Value = "1";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Foreigner";
            Temp.Value = "0";
            objNationality.Add(Temp);

            return objNationality;
        }
        #endregion

        /*------------------------AC Bus Tour Booking----------------------*/

        #region Display AC Bus Tour Booking
        [HttpGet]
        public ActionResult ACBusTourBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.getACBusTourList().Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View();
        }
        #endregion

        #region Book AC Bus Tour
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ACBusTourBooking(ACBusTourBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _msg = "Enter a valid 6 digit Pincode!";
                        isValid = false;
                    }
                    else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                    {
                        _msg = "Enter a valid 10 digit Mobile No.!";
                        isValid = false;
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {

                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "UBUS";
                    model.bookingFor = "ACBUS";
                    model.bookingBy = "CRS";
                    model.receiptNo = "CRS Payment";

                    var user = objBusinessClass.saveACBusTourBookingDetails(model);
                    if (user != null)
                    {
                        if (user.docketNo == "NA")
                        {
                            _msg = "This AC Bus Tour is not available on " + model.ArrivalDate.DayOfWeek + "!";
                        }
                        else if (user.docketNo == "NB")
                        {
                            _msg = "AC Bus Tour Not Booked!";
                        }
                        else
                        {
                            TempData["DocketNo"] = user.docketNo;

                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                            SpecialPackageName objSpclPackName = objBusinessClass.GetSpecialPackageName(user.docketNo);
                            try
                            {
                                SendOneDayBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "AC Bus Tour Booking");
                                SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "ACBUS");
                            }
                            catch
                            { }
                            return RedirectToAction("ACBusTourConfirmation");
                        }
                    }
                    else
                    {
                        _msg = "AC Bus Tour Not Booked!";
                    }
                }
            }
            catch
            {
                _msg = "Error in AC Bus Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Category = objBusinessClass.getACBusTourList().Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region AC Bus Tour Booking Confirmation
        public ActionResult ACBusTourConfirmation()
        {
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                model.docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetCRSBookingDetails(model.docketNo);

            }
            catch
            { }

            return View(model);

            //ACBusTourBooking model = new ACBusTourBooking();
            //model.docketNo = SessionManager.DocketNo;

            //return View(model);
        }
        #endregion

        #region Get AC Bus Tour Fare
        [HttpGet]
        public ActionResult GetACBusTourTotalAmount(Int32 packageID, Int32 isIndian)
        {
            return Json(objBusinessClass.GetACBusTourTotalAmount(packageID, isIndian), JsonRequestBehavior.AllowGet);
        }
        #endregion

        /*------------------------End AC Bus Tour Booking----------------------*/

        /*------------------------Cycle Tour Booking----------------------*/

        #region display cycle tour booking form
        [HttpGet]
        public ActionResult LkoOnCycleBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View();
        }
        #endregion

        #region Route Fare
        [HttpGet]
        public ActionResult GetSpecialPackegeFare(Int32 packageID, Int32 applicantTypeId)
        {
            return Json(objBusinessClass.GetSpecialPackegeFare(packageID, applicantTypeId), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region book cycle tour
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoOnCycleBooking(LkoOnCycleBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (model.ArrivalDate < minDate.Date)
                {
                    _msg = "Arrival Date should be greater than Current Date!";
                    isValid = false;
                }
                else
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                        {
                            _msg = "Enter a valid 6 digit Pincode!";
                            isValid = false;
                        }
                        else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid 10 digit Mobile No.!";
                            isValid = false;
                        }
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();
                    }
                    if (string.IsNullOrEmpty(model.email))
                    {
                        ModelState["email"].Errors.Clear();
                    }

                    ModelState["arrivalTime"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {
                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "UCYCL";
                    model.bookingFor = "CYCLE";
                    model.bookingBy = "CRS";
                    model.receiptNo = "CRS Payment";

                    var user = objBusinessClass.saveCycleTourBookingByUPTour(model);
                    if (user != null)
                    {
                        TempData["DocketNo"] = user.docketNo;

                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                        SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                        try
                        {
                            SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Cycle Tour Booking");
                            SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "CYCLE");
                        }
                        catch
                        { }

                        return RedirectToAction("CycleTourConfirmation");
                    }
                    else
                    {
                        _msg = "Cycle Tour Not Booked!";
                    }
                }

            }
            catch
            {
                _msg = "Error in Cycle Tour Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region cycle tour confirmation
        public ActionResult CycleTourConfirmation()
        {
            //LkoOnCycle model = new LkoOnCycle();
            //model.docketNo = SessionManager.DocketNo;
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                model.docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetCRSBookingDetails(model.docketNo);

            }
            catch
            { }
            return View(model);
        }
        #endregion

        /*------------------------End Cycle Tour Booking----------------------*/

        #region Method to  bind staff tariff
        public JsonResult GetStaffTariff(int gradeId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffGrade().Where(a => a.gradeId == gradeId).Select(a => a.facilityId).FirstOrDefault();
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method to  bind staff Room
        public JsonResult GetStaffRoom(int facilityId, Int64 unitId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffRoom(unitId, facilityId).FirstOrDefault().roomTypeId;
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region to get room occupancy details

        [HttpGet]
        public ActionResult GetRoomOccupancy(int roomId, int UnitID)
        {
            CustomerRegistration model = new CustomerRegistration();
            try
            {
                UnitRooms objRoom = objBusinessClass.GetRoomInfo(roomId, UnitID);
                if (objRoom != null)
                {
                    model.maxCapacity = objRoom.maxCapacity;
                    model.hasOccupancy = objRoom.hasOccupancy;
                    model.maxExtraBed = objRoom.maxExtraBed;
                }
            }
            catch
            {

            }
            return PartialView("_RoomOccupancy", model);
        }
        #endregion

        #region methods to validate

        public string IsDateValid(CustomerRegistration model)
        {
            string returnMsg = string.Empty;
            DateTime currDate = DateTime.Now.AddDays(-1);
            DateTime maxCheckInDate = currDate.AddDays(178);
            DateTime maxCheckOutDate = currDate.AddDays(179);
            if (model.checkInDate < currDate)
            {
                returnMsg = "Check In Date could not be past date";
            }
            else if (model.checkOutDate < currDate)
            {
                returnMsg = "Check Out Date could not be past date";
            }
            else if (model.checkOutDate < model.checkInDate)
            {
                returnMsg = "Check Out Date should be greater than Check In Date";
            }
            else if (model.checkInDate > maxCheckInDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            else if (model.checkOutDate > maxCheckOutDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            return returnMsg;
        }

        #endregion

        /*------------------------Heritage Walk Booking----------------------*/

        #region Heritage Walk by CRS
        public ActionResult LkoHeritageWalkBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("HTW", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("HTW").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            return View();
        }
        #endregion

        #region Book Heritage Walk
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoHeritageWalkBooking(LkoHTWBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (model.ArrivalDate < minDate.Date)
                {
                    _msg = "Arrival Date should be greater than Current Date!";
                    isValid = false;
                }
                else
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                        {
                            _msg = "Enter a valid 6 digit Pincode!";
                            isValid = false;
                        }
                        else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid 10 digit Mobile No.!";
                            isValid = false;
                        }
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();
                    }

                    ModelState["arrivalTime"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {
                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    //model.bookingFor = "UWALK";
                    model.bookingFor = "WALK";
                    model.bookingBy = "CRS";
                    model.receiptNo = "CRS Payment";

                    var user = objBusinessClass.saveHTWBookingByUPTour(model);
                    if (user != null)
                    {
                        TempData["DocketNo"] = user.docketNo;
                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                        SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                        try
                        {
                            SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Heritage Walk Booking");
                            SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "WALK");
                        }
                        catch
                        { }
                        return RedirectToAction("HeritageWalkConfirmation");
                    }
                    else
                    {
                        _msg = "Lucknow Heritage Walk Not Booked!";
                    }
                }

            }
            catch
            {
                _msg = "Error in Lucknow Heritage Walk Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("HTW", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("HTW").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            return View(model);
        }
        #endregion

        #region Heritage Walk Confirmation
        public ActionResult HeritageWalkConfirmation()
        {
            //LkoHTWBooking model = new LkoHTWBooking();
            //model.docketNo = Convert.ToString(TempData["DocketNo"]);
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                model.docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetCRSBookingDetails(model.docketNo);

            }
            catch
            { }
            return View(model);
        }
        #endregion

        /*------------------------End Heritage Walk Booking----------------------*/

        /*------------------------Tonga Ride Booking----------------------*/

        #region Tonga Ride by UPTour
        public ActionResult LkoTongaRideBooking()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LTR", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LTR").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            LkoTongaRideBooking model = new LkoTongaRideBooking();
            model.noOfGuests = 4;
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        #region get route fare
        [HttpGet]
        public ActionResult GetTongaRideFare(Int32 packageID, Int32 applicantTypeId)
        {
            return Json(objBusinessClass.GetTongaRideFare(packageID, applicantTypeId), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region tong ride confirmation
        public ActionResult LkoTongaRideConfirmation()
        {
            //LkoTongaRideBooking model = new LkoTongaRideBooking();
            //model.docketNo = Convert.ToString(TempData["DocketNo"]);
            SpecialBookedDetail model = new SpecialBookedDetail();
            try
            {
                model.docketNo = Convert.ToString(TempData["DocketNo"]);
                model = objBusinessClass.GetCRSBookingDetails(model.docketNo);

            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region book tonga ride
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoTongaRideBooking(LkoTongaRideBooking model)
        {
            string _msg = "";
            bool isValid = true;

            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (model.ArrivalDate < minDate.Date)
                {
                    _msg = "Arrival Date should be greater than Current Date!";
                    isValid = false;
                }
                else
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                        {
                            _msg = "Enter a valid 6 digit Pincode!";
                            isValid = false;
                        }
                        else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                        {
                            _msg = "Enter a valid 10 digit Mobile No.!";
                            isValid = false;
                        }
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();
                    }
                    if (string.IsNullOrEmpty(model.email))
                    {
                        ModelState["email"].Errors.Clear();
                    }

                    ModelState["arrivalTime"].Errors.Clear();
                }

                if (ModelState.IsValid && isValid)
                {
                    model.roleID = "UOCST";
                    model.userIP = this.Request.UserHostAddress;
                    model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    model.currency = "INR";
                    model.description = "";
                    // model.bookingFor = "UTONG";
                    model.bookingFor = "TONGA";
                    model.bookingBy = "CRS";
                    model.receiptNo = "CRS Payment";

                    var user = objBusinessClass.saveLkoTongaRideBookingByUPTour(model);
                    if (user != null)
                    {
                        TempData["DocketNo"] = user.docketNo;
                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(user.docketNo);
                        SpecialPackageName objSpclPackName = objBusinessClass.GetCounterSpecialPackageName(user.docketNo);
                        try
                        {
                            SendSpecialBookSms(user.docketNo, model.mobileNo, IEContactDetails, objSpclPackName, "Tonga Ride Booking");
                            SendSpecialPackageMail(user.docketNo, IEContactDetails, model.email, "TONGA");
                        }
                        catch
                        { }
                        return RedirectToAction("LkoTongaRideConfirmation");
                    }
                    else
                    {
                        _msg = "Lucknow Tonga Ride Not Booked!";
                    }
                }
            }

            catch
            {
                _msg = "Error in Lucknow Tonga Ride Booking!";
            }
            ViewBag.Show = _msg;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LTR", 0).Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LTR").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });

            return View(model);
        }
        #endregion

        /*------------------------End Tonga Ride Booking----------------------*/

        #region to add booked room details

        [HttpGet]
        public ActionResult GetBookedRoom(CustomerRegistration objCustomer, string fdate, string todate)
        {
            //CustomerRegistration model = new CustomerRegistration();
            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
            if (objCustomer != null && objCustomer.lstBookedRoomDetail != null && objCustomer.lstBookedRoomDetail.Count > 0 && objCustomer.lstBookedRoomDetail[0] != null)
            {
                lstBookedRoom = objCustomer.lstBookedRoomDetail;
            }
            DateTime checkinDate = DateTime.ParseExact(fdate, "dd/MM/yyyy", null);
            DateTime CheckOutDate = DateTime.ParseExact(todate, "dd/MM/yyyy", null);

            var roomtariffDetails = objBusinessClass.GetUnitRoomList(objCustomer.unitID, checkinDate, CheckOutDate, objCustomer.singleRoom + objCustomer.doubleRoom);
            var roomTariff = roomtariffDetails.Where(e => e.roomID == objCustomer.roomType).ToList().FirstOrDefault();
            RoomDetail objRoom = new RoomDetail();
            objRoom.roomType = objCustomer.roomType;
            objRoom.roomTypeDisplay = objCustomer.roomTypeDisplay;
            objRoom.singleRoom = objCustomer.singleRoom;
            objRoom.doubleRoom = objCustomer.doubleRoom;
            objRoom.extrabed = objCustomer.extrabed;
            objRoom.hasOccupancy = objCustomer.hasOccupancy;
            objRoom.maxCapacity = objCustomer.maxCapacity;
            objRoom.maxExtraBed = objCustomer.maxExtraBed;

            objRoom.singletariff = roomTariff.singleRoomAmount;
            objRoom.doubletariff = roomTariff.doubleRoomAmount;
            objRoom.totalTariff = (objRoom.singletariff * objRoom.singleRoom) + (objRoom.doubletariff * objRoom.doubleRoom);
            objRoom.status = roomTariff.isAvailable ? "Available" : "Not Available";
            objRoom.Sno = lstBookedRoom.Count + 1;
            lstBookedRoom.Add(objRoom);
            objCustomer.lstBookedRoomDetail = lstBookedRoom;
            return PartialView("_BookedRoom", objCustomer);
        }

        #region to delete booked room

        [HttpGet]
        public ActionResult DeleteBookedRoom(CustomerRegistration objCustomer)
        {
            var itemsToRemove = objCustomer.lstBookedRoomDetail.Where(m => m.Sno == objCustomer.tempRoomId).ToList();
            int? _roomId = itemsToRemove.FirstOrDefault().roomType;
            string _roomName = itemsToRemove.FirstOrDefault().roomTypeDisplay;
            foreach (var itemToRemove in itemsToRemove)
                objCustomer.lstBookedRoomDetail.Remove(itemToRemove);

            ModelState.Clear();

            objCustomer.tempRoomId2 = Convert.ToInt32(_roomId);
            objCustomer.tempRoomIdName = _roomName;
            return PartialView("_BookedRoom", objCustomer);
        }
        #endregion


        #endregion

        #region get unit and Package  booked room Details for CRS
        [HttpGet]
        public ActionResult GetBookingDetail(string docketNo, int UnitId)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            string _msg = "";
            try
            {

                obj_BookingList = objBusinessClass.GetUnitPackageBookingDetailsForCRS(docketNo, UnitId);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.BookedRoomList = objBusinessClass.GetBookedRoomDetailsForCRS(docketNo, UnitId);
                    return PartialView("_BookingListDetails", obj_BookingDetail);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }
        #endregion

        #region Special booking payment list by Roop Kanwar
        [HttpGet]
        public ActionResult SpecialBookingPaymentList()
        {
            return View();
        }

        public ActionResult GetSpecialBookingPaymentList(string dtBookingFrom, string dtBookingTo, string docket, string bookingType)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket;

                model.type = bookingType.Trim().TrimEnd().TrimStart();
                model.paymentList = objBusinessClass.GetUPTourSpecialBookingPayment(model);
            }
            catch
            {

            }
            return PartialView("_SpecialBookingPaymentListGrid", model.paymentList);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SpecialBookingPaymentList(UPTourTotalBooking model)
        {
            GridView gv = new GridView();
            ModelState.Clear();

            var dtresult = objBusinessClass.GetUPTourSpecialBookingPayment(model).ToList();

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Amount = e.Amount, Mode = e.Mode, Booking_Type = e.bookingType, Guest_Name = e.name, Mobile_No = e.mobileNo }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/SpecialPackagePaymentList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.paymentList = objBusinessClass.GetUPTourSpecialBookingPayment(model);
            return View(model);
        }
        #endregion


        /* ----------------------------CRS Booking Cancellation---------------------------------*/

        #region Display CRS Booking Cancellation List
        [HttpGet]
        public ActionResult BookingCancellation()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding cancellation grid
        public ActionResult GetCancellationList(string docketNo, int bookingType, Int64? unitID, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCRSBookingForCancellation(docketNo, bookingType, unitID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_BookingCancellationGrid", model.lstCanceRequest);
        }
        #endregion

        #region Print Booking Cancellation by Syed
        public ActionResult PrintBookingCancellation(string docketNo, int bookingType, Int64? unitID, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCRSBookingForCancellation(docketNo, bookingType, unitID, _fromDate, _toDate).ToList();
                return View(model.lstCanceRequest);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export cancel list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingCancellation(CRSBookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetCRSBookingForCancellation(model.docketNo, model.bookingType, model.unitID, _fromDate, _toDate).ToList();

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, Hotel_Package_Name = e.packageName, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};

            return View(model);
        }

        #endregion

        #region cancel CRS booking
        [HttpGet]
        public ActionResult CancelBooking(string docketNo)
        {
            try
            {
                CRSBookingCancellation model = new CRSBookingCancellation();
                string ipAddress = this.Request.UserHostAddress;
                model = objBusinessClass.CancelCRSBooking(docketNo, ipAddress);
                if (model != null && model.cancelRefNo != null && model.cancelRefNo != "")
                {
                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(docketNo);
                    SendCancelRequestSMS(docketNo, IEContactDetails);
                    SendCancelRequestEMail(docketNo, IEContactDetails, model.cancelRefNo, model.cancelConfirmationDate);
                    return Content(model.cancelRefNo);
                }
            }
            catch
            { }
            return Content("0");
        }
        #endregion

        /* ----------------------------End CRS Booking Cancellation---------------------------------*/

        /* ---------------------------Cancellation List---------------------------------*/

        #region Display cancelled booking list
        [HttpGet]
        public ActionResult CancelledBooking()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding cancelled booking grid
        public ActionResult GetCancelledBookingList(string docketNo, int bookingType, Int64? unitID, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/2012", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.Now;
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCRSCancelledBooking(docketNo.Trim(), bookingType, unitID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_CancelledBookingGrid", model.lstCanceRequest);
        }
        #endregion

        #region Print Cancellations by Syed
        public ActionResult PrintCancellations(string docketNo, int bookingType, Int64? unitID, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCRSCancelledBooking(docketNo.Trim(), bookingType, unitID, _fromDate, _toDate).ToList();
                return View(model.lstCanceRequest);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export cancelled booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CancelledBooking(CRSBookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetCRSCancelledBooking(model.docketNo, model.bookingType, model.unitID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, Hotel_Package_Name = e.packageName, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/CancelledBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Cancellation List---------------------------------*/

        /*------------------Online Booking Report----------------*/

        #region display online booking list
        [HttpGet]
        public ActionResult OnlineBookingRpt()
        {
            CRSOnlineBookingReport model = new CRSOnlineBookingReport();
            try
            {
                model.dtBookingDateFrom = DateTime.Now;
                model.dtBookingDateTo = DateTime.Now;
                model.bookingList = objBusinessClass.GetCRSOnlineBookingList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetOnlineBookingList(string dtBookingFrom, string dtBookingTo, string docket)
        {
            CRSOnlineBookingReport model = new CRSOnlineBookingReport();
            try
            {
                if (string.IsNullOrEmpty(dtBookingFrom))
                {
                    dtBookingFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dtBookingTo))
                {
                    dtBookingTo = "01/01/1900";
                }
                model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.docketNo = docket.Trim();

                model.bookingList = objBusinessClass.GetCRSOnlineBookingList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineBookingRpt", model.bookingList);
        }
        #endregion

        #region Print Online Bookings by Syed
        public ActionResult PrintOnlineBookings(string dtBookingDateFrom, string dtBookingDateTo, string docketNo)
        {
            CRSOnlineBookingReport model = new CRSOnlineBookingReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBookingDateFrom) ? "-" : dtBookingDateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dtBookingDateTo) ? "-" : dtBookingDateTo;
            try
            {
                if (string.IsNullOrEmpty(dtBookingDateFrom))
                {
                    dtBookingDateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dtBookingDateTo))
                {
                    dtBookingDateTo = "01/01/1900";
                }
                model.dtBookingDateFrom = DateTime.ParseExact(dtBookingDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBookingDateTo = DateTime.ParseExact(dtBookingDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.docketNo = docketNo.Trim();

                model.bookingList = objBusinessClass.GetCRSOnlineBookingList(model);
                return View(model.bookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineBookingRpt(CRSOnlineBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dtBookingDateFrom = model.dtBookingDateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dtBookingDateFrom);
            model.dtBookingDateTo = model.dtBookingDateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dtBookingDateTo);

            var dtresult = objBusinessClass.GetCRSOnlineBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Docket_No = e.docketNo, Booking_Type = e.bookingType, Package_Name = e.packageName, Amount = e.amount, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Booking_Status = e.bookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.bookingList = dtresult;

            return View(model);
        }
        #endregion

        /*-----------------End Online Booking Report-------------*/

        /*------------------Cancellation Booking Report----------------*/

        #region display online cancellation list
        [HttpGet]
        public ActionResult OnlineCancellationRpt()
        {
            CRSOnlineCancellationReport model = new CRSOnlineCancellationReport();
            try
            {
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.cancellationList = objBusinessClass.GetCRSOnlineCancellationList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetOnlineCancellationList(string dateFrom, string dateTo, string docket)
        {
            CRSOnlineCancellationReport model = new CRSOnlineCancellationReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.docketNo = docket.Trim();

                model.cancellationList = objBusinessClass.GetCRSOnlineCancellationList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineCancellationRpt", model.cancellationList);
        }
        #endregion

        #region Print Online Cancellations by Syed
        public ActionResult PrintOnlineCancellations(string dateFrom, string dateTo, string docketNo)
        {
            CRSOnlineCancellationReport model = new CRSOnlineCancellationReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.docketNo = docketNo.Trim();

                model.cancellationList = objBusinessClass.GetCRSOnlineCancellationList(model);
                return View(model.cancellationList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineCancellationRpt(CRSOnlineCancellationReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);

            var dtresult = objBusinessClass.GetCRSOnlineCancellationList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Docket_No = e.docketNo, Booking_Type = e.bookingType, Package_Name = e.packageName, Amount = e.amount, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Checkin_Date_Checkout_Date_Arrival_Date = e.checkinDate, Cancellation_Reference_No = e.cancelRefNo, Cancellation_Date = e.cancellationDate, Cancellation_Status_By_Unit = e.cancellationStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineCancellationList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.cancellationList = dtresult;

            return View(model);
        }
        #endregion

        /*-----------------End Online Booking Report-------------*/

        /*------------------Online Failed Booking Report----------------*/

        #region display online cancellation list
        [HttpGet]
        public ActionResult OnlineFailedBooking()
        {
            CRSOnlineCancellationReport model = new CRSOnlineCancellationReport();
            try
            {
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.cancellationList = objBusinessClass.GetOnlineFailedBookingList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetOnlineFailedBookingList(string dateFrom, string dateTo, string docket)
        {
            CRSOnlineCancellationReport model = new CRSOnlineCancellationReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.docketNo = docket.Trim();

                model.cancellationList = objBusinessClass.GetOnlineFailedBookingList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineFailedBooking", model.cancellationList);
        }
        #endregion

        #region Print Online Failed Booking by Syed
        public ActionResult PrintOnlineFailedBooking(string dateFrom, string dateTo, string docketNo)
        {
            CRSOnlineCancellationReport model = new CRSOnlineCancellationReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.docketNo = docketNo.Trim();

                model.cancellationList = objBusinessClass.GetOnlineFailedBookingList(model);
                return View(model.cancellationList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineFailedBooking(CRSOnlineCancellationReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);

            var dtresult = objBusinessClass.GetOnlineFailedBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Email = e.email, Mobile_No = e.mobileNo, Docket_No = e.docketNo, Booking_Type = e.bookingType, Package_Name = e.packageName, Actual_Amount = e.amount, Paid_Amount = e.amountPaid, Payment_Response = e.ResponseStatus, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineFailedBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.cancellationList = dtresult;

            return View(model);
        }
        #endregion

        /*-----------------End Online Failed Booking Report-------------*/

        /*------------------Online Unit Booking Guest Wise Report----------------*/

        #region display online unit booking guest wise list
        [HttpGet]
        public ActionResult OnlineUnitBookingGuestWiseRpt()
        {
            ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetOnlineUnitBookingGuestWiseList(Int64 unitID, int month, int year)
        {
            OnlineUnitGuestWiseBookingReport model = new OnlineUnitGuestWiseBookingReport();
            try
            {
                model.month = month;
                model.year = year;
                model.unitID = unitID;

                model.bookingList = objBusinessClass.GetOnlineUnitBookingGuestWiseList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineUnitBookingGuestWiseRpt", model.bookingList);
        }
        #endregion

        #region Print Online Hotel Bookings by Syed
        public ActionResult PrintOnlineHotelBookings(Int64? unitID, int month, int year, string monthname)
        {
            OnlineUnitGuestWiseBookingReport model = new OnlineUnitGuestWiseBookingReport();
            ViewBag.monthname = monthname;
            ViewBag.year = year;
            try
            {
                model.month = month;
                model.year = year;
                unitID = unitID ?? 0;
                model.unitID = unitID;

                model.bookingList = objBusinessClass.GetOnlineUnitBookingGuestWiseList(model);
                return View(model.bookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineUnitBookingGuestWiseRpt(OnlineUnitGuestWiseBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            var dtresult = objBusinessClass.GetOnlineUnitBookingGuestWiseList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Email = e.email, Mobile_No = e.mobileNo, Amount = e.amount, Docket_No = e.docketNo, Hotel = e.packageName, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Booking_Status = e.bookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineUnitBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.bookingList = dtresult;
            ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(model);
        }
        #endregion

        /*-----------------End Online Booking Report-------------*/

        /*-----------------------Common-------------------------*/

        #region Display online payment response details
        public ActionResult GetOnlinePaymentDetails(string docket)
        {
            CRSOnlinePaymentDetails model = new CRSOnlinePaymentDetails();
            try
            {
                model.docketNo = docket;

                model = objBusinessClass.GetCRSOnlinePaymentDetails(model);
            }
            catch
            {
            }
            return PartialView("_OnlinePaymentDetails", model);
        }
        #endregion
        /*----------------------End Common----------------------*/

        /*-------------------Methods--------------------------*/

        #region Calculate tour total amount for package and city tours
        [HttpGet]
        public ActionResult GetTourTotalAmount(Int32 packageID, Int32 isIndian, Int32 noOfPersons)
        {
            return Json(objBusinessClass.GetTourTotalAmount(packageID, isIndian, noOfPersons), JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region to calculate 25% of total room rent
        private decimal GetRequiredAdvanceAmount(CustomerRegistration model)
        {
            decimal advAmt = 0, totalAmt = 0;
            try
            {
                if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                {
                    foreach (var item in model.lstBookedRoomDetail)
                    {
                        totalAmt += objBusinessClass.GetTotalUnitRoomPrice(model.checkInDate, model.checkOutDate.AddDays(-1), item);
                    }
                    advAmt = (totalAmt * 25) / 100;
                }
            }
            catch
            {
                advAmt = 0;
            }
            return advAmt;
        }
        #endregion

        #region get vacancy status details
        public ActionResult GetRoomVacancyDetail(string dtBooking, string roomtypeid, string unitId, DateTime dtBookingTime)
        {
            VacancyStatusDetail model = new VacancyStatusDetail();
            try
            {
                model.RoomTypeId = Convert.ToInt64(roomtypeid);
                try
                {
                    if (dtBookingTime.Hour < 12)
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                    }
                    else
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                }
                catch
                {
                    model.BookingDate = DateTime.Now;
                }

                //model.unitID = SessionManager.UnitID;
                model.unitID = Convert.ToInt64(unitId);
                model = objBusinessClass.GetVacancyStatusDetail(model);
            }
            catch
            {

            }
            return PartialView("_RoomVacancy", model);
        }
        #endregion

        #region Generate Receipt
        [HttpGet]
        public ActionResult GenerateCheckoutReceipt(string docketNo)
        {

            CheckOutBillDetails objDetails = new CheckOutBillDetails();
            try
            {
                //string docketNo = SessionManager.DocketNo;              
                decimal totalAmount = 0, discountedAmount = 0, billAmount = 0, luxuryTax = 0, luxuryTaxAmt = 0, ServiceTax = 0, serviceTaxAmt = 0, netAmount = 0, advanceAmount = 0, discount = 0, discountAmount = 0, netpayableAmount = 0, privilegeAmt = 0, privilegeDist = 0;
                var objDetailsList = objBusinessClass.GetCheckOutBillDetailsUPT(docketNo).ToList();
                ViewBag.details = objDetailsList;
                objDetails.discountedAmount = objDetailsList.FirstOrDefault().discountedAmount;
                ServiceTax = objDetailsList.FirstOrDefault().serviceTax;
                serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.discountPer = objDetailsList.FirstOrDefault().discountPer;
                Int64 _unitId = objDetailsList.FirstOrDefault().unitID;
                foreach (var i in objDetailsList)
                {
                    netAmount += i.Amount;
                }
                //netAmount = netAmount + objDetailsList.FirstOrDefault().fAndBAmt + objDetailsList.FirstOrDefault().laundryAmt + objDetailsList.FirstOrDefault().roomServiceAmt + objDetailsList.FirstOrDefault().otherAmt;
                //String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                //if (!String.IsNullOrEmpty(_privilegeDist))
                //    privilegeDist = Convert.ToDecimal(_privilegeDist);
                //else
                //    privilegeDist = 15;

                //if (objDetails.isPrivilegeVerified == true)
                //{
                //    privilegeAmt = (netAmount * privilegeDist) / 100;
                //    netAmount = (netAmount - privilegeAmt);
                //    //objDetails.totalAmount = (objDetails.isPrivilegeVerified == true) ? (objDetails.totalAmount - privilegeAmt) : objDetails.totalAmount;
                //    objDetails.privilegeAmt = privilegeAmt;
                //}
                //discountedAmount = (netAmount - discountAmount);
                //billAmount = discountedAmount;
                //objDetails.billAmount = discountedAmount; 
                objDetails.serviceTax = objDetailsList.FirstOrDefault().serviceTax;
                objDetails.serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                objDetails.luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                objDetails.luxuryTaxDisplay = objDetailsList.FirstOrDefault().luxuryTax.ToString();
                objDetails.luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                // totalAmount = billAmount + serviceTaxAmt + luxuryTaxAmt;

                //if (totalAmount > advanceAmount)
                //{
                //    netpayableAmount = Math.Ceiling(totalAmount - advanceAmount);
                //}
                //else
                //{
                //    netpayableAmount = Math.Ceiling(advanceAmount - totalAmount);
                //}
                objDetails.netpayableAmount = objDetailsList.FirstOrDefault().netpayableAmount;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                //objDetails.totalAmount = totalAmount;
                objDetails.discountAmount = objDetailsList.FirstOrDefault().discountAmount;
                objDetails.netAmount = netAmount;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.AdvRecNo = objDetailsList.FirstOrDefault().AdvRecNo;
                objDetails.arrivalDate = objDetailsList.FirstOrDefault().arrivalDate;
                objDetails.arrivalTime = objDetailsList.FirstOrDefault().arrivalTime;
                objDetails.BillDate = objDetailsList.FirstOrDefault().BillDate;
                objDetails.BillDetail = objDetailsList.FirstOrDefault().BillDetail;
                objDetails.billNo = objDetailsList.FirstOrDefault().billNo;
                objDetails.bookedThrough = objDetailsList.FirstOrDefault().bookedThrough;
                objDetails.CheckoutDate = objDetailsList.FirstOrDefault().CheckoutDate;
                objDetails.CheckoutTime = objDetailsList.FirstOrDefault().CheckoutTime;
                objDetails.guestName = objDetailsList.FirstOrDefault().guestName;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.nationality = objDetailsList.FirstOrDefault().nationality;
                objDetails.docketNo = objDetailsList.FirstOrDefault().docketNo;
                objDetails.roomNo = objDetailsList.FirstOrDefault().roomNo;
                objDetails.unitAddress = objDetailsList.FirstOrDefault().unitAddress;
                objDetails.UnitName = objDetailsList.FirstOrDefault().UnitName;
                objDetails.tinNo = objDetailsList.FirstOrDefault().tinNo;
                objDetails.tanNo = objDetailsList.FirstOrDefault().tanNo;
                objDetails.panNo = objDetailsList.FirstOrDefault().panNo;
                objDetails.serTaxNo = objDetailsList.FirstOrDefault().serTaxNo;
                objDetails.fAndBAmt = objDetailsList.FirstOrDefault().fAndBAmt;
                objDetails.laundryAmt = objDetailsList.FirstOrDefault().laundryAmt;
                objDetails.roomServiceAmt = objDetailsList.FirstOrDefault().roomServiceAmt;
                objDetails.otherAmt = objDetailsList.FirstOrDefault().otherAmt;
                objDetails.totalPayable = objDetailsList.FirstOrDefault().totalPayable;
                objDetails.roundOffValue = objDetailsList.FirstOrDefault().roundOffValue;
                objDetails.spclDiscount = objDetailsList.FirstOrDefault().spclDiscount;
                objDetails.SpclDiscountName = objDetailsList.FirstOrDefault().SpclDiscountName;
                objDetails.isPrivilegeVerified = objDetailsList.FirstOrDefault().isPrivilegeVerified;
                objDetails.privilegeCardNo = objDetailsList.FirstOrDefault().privilegeCardNo;
                objDetails.privilegeCardDate = objDetailsList.FirstOrDefault().privilegeCardDate;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                objDetails.privilegeDist = objDetailsList.FirstOrDefault().privilegeDist;
                objDetails.unitContact = objDetailsList.FirstOrDefault().unitContact;
                String _UnitForTax = System.Configuration.ConfigurationManager.AppSettings["UnitForTax"].ToString();
                //bool _isExtraTax = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? true : false;
                objDetails.luxuryTaxDisplay = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? objDetailsList.FirstOrDefault().luxuryTax.ToString() + " / 10.00" : objDetailsList.FirstOrDefault().luxuryTax.ToString();

            }
            catch
            { }
            return View(objDetails);
        }
        #endregion

        #region to send sms on booking cancellation
        protected void SendCancelRequestSMS(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["CancelBookingSMSByCRS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string concernedPersonSms = ConfigurationManager.AppSettings["CancelBookingSMSByCRSForOthers"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                concernedPersonSms = concernedPersonSms.Replace("[DocketNo]", docketNo);
                string SMSStatus = string.Empty;

                try
                {
                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo.ToUpper() == "CUSTOMER" && !(string.IsNullOrEmpty(lst.MobileNo)))
                            {
                                SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);
                                SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
                            }
                            else
                            {
                                SMSStatus = SMS.SMSSend(concernedPersonSms, lst.MobileNo);
                                SMS.SMSLog(concernedPersonSms, lst.MobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send mail on booking cancellation
        protected void SendCancelRequestEMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails, string cancelRefNo, string cancelDate)
        {
            try
            {
                StreamReader reader;
                string subject = "";
                reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/CancelRequest.html"));
                subject = "UP Tourism Booking Cancellation";

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", docketNo);
                MailBody = MailBody.Replace("[cancellationreferenceno]", cancelRefNo);
                MailBody = MailBody.Replace("[cancellationdate]", cancelDate);

                foreach (var lst in contactDetails)
                {
                    try
                    {
                        if (lst.sendTo.ToUpper() == "CUSTOMER" && !(string.IsNullOrEmpty(lst.Email)))
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                        else
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                        }
                    }
                    catch { }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send unit room booking mail
        protected void SendUnitRoomMail(string docketNo, string type, string mailTo)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                StreamReader reader;
                string subject = "";

                if (type == "CUSTOMER")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/UnitRoomBookingConfirmation_Customer.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/UnitRoomBookingConfirmation_Other.html"));
                    subject = "Room Booking Docket No. " + docketNo + " Booked by CRS.";
                }
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[hotelname]", model.unitName);
                MailBody = MailBody.Replace("[hoteladdress]", model.unitAddress);
                MailBody = MailBody.Replace("[hotelphone]", model.unitMobile);
                MailBody = MailBody.Replace("[roomtype]", model.roomType);
                MailBody = MailBody.Replace("[noofrooms]", model.noOfRooms.ToString());
                MailBody = MailBody.Replace("[extrabed]", model.extraBed.ToString());

                MailBody = MailBody.Replace("[checkindate]", model.checkinDate);
                MailBody = MailBody.Replace("[checkoutdate]", model.checkoutDate);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                if (type != "CUSTOMER")
                {
                    MailBody = MailBody.Replace("[bookedby]", model.bookingBy);
                }
                //MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);

                //MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                //MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "CUSTOMER")
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                    }
                    else
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send unit booking sms
        protected void SendUnitBookSms(string docketNo, string MobileNo, string type)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                var checkInDate = model.checkinDate;
                var roomInfo = model.noOfRooms + " " + model.roomType;
                var unitName = model.unitName;
                string customerName = model.name;

                string customerSms = ConfigurationManager.AppSettings["UnitBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[CustomerName]", customerName);
                customerSms = customerSms.Replace("[noOfRoomsAndType]", roomInfo);
                customerSms = customerSms.Replace("[UnitName]", unitName);
                customerSms = customerSms.Replace("[CheckinDate]", checkInDate);
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string concernPersonSMS = ConfigurationManager.AppSettings["UnitConcernPersonSMS"].ToString() + " Booked by CRS." + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                concernPersonSMS = concernPersonSMS.Replace("[noOfRoomsAndType]", roomInfo);
                concernPersonSMS = concernPersonSMS.Replace("[UnitName]", unitName);
                concernPersonSMS = concernPersonSMS.Replace("[CheckinDate]", checkInDate);
                concernPersonSMS = concernPersonSMS.Replace("[DocketNo]", docketNo);

                //string nodalOfficerSMS = ConfigurationManager.AppSettings["UnitNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[noOfRoomsAndType]", roomInfo);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[UnitName]", unitName);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[CheckinDate]", checkInDate);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[DocketNo]", docketNo);
                if (!(string.IsNullOrEmpty(MobileNo)))
                {
                    if (type == "CUSTOMER")
                    {
                        string SMSStatus = SMS.SMSSend(customerSms, MobileNo);              // Send SMS to Customer
                        SMS.SMSLog(customerSms, MobileNo, docketNo, SMSStatus);
                    }
                    else
                    {
                        string SMSStatus = SMS.SMSSend(concernPersonSMS, MobileNo);              // Send SMS to Customer
                        SMS.SMSLog(concernPersonSMS, MobileNo, docketNo, SMSStatus);
                    }
                }


                //foreach (var lst in contactDetails)
                //{
                //    SMSStatus = string.Empty;
                //    if (lst.sendTo == "UNIT")
                //    {
                //        SMSStatus = SMS.SMSSend(concernPersonSMS, lst.MobileNo);         // Send SMS to Unit
                //        SMS.SMSLog(concernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                //    }
                //    if (lst.sendTo == "NODAL")
                //    {
                //        SMSStatus = SMS.SMSSend(nodalOfficerSMS, lst.MobileNo);          // Send SMS to Nodal Officer
                //        SMS.SMSLog(nodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                //    }
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send package tour booking mail
        protected void SendPackageTourMail(string docketNo, string mailTo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                PackageTransactionDetail model = objBusinessClass.GetPackageBookingDetails(docketNo);
                model.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(model.packageID);

                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/PackageBookingConfirmation_Customer.html"));
                string subjectCust = "UP Tourism Booking Confirmation";

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/PackageBookingConfirmation_Other.html"));
                string subjectOthers = "Booking Docket No. " + docketNo;

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);
                MailBody = MailBody.Replace("[duration]", model.duration);
                MailBody = MailBody.Replace("[noofpersons]", model.noOfTourists);
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);
                MailBody = MailBody.Replace("[meetingpoint]", model.meetingPoint);
                MailBody = MailBody.Replace("[amount]", model.amount.ToString());
                MailBody = MailBody.Replace("[bookingdate]", model.bookingDate);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);

                string accomStr = "";
                if (model.IEPackageAccomodation != null && model.IEPackageAccomodation.Count() > 0)
                {
                    accomStr = "<table>";

                    foreach (var accom in model.IEPackageAccomodation)
                    {
                        accomStr += "<tr><td colspan='2' style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.daySequence + "</td></tr>" +
                                     "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>City Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.cityname + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Unit Name</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitName + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Address</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitAddress + "</td></tr>" +
                                    "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Room Type</td>" +
                                    "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.roomType + "</td></tr>";
                    }
                    accomStr += "</table>";
                }

                MailBody = MailBody.Replace("[accomodationdetails]", accomStr);


                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", model.docketNo);
                MailBodyOthers = MailBodyOthers.Replace("[packagename]", model.packageName);
                MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", model.subPackage);
                MailBodyOthers = MailBodyOthers.Replace("[duration]", model.duration);
                MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", model.noOfTourists);
                MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", model.arrivalDate);
                MailBodyOthers = MailBodyOthers.Replace("[meetingpoint]", model.meetingPoint);
                MailBodyOthers = MailBodyOthers.Replace("[amount]", model.amount.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[bookingdate]", model.bookingDate);
                MailBodyOthers = MailBodyOthers.Replace("[bookedby]", model.bookingBy);

                MailBodyOthers = MailBodyOthers.Replace("[customername]", model.name);
                MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", model.customerMobile);
                MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", model.customerAddress);
                MailBodyOthers = MailBodyOthers.Replace("[accomodationdetails]", accomStr);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subjectCust, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subjectCust, MailBody);

                        foreach (var lst in contactDetails)
                        {
                            try
                            {

                                if (lst.sendTo == "UNIT" || lst.sendTo == "NODAL" || lst.sendTo == "UPTOURS")
                                {
                                    //MailService.EmailData objMailOthers = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subjectOthers, toemail = lst.Email };
                                    //objService.sendMail(objMailOthers);
                                    SendMail.SendMailNew(lst.Email, subjectOthers, MailBodyOthers);
                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send package tour booking sms
        protected void SendPackageBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["PackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[PackageName]", spclPack.packageName);

                string ConcernPersonSMS = ConfigurationManager.AppSettings["PackageConcernPersonSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                ConcernPersonSMS = ConcernPersonSMS.Replace("[DocketNo]", docketNo);
                ConcernPersonSMS = ConcernPersonSMS.Replace("[PackageName]", spclPack.packageName);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["PackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.packageName);

                string UPTourSMS = ConfigurationManager.AppSettings["PackageUPTourSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.packageName);


                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "UNIT")
                            {
                                SMSStatus = SMS.SMSSend(ConcernPersonSMS, lst.MobileNo);    // Send SMS to Unit
                                SMS.SMSLog(ConcernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch
                        {
                        }
                    }
                }
                catch
                {

                }
            }
            catch
            {

            }
        }
        #endregion

        #region to send one day tour booking sms
        protected void SendOneDayBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack, string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["OneDayBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace(" [PackageName]", spclPack.packageName);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["OneDayNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace(" [PackageName]", spclPack.packageName);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["OneDayUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace(" [PackageName]", spclPack.packageName);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send special package booking mail
        protected void SendSpecialPackageMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails, string mailTo, string bookingType)
        {
            try
            {
                SpecialBookedDetail model = objBusinessClass.GetCRSBookingDetails(docketNo);

                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/SpecialPackBookingConfirmation_Customer.html"));
                string subjectCust = "UP Tourism Booking Confirmation";

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/SpecialPackBookingConfirmation_Other.html"));
                string subjectOthers = "Booking Docket No. " + docketNo;

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[packagename]", model.packageName);
                MailBody = MailBody.Replace("[subpackagename]", model.subPackage);
                MailBody = MailBody.Replace("[noofpersons]", model.noOfPerson.ToString());
                MailBody = MailBody.Replace("[arrivaldate]", model.arrivalDate);
                MailBody = MailBody.Replace("[amount]", model.advanceAmount.ToString());
                MailBody = MailBody.Replace("[bookingdate]", model.bookingDate);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);

                string arrivalTime = "";
                if (bookingType == "CYCLE" || bookingType == "TONGA" || bookingType == "WALK")
                {
                    arrivalTime = "<tr>";
                    arrivalTime += "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Arrival Time</td>" +
                             "<td style='font-size: 12px; font-weight: 500; padding: 8px; color: #464646;'>" + model.arrivalTime.ToShortTimeString() + "</td>";
                    arrivalTime += "</tr>";
                }

                MailBody = MailBody.Replace("[arrivaltime]", arrivalTime);

                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", model.docketNo);
                MailBodyOthers = MailBodyOthers.Replace("[packagename]", model.packageName);
                MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", model.subPackage);
                MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", model.noOfPerson.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", model.arrivalDate);
                MailBodyOthers = MailBodyOthers.Replace("[amount]", model.advanceAmount.ToString());
                MailBodyOthers = MailBodyOthers.Replace("[bookingdate]", model.bookingDate);
                MailBodyOthers = MailBodyOthers.Replace("[bookedby]", model.bookingBy);

                MailBodyOthers = MailBodyOthers.Replace("[customername]", model.name);
                MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", model.mobileNo);
                MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", model.customerAddress);

                MailBodyOthers = MailBodyOthers.Replace("[arrivaltime]", arrivalTime);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        SendMail.SendMailNew(mailTo, subjectCust, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subjectCust, toemail = mailTo };
                        //objService.sendMail(objMail);

                        foreach (var lst in contactDetails)
                        {
                            try
                            {

                                if (lst.sendTo == "NODAL" || lst.sendTo == "UPTOURS")
                                {
                                    //MailService.EmailData objMailOthers = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subjectOthers, toemail = lst.Email };
                                    //objService.sendMail(objMailOthers);
                                    SendMail.SendMailNew(lst.Email, subjectOthers, MailBodyOthers);

                                }
                            }
                            catch
                            {
                            }
                        }
                    }
                    catch
                    {

                    }
                }

            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region to send special tour booking sms
        protected void SendSpecialBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, SpecialPackageName spclPack, string smsFor)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["SplPackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[PackageName]", spclPack.packageName);
                customerSms = customerSms.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["SplPackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PackageName]", spclPack.packageName);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                string UPTourSMS = ConfigurationManager.AppSettings["SplPackageUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PackageName]", spclPack.packageName);
                UPTourSMS = UPTourSMS.Replace("[ArrivalDate]", spclPack.arrivalDate);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send bus/taxi enquiry reply mail
        protected void SendReplyMail(BusTaxiEnquiryReply model)
        {
            try
            {
                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BusTaxiEnquiryReply.html"));
                string subject = "Quotation for UP Tourism " + model.enquiryType + " Booking.";

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[name]", model.name);
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[enquiryno]", model.enquiryNo);
                MailBody = MailBody.Replace("[amount]", model.amount.ToString());
                MailBody = MailBody.Replace("[remark]", model.remark);
                MailBody = MailBody.Replace("[document]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + model.documentPath);
                MailBody = MailBody.Replace("[url]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + "UPTourism/TaxiBusQuotation/" + Server.UrlEncode(EncryptionDecryption.EncodeTo64(model.enquiryNo)));

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(model.email)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        SendMail.SendMailNew(model.email, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.email };
                        //objService.sendMail(objMail);

                        //MailService.EmailData objMailNew = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMailNew);
                    }
                    catch
                    {

                    }
                }

            }
            catch (Exception)
            {
            }
        }
        #endregion

        /*------------------End Methods-----------------------*/


        /*------------------Online Bus/Taxi Enquiries Report----------------*/

        #region display online bus taxi enquiry list
        [HttpGet]
        public ActionResult OnlineBusTaxiEnquiry()
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            try
            {
                ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.uptourId = 0;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBusTaxiEnquiryList(string dateFrom, string dateTo, string enquiryNo, int uptourId)
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.uptourId = uptourId;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineBusTaxiEnquiry", model.busTaxiEnquiryList);
        }
        #endregion


        #region Print Online Bus Enquiry Details by Syed
        public ActionResult PrintOnlineBusEnquiryDetails(string dateFrom, string dateTo, string enquiryNo, int? uptourId)
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.uptourId = uptourId;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
                return View(model.busTaxiEnquiryList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export bus/ taxi enquiry list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineBusTaxiEnquiry(BusTaxiEnquiryReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);

            var dtresult = objBusinessClass.GetBusTaxiEnquiryList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Enquiry_Date = e.enquiryDate, Enquiry_Type = e.enquiryType, Pickup_Date = e.pickupDate.ToString("dd/MM/yyyy"), Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Status = e.bookingStatus, Amount_Quoted = e.amount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineBusTaxiEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.busTaxiEnquiryList = dtresult;
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });

            return View(model);
        }
        #endregion

        #region get bus/ taxi enquiry details
        [HttpGet]
        public ActionResult GetBusTaxiEnquiryDetail(string enquireNo)
        {
            BusTaxiEnquiry model = new BusTaxiEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetTaxiBusEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineBusTaxiEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        #region display reply screen
        [HttpGet]
        public ActionResult ReplyBusTaxiEnquiry(string id)
        {
            BusTaxiEnquiryReply model = new BusTaxiEnquiryReply();
            try
            {
                if (TempData["message"] != null)
                {
                    ViewBag.Message = TempData["message"];
                }
                model = objBusinessClass.GetTaxiBusEnquiryDetails(id);
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region save reply
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReplyBusTaxiEnquiry(BusTaxiEnquiryReply model)
        {
            string returnMessage = "";
            try
            {
                if (ModelState.IsValid)
                {
                    model.userIP = this.Request.UserHostAddress;
                    model.userID = SessionManager.UserID;
                    string documentPath = "";
                    string res = objCommonClass.ValidateFile(model.document);
                    if (res != "Valid")
                    {
                        returnMessage = res;
                        return View(model);
                    }
                    else
                    {
                        documentPath = SaveDocument(model.document);
                        model.documentPath = documentPath;
                    }

                    var user = objBusinessClass.SaveBusTaxiEnquiryReply(model);
                    if (user > 0)
                    {
                        model = objBusinessClass.GetTaxiBusEnquiryDetails(model.enquiryNo);
                        if (model != null)
                        {
                            model.documentPath = documentPath;
                            try
                            {
                                SendReplyMail(model);
                                TempData["message"] = "Reply successfully done to Enquiry No. " + model.enquiryNo;
                                return RedirectToAction("ReplyBusTaxiEnquiry");
                            }
                            catch
                            {
                                returnMessage = "Mail not sent.";
                            }
                        }
                        else
                        {
                            returnMessage = "Mail not sent.";
                        }
                    }
                    else
                    {
                        returnMessage = "Error in sending reply.";
                    }
                    ViewBag.Message = returnMessage;
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion


        public string SaveDocument(HttpPostedFileBase document)
        {
            string documentPath = "";
            try
            {
                if (document != null)
                {
                    string ext = Path.GetExtension(document.FileName);
                    string filename = Path.GetFileName("Quotation" + DateTime.Now.Ticks + ext);

                    documentPath = Path.Combine("Content/writereaddata/Documents", filename);
                    var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                    document.SaveAs(docPath);
                }
            }
            catch
            { }
            return documentPath;
        }

        /*-----------------End Online Bus/Taxi Enquiries Report-------------*/


        /*------------------Counter Bus/Taxi Enquiries Booking----------------*/

        #region Display bus/ taxi booking
        [HttpGet]
        public ActionResult TaxiBusBooking()
        {
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
            return View();
        }
        #endregion

        #region save bus/ taxi enquiry
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusBooking(BusTaxiBooking model)
        {
            string returnMessage = "";
            try
            {
                ModelState["pickupTime"].Errors.Clear();
                ModelState["Captcha"].Errors.Clear();
                ModelState["message"].Errors.Clear();
                if (ModelState.IsValid)
                {
                    model.ipAddress = this.Request.UserHostAddress;
                    model.bookingBy = "CRS";
                    if (model.document != null)
                    {
                        string documentPath = "";
                        string res = objCommonClass.ValidateFile(model.document);
                        if (res != "Valid")
                        {
                            returnMessage = res;
                            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).Where(m => m.Value == SessionManager.PackageCategoryID.ToString());
                            return View(model);
                        }
                        else
                        {
                            documentPath = SaveDocument(model.document);
                            model.documentPath = documentPath;
                        }
                    }
                    BusTaxiBooking result = objBusinessClass.InsertBusTaxiBooking(model);
                    if (result != null)
                    {
                        try
                        {
                            ModelState.Clear();
                            TempData["docketNo"] = result.docketNo;
                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(result.docketNo);
                            var bookingType = IEContactDetails.Select(m => m.BookingFor).FirstOrDefault();

                            string smsfor = bookingType == "BUS" ? "Bus Booking" : "Taxi Booking";
                            SendBusTaxiBookSms(result.docketNo, model.mobileNo, IEContactDetails, smsfor, model.pickupDate.ToString("dd/MM/yyyy"), Convert.ToDateTime(model.pickupTime));
                            SendBusTaxiMail(result.docketNo, "cust", model.email, bookingType);
                            foreach (var lst in IEContactDetails)
                            {
                                SendBusTaxiMail(result.docketNo, "upt", lst.Email, bookingType);
                            }

                            return RedirectToAction("TaxiBusBookingConfirmation");
                        }
                        catch
                        { }
                        ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                        return View(model);
                    }
                }

            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region taxi/bus booking confirmation
        public ActionResult TaxiBusBookingConfirmation()
        {
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            try
            {
                if (TempData.Peek("docketNo") != null)
                {
                    model = objBusinessClass.GetTaxiBusCounterBookingDetails(TempData.Peek("docketNo").ToString());
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region to send bus/taxi booking sms
        protected void SendBusTaxiBookSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string smsFor, string pickupDate, DateTime pickupTime)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["BusTaxiBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[PickupDate]", pickupDate);
                customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                string NodalOfficerSMS = ConfigurationManager.AppSettings["BusTaxiNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[BookingFor]", smsFor);
                NodalOfficerSMS = NodalOfficerSMS.Replace("[PickupDate]", pickupDate);
                customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                string UPTourSMS = ConfigurationManager.AppSettings["BusTaxiUPToursSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UPTourSMS = UPTourSMS.Replace("[DocketNo]", docketNo);
                UPTourSMS = UPTourSMS.Replace("[BookingFor]", smsFor);
                UPTourSMS = UPTourSMS.Replace("[PickupDate]", pickupDate);
                customerSms = customerSms.Replace("[PickupTime]", pickupTime.ToShortTimeString());

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "UPTOURS")
                            {
                                SMSStatus = SMS.SMSSend(UPTourSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UPTourSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send bus/taxi booking mail
        protected void SendBusTaxiMail(string docketNo, string type, string mailTo, string bookingType)
        {
            try
            {
                BusTaxiBookingDetails model = objBusinessClass.GetTaxiBusCounterBookingDetails(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/TaxiBusCounterBookingConfirmation.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/TaxiBusCounterBookingConfirmation.html"));
                    subject = "Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[fromcity]", model.fromCityName);
                MailBody = MailBody.Replace("[tocity]", model.toCity);
                MailBody = MailBody.Replace("[journeydate]", model.dateOfJourney);
                MailBody = MailBody.Replace("[returndate]", model.dateOfReturn);
                MailBody = MailBody.Replace("[pickupdate]", model.pickupDate);
                MailBody = MailBody.Replace("[pickuptime]", model.pickupTime.ToShortTimeString());
                MailBody = MailBody.Replace("[pickupaddress]", model.pickupAddress);
                MailBody = MailBody.Replace("[amount]", model.transactionAmount);

                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);

                    }
                    else
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        /*-----------------End Counter Bus/Taxi Booking-------------*/

        /*------------------Online Packages Booking Guest Wise Report----------------*/

        #region display online package booking guest wise list
        [HttpGet]
        public ActionResult OnlinePackBookingGuestWiseRpt()
        {
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetOnlinePackBookingGuestWiseList(int month, int year)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetOnlinePackBookingGuestWiseList(model);
            }
            catch
            {
            }
            return PartialView("_OnlinePackBookingGuestWiseRpt", model.bookingList);
        }
        #endregion

        #region Print Online Package Bookings by Syed
        public ActionResult PrintOnlinePackageBookings(int month, int year, string monthname)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            ViewBag.year = year;
            ViewBag.monthname = monthname;
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetOnlinePackBookingGuestWiseList(model);
                return View(model.bookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlinePackBookingGuestWiseRpt(OnlinePackGuestWiseBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            var dtresult = objBusinessClass.GetOnlinePackBookingGuestWiseList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Email = e.email, Mobile_No = e.mobileNo, Amount = e.amount, Docket_No = e.docketNo, Booking_Type = e.bookingType, Package_Name = e.packageName, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Booking_Status = e.bookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlinePackageBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.bookingList = dtresult;
            return View(model);
        }
        #endregion

        /*-----------------End Online Booking Report-------------*/

        /*------------------Taxi/Bus Booking Guest Wise Report----------------*/

        #region display Taxi/Bus booking guest wise list
        [HttpGet]
        public ActionResult TaxiBusBookingGuestWiseRpt()
        {
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetTaxiBusBookingGuestWiseList(int month, int year)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetTaxiBusBookingGuestWiseList(model);
            }
            catch
            {
            }
            return PartialView("_TaxiBusBookingGuestWiseRpt", model.bookingList);
        }
        #endregion

        #region Print Bus Bookings by Syed
        public ActionResult PrintBusBookings(int month, int year, string monthname)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            ViewBag.year = year;
            ViewBag.monthname = monthname;
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetTaxiBusBookingGuestWiseList(model);
                return View(model.bookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion


        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusBookingGuestWiseRpt(OnlinePackGuestWiseBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            var dtresult = objBusinessClass.GetTaxiBusBookingGuestWiseList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Email = e.email, Mobile_No = e.mobileNo, Amount = e.amount, Docket_No = e.docketNo, Booking_Type = e.bookingType, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Booking_Status = e.bookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.bookingList = dtresult;
            return View(model);
        }
        #endregion

        /*-----------------End Taxi/Bus Booking Guest Wise Report-------------*/

        /*------------------Taxi/Bus Booking List----------------*/

        #region display Taxi/Bus booking list
        [HttpGet]
        public ActionResult TaxiBusBookedList()
        {
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetTaxiBusBookedList(string dateFrom, string dateTo, string docketNo, int? uptourId)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.uptourId = uptourId;
                model.busTaxiBookingList = objBusinessClass.GetTaxiBusBookingList(model);
            }
            catch
            {
            }
            return PartialView("_TaxiBusBookedList", model.busTaxiBookingList);
        }
        #endregion

        #region Print Bus Booking Details by Syed
        public ActionResult PrintBusBookingDetails(string dateFrom, string dateTo, string docketNo, int? uptourId)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                ViewBag.fromdate = model.dateFrom == null ? "-" : ((DateTime)model.dateFrom).ToString("dd/MM/yyyy");
                ViewBag.todate = model.dateTo == null ? "-" : ((DateTime)model.dateTo).ToString("dd/MM/yyyy");
                model.uptourId = uptourId ?? 0;
                model.docketNo = docketNo.Trim();
                var dtresult = objBusinessClass.GetTaxiBusBookingList(model);
                return View(dtresult);
            }
            catch { }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusBookedList(BusTaxiBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            model.uptourId = SessionManager.PackageCategoryID;
            var dtresult = objBusinessClass.GetTaxiBusBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Booking_Date = e.bookingDate, Booking_Type = e.bookingType, Pickup_Date = e.pickupDate, Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Amount = e.transactionAmount, Booked_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.busTaxiBookingList = dtresult;
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });

            return View(model);
        }
        #endregion


        #region get bus/ taxi booking details
        [HttpGet]
        public ActionResult GetBusTaxiBookingDetail(string docketNo)
        {
            BusTaxiBookingReport objSearch = new BusTaxiBookingReport();
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            string _msg = "";
            try
            {
                objSearch.docketNo = docketNo;
                objSearch.uptourId = SessionManager.PackageCategoryID;

                model = objBusinessClass.GetTaxiBusBookingList(objSearch).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_TaxiBusBookedDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        /*-----------------End Taxi/Bus Booking Guest Wise Report-------------*/


        /*-----------------------Prepone and postpone---------------------------*/
        #region Prepone Postpone
        [HttpGet]
        public ActionResult PreponePostpone()
        {
            return View();
        }
        #endregion

        #region Get booking current details
        [HttpGet]
        public ActionResult ExistingBookingDetails(string docketNo)
        {
            PreponePostponeCRS model = new PreponePostponeCRS();
            model = objBusinessClass.GetBookingDetailsForPrePostpone(docketNo.Trim());
            if (model != null)
            {

                model.bookedRoomList = objBusinessClass.GetBookedRoomDetails(docketNo.Trim(), model.unitID);
                model.duration = model.checkOutDateShow.Subtract(model.checkInDate).Days.ToString();
                var unitID = model.unitID;
            }
            return PartialView("_PreponePostpone", model);
        }
        #endregion

        #region save prepone-postpone booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PreponePostpone(PreponePostponeCRS model)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                if (ModelState.IsValid)
                {
                    model.userIP = this.Request.UserHostAddress;
                    string isValid = IsNewDateValid(model);
                    if (string.IsNullOrEmpty(isValid))
                    {
                        model.bookedRoomList = objBusinessClass.GetBookedRoomDetails(model.docketNo, model.unitID);
                        if (model.bookedRoomList != null && model.bookedRoomList.Count > 0)
                        {
                            var oldDuration = model.checkOutDateShow.Subtract(model.checkInDate).Days;

                            int totalDays = Convert.ToDateTime(model.newCheckOutDate).Subtract(Convert.ToDateTime(model.newCheckInDate)).Days;

                            if (totalDays != oldDuration)
                            {
                                _isValid = false;
                                _msg = "Booking Duration cannot be changed! ";
                            }
                            if (_isValid)
                            {
                                bool _isRoomAvl = true;
                                int _noOfRooms = 0;

                                foreach (var item in model.bookedRoomList)
                                {
                                    int _extrabedAdd = 0;
                                    RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                                    objRoom.roomTypeId = item.roomID;
                                    objRoom.unitId = model.unitID;
                                    _noOfRooms = item.singleRoom + item.doubleRoom;

                                    for (int i = 0; i < totalDays; i++)
                                    {
                                        objRoom.bookingDate = Convert.ToDateTime(model.newCheckInDate).AddDays(i);
                                        var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                        if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                        {
                                            _isRoomAvl = false;
                                            _msg = "Room Not Available In " + item.roomType + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                            break;
                                        }
                                    }
                                    if (_isRoomAvl == false)
                                    {
                                        break;
                                    }
                                }
                                if (_isRoomAvl == true)
                                {
                                    int result = objBusinessClass.SavePreponePostponeBookingByCrs(model);

                                    if (result > 0)
                                    {
                                        try
                                        {
                                            #region send mail and sms
                                            IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(model.docketNo);

                                            foreach (var lst in IEContactDetails)
                                            {
                                                if (lst.sendTo == "CUSTOMER")
                                                {
                                                    SendUnitRoomMail(model.docketNo, "CUSTOMER", lst.Email);
                                                    SendUnitBookSms(model.docketNo, lst.MobileNo, "CUSTOMER");
                                                }
                                                else if (lst.sendTo == "UNIT")
                                                {
                                                    SendUnitRoomMail(model.docketNo, "UNIT", lst.Email);
                                                    SendUnitBookSms(model.docketNo, lst.MobileNo, "UNIT");
                                                }
                                            }
                                            #endregion
                                        }
                                        catch
                                        {
                                        }
                                        SessionManager.DocketNo = model.docketNo;
                                        TempData["UnitId"] = model.unitID;
                                        return RedirectToAction("PreponePostponeConfirmation");
                                    }
                                    else
                                    {
                                        _msg = "Booking Schedule not changed!";
                                    }
                                }
                            }
                        }
                        else
                        {
                            _msg = "Room Details Not Found!";
                        }
                    }
                    else
                    {
                        _msg = isValid;
                    }
                }
                else
                {
                    _msg = string.IsNullOrEmpty(_msg) ? "Error in Process!" : _msg;
                }
            }
            catch
            {
                _msg = string.IsNullOrEmpty(_msg) ? "Error in Process!" : _msg;
            }

            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion



        public string IsNewDateValid(PreponePostponeCRS model)
        {
            string returnMsg = string.Empty;
            DateTime currDate = DateTime.Now.AddDays(-1);
            DateTime maxCheckInDate = currDate.AddDays(178);
            DateTime maxCheckOutDate = currDate.AddDays(179);
            if (model.newCheckInDate < currDate)
            {
                returnMsg = "Check In Date could not be past date";
            }
            else if (model.newCheckOutDate < currDate)
            {
                returnMsg = "Check Out Date could not be past date";
            }
            else if (model.newCheckOutDate < model.newCheckInDate)
            {
                returnMsg = "Check Out Date should be greater than Check In Date";
            }
            else if (model.newCheckInDate > maxCheckInDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            else if (model.newCheckOutDate > maxCheckOutDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            return returnMsg;
        }

        #region Prepone-postpone booking Confirmation
        [HttpGet]
        public ActionResult PreponePostponeConfirmation()
        {
            PreponePostponeCRS model = new PreponePostponeCRS();
            try
            {
                model.docketNo = SessionManager.DocketNo;
                model.unitID = Convert.ToInt64(Convert.ToString(TempData["UnitId"]) == "" ? 0 : TempData["UnitId"]);
            }
            catch
            {
            }
            return View(model);
        }

        #endregion

        /*---------------------- End Prepone and postpone------------------------*/

        /*-------------------Update Payment whiches Responce not Receved ------------------------------*/
        [HttpGet]
        public ActionResult UpdateFailPayment(string id)
        {
            UpdatePayment uppay = new UpdatePayment();
            uppay.docketNo = id;
            return View(uppay);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateFailPayment(UpdatePayment model)
        {
            if (ModelState.IsValid)
            {
                int i = 0;
                i = objBusinessClass.UpdateFailPaymentResponceCRS(model);
                if (i > 0)
                {
                    PaymentController pay = new PaymentController();
                    Session["DocketNo"] = model.docketNo;
                    int a = pay.SendMailAfterUpdatedBooking();
                    TempData["Result"] = a;
                    TempData["mod"] = model;
                    return RedirectToAction("PaymentUpdatesuccessfull");
                }
                else
                {
                    ViewBag.msg = "Fail to Update Responce Please try Again..";
                }
            }
            else
            {
                ViewBag.msg = "you didn't Provide Requred Data for Process this Request";
            }
            return View();
        }

        public ActionResult PaymentUpdatesuccessfull()
        {
            UpdatePayment model = new UpdatePayment();
            try
            {

                if (SessionManager.DocketNo != "")
                {
                    if (Convert.ToString(TempData["Result"]) != "")
                    {
                        model = (UpdatePayment)TempData["mod"];
                        model.docketNo = SessionManager.DocketNo;
                    }
                }

            }
            catch
            {

            }
            return View(model);
        }

        /*-------------------End Update Payment------------------------------*/


        /* ---------------------------Revenue Report---------------------------------*/

        #region Display Booking Revenue
        [HttpGet]
        public ActionResult BookingRevenue()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway", Value = "1"},
                                            new SelectListItem { Text="Total Revenue Including Checkout (Gateway).", Value = "2"}, 
                                            new SelectListItem { Text="Online net Revenue after Checkout.", Value = "5"}, 
                                            new SelectListItem { Text="Revenue for Online Booked by Unit Level.", Value = "3"}, 
                                            new SelectListItem { Text="Total Revenue after Checkout booking by Unit.", Value = "4"},                                             
                                            new SelectListItem { Text="Revenue against cancelled booking.", Value = "6"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding Booking Revenue grid
        public ActionResult GetBookingRevenue(int RevenueType, Int64? unitID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBookingRevenue(RevenueType, unitID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_BookingRevenue", model.lstBookingRevenue);
        }
        #endregion

        #region Print Hotel Booking Revenue Detail by Syed
        public ActionResult PrintHotelBookingRevenueDetail(int RevenueType, Int64? unitID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBookingRevenue(RevenueType, unitID, _fromDate, _toDate).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export Booking Revenue list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingRevenue(BookingRevenue model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetBookingRevenue(model.RevenueType, model.unitID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Month = e.reqMonth, Year = e.reqYear, Total = e.Total }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingRevenueList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Online Revenue for Hotel booking", Value = "1"},
                                            new SelectListItem { Text="Total Revenue for Online Hotel booking", Value = "2"}, 
                                            new SelectListItem { Text="Total Revenue for Unit Hotel booking", Value = "3"}, 
                                            new SelectListItem { Text="Total Revenue for Checked Out Unit Hotel booking", Value = "4"}, 
                                            new SelectListItem { Text="Total Revenue for Checked Out Online Hotel booking", Value = "5"}, 
                                            new SelectListItem { Text="Total Revenue by Cancelled Booking  ", Value = "6"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Booking Revenue---------------------------------*/

        /* ---------------------------Package Revenue Report---------------------------------*/

        #region Display Booking Revenue
        [HttpGet]
        public ActionResult PackageRevenue()
        {
            try
            {
                ViewBag.PackageList = objBusinessClass.GetPackagesList().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageID.ToString() });
                ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway Package booking", Value = "1"},
                                            new SelectListItem { Text="Total Revenue Including Checkout (Gateway). Package booking", Value = "2"}, 
                                            new SelectListItem { Text="Revenue through ARC, CRS, UPTOURS Package booking", Value = "3"}, 
                                            //new SelectListItem { Text="Total Revenue for Checked Out Unit Hotel booking", Value = "4"},  
                                            new SelectListItem { Text="Revenue against cancelled Package Booking  ", Value = "5"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding Booking Revenue grid
        public ActionResult GetPackageRevenue(int RevenueType, int? PackageCategoryID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetPackageRevenueReport(RevenueType, PackageCategoryID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_PackageRevenue", model.lstBookingRevenue);
        }
        #endregion

        #region Print Package Revenue Detail by Syed
        public ActionResult PrintPackageRevenueDetail(int RevenueType, int? PackageCategoryID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetPackageRevenueReport(RevenueType, PackageCategoryID, _fromDate, _toDate).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion


        #region export Booking Revenue list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageRevenue(BookingRevenue model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetPackageRevenueReport(model.RevenueType, model.PackageCategoryID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Package_Name = e.PackageName, Month = e.reqMonth, Year = e.reqYear, Total = e.Total }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/PackageRevenueList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.PackageList = objBusinessClass.GetPackagesList().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageID.ToString() });
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Online Revenue for Package booking", Value = "1"},
                                            new SelectListItem { Text="Total Revenue for Online Package booking", Value = "2"}, 
                                            new SelectListItem { Text="Total Revenue for Unit Package booking", Value = "3"}, 
                                            //new SelectListItem { Text="Total Revenue for Checked Out Unit Hotel booking", Value = "4"},  
                                            new SelectListItem { Text="Total Revenue by Cancelled Package Booking  ", Value = "5"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Package Booking Revenue---------------------------------*/

        /* ---------------------------Special Package Revenue Report---------------------------------*/

        #region Display Booking Revenue
        [HttpGet]
        public ActionResult SpecialPackageRevenue()
        {
            try
            {
                ViewBag.PackageList = new List<SelectListItem>() {new SelectListItem { Text="AC Bus Tour Booking", Value = "ACBUS"},
                                            new SelectListItem { Text="One Day Tour Booking", Value = "CITY"}, 
                                            new SelectListItem { Text="Cycle Tour Booking", Value = "CYCLE"}, 
                                            new SelectListItem { Text="Tonga Booking", Value = "TONGA"},  
                                            new SelectListItem { Text="Heritage Walk Booking", Value = "WALK"}};
                ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway Special Package booking", Value = "1"}, 
                                            new SelectListItem { Text="Revenue for CRS, ARC, UPTOURS Special Package booking", Value = "2"},  
                                            new SelectListItem { Text="Revenue against cancelled Special Package Booking  ", Value = "3"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding Booking Revenue grid
        public ActionResult GetSpecialPackageRevenue(int RevenueType, string PackageName, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetSpecialPackageRevenueReport(RevenueType, PackageName, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_SpecialPackageRevenue", model.lstBookingRevenue);
        }
        #endregion

        #region Print Special Package Revenue Detail by Syed

        public ActionResult PrintSpecialPackageRevenueDetail(int RevenueType, string PackageName, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetSpecialPackageRevenueReport(RevenueType, PackageName, _fromDate, _toDate).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion


        #region export Booking Revenue list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SpecialPackageRevenue(BookingRevenue model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetSpecialPackageRevenueReport(model.RevenueType, model.packageType, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Package_Name = e.PackageName, Month = e.reqMonth, Year = e.reqYear, Total = e.Total }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/SpecialPackageRevenueList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.PackageList = new List<SelectListItem>() {new SelectListItem { Text="AC Bus Tour Booking", Value = "ACBUS"},
                                            new SelectListItem { Text="One Day Tour Booking", Value = "CITY"}, 
                                            new SelectListItem { Text="Cycle Tour Booking", Value = "CYCLE"}, 
                                            new SelectListItem { Text="Tonga Booking", Value = "TONGA"},  
                                            new SelectListItem { Text="Heritage Walk Booking", Value = "WALK"}};
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Online Revenue for Special Package booking", Value = "1"}, 
                                            new SelectListItem { Text="Revenue for Unit Special Package booking", Value = "2"},  
                                            new SelectListItem { Text="Total Revenue by Cancelled Special Package Booking  ", Value = "3"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Special Package Booking Revenue---------------------------------*/

        /*------------------Taxi/Bus Booking List by Bramh ----------------*/

        #region display real Time Bus/Taxi booking list
        [HttpGet]
        public ActionResult BusTaxiBookedList()
        {
            ViewBag.Uptours = objBusinessClass.GetUptoursList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBusTaxiBookedList(string dateFrom, string dateTo, string docketNo, string UPTOURS)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                UPTOURS = string.IsNullOrEmpty(UPTOURS) ? "0" : UPTOURS;
                model.docketNo = docketNo.Trim();
                model.uptourId = Convert.ToInt32(UPTOURS);
                model.busTaxiBookingList = objBusinessClass.GetBookingListBusTaxi(model);
            }
            catch
            {
            }
            return PartialView("_BusTaxiBookedList", model.busTaxiBookingList);
        }
        #endregion

        #region Print Taxi Booking Details by Syed
        public ActionResult PrintTaxiBookingDetails(string dateFrom, string dateTo, string docketNo, int? uptourId)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                ViewBag.fromdate = model.dateFrom == null ? "-" : ((DateTime)model.dateFrom).ToString("dd/MM/yyyy");
                ViewBag.todate = model.dateTo == null ? "-" : ((DateTime)model.dateTo).ToString("dd/MM/yyyy");
                model.uptourId = uptourId ?? 0;
                model.docketNo = docketNo.Trim();
                var dtresult = objBusinessClass.GetBookingListBusTaxi(model);
                return View(dtresult);
            }
            catch { }
            return View();

        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BusTaxiBookedList(BusTaxiBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            //model.uptourId = SessionManager.PackageCategoryID;
            model.uptourId = model.uptourId ?? 0;
            var dtresult = objBusinessClass.GetBookingListBusTaxi(model);
            //if (btnprintexcel == "Print")
            //{
            //    ViewBag.fromdate = model.dateFrom == null ? "-" : ((DateTime)model.dateFrom).ToString("dd/MM/yyyy");
            //    ViewBag.todate = model.dateTo == null ? "-" : ((DateTime)model.dateTo).ToString("dd/MM/yyyy");
            //    return View("PrintTaxiBookingDetails", dtresult);
            //}
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, UPTours_Name = e.UPToursName, Booking_Date = e.bookingDate, Booking_Type = e.bookingType, Pickup_Date = e.dateOfJourney, Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Amount = e.transactionAmount, Booked_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            ViewBag.Uptours = objBusinessClass.GetUptoursList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            model.busTaxiBookingList = dtresult;
            return View(model);
        }
        #endregion


        #region get bus/ taxi booking details
        [HttpGet]
        public ActionResult GetTaxiBusBookingDetail(string docketNo)
        {
            BusTaxiBookingReport objSearch = new BusTaxiBookingReport();
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            string _msg = "";
            try
            {
                objSearch.docketNo = docketNo;
                objSearch.uptourId = SessionManager.PackageCategoryID;

                model = objBusinessClass.GetBookingListBusTaxi(objSearch).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_BusTaxiBookedListDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        /*-----------------End Taxi/Bus Booking Guest Wise Report-------------*/

        #region createdby Syed

        [HttpGet]
        public ActionResult ReleasedTaxiList()
        {
            ViewBag.Uptours = objBusinessClass.GetUptoursList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReleasedTaxiList(BusTaxiBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            //model.uptourId = SessionManager.PackageCategoryID;
            model.uptourId = model.uptourId ?? 0;
            var dtresult = objBusinessClass.GetReleasedListTaxi(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, UPTours_Name = e.UPToursName, Booking_Date = e.bookingDate, Booking_Type = e.bookingType, Pickup_Date = e.dateOfJourney, Drop_Date = e.dropDate, Duration = e.Duration, Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Amount = e.billAmount, Booked_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            ViewBag.Uptours = objBusinessClass.GetUptoursList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            model.busTaxiBookingList = dtresult;
            return View(model);
        }


        public ActionResult GetReleasedTaxiList(string dateFrom, string dateTo, string docketNo, string UPTOURS)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                UPTOURS = string.IsNullOrEmpty(UPTOURS) ? "0" : UPTOURS;
                model.docketNo = docketNo.Trim();
                model.uptourId = Convert.ToInt32(UPTOURS);
                model.busTaxiBookingList = objBusinessClass.GetReleasedListTaxi(model);
            }
            catch
            {
            }
            return PartialView("_TaxiReleasedList", model.busTaxiBookingList);
        }


        #region Print Taxi Released List
        public ActionResult PrintTaxiReleasedList(string dateFrom, string dateTo, string docketNo, int? uptourId)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                uptourId = uptourId ?? 0;
                model.docketNo = docketNo.Trim();
                model.uptourId = uptourId;
                model.busTaxiBookingList = objBusinessClass.GetReleasedListTaxi(model);
                return View(model.busTaxiBookingList);
            }
            catch
            {
            }
            return View();
        }

        #endregion


        public ActionResult GetTaxiReleasedDetail(string docketNo)
        {
            BusTaxiBookingReport objSearch = new BusTaxiBookingReport();
            BusTaxiBookingDetails model = new BusTaxiBookingDetails();
            string _msg = "";
            try
            {
                objSearch.docketNo = docketNo;
                objSearch.uptourId = SessionManager.PackageCategoryID;

                model = objBusinessClass.GetReleasedListTaxi(objSearch).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_BusTaxiBookedListDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }

        /*----------------------Relese Bus Taxi-------------------------------*/
        [HttpGet]
        public ActionResult ReleseTaxiPre()
        {
            ReleseBusTaxi model = new ReleseBusTaxi();

            return View(model);

        }

        public ActionResult GetBusTaxiBookingDetails(string docketNo)
        {
            BusTaxiBookingReport model = new BusTaxiBookingReport();
            ReleseBusTaxi mod = new ReleseBusTaxi();
            try
            {
                model.docketNo = docketNo.Trim();
                model.uptourId = 0;
                mod.busTaxiBookingList = objBusinessClass.GetBookingListBusTaxi(model).ToList();
                ViewBag.balamt = mod.busTaxiBookingList.FirstOrDefault().BalanceAmount;
                mod.busTaxiDetails = objBusinessClass.GetBusTaxiDetail(0, mod.busTaxiBookingList[0].BusTaxiId).ToList();
                mod.ReleseDate = DateTime.Now.Date;
                mod.DocketNo = docketNo;
                if (mod.busTaxiBookingList.Count > 0)
                {
                    if (mod.busTaxiDetails.Count > 0)
                    {
                        return PartialView("_BusTaxiReleseDetails", mod);
                    }
                    else
                    {
                        return PartialView("NA");
                    }
                }
                else
                {
                    return PartialView("C");
                }
            }
            catch
            {
                return PartialView("NA");
            }

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReleseTaxiPre(ReleseBusTaxi model)
        {
            decimal total = 0, balanceamt = 0;

            if (ModelState.IsValid)
            {
                try
                {
                    ModelState.Clear();
                    BusTaxiBookingReport mo = new BusTaxiBookingReport();
                    mo.docketNo = model.DocketNo.Trim();
                    mo.uptourId = 0;
                    var details = objBusinessClass.GetBookingListBusTaxi(mo).ToList().FirstOrDefault();
                    balanceamt = details.BalanceAmount;
                    model.BusTaxiId = details.BusTaxiId;
                    model.RequestId = details.RequestId;
                    model.uptoursid = details.uptoursid ?? 0;

                    total = model.ExtraKmCharges + model.ExtraNightHaltCharges + model.ExtrHoursCharges + balanceamt + model.OtherAmount;
                    model.NetPaybal = total;
                    var a = objBusinessClass.InsertBillDetails(model);
                    if (a != null)
                    {
                        SessionManager.BillNo = a.billNo;
                        SessionManager.DocketNo = a.DocketNo;
                        return RedirectToAction("ReleseConfirmation");
                    }
                    else
                    {
                        TempData["usMsg"] = "Fail to Relese BusTaxi.";
                        return RedirectToAction("ReleseTaxiPre");
                    }
                }
                catch (Exception ex)
                {
                    TempData["usMsg"] = ex.Message;
                    return RedirectToAction("ReleseTaxiPre");
                }

            }
            TempData["usMsg"] = "Model State is Not Valid";
            return RedirectToAction("ReleseTaxiPre");

        }
        /*----------------------End Relese Bus Taxi-------------------------------*/

        public ActionResult ReleseConfirmation()
        {
            ReleseBusTaxi model = new ReleseBusTaxi();
            model.DocketNo = SessionManager.DocketNo;
            model.billNo = SessionManager.BillNo;
            return View(model);
        }

        public ActionResult ReleseBill(string docketNo)
        {
            if (string.IsNullOrEmpty(docketNo))
            {
                return RedirectToAction("ReleseConfirmation");
            }
            else
            {
                BusTaxiBillDetails model = objBusinessClass.GetBusTaxiBillDetail(docketNo);
                if (model != null)
                {
                    return View(model);
                }
                else
                {
                    return RedirectToAction("ReleseConfirmation");
                }
            }

        }

        public ActionResult TaxiReleseBill(string docketNo)
        {
            if (string.IsNullOrEmpty(docketNo))
            {
                return RedirectToAction("ReleseConfirmation");
            }
            else
            {
                BusTaxiBillDetails model = objBusinessClass.GetBusTaxiBillDetail(docketNo);
                if (model != null)
                {
                    return View(model);
                }
                else
                {
                    return RedirectToAction("ReleseConfirmation");
                }
            }

        }



        [HttpGet]
        public ActionResult taxibooking()
        {
            ViewBag.packagecategory = objBusinessClass.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            ViewBag.bus = objBusinessClass.GetBusTaxiNameList("B", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            ViewBag.taxi = objBusinessClass.GetBusTaxiNameList("T", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            ViewBag.departuretime = GetTimeList();
            //ViewBag.UPTourCity = objBusinessClass.GetFromCityBusTaxiListByUpToursId(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).ToList();
            ViewBag.UPTourDestinationCity = objBusinessClass.GetDestinationCityBusTaxiList().Select(e => new SelectListItem() { Text = e.label, Value = e.value.ToString() });
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() }).ToList();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() }).ToList();
            ViewBag.Nationality = GetNationality();
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() }).ToList();
            UPTBusTaxibooking bustaxibooking = new UPTBusTaxibooking();
            bustaxibooking.duration = 0;
            bustaxibooking.distance = 0;
            bustaxibooking.noofpersons = 0;
            bustaxibooking.age = 0;
            bustaxibooking.noofvehicles = 0;
            return View(bustaxibooking);
        }





        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult taxibooking(UPTBusTaxibooking bustaxibooking)
        {
            ViewBag.fromcityid = bustaxibooking.fromCityId;
            ViewBag.taxiid = bustaxibooking.taxiid;
            UP_TourismConnection db = new UP_TourismConnection();
            ViewBag.packagecategory = objBusinessClass.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            ViewBag.bus = objBusinessClass.GetBusTaxiNameList("B", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            ViewBag.taxi = objBusinessClass.GetBusTaxiNameList("T", SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            ViewBag.departuretime = GetTimeList();
            //ViewBag.UPTourCity = objBusinessClass.GetFromCityBusTaxiListByUpToursId(SessionManager.PackageCategoryID).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).ToList();
            ViewBag.UPTourDestinationCity = objBusinessClass.GetDestinationCityBusTaxiList().Select(e => new SelectListItem() { Text = e.label, Value = e.value.ToString() });
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() }).ToList();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() }).ToList();
            ViewBag.Nationality = GetNationality();
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() }).ToList();
            if (bustaxibooking.duration == 0)
            {
                ModelState.AddModelError("duration", "Value cannot be 0!");
            }
            if (bustaxibooking.distance == 0)
            {
                ModelState.AddModelError("distance", "Value cannot be 0!");
            }
            if (bustaxibooking.noofpersons == 0)
            {
                ModelState.AddModelError("noofpersons", "Value cannot be 0!");
            }
            //if (bustaxibooking.age == 0)
            //{
            //    ModelState.AddModelError("age", "Value cannot be 0!");
            //}
            if (bustaxibooking.busortaxi == "B" && bustaxibooking.busid == null)
            {
                ModelState.AddModelError("busid", "Select Bus!");
            }
            else if (bustaxibooking.busortaxi == "T" && bustaxibooking.taxiid == null)
            {
                ModelState.AddModelError("taxiid", "Select Taxi!");
            }
            if (bustaxibooking.countryID == 98)
            {
                if (bustaxibooking.stateID == null)
                {
                    ModelState.AddModelError("stateID", "Select State!");
                }
                if (bustaxibooking.cityID == null)
                {
                    ModelState.AddModelError("cityID", "Select City!");
                }
            }
            if (bustaxibooking.advanceamount != null)
            {
                if (string.IsNullOrEmpty(bustaxibooking.receiptno))
                {
                    ModelState.AddModelError("receiptno", "Enter Receipt No.");
                }
                if (bustaxibooking.paymentdate == null)
                {
                    ModelState.AddModelError("paymentdate", "Enter Payment Date");
                }
            }
            if (bustaxibooking.bookingtype == "local")
            {
                bustaxibooking.toCity = bustaxibooking.fromCity;
                bustaxibooking.toCityId = bustaxibooking.fromCityId;
            }
            //else
            //{
            //    if (bustaxibooking.toCityId == null)
            //    {
            //        ModelState.AddModelError("toCityId", "Select To City!");
            //    }
            //}
            if (ModelState.IsValid)
            {
                string docketno = objBusinessClass.insertbustaxibookingdetails(bustaxibooking, this.Request.UserHostAddress);
                Session["docket1"] = docketno;
                return RedirectToAction("taxibookingconfirmation", "UPTours");
            }
            return View(bustaxibooking);
        }

        public ActionResult taxibookingconfirmation()
        {
            UP_TourismConnection db = new UP_TourismConnection();
            bustaxibookingconfirm bustaxiconfirm = null;
            if (Session["docket1"] != null)
            {
                string docket = (string)Session["docket1"];
                //string docket = "BUS16000025";
                List<bustaxibookingconfirm> detail = objBusinessClass.getbustaxibookingconfirmation(docket).ToList();
                if (detail != null)
                {
                    bustaxiconfirm = detail.FirstOrDefault();
                }
            }
            return View(bustaxiconfirm);
        }

        public JsonResult getTariff(Int64? bustaxiid, int? duration, int? km, string bookingtype, string departuretime, decimal? guidetariff, int? noofvehicles)
        {
            guidetariff = guidetariff ?? 0;
            noofvehicles = noofvehicles ?? 0;
            List<string> tariff = new List<string>();
            string servicetaxper = ConfigurationManager.AppSettings["ServiceTaxBusTaxi"];
            List<decimal> basetariff = objBusinessClass.getBusTaxitariff(bustaxiid, duration, km, bookingtype, departuretime).ToList();
            tariff.Add(servicetaxper);
            //decimal? guidetarifftotal = guidetariff * duration;
            tariff.Add((basetariff.FirstOrDefault() * noofvehicles).ToString());
            tariff.Add(guidetariff.ToString());
            return Json(tariff);
        }

        public JsonResult getfromcitybypackagecategory(int? packagecategoryid)
        {
            List<SelectListItem> sli = objBusinessClass.GetFromCityBusTaxiListByUpToursId(packagecategoryid).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() }).ToList();
            return Json(sli);
        }

        public JsonResult gettaxiname(int? packagecategoryid)
        {
            List<SelectListItem> sli = objBusinessClass.GetBusTaxiNameList("T", packagecategoryid).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            return Json(sli);
        }

        public JsonResult getguidetariff(int? noofperson, int? duration = 0)
        {
            string servicetaxper = ConfigurationManager.AppSettings["ServiceTaxBusTaxi"];
            decimal? guideperday = objBusinessClass.getguidetariffbynoofperson(noofperson);
            decimal? guide = guideperday * duration;
            List<string> guidetf = new List<string>();
            guidetf.Add(servicetaxper);
            guidetf.Add(guide.ToString());
            return Json(guidetf);
        }

        #endregion
        #region Method - get Time Value in List
        public IEnumerable<SelectListItem> GetTimeList()
        {

            string Time24 = "";
            string Time12 = "";

            var objTimeList = new List<SelectListItem>();
            SelectListItem Temp;
            int SpanValue = 00;
            for (int i = 0; i < 96; i++)
            {
                TimeSpan spanetst = TimeSpan.FromMinutes(SpanValue);
                DateTime time = DateTime.Today + spanetst;
                Time12 = time.ToString("hh:mm tt");

                DateTime getTime24 = DateTime.Parse(Time12);
                getTime24.ToString("HH:mm");
                Time24 = getTime24.TimeOfDay.ToString();

                Temp = new SelectListItem();
                Temp.Text = Time12;
                Temp.Value = Time24;
                objTimeList.Add(Temp);
                SpanValue = SpanValue + 15;
            }

            return objTimeList;
        }
        #endregion

        #region by Syed
        [HttpGet]
        public ActionResult LawnBanquetBookingAlldetails()
        {
            ViewBag.UnitList = objBusinessClass.GetUnitListByOnlineHasLawnHasBanquet().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LawnBanquetBookingAlldetails(LawnBanquetBooking model)
        {
            ViewBag.UnitList = objBusinessClass.GetUnitListByOnlineHasLawnHasBanquet().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ModelState.Clear();

            GridView gv = new GridView();
            model.UnitId = SessionManager.UnitID;
            var dtresult = objBusinessClass.GetLawnBanquetBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Docket_No = e.docketNo, Booking_Date = e.ForDate.ToString("dd/MM/yyyy"), Booking_For = e.BookingFor, Name = e.name, Mobile_No = e.mobileNo, Email = e.email, Function_Name = e.functionName, Amount = e.advanceAmount, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/LawnBanquetBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            IEnumerable<LawnBanquetBooking> modellist = dtresult;
            return View(modellist);
        }


        public ActionResult GetLawnBanquetBookingList(string dateFrom, string dateTo, string docketNo, long? UnitId)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            List<LawnBanquetBooking> modellist = new List<LawnBanquetBooking>();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.UnitId = UnitId;
                modellist = objBusinessClass.GetLawnBanquetBookingList(model).ToList();
            }
            catch
            {
            }
            return PartialView("_LawnBanquetBookingList", modellist);
        }
        #region Print Lawn Banquet Booking List by Syed
        public ActionResult PrintLawnBanquetBookingList(string dateFrom, string dateTo, string docketNo, long? UnitId)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            List<LawnBanquetBooking> modellist = new List<LawnBanquetBooking>();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                UnitId = UnitId ?? 0;
                model.docketNo = docketNo.Trim();
                model.UnitId = UnitId;
                modellist = objBusinessClass.GetLawnBanquetBookingList(model).ToList();
                return View(modellist);
            }
            catch
            {
            }
            return View();
        }
        #endregion


        public ActionResult GetLawnBanquetBookingDetail(string docketNo, long? UnitId)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            string _msg = "";
            try
            {
                model.docketNo = docketNo;
                model.UnitId = UnitId;

                model = objBusinessClass.GetLawnBanquetBookingList(model).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_LawnBanquetBookingListDetail", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }

        [HttpGet]
        public ActionResult OnlineLawnEnquiry()
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                GetEnQList();
                ViewBag.UnitList = objBusinessClass.GetUnitListByOnlineHasLawnHasBanquet().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                model.dateFrom = DateTime.Now.AddDays(-2);
                model.dateTo = DateTime.Now;
                //model.unitID = SessionManager.UnitID;
                model.enquiryType = "All";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);
            }
            catch
            {
            }
            return View(model);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineLawnEnquiry(LawnEnquiryReport model)
        {
            ModelState.Clear();
            ViewBag.UnitList = objBusinessClass.GetUnitListByOnlineHasLawnHasBanquet().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            GridView gv = new GridView();
            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);
            model.enquiryType = "All";
            var dtresult = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Name = e.name, Mobile_No = e.mobileNo, Enquiry_Type = e.enquiryType, Booking_Date = e.lawnBookingDate.ToString("dd/MM/yyyy"), Hotel = e.unitName, Function_Type = e.functionName, Enquiry_Date = e.enquiryDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineLawnEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.lawnEnquiryList = dtresult;


            GetEnQList();
            return View(model);
        }

        #region bind booking grid
        public ActionResult GetLawnEnquiryList(string dateFrom, string dateTo, string enquiryNo, string EnquiryType, long? unitID)
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.unitID = unitID;
                model.enquiryType = EnquiryType;
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);
            }
            catch
            {
            }
            return PartialView("_OnlineLawnEnquiry", model.lawnEnquiryList);
        }
        #endregion

        #region Print Online Lawn Banquet Enquiry by Syed
        public ActionResult PrintOnlineLawnEnquiry(string dateFrom, string dateTo, long? unitID, string enquiryType, string enquiryNo)
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.unitID = unitID;
                model.enquiryType = enquiryType;
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);
                return View(model.lawnEnquiryList);
            }
            catch
            {
            }
            return View();
        }
        #endregion



        #region display reply screen
        [HttpGet]
        public ActionResult ReplyLawnBanqEnquiry(string id)
        {
            LawnEnquiry model = new LawnEnquiry();
            try
            {
                if (TempData["message"] != null)
                {
                    ViewBag.Message = TempData["message"];
                }
                model = objBusinessClass.GetLawnBanquetEnquiry(id);
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region save reply
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReplyLawnBanqEnquiry(LawnEnquiry model)
        {
            string returnMessage = "";
            try
            {
                ModelState["firstName"].Errors.Clear();
                ModelState["lastName"].Errors.Clear();
                ModelState["mobileNo"].Errors.Clear();
                ModelState["message"].Errors.Clear();
                ModelState["email"].Errors.Clear();

                ModelState["Captcha"].Errors.Clear();

                if (ModelState.IsValid)
                {
                    model.userIP = this.Request.UserHostAddress;
                    model.userID = SessionManager.UserID;
                    string documentPath = "";
                    string res = objCommonClass.ValidateFile(model.document);
                    if (res != "Valid")
                    {
                        returnMessage = res;
                        return View(model);
                    }
                    else
                    {
                        documentPath = SaveDocument(model.document);
                        model.documentPath = documentPath;
                    }

                    var user = objBusinessClass.SaveBanqLawnEnquiryReply(model);
                    if (user > 0)
                    {
                        model = objBusinessClass.GetLawnBanquetEnquiry(model.enquiryNo);
                        if (model != null)
                        {
                            model.documentPath = documentPath;
                            try
                            {
                                SendReplyMail(model);
                                TempData["message"] = "Reply successfully done to Enquiry No. " + model.enquiryNo;
                                return RedirectToAction("ReplyLawnBanqEnquiry");
                            }
                            catch
                            {
                                returnMessage = "Mail not sent.";
                            }
                        }
                        else
                        {
                            returnMessage = "Mail not sent.";
                        }
                    }
                    else
                    {
                        returnMessage = "Error in sending reply.";
                    }
                    ViewBag.Message = returnMessage;
                }
            }
            catch
            {
                return RedirectToAction("ReplyLawnBanqEnquiry", model.enquiryNo);
            }
            return View(model);
        }
        #endregion

        #region get lawn enquiry details
        [HttpGet]
        public ActionResult GetLawnEnquiryDetail(string enquireNo)
        {
            LawnEnquiry model = new LawnEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetLawnBanquetEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineLawnEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion


        void GetEnQList()
        {
            ViewBag.EnQtype = new List<SelectListItem>() {new SelectListItem { Text="All", Value = "All"},
                                            new SelectListItem { Text="Lawn", Value = "Lawn"}, 
                                            new SelectListItem { Text="Banquet", Value = "Banquet"}};
        }
        #endregion


        #region to send special package booking mail
        protected void SendReplyMail(LawnEnquiry model)
        {
            try
            {
                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BusTaxiEnquiryReply.html"));
                string subject = "Quotation for UP Tourism " + model.enquiryType + " Booking.";

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[name]", model.name);
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[enquiryno]", model.enquiryNo);
                MailBody = MailBody.Replace("[amount]", model.amount.ToString());
                MailBody = MailBody.Replace("[remark]", model.remark);
                MailBody = MailBody.Replace("[document]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + model.documentPath);
                MailBody = MailBody.Replace("[url]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + "UPTourism/LawnBanqQuotation/" + Server.UrlEncode(EncryptionDecryption.EncodeTo64(model.enquiryNo)));

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(model.email)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        SendMail.SendMailNew(model.email, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.email };
                        //objService.sendMail(objMail);

                        //MailService.EmailData objMailNew = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMailNew);
                    }
                    catch
                    {

                    }
                }

            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region
        public ActionResult BlockAcBus()
        {

            //PackageEntry
            DateTime fromdate = new DateTime(2016, 1, 1);
            PackageBlockModel model = new PackageBlockModel();
            ViewBag.PackageList = objBusinessClass.getACBUSPackageList().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            try
            {
                model.BlockList = objBusinessClass.getACBUSPackageBlockedList(0, fromdate, DateTime.Now.AddYears(1));
            }
            catch
            {
            }
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BlockAcBus(PackageBlockModel model)
        {
            ViewBag.PackageList = objBusinessClass.getACBUSPackageList().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            if (ModelState.IsValid)
            {
                int a = objBusinessClass.Insert_AcBus_Blocked(model);
                if (a > 0)
                {
                    ViewBag.msg = "Package Blocked";
                    ModelState.Clear();
                    model.Blockdate = null;
                    model.Packageid = 0;
                }
                else
                {
                    ViewBag.msg = "Package couldn't Block please try later";
                }
                try
                {
                    DateTime FromDate = model.FromDate ?? new DateTime(2016, 1, 1);
                    DateTime todate = model.ToDate ?? DateTime.Now.AddYears(1);
                    model.BlockList = objBusinessClass.getACBUSPackageBlockedList(0, FromDate, todate);
                }
                catch
                {
                    DateTime fromdate = new DateTime(2016, 1, 1);

                    model.BlockList = objBusinessClass.getACBUSPackageBlockedList(0, fromdate, DateTime.Now.AddYears(1));
                }
            }
            else
            {
                ModelState.AddModelError("", "Check Inputs");
            }
            return View(model);
        }

        public ActionResult GetACBUSPACKBlockedList(string fromdate, string Todate, string Package)
        {
            DateTime fdate, tdate;
            try
            {
                fdate = DateTime.ParseExact(fromdate, "dd/MM/yyyy", null);
            }
            catch
            {
                fdate = new DateTime(2016, 1, 1);
            }
            try
            {
                tdate = DateTime.ParseExact(Todate, "dd/MM/yyyy", null);
            }
            catch
            {
                tdate = DateTime.Now.AddYears(1);
            }
            int packageid = 0;
            int.TryParse(Package, out packageid);

            PackageBlockModel model = new PackageBlockModel();

            model.BlockList = objBusinessClass.getACBUSPackageBlockedList(packageid, fdate, tdate);

            return PartialView("_PackageBlockedList", model.BlockList);
        }

        public ActionResult ReleseACBUSour(string BlockId)
        {
            try
            {
                Int64 bid = 0;
                Int64.TryParse(BlockId, out bid);
                int A = objBusinessClass.ReleseBlockedACBUSTOUR(bid);
                if (A > 0)
                {
                    PackageBlockModel model = new PackageBlockModel();
                    DateTime fromdate = new DateTime(2016, 1, 1);
                    model.BlockList = objBusinessClass.getACBUSPackageBlockedList(0, fromdate, DateTime.Now.AddYears(1));
                    return PartialView("_PackageBlockedList", model.BlockList);
                }
                else
                {
                    return Content("ND");
                }
            }
            catch
            {
                return Content("W");
            }
        }

        #endregion



        #region To send unit room pre pone postpone mail
        protected void SendUnitPreponePostponeMail(string docketNo, string type, string mailTo)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                StreamReader reader;
                string subject = "";

                if (type == "CUSTOMER")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BookingPreponePostponeConfirmation_Customer.html"));
                    subject = "UP Tourism Booking Modification Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BookingPreponePostponeConfirmation_Other.html"));
                    subject = "Room Booking Docket No. " + docketNo + " Modified by Unit.";
                }
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[hotelname]", model.unitName);
                MailBody = MailBody.Replace("[hoteladdress]", model.unitAddress);
                MailBody = MailBody.Replace("[hotelphone]", model.unitMobile);
                MailBody = MailBody.Replace("[roomtype]", model.roomType);
                MailBody = MailBody.Replace("[noofrooms]", model.noOfRooms.ToString());
                MailBody = MailBody.Replace("[extrabed]", model.extraBed.ToString());

                MailBody = MailBody.Replace("[checkindate]", model.checkinDate);
                MailBody = MailBody.Replace("[checkoutdate]", model.checkoutDate);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                //MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                if (type != "CUSTOMER")
                {
                    MailBody = MailBody.Replace("[bookedby]", model.bookingBy);
                }
                // MailBody = MailBody.Replace("[transactionid]", model.transactionID); 
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                //MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "CUSTOMER")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                    //else
                    //{
                    //    MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "anuj@otpl.co.in", mailbody = MailBody, subject = subject, toemail = mailTo };
                    //    objService.sendMail(objMail);
                    //}
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region ChaneRoomDetails
        public ActionResult ChangeRoomDetails()
        {
            return View();
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ChangeRoomDetails(BookingChange model)
        {
            model = objBusinessClass.GetUnitBookingDetailseEDITAtCRS(model.DocketNo).FirstOrDefault();
            if (model != null)
            {
                model.roomdetList = objBusinessClass.getRoomBookingList(model.DocketNo, 0, model.unitID);
                SessionManager.UnitID = model.unitID;
                model.AdvanceAmountdetList = objBusinessClass.GetAdvanceAmountList(model.DocketNo, 0, model.unitID);

            }
            else
            {
                ViewBag.msg = "Docket no is not valid or guest is already checked-in with this docket";
            }
            return View(model);
        }

        [HttpGet]
        public ActionResult GetAdvanceAmountList(string DoscketNo)
        {
            List<AdvanceAmountDetails> Model = objBusinessClass.GetAdvanceAmountList(DoscketNo, 0, SessionManager.UnitID);
            return PartialView("_AdvanceAmountList", Model);
        }

        [HttpGet]
        public ActionResult GetRoomBookingdetlsList(string DoscketNo)
        {
            List<RoomBookingDetails> Model = objBusinessClass.getRoomBookingList(DoscketNo, 0, SessionManager.UnitID);
            return PartialView("_ChangeBookingDetails", Model);
        }

        [HttpGet]
        public ActionResult GetAllBookingDetails()
        {
            return View();
        }

        public ActionResult UpdateRoomOccupancy(string id)
        {
            int reqId = 0;
            int.TryParse(id, out reqId);
            if (reqId > 0)
            {
                RoomBookingDetails mode = objBusinessClass.getRoomBookingList("", reqId, SessionManager.UnitID).FirstOrDefault();
                return View("_UpdateRoomOccupancy", mode);
            }
            else
            {
                return Content("NA");
            }
        }

        [HttpPost]
        public ActionResult UpdateRoomOccupancy(RoomBookingDetails model)
        {
            try
            {
                if (model.noOfRooms == model.doubleRoom + model.singleRoom)
                {
                    int a = objBusinessClass.UpdateRoomOccupancyByReqId(model);
                    if (a > 0)
                    {
                        return Content("Room(s) updated successfully.");
                    }
                    else
                    {
                        return Content("Fail to Update because either room is Checked-in or booking by online.");
                    }
                }
                else
                {
                    return Content("Sum of Rooms must equal to total rooms.");
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }
        }

        public ActionResult UpdateAdvanceAmount(string id)
        {
            int AdvanceAmtID = 0;
            int.TryParse(id, out AdvanceAmtID);
            if (AdvanceAmtID > 0)
            {
                AdvanceAmountDetails mode = objBusinessClass.GetAdvanceAmountList("", AdvanceAmtID, SessionManager.UnitID).FirstOrDefault();
                return View("_UpdateAdvanceAmount", mode);
            }
            else
            {
                return Content("NA");
            }
        }

        [HttpPost]

        public ActionResult UpdateAdvanceAmount(AdvanceAmountDetails model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int i = 0;
                    i = objBusinessClass.UpdateAdvanceAmountByAdvanceAmtId(model);
                    if (i > 0)
                    {
                        return Content("Amount Updated Successfully");
                    }
                    else
                    {
                        return Content("Fail to Update Amount");
                    }
                }
                else
                {
                    return Content("Check Inputs");
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }

        }
        #endregion


        /*----------------------------Edit Customer Details-------------------------------*/

        #region Display search panel for editing
        public ActionResult GetCustomerDetails()
        {
            return View();
        }
        #endregion

        #region Get customer details for editing

        public ActionResult EditCustomerDetails(string DocketNo)
        {
            Customer mc = objBusinessClass.GetCustomerDetailsForEdit(DocketNo).FirstOrDefault();
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });

            if (mc != null && mc.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(mc.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (mc.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(mc.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }

            ViewBag.Identity = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
            ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
            var l = objBusinessClass.GetSeason().Where(e => e.SeasonId != 13);
            ViewBag.Month = l.Select(e => new SelectListItem() { Text = e.Seasonname, Value = e.SeasonId.ToString() });
            ViewBag.date = objCommonClass.getMonthdate().Select(e => new SelectListItem() { Text = e.dateId.ToString(), Value = e.dateId.ToString() });
            return PartialView("_ViewEditCustomerdetails", mc);
        }
        #endregion

        #region Update customer details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateCustomer(Customer cust)
        {
            try
            {
                int result = objBusinessClass.UpdateCustomerDetails(cust);

                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });


                if (cust != null && cust.countryID != null && cust.countryID == 98)
                {
                    ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(cust.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                    if (cust.stateID > 0)
                    {
                        ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(cust.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                    }
                    else
                    {
                        ViewBag.City = Enumerable.Empty<SelectListItem>();
                    }

                }
                else
                {
                    ViewBag.State = Enumerable.Empty<SelectListItem>();
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
                //if (cust.stateID != null && cust.stateID > 0)
                //{
                //    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(cust.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                //}
                //else
                //{
                //    ViewBag.City = Enumerable.Empty<SelectListItem>();
                //}

                ViewBag.Identity = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                var l = objBusinessClass.GetSeason().Where(e => e.SeasonId != 13);
                ViewBag.Month = l.Select(e => new SelectListItem() { Text = e.Seasonname, Value = e.SeasonId.ToString() });
                ViewBag.date = objCommonClass.getMonthdate().Select(e => new SelectListItem() { Text = e.dateId.ToString(), Value = e.dateId.ToString() });

                if (result > 0)
                {
                    ModelState.Clear();
                    ViewBag.Show = "Customer Details Updated Successfully!";

                    return PartialView("_ViewEditCustomerdetails", cust);
                }
                else
                {
                    ViewBag.Show = "Customer Details Not Updated!";

                }

            }
            catch
            {
                ViewBag.Show = "Error in Updating Customer Details!";
            }
            return PartialView("_ViewEditCustomerdetails", cust);
        }
        #endregion

        /*----------------------------End Edit Customer Details-------------------------------*/


        /*----------------------------VIEW DAY REPORT Details-------------------------------*/

        public ActionResult ViewDayReport()
        {
            CRSReportModel model = new CRSReportModel();
            model.reportDate = DateTime.Now.ToString("dd/MM/yyyy");
            model.bookingStatus = "NotBooked";
            return View(model);
        }

        [HttpPost]
        public ActionResult BindDayReport(CRSReportModel model)
        {
            if (ModelState.IsValid)
            {
                var result = objBusinessClass.GetDayClosingReport(model);
                return View("_BindDayClosingReport", result);
            }
            else
            {
                return Content("ME");
            }
        }

        [HttpPost]
        public ActionResult ViewDayReport(CRSReportModel model)
        {

            #region Create Data Table
            DataTable dt = new DataTable();
            dt.Columns.Add("S.No. 	", typeof(int));
            dt.Columns.Add("Name", typeof(string));
            dt.Columns.Add("Docket No", typeof(string));
            dt.Columns.Add("Email ", typeof(string));
            dt.Columns.Add("Mobile ", typeof(string));
            dt.Columns.Add("Address", typeof(string));
            dt.Columns.Add("Booking For", typeof(string));
            dt.Columns.Add("From Date ", typeof(string));
            dt.Columns.Add("Unit / Package Name", typeof(string));
            dt.Columns.Add("Room Type", typeof(string));
            dt.Columns.Add("Booking Status", typeof(string));
            dt.Columns.Add("Request Date", typeof(string));
            dt.Columns.Add("Payment Amount", typeof(string));


            #endregion

            var result = objBusinessClass.GetDayClosingReport(model);

            int i = 1;
            foreach (var row in result)
            {

                DataRow dr = dt.NewRow();
                dr[0] = i.ToString();
                dr[1] = row.name;
                dr[2] = row.docketNo;
                dr[3] = row.email;
                dr[4] = row.mobileNo;
                dr[5] = row.address;
                dr[6] = row.BookingFor;
                dr[7] = row.fromDate;
                dr[8] = row.UnitOrPackageName;
                dr[9] = row.roomType;
                dr[10] = row.BookingStatus;
                dr[11] = row.requestDate;
                dr[12] = row.amount;
                i = i + 1;
                dt.Rows.Add(dr);
            }

            if (result.Count > 0)
            {
                GridView gv = new GridView();
                gv.DataSource = dt;
                gv.DataBind();
                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/ClosingReportOf_" + model.reportDate + ".xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }

            return RedirectToAction("ViewDayReport");
        }

        /*----------------------------END VIEW DAY REPORT Details-------------------------------*/


        /*----------------------------Payment Reconcile-------------------------------*/

        public ActionResult PaymentReconcile()
        {
            CRSReportModel model = new CRSReportModel();
            model.reportDate = DateTime.Now.ToString("dd/MM/yyyy");
            return View(model);
        }

        [HttpPost]
        public ActionResult BindFailedbooking(CRSReportModel model)
        {
            model.bookingStatus = "NotBooked";
            if (ModelState.IsValid)
            {

                var result = objBusinessClass.GetDayClosingReport(model);
                return View("_bindFailBookingForReconcile", result);
            }
            else
            {
                return Content("ME");
            }
        }

        [HttpGet]
        public ActionResult UpdatePaymentStatus(string RequestIds)
        {
            string msg = "";
            int counter = 0;
            DataTable dt = objCommonClass.ReturnDatatable(RequestIds.Split(','));
            if (dt.Rows.Count > 0)
            {
                PaymentController objPayment = new PaymentController();
                foreach (DataRow dr in dt.Rows)
                {
                    var res = objPayment.paymentReconcileAPIImplementation(dr[0].ToString());

                    if (string.IsNullOrEmpty(res.errorCode))
                    {
                        counter = counter + 1;
                    }
                }

                if (counter > 0)
                {
                    msg = counter + " Payment Reconcile Successfully";
                }
                else
                {
                    msg = "No payment is confirmed by Bank looking like no payment is made";
                }
            }
            else
            {
                msg = "Unable to get Docket No please try later";
            }
            return Content(msg);
        }

        /*----------------------------END Payment Reconcile-------------------------------*/


        #region  Total Booking for GST and tarrif
        [HttpGet]
        public ActionResult GetTotalBookingList()
        {

            TotalBookingDetail model = new TotalBookingDetail();

            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(model);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult GetTotalBookingList(TotalBookingDetail model)
        {
            ModelState.Clear();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            GridView gv = new GridView();
            model.fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            model.toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);

            var dtresult = objBusinessClass.BindTotalBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Total_Booking = e.BookingCount, CGST = e.CGST, SGST = e.SGST, Room_Rent = e.roomRent, Total_Amount = e.Amount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/GSTDetails.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.BookingList = dtresult;
            return View(model);
        }


        public ActionResult GetBookingList(string dateFrom, string dateTo, long? unitID)
        {
            TotalBookingDetail model = new TotalBookingDetail();

            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    //dateFrom = "01/01/1900";
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    //dateTo = "01/01/1900";
                }
                model.UnitID = unitID ?? 0;

                model.BookingList = objBusinessClass.BindTotalBookingList(model);
            }
            catch
            {
            }
            return PartialView("_GetTotalBookingList", model.BookingList);
        }

        #endregion


        #region Print GST List
        public ActionResult PrintGSTBookingList(string dateFrom, string dateTo, long? unitID)
        {
            TotalBookingDetail model = new TotalBookingDetail();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    ViewBag.fromDate = dateFrom;
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    ViewBag.toDate = dateTo;
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.UnitID = unitID ?? 0;
                model.BookingList = objBusinessClass.BindTotalBookingList(model);
                return View(model.BookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion


        #region Ankita Tripathi
        #region Display Booked Detail List

        [HttpGet]
        public ActionResult ViewBookingDetail()
        {
            ViewBookedDetail model = new ViewBookedDetail();
            return View(model);
        }

        [HttpPost]

        public ActionResult ViewBookingDetail(ViewBookedDetail model)
        {
            return View();
        }

        public ActionResult GetBookedListDetailOnline(string fromDate, string toDate, string docketNo)
        {
            ViewBookedDetail model = new ViewBookedDetail();
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {
                    //dateFrom = "01/01/1900";
                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    //dateTo = "01/01/1900";
                }
                model.docketNo = docketNo;
                model.ViewBookedDetailList = objBusinessClass.ViewBookedDetail(model);
            }
            catch
            {
            }
            return PartialView("_ViewBookingDetail", model.ViewBookedDetailList);
        }



        #region display cancel booking Detail

        [HttpGet]
        public ActionResult CancelBookingDetail(string docketNo)
        {
            CancelBookingDetail obj_BookingDetail = new CancelBookingDetail();
            List<CancelBookingDetail> obj_BookingList = new List<CancelBookingDetail>();
            try
            {

                Session["docketNoForCancel"] = docketNo;

                obj_BookingList = objBusinessClass.CancelDetailList(docketNo);

                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    if (obj_BookingDetail.refaundAmountPer > 0)
                    {
                        obj_BookingDetail.refaundAmount = ((obj_BookingDetail.refaundAmountPer * obj_BookingDetail.amount) / 100);
                    }
                    else
                    {
                        obj_BookingDetail.refaundAmount = 0;
                    }
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.CancelDetail = objBusinessClass.ViewpackagedetailUnitwise(docketNo);
                }
                return View("CancelledBookedDetail", obj_BookingDetail);
            }
            catch
            {

            }
            return View("CancelledBookedDetail", obj_BookingDetail);
        }
        [HttpGet]
        public ActionResult CancelledBookedDetail()
        {
            CancelBookingDetail obj_BookingDetail = new CancelBookingDetail();
            List<CancelBookingDetail> obj_BookingList = new List<CancelBookingDetail>();
            //try
            //{

            //    string docketNo = Convert.ToString(Session["docketNoForCancel"]);

            //    obj_BookingList = objBusinessClass.DetailsOfCancellationConfirmation(docketNo);
            //    if (obj_BookingList != null && obj_BookingList.Count > 0)
            //    {
            //        obj_BookingDetail = obj_BookingList.FirstOrDefault();
            //        obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
            //    }
            //    if (obj_BookingDetail != null)
            //    {
            //        obj_BookingDetail.CancelDetail = objBusinessClass.ViewpackagedetailUnitwise(docketNo);
            //    }
            //    return View(obj_BookingDetail);
            //}
            //catch
            //{

            //}
            //BookingCancellation model = new BookingCancellation();
            return View(obj_BookingDetail);
        }

        [HttpPost]
        public ActionResult CancelledBookedDetail(CancelBookingDetail obj_BookingDetail)
        {
            string id = Convert.ToString(Session["docketNoForCancel"]);
            obj_BookingDetail.MobileNo = Convert.ToString(SessionManager.CustomerMobile);

            #region Calculate cancilaton amount

            List<CancelBookingDetail> obj_BookingList = new List<CancelBookingDetail>();
            obj_BookingList = objBusinessClass.BookingForCancellation(id);

            if (obj_BookingList != null && obj_BookingList.Count > 0)
            {
                obj_BookingDetail = obj_BookingList.FirstOrDefault();
                if (obj_BookingDetail.refaundAmountPer > 0)
                {
                    obj_BookingDetail.refaundAmount = ((obj_BookingDetail.refaundAmountPer * obj_BookingDetail.amount) / 100);
                }
                else
                {
                    obj_BookingDetail.refaundAmount = 0;
                }
                obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
            }
            #endregion

            var CancelDetails = objBusinessClass.InsertCancelBooking(id, obj_BookingDetail.refaundAmountPer, obj_BookingDetail.refaundAmount);
            if (!string.IsNullOrEmpty(CancelDetails.cancelRefNo) && !string.IsNullOrEmpty(CancelDetails.BookingFor))
            {
                //Send Email
                IEnumerable<CancelBookingDetail> IEContactDetails = objBusinessClass.getMobileNoAndEmailId(id);
                // Send SMS to customer
                SendCancelRequestSMS(id, IEContactDetails.FirstOrDefault().MobileNo, IEContactDetails, CancelDetails.BookingFor, CancelDetails.refaundAmount);
                SendCancelRequestEMail(id, IEContactDetails.FirstOrDefault().Email, IEContactDetails, CancelDetails.BookingFor, CancelDetails.refaundPer.ToString(), CancelDetails.refaundAmount.ToString());


                return RedirectToAction("SuccessOnlineBooking", CancelDetails);
            }
            else
            {
                TempData["message"] = "Request Not Cancelled.";
            }
            return View(obj_BookingDetail);
        }
        public ActionResult SuccessOnlineBooking(CancelBookingDetail obj_BookingDetail)
        {
            return View(obj_BookingDetail);
        }
        #endregion

        #region to send sms on booking cancellation
        protected void SendCancelRequestSMS(string docketNo, string mobileNo, IEnumerable<CancelBookingDetail> contactDetails, string BookingFor, decimal refoundAmt)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["CancelBookingSMSByUser"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[Amount]", refoundAmt.ToString());

                string UntAndNodelMsg = ConfigurationManager.AppSettings["CancelBookingSMSByCRSForOthers"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UntAndNodelMsg = UntAndNodelMsg.Replace("[DocketNo]", docketNo);
                UntAndNodelMsg = UntAndNodelMsg.Replace("[Amount]", refoundAmt.ToString());
                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (BookingFor == "UNIT")
                            {
                                if (lst.sendTo == "UNIT")
                                {
                                    SMSStatus = SMS.SMSSend(UntAndNodelMsg, lst.MobileNo);
                                    SMS.SMSLog(UntAndNodelMsg, lst.MobileNo, docketNo, SMSStatus);
                                }
                            }
                            if (BookingFor == "PACK")
                            {
                                if (lst.sendTo == "PACK")
                                {
                                    SMSStatus = SMS.SMSSend(UntAndNodelMsg, lst.MobileNo);
                                    SMS.SMSLog(UntAndNodelMsg, lst.MobileNo, docketNo, SMSStatus);
                                }
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(UntAndNodelMsg, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UntAndNodelMsg, lst.MobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send mail on booking cancellation
        protected void SendCancelRequestEMail(string docketNo, string mailTo, IEnumerable<CancelBookingDetail> contactDetails, string BookingFor, string refundPer, string refundAmount)
        {
            try
            {
                string MailBody, subject, MailBodyOthers;

                CancelBookingDetail obj_BookingList = objBusinessClass.BookingForCancellation(docketNo).FirstOrDefault();

                if (obj_BookingList.BookingFor.ToUpper() == "UNIT")
                {
                    subject = "UP Tourism Room Booking Cancellation Request";
                    StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/RoomCancelRequest.html"));
                    MailBody = reader.ReadToEnd();
                    MailBody = MailBody.Replace("[docketno]", docketNo);
                    MailBody = MailBody.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBody = MailBody.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBody = MailBody.Replace("[hotelname]", obj_BookingList.UnitName);
                    MailBody = MailBody.Replace("[hoteladdress]", obj_BookingList.unitAddress);
                    MailBody = MailBody.Replace("[hotelphone]", obj_BookingList.unitMobile);
                    MailBody = MailBody.Replace("[roomtype]", obj_BookingList.roomType);
                    MailBody = MailBody.Replace("[noofrooms]", obj_BookingList.noOfRooms.ToString());
                    MailBody = MailBody.Replace("[extrabed]", obj_BookingList.extraBed.ToString());
                    MailBody = MailBody.Replace("[checkindate]", obj_BookingList.checkinDate);
                    MailBody = MailBody.Replace("[checkoutdate]", obj_BookingList.checkoutDate);
                    MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                    MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBody = MailBody.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBody = MailBody.Replace("[RefundPercent]", refundPer);
                    MailBody = MailBody.Replace("[refundAmount]", refundAmount);

                    StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/RoomCancelRequest.html"));
                    MailBodyOthers = readerOthers.ReadToEnd();
                    MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBodyOthers = MailBodyOthers.Replace("[hotelname]", obj_BookingList.UnitName);
                    MailBodyOthers = MailBodyOthers.Replace("[hoteladdress]", obj_BookingList.unitAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[hotelphone]", obj_BookingList.unitMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[roomtype]", obj_BookingList.roomType);
                    MailBodyOthers = MailBodyOthers.Replace("[noofrooms]", obj_BookingList.noOfRooms.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[extrabed]", obj_BookingList.extraBed.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[checkindate]", obj_BookingList.checkinDate);
                    MailBodyOthers = MailBodyOthers.Replace("[checkoutdate]", obj_BookingList.checkoutDate);
                    MailBodyOthers = MailBodyOthers.Replace("[customername]", obj_BookingList.name);
                    MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[RefundPercent]", refundPer);
                    MailBodyOthers = MailBodyOthers.Replace("[refundAmount]", refundAmount);
                }
                else if (obj_BookingList.BookingFor.ToUpper() == "PACK")
                {
                    obj_BookingList.CancelDetail = objBusinessClass.PackageAccomodationList(obj_BookingList.packageID);

                    subject = "UP Tourism Package Booking Cancellation Request";
                    StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/PackageCancelRequest.html"));
                    MailBody = reader.ReadToEnd();
                    MailBody = MailBody.Replace("[docketno]", docketNo);
                    MailBody = MailBody.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBody = MailBody.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBody = MailBody.Replace("[packagename]", obj_BookingList.packageName);
                    MailBody = MailBody.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBody = MailBody.Replace("[duration]", obj_BookingList.duration);
                    MailBody = MailBody.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBody = MailBody.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBody = MailBody.Replace("[meetingpoint]", obj_BookingList.meetingPoint);
                    MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                    MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBody = MailBody.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBody = MailBody.Replace("[RefundPercent]", refundPer);
                    MailBody = MailBody.Replace("[refundAmount]", refundAmount);
                    StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/PackageCancelRequest.html"));
                    MailBodyOthers = readerOthers.ReadToEnd();
                    MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBodyOthers = MailBodyOthers.Replace("[packagename]", obj_BookingList.packageName);
                    MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBodyOthers = MailBodyOthers.Replace("[duration]", obj_BookingList.duration);
                    MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBodyOthers = MailBodyOthers.Replace("[meetingpoint]", obj_BookingList.meetingPoint);
                    MailBodyOthers = MailBodyOthers.Replace("[customername]", obj_BookingList.name);
                    MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[RefundPercent]", refundPer);
                    MailBodyOthers = MailBodyOthers.Replace("[refundAmount]", refundAmount);

                    string accomStr = "";
                    if (obj_BookingList.CancelDetail != null && obj_BookingList.CancelDetail.Count() > 0)
                    {
                        accomStr = "<table>";

                        foreach (var accom in obj_BookingList.CancelDetail)
                        {
                            accomStr += "<tr><td colspan='2' style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.daySequence + "</td></tr>" +
                                         "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>City Name</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.cityname + "</td></tr>" +
                                        "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Unit Name</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.UnitName + "</td></tr>" +
                                        "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Address</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitAddress + "</td></tr>" +
                                        "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Room Type</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.roomType + "</td></tr>";
                        }
                        accomStr += "</table>";
                    }

                    MailBody = MailBody.Replace("[accomodationdetails]", accomStr);
                    MailBodyOthers = MailBodyOthers.Replace("[accomodationdetails]", accomStr);
                }
                else
                {
                    subject = "UP Tourism Special Package Booking Cancellation Request";
                    StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/SplPackageCancelRequest.html"));
                    MailBody = reader.ReadToEnd();
                    MailBody = MailBody.Replace("[docketno]", docketNo);
                    MailBody = MailBody.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBody = MailBody.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBody = MailBody.Replace("[packagename]", obj_BookingList.packageName);
                    MailBody = MailBody.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBody = MailBody.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBody = MailBody.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                    MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBody = MailBody.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBody = MailBody.Replace("[RefundPercent]", refundPer);
                    MailBody = MailBody.Replace("[refundAmount]", refundAmount);

                    StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/SplPackageCancelRequest.html"));
                    MailBodyOthers = readerOthers.ReadToEnd();
                    MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBodyOthers = MailBodyOthers.Replace("[packagename]", obj_BookingList.packageName);
                    MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBodyOthers = MailBodyOthers.Replace("[customername]", obj_BookingList.name);
                    MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[RefundPercent]", refundPer);
                    MailBodyOthers = MailBodyOthers.Replace("[refundAmount]", refundAmount);

                }

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    SendMail.SendMailNew(mailTo, subject, MailBody);

                }

                foreach (var lst in contactDetails)
                {
                    try
                    {
                        if (BookingFor == "UNIT")
                        {
                            if (lst.sendTo == "UNIT")  // Send Email to Unit
                            {
                                SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);

                            }
                        }
                        if (BookingFor == "PACK")
                        {
                            if (lst.sendTo == "PACK")  // Send Email to Unit
                            {
                                SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);

                            }
                        }
                        if (lst.sendTo == "NODAL")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);

                        }
                        if (lst.sendTo == "UPTOURS")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);

                        }
                    }
                    catch { }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region print cancellation details

        public ActionResult PrintCancellationDetails(string docketNo)
        {
            CancelBookingDetail obj_BookingDetail = new CancelBookingDetail();
            List<CancelBookingDetail> obj_BookingList = new List<CancelBookingDetail>();
            try
            {
                if (Session["docketNoForCancel"] != null)
                {

                    docketNo = Convert.ToString(Session["docketNoForCancel"]);
                }
                Session["docketNoForCancel"] = null;
                obj_BookingList = objBusinessClass.DetailsOfCancellationConfirmation(docketNo);
                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.CancelDetail = objBusinessClass.ViewpackagedetailUnitwise(docketNo);
                }
            }
            catch
            {

            }

            return View("PrintCancellationDetails", obj_BookingDetail);

        }
        #endregion


        #endregion
        public ActionResult OnlineCancellationBooking()
        {
            return View();
        }
        public ActionResult GetOnlinCancelDetail(string fromDate, string toDate)
        {
            ViewBookedDetail model = new ViewBookedDetail();
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                model.ViewBookedDetailList = objBusinessClass.ViewCancelDetail(model);
            }
            catch
            {
            }
            return PartialView("_OnlineCancellationBooking", model.ViewBookedDetailList);
        }
        #endregion

        #region ViewGSTDetail for Online Booking Unit Wise

        public ActionResult GetGSTReportforOnlineBooking(string docketNo)
        {
            ViewGSTDetailOnline model = new ViewGSTDetailOnline();
            model.docketNo = docketNo;
            model.ViewGSTReportForOnlineBooking = objBusinessClass.ViewGSTReportForOnlineBooking(docketNo).ToList();

            // var model1 = objBusinessClass.ViewGSTReportForOnlineBooking(docketNo).ToList();
            // model.UnitName = model1[0].UnitName;

            model.fromDate = model.ViewGSTReportForOnlineBooking.FirstOrDefault().fromDate;
            model.toDate = model.ViewGSTReportForOnlineBooking.FirstOrDefault().toDate;
            model.Amount = model.ViewGSTReportForOnlineBooking.FirstOrDefault().Amount;
            model.CGST = model.ViewGSTReportForOnlineBooking.FirstOrDefault().CGST;
            model.SGST = model.ViewGSTReportForOnlineBooking.FirstOrDefault().SGST;
            model.name = model.ViewGSTReportForOnlineBooking.FirstOrDefault().name;
            model.docketNo = model.ViewGSTReportForOnlineBooking.FirstOrDefault().docketNo;
            model.checkInDate = model.ViewGSTReportForOnlineBooking.FirstOrDefault().checkInDate;
            model.checkOutDate = model.ViewGSTReportForOnlineBooking.FirstOrDefault().checkOutDate;
            model.BookingCount = model.ViewGSTReportForOnlineBooking.FirstOrDefault().BookingCount;
            model.roomRent = model.ViewGSTReportForOnlineBooking.FirstOrDefault().roomRent;
            model.UnitName = model.ViewGSTReportForOnlineBooking.FirstOrDefault().UnitName;
            return View(model);
        }
        #endregion

        //----------Start GST Slab wise----------------------//

        [HttpGet]
        public ActionResult GetOnlineGSTReportSlabWise()
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View();
        }

        public ActionResult ViewGSTSlabWise(string fromDate, string toDate, long? unitID)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                model.UnitID = unitID ?? 0;
                model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWise(model);
            }
            catch
            {
            }

            //model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWise();
            return PartialView("_ViewOnlineGSTSlabWise", model.SlabWiseDetail);
        }

        public ActionResult GetGSTReportforOnlineSlabWise(long unitId, string fromDate, string toDate)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            //model.DocketNumber = docketNo;
            model.UnitID = unitId;
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                // model.fromDate=frmDate
                // model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWise(model).ToList();
                model.SlabWiseDetail = objBusinessClass.GetOnlineDocketSlabWise(model).ToList();
            }
            catch
            {
            }

            model.UnitName = model.SlabWiseDetail.FirstOrDefault().UnitName;
            return View(model);
        }

        #region Print GST List
        public ActionResult PrintGSTDetailSlabWise(string dateFrom, string dateTo, long? unitID)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            try
            {
                ViewBag.UnitName = objBusinessClass.GetTotalUnitList().Where(e => e.UnitID == unitID).ToList().FirstOrDefault().UnitName;
            }
            catch
            {
                ViewBag.UnitName="All";
            }
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    ViewBag.fromDate = dateFrom;
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    ViewBag.toDate = dateTo;
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.UnitID = unitID ?? 0;
                model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWise(model);
                return View(model.SlabWiseDetail);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region Print GST List
        public ActionResult PrintGSTUnitWiseSlabDetail(string dateFrom, string dateTo, long? unitID)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    ViewBag.fromDate = dateFrom;
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    ViewBag.toDate = dateTo;
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.UnitID = unitID ?? 0;
                model.SlabWiseDetail = objBusinessClass.GetOnlineDocketSlabWise(model).ToList();
                model.UnitName = model.SlabWiseDetail.FirstOrDefault().UnitName;
                return View(model.SlabWiseDetail);
            }
            catch
            {
            }
            return View();
        }
        #endregion


        [HttpGet]
        public ActionResult GetOnlineGSTReportSlabWiseCurrent()
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View();
        }

        public ActionResult ViewGSTSlabWiseCurrent(string fromDate, string toDate, long? unitID)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                model.UnitID = unitID ?? 0;
                model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWiseCurrent(model);
            }
            catch
            {
            }

            //model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWise();
            return PartialView("_ViewOnlineGSTSlabWiseCurrent", model.SlabWiseDetail);
        }

        public ActionResult GetGSTReportforOnlineSlabWiseCurrent(long unitId, string fromDate, string toDate)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            //model.DocketNumber = docketNo;
            model.UnitID = unitId;
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                // model.fromDate=frmDate
                // model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWise(model).ToList();
                model.SlabWiseDetail = objBusinessClass.GetOnlineDocketSlabWiseCurrent(model).ToList();
            }
            catch
            {
            }

            model.UnitName = model.SlabWiseDetail.FirstOrDefault().UnitName;
            return View(model);
        }

        #region Print GST List
        public ActionResult PrintGSTDetailSlabWiseCurrent(string dateFrom, string dateTo, long? unitID)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            //if
            //ViewBag.UnitName = objBusinessClass.GetTotalUnitList().Where(e => e.UnitID == unitID).ToList().FirstOrDefault().UnitName;
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    ViewBag.fromDate = dateFrom;
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    ViewBag.toDate = dateTo;
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.UnitID = unitID ?? 0;
                model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWiseCurrent(model);
                return View(model.SlabWiseDetail);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region Print GST List
        public ActionResult PrintGSTUnitWiseSlabDetailCurrent(string dateFrom, string dateTo, long? unitID)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    ViewBag.fromDate = dateFrom;
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    ViewBag.toDate = dateTo;
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.UnitID = unitID ?? 0;
                model.SlabWiseDetail = objBusinessClass.GetOnlineDocketSlabWiseCurrent(model).ToList();
                model.UnitName = model.SlabWiseDetail.FirstOrDefault().UnitName;
                return View(model.SlabWiseDetail);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        //----------End GST Slab wise----------------------//




        #region riya
        [HttpGet]
        public ActionResult PackageGSTReport()
        {

            TourList model = new TourList();



            return View(model);

        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageGSTReport(TourList model)//get data in excel
        {
            ModelState.Clear();

            GridView gv = new GridView();
            model.fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            model.toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);

            var dtresult = objBusinessClass.BindTourBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Package_Name = e.packageName, Total_Booking = e.BookingCount, CGST = e.CGST, SGST = e.SGST, Package_Price = e.PackageAmountExcludingGST, Total_Amount = e.TotalAmount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/GSTDetails.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.BookingList = dtresult;
            return View(model);
        }

        public ActionResult ViewPackageGSTReport(string fromDate, string toDate)//get data in grid
        {
            TourList model = new TourList();
            //model.DocketNumber = docketNo;
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                // model.fromDate=frmDate
                model.SlabWiseDetail = objBusinessClass.BindTourBookingList(model).ToList();

            }
            catch
            {
            }

            //model.UnitName = model.SlabWiseDetail.FirstOrDefault().UnitName;
            return PartialView("_ViewPackageGSTReport", model.SlabWiseDetail);
        }

        public ActionResult GetGSTReportPackages(string docketNo)//get data as per docket number
        {
            ViewTourList model = new ViewTourList();
            model.docketNo = docketNo;
            model.ViewGSTReportForOnlineBooking = objBusinessClass.ViewGSTReportForPackageOnlineBooking(docketNo).ToList();

            // var model1 = objBusinessClass.ViewGSTReportForOnlineBooking(docketNo).ToList();
            // model.UnitName = model1[0].UnitName;

            model.fromDate = model.ViewGSTReportForOnlineBooking.FirstOrDefault().fromDate;
            model.toDate = model.ViewGSTReportForOnlineBooking.FirstOrDefault().toDate;
            model.TotalAmount = model.ViewGSTReportForOnlineBooking.FirstOrDefault().TotalAmount;
            model.CGST = model.ViewGSTReportForOnlineBooking.FirstOrDefault().CGST;
            model.SGST = model.ViewGSTReportForOnlineBooking.FirstOrDefault().SGST;
            model.packageName = model.ViewGSTReportForOnlineBooking.FirstOrDefault().packageName;
            model.docketNo = model.ViewGSTReportForOnlineBooking.FirstOrDefault().docketNo;
            model.BookingCount = model.ViewGSTReportForOnlineBooking.FirstOrDefault().BookingCount;
            model.PackageAmountExcludingGST = model.ViewGSTReportForOnlineBooking.FirstOrDefault().PackageAmountExcludingGST;

            return View(model);
        }
        #endregion

    }
}
