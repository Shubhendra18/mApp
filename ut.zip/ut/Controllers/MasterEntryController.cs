﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models;
using System.IO;
using UP_TourismBooking.Models.ProcessClasses;
using System.Xml.Linq;
using System.Data;

namespace UP_TourismBooking.Controllers
{
    [AuthorizeHQ]
    public class MasterEntryController : Controller
    {        
        BusinessClass objBuss = new BusinessClass();
        Common ObjCom = new Common();
        public ActionResult Dashboard()
        {

            return View();
        }

        public JsonResult GetRoomUnitType(int unitID)
        {
            //for state pass 3 as masterID
            IEnumerable<SelectListItem> obj = objBuss.GetUnitRoomType(unitID).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
            return Json(obj, JsonRequestBehavior.AllowGet);
        }

        public ActionResult CreateUnit()
        {
            ViewBag.Destinations = objBuss.GetallDestination().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateUnit(MasterUnits pack)
        {
            if (ModelState.IsValid)
            {
                if (pack.tileImage != null)
                {
                    string ext = Path.GetExtension(pack.tileImage.FileName);
                    string filename = Path.GetFileName(DateTime.Now.Ticks + ext);
                    string Cmsg = ObjCom.ValidateImageExt(pack.tileImage, filename);
                    if (Cmsg != "Valid")
                    {
                        ViewBag.Destinations = objBuss.GetallDestination().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
                        TempData["Msg"] = Cmsg;
                        return View(pack);
                    }
                    else
                    {
                        pack.titleImagePath = Path.Combine("~/Uploads/Units/Images/", filename);
                        var docPath = Path.Combine(Server.MapPath("~/Uploads/Units/Images/"), filename);
                        pack.tileImage.SaveAs(docPath);
                    }
                }
                else if (pack.titleImagePath == null)
                {
                    pack.titleImagePath = "";

                }

                Messg a = objBuss.InsertUnitDetails(pack);

                TempData["Msg"] = Convert.ToString(a.msg);

                return RedirectToAction("GetUnits");
            }
            else
            {
                ViewBag.Destinations = objBuss.GetallDestination().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
                TempData["Msg"] = "Check Your Inputs";
                return View(pack);
            }
        }

        public ActionResult GetUnits()
        {
            int id = 0;
            List<MasterUnits> AllUnit = objBuss.GetallUnit(id).ToList();
            return View("GetUnits", AllUnit);
        }

        public ActionResult EditUnit(int id)
        {
            ViewBag.Destinations = objBuss.GetallDestination().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
            MasterUnits Unit = new MasterUnits();
            Unit = objBuss.GetallUnit(id).ToList().FirstOrDefault();
            @TempData["Task"] = "Edit";
            return View("CreateUnit", Unit);
        }

        public ActionResult Rooms()
        {
            ViewBag.Roomtype = objBuss.getAllRoomType().Select(e => new SelectListItem() { Text = e.roomType, Value = e.RoomTypeId.ToString() });
            ViewBag.Units = objBuss.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            //string msg = TempData["Msg"].ToString();
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Rooms(MasterRooms Rooms)
        {
            if (ModelState.IsValid)
            {
                int a = objBuss.insertInRooms(Rooms);
                if (a > 0)
                {
                    TempData["Msg"] = "Room Added Successfully";
                }
                else
                {
                    TempData["Msg"] = "Failed to Added Room";
                }
            }
            else
            {

            }

            return RedirectToAction("Rooms");
        }

        public ActionResult EditRooms(string RoomId)
        {
            ViewBag.Roomtype = objBuss.getAllRoomType().Select(e => new SelectListItem() { Text = e.roomType, Value = e.RoomTypeId.ToString() });
            ViewBag.Units = objBuss.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            int un;
            int.TryParse(RoomId, out un);
            MasterRooms RoomsList = objBuss.GetRoomForEdit(0, un).ToList().FirstOrDefault();
            return View("_EditRooms", RoomsList);

        }

        public ActionResult Delete(string RoomId)
        {
            int un;
            int.TryParse(RoomId, out un);
            int a = objBuss.DeleteRooms(un);
            if (a > 0)
            {
                TempData["Msg"] = "Room Deleted Successfully";
            }
            else
            {
                TempData["Msg"] = "Failed to Deleted Room";
            }
            return RedirectToAction("Rooms");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditRooms(MasterRooms Room)
        {
            if (ModelState.IsValid)
            {
                int a = objBuss.insertInRooms(Room);
                if (a > 0)
                {
                    TempData["Msg"] = "Room Updated Successfully";
                }
                else
                {
                    TempData["Msg"] = "Failed to Update Room";
                }
            }
            return RedirectToAction("Rooms");
        }

        public ActionResult GetRoomDetails(string UnitID)
        {
            int un;
            int.TryParse(UnitID, out un);
            List<ViewRooms> RoomsList = objBuss.GetallRooms(un, 0).ToList();
            return View("_GetRooms", RoomsList);
        }

        public ActionResult AddTariff(string Id)
        {
            TempData["RoomId"] = Id.ToString();
            ViewBag.Seasons = objBuss.GetSeason().Select(e => new SelectListItem() { Text = e.Seasonname, Value = e.SeasonId.ToString() });
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddTariff(RoomTariff mrt, int id)
        {
            if (ModelState.IsValid)
            {
                mrt.roomID = id;
                Messg i = objBuss.InsertRoomTariffDetails(mrt);

                TempData["Msg"] = Convert.ToString(i.msg);

                return RedirectToAction("AddTariff", "MasterEntry", new { id = id });
            }
            else
            {
                TempData["Msg"] = "Please Check Your Inputs";
                return View(mrt);
            }
        }

        public ActionResult GetRoomTariff(string roomid)
        {
            Session["RoomId"] = roomid;
            int RM_id;
            int.TryParse(roomid, out RM_id);
            List<ViewRoomTariff> RoomTariff = objBuss.GetRoomTariff(RM_id).ToList();
            return View("_GetRoomTariff", RoomTariff);
        }

        public ActionResult EditTariff(int id)
        {
            ViewBag.Seasons = objBuss.GetSeason().Select(e => new SelectListItem() { Text = e.Seasonname, Value = e.SeasonId.ToString() });
            RoomTariff ObjRoomTariff = objBuss.GetRoomTariffByroomTariffID(id).FirstOrDefault();
            return View("_EditTariff", ObjRoomTariff);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EditTariff(RoomTariff mrt)
        {
            try
            {
                string roomid = Session["RoomId"].ToString();
                if (ModelState.IsValid)
                {
                   
                    Messg i = objBuss.InsertRoomTariffDetails(mrt);
                    TempData["Msg"] = Convert.ToString(i.msg);
                    return RedirectToAction("AddTariff", "MasterEntry", new { id = roomid });
                }
                else
                {
                    TempData["Msg"] = "Inputs are not Valid";
                    return RedirectToAction("AddTariff", "MasterEntry", new { id = roomid });
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }

        public ActionResult AddUnitImage()
        {
            ViewBag.Roomtype = objBuss.getAllRoomType().Select(e => new SelectListItem() { Text = e.roomType, Value = e.RoomTypeId.ToString() });
            ViewBag.Units = objBuss.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.Mode = "Add";

            if( TempData["Msg"] != null &&  Convert.ToString(TempData["Msg"]) != "")
            {
                ViewBag.Message = TempData["Msg"];
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddUnitImage(UnitImage Model)
        {
            try
            {
                ViewBag.Roomtype = objBuss.getAllRoomType().Select(e => new SelectListItem() { Text = e.roomType, Value = e.RoomTypeId.ToString() });
                ViewBag.Units = objBuss.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

                ModelState["UnitImagesID"].Errors.Clear();
                ModelState["ImagePath"].Errors.Clear();

                if (ModelState.IsValid)
                {
                    if (Model.Image != null)
                    {
                        string ext = Path.GetExtension(Model.Image.FileName);
                        string filename = Path.GetFileName("UNIT-" + Model.UnitID + "-" + DateTime.Now.Ticks + ext);
                        string Cmsg = ObjCom.ValidateImageExt(Model.Image, filename);
                        if (Cmsg != "Valid")
                        {
                            ViewBag.Message = Cmsg;
                            return View(Model);
                        }
                        else
                        {
                            Model.ImagePath = Path.Combine("~/Uploads/Units/Images/", filename);
                            var DocPath = Path.Combine(Server.MapPath("~/Uploads/Units/Images/"), filename);
                            Model.Image.SaveAs(DocPath);
                        }

                    }
                    else if (Model.ImagePath == null)
                    {
                        ViewBag.Message = "Select an Image!";
                        return View(Model);
                    }
                    int i = 0;
                    i = objBuss.InsertUpdateUnitImage(Model);
                    if (i > 1)
                    {
                        TempData["Msg"] = "Image Saved Sucessfully";
                        return RedirectToAction("AddUnitImage", "MasterEntry");
                    }
                    else
                    {
                       ViewBag.Message = "Image Not Saved.";
                    }
                }                
            }
            catch
            { }
            return View(Model);
        }

        public ActionResult GetUnitImage(int UnitId)
        {
            List<UnitImageDetaisl> UnitImg = objBuss.getUnitImage(UnitId, 0).ToList();

            return View("_GetUnitImage", UnitImg);
        }

        public ActionResult EditUnitImage(Int64 id)
        {
            UnitImage model = objBuss.getUnitImageForEditByUnitImageId(id);
            ViewBag.Roomtype = model.roomTypeID;
            //RoomType m = new RoomType();
            //m.roomTypeId =Convert.ToInt32(model.roomTypeID);
            ViewBag.Mode = "Edit";
            ViewBag.Units = objBuss.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.Roomtype = objBuss.GetUnitRoomType(model.UnitID).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
           // GetRoomUnitType(Convert.ToInt32(model.UnitID));
            return View("AddUnitImage", model);
        }

        public ActionResult OutOfService()
        {
            ViewBag.Units = objBuss.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View();
        }

        [HttpGet]
        public ActionResult GetOutofService(int Unit)
        {
            RoomOutOfServiceDetail ROS = new RoomOutOfServiceDetail();
            ROS.unitID = Unit;
            ROS.RoomsOutofServiceList = objBuss.getRoomOutOfOrder(Unit);
            return PartialView("_GetSetOutofService", ROS);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OutOfService(RoomOutOfServiceDetail OutOfServ)
        {
            ViewBag.Units = objBuss.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            try
            {
                
                List<RoomOutOfServiceDetail> OutOforderlist = OutOfServ.RoomsOutofServiceList;
                int totlCount = 0;
                bool Status = false;
                int Block = 0;


                string xml = "<OutofOrderDetail>";
                for (int i = 0; i < OutOforderlist.Count(); i++)
                {
                    xml += "<OutofOrderList>";
                    xml += "<UnitId>" + OutOfServ.unitID + "</UnitId>";
                    xml += "<RoomID>" + OutOforderlist[i].roomID + "</RoomID>";
                    xml += "<OutofServicCount>" + OutOforderlist[i].outOfServiceCount + "</OutofServicCount>";
                    xml += "</OutofOrderList>";
                    totlCount = OutOforderlist[i].TotalRoom;
                    Block = OutOforderlist[i].outOfServiceCount;
                    if (Block <= totlCount)
                    {
                        Status = true;
                    }
                }
                if (Status)
                {
                    xml += "</OutofOrderDetail>";
                    int x = objBuss.InsertUpdateRoomOutOfOrder(OutOfServ, xml);
                    if (x > 0)
                    {
                        ViewBag.Msg = "Record Saved Successfully!";
                    }
                    else
                    {
                        ViewBag.Msg = "Some Thing went Wrong!";
                    }


                }
                else
                {
                    ViewBag.Msg = "Can't Block Room Count Grater than Total Room Count!";
                }

            }
            catch
            {
                ViewBag.Msg = "Error in Process!";
            }
            return View(OutOfServ);
        }

        [HttpGet]
        public ActionResult GetRoomTypeWiseRoomNo(int unitID, int roomID)
        {
            RoomOutOfServiceDetail model = new RoomOutOfServiceDetail();
            model = objBuss.GetOutofServiceRoomDetails(unitID, roomID);
            if (model != null)
            {
                model.RoomNoList = objBuss.GetRoomTypeWiseRoomNo(unitID, roomID);
            }
            return PartialView("_OutOfServiceRoomDetail", model);
        }

        public ActionResult SearchGuest()
        {
            return View();
        }

        [HttpGet]
        public ActionResult GetGuestList(string name, string email, string mobile,string fromdate,string todate)
        {
            DateTime _fromDate = DateTime.Now, _Todate = DateTime.Now;
            try
            {
                _fromDate = DateTime.ParseExact(fromdate, "dd/MM/yyyy", null);
                _Todate = DateTime.ParseExact(todate, "dd/MM/yyyy", null);
            }
            catch
            {
                _fromDate = DateTime.Now.AddMonths(-6);
                _fromDate = DateTime.Now;
            }
            int UserId = 0;
            List<GuestList> ggl = objBuss.getGuestList(UserId, name, mobile, email,_fromDate,_Todate).ToList();

            return PartialView("_GetGuestList", ggl);
        }

        [HttpGet]
        public ActionResult GetSpecialPackages()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult GetSpecialPackages(SpecialPackages sepPackage)
        {
            if (ModelState.IsValid)
            {
                Messg Msg = objBuss.InsertUpdateSpecialPackage(sepPackage);
                TempData["Msg"] = Msg == null ? string.Empty : Convert.ToString(string.IsNullOrEmpty(Msg.msg) ? "Error in Process" : Msg.msg);
            }
            ModelState.Clear();
            sepPackage.package_Abbr = "";
            sepPackage.pid = 0;
            sepPackage.programEndTimeSummer = "";
            sepPackage.programEndTimeWinter = "";
            sepPackage.programStratTimeSummer = "";
            sepPackage.programStratTimeWinter = "";
            sepPackage.routeType = "";
            
            return View();
        }

        [HttpGet]
        public ActionResult ViewSpecPackage(Int64 PackId)
        {
            SpecialPackages sp = new SpecialPackages();
            sp.SpecList = objBuss.GetSpecialpackageDetails(PackId).ToList();
            return PartialView("_ViewSpecialPackages", sp);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SaveOutofServiceRoomNo(RoomOutOfServiceDetail model)
        {
            try
            {
                var outOfServiceRooms = Request.Form["rooms"];
                if (!string.IsNullOrEmpty(outOfServiceRooms))
                {
                    var rooms = outOfServiceRooms.ToString().Split(',');
                    if (model.outOfServiceCount == rooms.Length)
                    {
                        string roomXml = "<RoomDetail>";
                        foreach (var _room in rooms)
                        {
                            roomXml += "<RoomNo>";
                            roomXml += "<RoomNoId>" + _room + "</RoomNoId>";
                            roomXml += "</RoomNo>";
                        }
                        roomXml += "</RoomDetail>";

                        int x = objBuss.UpdateRoomStatus(model, roomXml);

                        if (x > 0)
                        {
                            return Json(new { result = true, message = "Room Status Modified Successfully!" }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(new { result = false, message = "Room Status Not Modified!" }, JsonRequestBehavior.AllowGet);
                        }
                    }
                    else
                    {
                        return Json(new { result = false, message = "selected Room  count must equal to Block count!" }, JsonRequestBehavior.AllowGet);
                    }

                }
                else
                {
                    if (model.outOfServiceCount > 0)
                    {
                        return Json(new { result = false, message = "selected Room  count must equal to Block count!" }, JsonRequestBehavior.AllowGet);
                    }
                    else
                    {
                        string roomXml = "";
                        int x = objBuss.UpdateRoomStatus(model, roomXml);

                        if (x > 0)
                        {
                            return Json(new { result = true, message = "Room Status Modified Successfully!" }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            return Json(new { result = false, message = "Room Status Not Modified!" }, JsonRequestBehavior.AllowGet);
                        }
                    }

                }
            }
            catch
            {
                return Json(new { result = false, message = "Error in Process!" }, JsonRequestBehavior.AllowGet);
            }
        }

        [HttpGet]
        public ActionResult EditSpecPackage(Int64 id)
        {
            SpecialPackages sp = new SpecialPackages();
            sp = objBuss.GetSpecialpackageDetails(id).FirstOrDefault();
            return View("GetSpecialPackages", sp);
        }

        [HttpGet]
        public ActionResult ViewEditPackageProgram(int id)
        {
            SpecialPackages sepPackage = new SpecialPackages();
            sepPackage = objBuss.GetSpecialpackageDetails(id).FirstOrDefault(); 
            //Int64 Pid = sepPackage.pid;
            sepPackage.PackageProgram = objBuss.GetSetspecialPackageProgram(id).ToList();
            return View(sepPackage);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ViewEditPackageProgram(SpecialPackages spec)
        {

            if (ModelState.IsValid)
            {
                Int64? pacId = spec.pid;
                int i = 0;
                var ProgXml = new XElement("ProgramDetail",
                  from Prog in spec.PackageProgram
                  select new XElement("ProgramList",
                                 new XElement("pid", Prog.pid),
                                 new XElement("programName", Prog.programName),
                                 new XElement("DisplayOrder", Prog.DisplayOrder),
                                 new XElement("stratEnd", Prog.stratEnd))
                                     );
                string spProgram = ProgXml.ToString();
                i = objBuss.UpdateSpecialProgram(spProgram, pacId);
                if (i > 1)
                {
                    TempData["Msg"] = "Programs Updated Sucessfully";
                }
                else
                {
                    TempData["Msg"] = "Program Could not Updated";
                }                
            }
            else
            {
                TempData["Msg"] = "Error In Inputs Try Again with Valid Input.";
            }
            return RedirectToAction("ViewEditPackageProgram");
        }

        [HttpGet]
        public ActionResult AddSpecialPackProgram(int id)
        {
            SpecialPackageProgram sepPackage = new SpecialPackageProgram();
            sepPackage.pid = id;
            return PartialView("_AddSpecialPackageProgram", sepPackage);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddSpecialPackProgram(SpecialPackageProgram spp)
        {
            int i = 0;
            Int64 id = spp.pid;
            if (ModelState.IsValid)
            {
                
                i = objBuss.AddSpecialPackageProgram(spp);
                if (i > 1)
                {
                    TempData["Msg"] = "Program Added Sucessfully";
                }
                else
                {
                    TempData["Msg"] = "Program Could not Added with same Display Order ";
                }
                return RedirectToAction("ViewEditPackageProgram", "MasterEntry", new { id = id });
            }
            else
            {
                TempData["Msg"] = "Error in Inputs try Again with Valid Inputs";
                return RedirectToAction("ViewEditPackageProgram", "MasterEntry", new { id = id });
            }
        }

        [HttpGet]
        public ActionResult SpecialPackageFare(Int64 Id)
        {
            //Session["temp"] = Id.ToString();

            SpecialPackageFare model = new SpecialPackageFare();
            model = objBuss.GetSetspecialPackageFare(Id).FirstOrDefault();
            model.PackList = objBuss.GetSetspecialPackageFare(Id);
            model.pid = Id;
            model.applicantTypeId = null;
            model.fare = 0;
            ViewBag.AType = GetAppType();
            ViewBag.NoOfPerson = GetNoOfperson();          

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddSpecPackfare(SpecialPackageFare spf)
        {
            Int64 i = spf.pid;
            if (ModelState.IsValid)
            {
                
                Messg m = objBuss.InsertUpdateSpecialPackFare(spf);
                TempData["MsgS"] = m.msg;
                return RedirectToAction("SpecialPackageFare", new { id = i });
            }
            else
            {
                TempData["MsgS"] = "Error in Inputs please try again with Valid Inputs";
                return RedirectToAction("SpecialPackageFare", new { id = i });
            }
        }

        [HttpGet]
        public ActionResult ViewSpecPackfare(Int64 Id)
        {
            IEnumerable<SpecialPackageFare> PackList = objBuss.GetSetspecialPackageFare(Id);
            return PartialView("_viewSpecFare", PackList);
        }

        #region Method - get List type
        public IEnumerable<SelectListItem> GetAppType()
        {
            var objNationality = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Indian";
            Temp.Value = "1";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Foreigner";
            Temp.Value = "0";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Student";
            Temp.Value = "3";
            objNationality.Add(Temp);

            return objNationality;
        }
        public IEnumerable<SelectListItem> GetNoOfperson()
        {
            var objNationality = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "1";
            Temp.Value = "1";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "2";
            Temp.Value = "2";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "3";
            Temp.Value = "3";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "4";
            Temp.Value = "4";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "5";
            Temp.Value = "5";
            objNationality.Add(Temp);
            return objNationality;
        }

        #endregion

        #region By Radhey
        [HttpGet]
        public ActionResult PackageMapping()
        {
            PackageMappingModel objPackageMPModel = new PackageMappingModel();

            FIllDropDown(false, 0, 0);

            objPackageMPModel = FillPackageDestinationDetails(0);
            return View(objPackageMPModel);
        }

        //#region Bind Destination City (To City) By from City (From City ID)

        //[HttpGet]
        //public JsonResult BindDdlToCityByCityID(int fromCityId)
        //{
        //    ViewBag.SelectToCity = objBuss.GetToCity(fromCityId).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });

        //    return Json(ViewBag.SelectToCity, JsonRequestBehavior.AllowGet);
        //}

        //#endregion

        #region Bind Dropdown Unit By To City (Destination City)

        [HttpGet]
        public JsonResult BindDdlUntiByToCityID(int toCityID)
        {
            ViewBag.SelectUnit = objBuss.GetUnitDetail(toCityID).Select(e => new SelectListItem() { Text = e.unitName, Value = e.UnitID.ToString() });
            return Json(ViewBag.SelectUnit, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Bind Dropdown Room Type By To Unit

        [HttpGet]
        public JsonResult BindDdlRoomTypebyUnitID(int unitID)
        {
            ViewBag.selectRoomType = objBuss.GetRoomTypeDetails(unitID).Select(e => new SelectListItem() { Text = e.roomType, Value = e.RoomTypeID.ToString() });
            return Json(ViewBag.selectRoomType, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region Insert Package Destination Records

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageMapping(PackageMappingModel model)
        {
            if (ModelState.IsValid)
            {
                if (model.sequenceNo != 0)
                {

                    int i = objBuss.InsertPackageMapDetails(model);
                    if (i > 0)
                    {
                        ViewBag.Message = "Record Inserted Successfully ...!";
                    }
                    else
                    {
                        ViewBag.Message = "Record Not Inserted, Please insert correct record ...!";
                    }
                }
                else
                {
                    ViewBag.Message = "Please insert sequence number its can not be Zero ...!";

                }


            }

            FIllDropDown(true, model.toCityID, model.unitID);

            int packageID = model.packageTypeID;


            model = FillPackageDestinationDetails(packageID);
            //ViewBag.Message = BindDdlUntiByToCityID(objPMM.toCityID).Data.ToString().se

            model.Day = 0;
            model.packageDestionationID = 0;

            return View(model);
        }

        #endregion

        #region FIll Record Package ID wise in table

        [HttpGet]
        public ActionResult fillPackageWiseDetails(int packageID)
        {
            ViewBag.Message = "";
            PackageMappingModel objPackageMPModel = new PackageMappingModel();
            List<PackageMappingModel> GetRecord = new List<PackageMappingModel>();
            DataSet ds = new DataSet();

            var Details = objBuss.GetMappedPackageDetails(packageID);
            if (Details.Count > 0)
            {
                objPackageMPModel.lst_FillPackgeMappedDetails = Details;
            }
            else
            {
                objPackageMPModel.lst_FillPackgeMappedDetails = null;
                ViewBag.Message = "No record found...!";
            }

            return PartialView("_PackageMappingPartial", objPackageMPModel);

        }

        #endregion

        #region FIll All record in table on clicking Show All Button  (not Being Used)
        [HttpGet]
        public ActionResult fillAllDetails(int packageID)
        {
            PackageMappingModel objPackageMPModel = new PackageMappingModel();
            List<PackageMappingModel> GetRecord = new List<PackageMappingModel>();
            DataSet ds = new DataSet();


            var Details = objBuss.GetMappedPackageDetails(packageID);
            if (Details.Count > 0)
            {
                objPackageMPModel.lst_FillPackgeMappedDetails = Details;
            }
            else
            {
                objPackageMPModel.lst_FillPackgeMappedDetails = null;
                ViewBag.Message = "No record found...!";
            }
            return PartialView("_PackageMappingPartial", objPackageMPModel);

        }

        #endregion

        #region Delete Package Destination (Mapped Pakage Record) record

        [HttpGet]
        public ActionResult DeletePackages(int? ID)
        {
            int IDs = Convert.ToInt32(ID);
            PackageMappingModel objPackageMPModel = new PackageMappingModel();
            int i = objBuss.DeletePackageMapDetails(objPackageMPModel, IDs);
            if (i > 0)
            {
                ViewBag.Message = "Record Deleted Successfully ...!";
            }
            else
            {
                ViewBag.Message = "Record Not Deleted, Please try Again";
            }
            FIllDropDown(false,0,0);
            int packageID = 0;
            objPackageMPModel = FillPackageDestinationDetails(packageID);

            return PartialView("_PackageMappingPartial", objPackageMPModel);

        }

        #endregion

        #region Method for Fill All Details with Conditions

        public PackageMappingModel FillPackageDestinationDetails(int packageId)
        {
            PackageMappingModel objPackageMPModel = new PackageMappingModel();
            List<PackageMappingModel> GetRecord = new List<PackageMappingModel>();



            var Details = objBuss.GetMappedPackageDetails(packageId);
            if (Details.Count > 0)
            {
                objPackageMPModel.lst_FillPackgeMappedDetails = Details;
            }
            else
            {
                objPackageMPModel.lst_FillPackgeMappedDetails = null;
                ViewBag.Message = "No record found...!";
            }
            // return View(Test);
            return objPackageMPModel;
        }

        #endregion

        #region Method for getting record for dropdown being fill direct on page load

        public void FIllDropDown(bool isPostBack, int toCityID, int unitID)
        {
            ViewBag.SelectPackageType = objBuss.GetPackageType().Select(e => new SelectListItem() { Text = e.packageName, Value = e.packageID.ToString() });
            ViewBag.SelectFromCity = objBuss.GetFromCity().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
            ViewBag.SelectToCity = objBuss.GetToCity().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });

            if (!isPostBack)
            {
                ViewBag.Units = new SelectList(Enumerable.Empty<SelectListItem>());
                ViewBag.RoomTypes = new SelectList(Enumerable.Empty<SelectListItem>());
            }
            else
            {
                ViewBag.Units = objBuss.GetUnitDetail(toCityID).Select(e => new SelectListItem() { Text = e.unitName, Value = e.UnitID.ToString() }); 
                ViewBag.RoomTypes = objBuss.GetRoomTypeDetails(unitID).Select(e => new SelectListItem() { Text = e.roomType, Value = e.RoomTypeID.ToString() });
            }
        }

        #endregion
        #endregion

        public ActionResult PackageDashboard()
        {
            return View();
        }

        #region
        public ActionResult ActivatePackage()
        {
            ViewBag.PackageList = objBuss.GetAllDeactivatedPackage().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ActivatePackage(ActivatePackage Act)
        {
            int packageID = Act.Packageid;
            Act.MappingDetailslist = objBuss.GetMappedPackageDetails(packageID);
            Act.Imagelist = objBuss.GetPackageImageAdmin(packageID).ToList();
            Act.AmountList = objBuss.GetPackageAmount(packageID, 0).ToList();
            Act.ItnaryList = objBuss.GetPackageItinery(packageID).ToList();
            Act.Po = true;
            ViewBag.PackageList = objBuss.GetAllDeactivatedPackage().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            return View(Act);
        }

        public string ActivatePackageFinaly(int Pid)
        {
            Messg mgs = objBuss.ActivateDeactivatePackage(Pid);

            return mgs.msg;             
        }
        #endregion

        public JsonResult BindDactivDDlpack()
        {
            PackageEntry pi = new PackageEntry();

            IEnumerable<SelectListItem> obj = objBuss.GetAllDeactivatedPackage().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            return Json(obj,JsonRequestBehavior.AllowGet);
        }

        public ActionResult PackageContact()
        {
            PackageContact pc = new PackageContact();
            pc.ContactsofPackages = objBuss.GetPackageContact(0).ToList();
            ViewBag.PackageList = objBuss.GetPackageAdmin().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            return View(pc);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageContact(PackageContact pmod)
        {
            if (ModelState.IsValid)
            {
                int a = objBuss.InsertUpdatePackageContact(pmod);
                if (a > 0)
                {
                    ViewBag.msg = "Package Contact Added Successfully !";
                    ModelState.Clear();
                    pmod.ContactsofPackages = objBuss.GetPackageContact(pmod.PackageID).ToList();
                    pmod.address = "";
                    pmod.contactName = "";
                    pmod.email = "";
                    pmod.mobileNo = "";
                    pmod.nodalOfficer = "";
                    pmod.PackageID = 0;
                    pmod.phoneNo = "";
                    
                }
                else
                {
                    ViewBag.msg = "Some Thing Went Wrong, Could Not Add Package Contact !";
                }
                //objBusinessClass.GetPackageContactList(Id);
            }
            ViewBag.PackageList = objBuss.GetPackageAdmin().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            return View(pmod);
        }

        public ActionResult GetContactDetails(int PacKID)
        {
            PackageContact pc = new PackageContact();
            pc.PackageID = PacKID;
            pc.ContactsofPackages = objBuss.GetPackageContact(PacKID).ToList();
            return PartialView("_GetPackageContact", pc.ContactsofPackages);
        }

        [HttpGet]
        public ActionResult InclusionExclusion()
        {
            IncExc pc = new IncExc();
            pc.IncExcList = objBuss.GetPackageIncExc(0).ToList();
            ViewBag.PackageList = objBuss.GetPackageAdmin().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            return View(pc);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
      public ActionResult InclusionExclusion(IncExc model)
      {
          if (ModelState.IsValid)
          {
              int r = objBuss.InsertUpdatePackageINCEXC(model);
              if (r > 0)
              {
                  ModelState.Clear();
                  model.PackageID = 0;
                  model.Ins_Type = "";
                  model.Ins_Description="";
              }
              model.IncExcList = objBuss.GetPackageIncExc(0).ToList();         
              
          }
          ViewBag.PackageList = objBuss.GetPackageAdmin().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
          return View(model);
      }

        public ActionResult getInclusionExclusion( int PackId)
        {
            IncExc pc = new IncExc();
            pc.IncExcList = objBuss.GetPackageIncExc(PackId).ToList();           
            return View("_getInclusionExclusion",pc.IncExcList);
        }

        public ActionResult EditSpecilaPackageFair()
        {
            return View();
        }
    }
}
