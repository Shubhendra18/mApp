﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Controllers
{
    public class New_BookingController : Controller
    {
        //
        // GET: /New_Booking/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult User()
        {
            return View();
        }

    }
}
