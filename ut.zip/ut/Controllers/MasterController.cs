﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SRVTextToImage;
using UP_TourismBooking.Models;

namespace UP_TourismBooking.Controllers
{
    public class MasterController : Controller
    {
        #region declarations
        BusinessClass objBusinessClass = new BusinessClass();
        #endregion

        #region Method - get states
        [HttpGet]
        public JsonResult GetStates(int countryID)
        {         
            //for state pass 2 as masterID
             IEnumerable<SelectListItem>  obj = objBusinessClass.GetStateList(countryID).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method - get cities
        [HttpGet]
        public JsonResult GetCities(int stateID)
        {
            //for state pass 3 as masterID
            IEnumerable<SelectListItem> obj = objBusinessClass.GetCityList(stateID).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method - get tour types
        [HttpGet]
        public IEnumerable<SelectListItem> GetAllTourTypes()
        {
            //for tour types pass 7 as masterID
            IEnumerable<SelectListItem> obj = objBusinessClass.GetAllTourTypes().Select(e => new SelectListItem() { Text = e.TourType, Value = e.TourName.ToString() });
            return obj;
        }
        #endregion
        
        #region Method - get Room Types
        [HttpGet]
        public JsonResult GetRoomType(int unitID)
        {
            //for state pass 3 as masterID
            IEnumerable<SelectListItem> obj = objBusinessClass.GetRoomType(unitID).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method-getallcity
        public JsonResult GetAllDestinations()
        {
            //for AllDestinations pass 4 as masterID
            IEnumerable<SelectListItem> obj = objBusinessClass.GetallDestination().Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        public FileResult GetCaptchaimage()
        {
            CaptchaRandomImage ci = new CaptchaRandomImage();
            this.Session["capimagetext"] = ci.GetRandomString(5).ToUpper();
            ci.GenerateImage(this.Session["capimagetext"].ToString(), 150, 40, Color.Black, Color.White);
            MemoryStream stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            return new FileStreamResult(stream, "image/png");

        }

        public FileResult GetCaptchaimageReg()
        {
            CaptchaRandomImage ci = new CaptchaRandomImage();
            this.Session["capimagetextReg"] = ci.GetRandomString(5).ToUpper();
            ci.GenerateImage(this.Session["capimagetextReg"].ToString(), 150, 40, Color.Black, Color.White);
            MemoryStream stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            return new FileStreamResult(stream, "image/png");

        }


        public FileResult GetCaptchaimageForgot()
        {
            CaptchaRandomImage ci = new CaptchaRandomImage();
            this.Session["capimagetextForgot"] = ci.GetRandomString(5).ToUpper();
            ci.GenerateImage(this.Session["capimagetextForgot"].ToString(), 150, 40, Color.Black, Color.White);
            MemoryStream stream = new MemoryStream();
            ci.Image.Save(stream, ImageFormat.Png);
            stream.Seek(0, SeekOrigin.Begin);
            return new FileStreamResult(stream, "image/png");

        }

    }
}
