﻿using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Collections.Generic;
using UP_TourismBooking.Models;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;
using System.Data;
using System;
using System.Xml.Linq;

namespace UP_TourismBooking.Controllers
{
    [AuthorizeHQ]
    public class AdminEntryController : Controller
    {
        //
        // GET: /AdminEntry/
        BusinessClass obj = new BusinessClass();
        Common objcom = new Common();

        #region Get Package Category

        [HttpGet]
        public ActionResult GetPackageCategory()
        {
            PackageCategory model = new PackageCategory();
            try
            {
                ViewBag.CategoryList = obj.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                return PartialView("AddPackageAdmin");
            }
            catch
            {
                return RedirectToAction("Error", "Admin");
            }
        }
        #endregion

        #region Add Package
        [HttpGet]
        public ActionResult AddPackage()
        {
            PackageEntry model = new PackageEntry();

            ViewBag.CategoryList = obj.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.TourTypes = new MasterController().GetAllTourTypes();

            //GetPackageCategory();
            model.ImagePathUrl = "images.jpg";
            model.ImagePathSmallUrl = "images.jpg";
            return View(model);
        }
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddPackage(PackageEntry model)
        {
           
            try
            {
                ViewBag.CategoryList = obj.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.TourTypes = new MasterController().GetAllTourTypes();

                if (model.PackageId > 0)
                {
                    ModelState["ImagePath"].Errors.Clear();
                    ModelState["ImagePathSmall"].Errors.Clear();
                }
                if (ModelState.IsValid)
                {
                    var check = obj.CheckPackageExist(model);
                    if (check.Count() == 0 || model.PackageId != 0)
                    {
                        if (model.ImagePath != null)
                        {
                            string ext = Path.GetExtension(model.ImagePath.FileName);
                            string filename = Path.GetFileName(DateTime.Now.Ticks + ext);
                            string Vm = objcom.ValidateImageExt(model.ImagePath, filename);
                            if (Vm != "Valid")
                            {
                                GetPackageCategory();
                                model.ImagePathUrl = "images.jpg";
                                model.ImagePathSmallUrl = "images.jpg";
                                TempData["msg"] = Vm;
                                return View(model);
                            }
                            else
                            {
                                model.ImagePathUrl = Path.Combine("~/Uploads/PackageTours/Images/Banner/", filename);
                                var docPath = Path.Combine(Server.MapPath("~/Uploads/PackageTours/Images/Banner/"), filename);
                                model.ImagePath.SaveAs(docPath);
                            }
                        }

                        if (model.ImagePathSmall != null)
                        {
                            
                            string ext = Path.GetExtension(model.ImagePathSmall.FileName);
                            string filename = Path.GetFileName(DateTime.Now.Ticks + ext);
                            string Cvm = objcom.ValidateImageWithCusomSize(model.ImagePathSmall, 300);
                            if (Cvm != "Valid")
                            {
                                GetPackageCategory();
                                model.ImagePathUrl = "images.jpg";
                                model.ImagePathSmallUrl = "images.jpg";
                                TempData["msgA"] = Cvm;
                                return View(model);
                            }
                            else
                            {
                                model.ImagePathSmallUrl = Path.Combine("~/Uploads/PackageTours/Images/Thumbnail/", filename);
                                var docPath = Path.Combine(Server.MapPath("~/Uploads/PackageTours/Images/Thumbnail/"), filename);
                                model.ImagePathSmall.SaveAs(docPath);
                            }
                        }

                        int result = obj.InsertPackage(model);
                        if (result > 0)
                        {
                            TempData["msgA"] = (model.PackageId > 0) ? Message.Update : Message.Add;
                            return RedirectToAction("GetPackage");
                        }
                        else
                        {
                            ViewBag.Message = (model.PackageId > 0) ? Message.ErrorUpdate : Message.ErrorAdd;
                        }
                        ModelState.Clear();

                    }
                    else
                    {
                        ViewBag.Message = "Record already Exist";
                    }
                }
                //else
                //{
                //    //ViewBag.Message = "Check Your Inputs";
                //}
                ViewBag.CategoryList = obj.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.TourTypes = new MasterController().GetAllTourTypes();

            }
            catch
            {
                //return JavaScript("window.location='" + Url.Action("Error", "AdminEntry") + "'");   
                ViewBag.CategoryList = obj.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.TourTypes = new MasterController().GetAllTourTypes();

            }
            return View(model);
        }

        public ActionResult GetPackage()
        {
            ViewBag.CategoryList = obj.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            return View(obj.GetPackageAdmin());
        }
        #endregion

        #region Delete Package
        public ActionResult DeletePackage(int packageId)
        {
            try
            {
                int result = obj.DeletePackageAdmin(packageId);               
                if (result > 0)
                {
                    ViewBag.Message = Message.Delete;
                }
                else
                {
                    ViewBag.Message = Message.ErrorDelete;
                }
                return PartialView("_GetPackageList", obj.GetPackageAdmin());
            }
            catch (Exception Ex)
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }
        }
        #endregion

        #region Edit Package 
        public ActionResult EditPackage(int packageId)
        {
            PackageEntry model = new PackageEntry();
            try
            {
                GetPackageCategory();
                ViewBag.TourTypes = new MasterController().GetAllTourTypes();
                model = obj.GetPackageDetailById(packageId);
            }
            catch 
            { }
            return View("AddPackage", model);
        }
        #endregion

        #region Get Package

        public JsonResult GetPackageById(int id)
        {
            ModelState.Clear();
            var data = obj.GetPackageAdminById(id);
            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult GetPackageList()
        {
            PackageEntry model = new PackageEntry();
            try
            {
                ViewBag.PackageList = obj.GetPackageAdmin().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
                return PartialView("AddPackageImageAdmin");
            }
            catch
            {
                return RedirectToAction("Error", "Admin");
            }
        }
        #endregion

        #region Add Package Image
        public ActionResult AddPackageImage()
        {
            PackageImageEntry model = new PackageImageEntry();
            GetPackageList();
            model.IPackageImage = obj.GetPackageImageAdmin(0).ToList();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddPackageImage(PackageImageEntry model)
        {
            try
            {
                  if (model.imagePath != null)
                    {
                        string ext = Path.GetExtension(model.imagePath.FileName);
                        string FileName = "Bann" + Path.GetFileName(DateTime.Now.Ticks + ext);
                        string Cmsg = objcom.ValidateImageExt(model.imagePath, FileName);
                        if (Cmsg != "Valid")
                        {
                            ViewBag.Show = Cmsg;
                            GetPackageList();
                            model.IPackageImage = obj.GetPackageImageAdmin(0).ToList();
                            return View(model);
                        }
                        else
                        {
                            model.imagePathUrl = Path.Combine("~/Uploads/PackageTours/Images/", FileName);
                            var docPath = Path.Combine(Server.MapPath("~/Uploads/PackageTours/Images/"), FileName);
                            model.imagePath.SaveAs(docPath);
                        }
                    }
                    if (model.imagePathSmall != null)
                    {
                        string ext = Path.GetExtension(model.imagePathSmall.FileName);
                        string FileName = "Small"+Path.GetFileName(DateTime.Now.Ticks + ext);
                        string Cmsg = objcom.ValidateImageWithCusomSize(model.imagePath,200);
                        if (Cmsg != "Valid")
                        {
                            ViewBag.Show = Cmsg;
                            GetPackageList();
                            model.IPackageImage = obj.GetPackageImageAdmin(0).ToList();
                            return View(model);
                        }
                        else
                        {
                            model.imagePathSmallUrl = Path.Combine("~/Uploads/PackageTours/Images/", FileName);
                            var docPath = Path.Combine(Server.MapPath("~/Uploads/PackageTours/Images/"), FileName);
                            model.imagePathSmall.SaveAs(docPath);
                        }
                    }
                    int result = obj.InsertPackageImage(model);
                    if (result > 0)
                    {
                        ViewBag.Show = (model.packageImageId > 0) ? Message.Update : Message.Update;

                    }
                    else
                    {
                        ViewBag.Show = (model.packageImageId > 0) ? Message.ErrorUpdate : Message.ErrorAdd;
                    }
                        ModelState.Clear();
                    
            }
            catch
            {
                ViewBag.Show = "Oops Something went wrong Please Try Again..";
            }
            GetPackageList();
            model.IPackageImage = obj.GetPackageImageAdmin(0).ToList();
            return View(model);
           
        }

        #endregion

         #region Get Package Image
        [HttpGet]
        public ActionResult GetPackageImageList()
        {
            PackageImageEntry model = new PackageImageEntry();
            try
            {
                model.IPackageImage = obj.GetPackageImageAdmin(0).ToList();
            }
            catch { }
            return PartialView("_GetPackageImageList", model.IPackageImage);
        }
    #endregion

        #region Edit Package Image
        public ActionResult EditPackageImage(int PackageImageId)
        {
            PackageImageEntry model = new PackageImageEntry();
            try
            {
                GetPackageList();
                model = obj.GetPackageImageById(PackageImageId);
                model.IPackageImage = obj.GetPackageImageAdmin(0).ToList();
            }
            catch
            { }
            return View("AddPackageImage", model);
        }
        #endregion

        #region Delete Package Image Detail 
        public ActionResult DeletePackageImage(int packageImageId)
        {
            try
            {
                int result = obj.DeletePackageImageDetail(packageImageId);
                if (result > 0)
                {
                    ViewBag.Message = Message.Delete;
                }
                else
                {
                    ViewBag.Message = Message.ErrorDelete;
                }
                return RedirectToAction("AddPackageImage");
            }
            catch
            {
                ViewBag.Show = "Oops Something went wrong Please Try Again..";
                return RedirectToAction("AddPackageImage");
            }
        }
        #endregion

        #region InsertUpdate Package Itinery

        public ActionResult AddPackageItinery()
        {
            PackageItinery model = new PackageItinery();
            GetPackageList();
            GetCity();
            GetDestination();
            model.IPackageItinery = obj.GetPackageItinery(0);
            return View(model);
        
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddPackageItinery(PackageItinery model)
        {
            int pid = model.PackageId;
            int? displ = model.DesplayOrder;
            try
            {
               
                int result=0;
                var Check = obj.CheckPackageItineryExist(model);
                if (model.ItineryID == 0)
                {
                    if (Check.Count() == 0)
                    {
                        var Display = obj.checkDisplayOrder(model);
                        if (Display.Count() == 0)
                        {
                            result = obj.InsertUpdatePackageItinery(model);
                            if (result > 0)
                            {
                                ViewBag.Show = (model.ItineryID > 0) ? Message.Update : Message.Add;
                                ModelState.Clear();
                                model.DesplayOrder = displ+1;
                            }
                            else
                            {
                                ViewBag.Show = (model.ItineryID > 0) ? Message.ErrorUpdate : Message.Add;
                            }
                        }
                        else
                        {
                            ViewBag.Show = "Display Order already Exist for this Package!";
                        }
                    }
                    else
                    {
                        ViewBag.Show = "Record already Exist!";
                    }
                   
                }
                if (model.ItineryID != 0)
                {
                    if (Check.Count() < 2)
                    {
                        var Display = obj.checkDisplayOrder(model);
                        if (Display.Count() < 2)
                        {
                            result = obj.InsertUpdatePackageItinery(model);
                            if (result > 0)
                            {
                                ViewBag.Show = (model.ItineryID > 0) ? Message.Update : Message.Add;
                                ModelState.Clear();
                                model.DesplayOrder = 0;
                                model.ItineryID = 0;
                                model.Particulars = "";

                            }
                            else
                            {
                                ViewBag.Show = (model.ItineryID > 0) ? Message.ErrorUpdate : Message.Add;
                            }
                        }
                        else
                        {
                            ViewBag.Show = "Display Order already Exist for this Package!";
                        }
                    }
                    else
                    {
                        ViewBag.Show = "Record already Exist!";
                    }
                    
                }
                
               
            }
            catch 
            {
                ViewBag.Show = "Oops something went wrong!";
            }
           // PackageItinery model = new PackageItinery();
            GetPackageList();
            GetCity();
            GetDestination();
            model.IPackageItinery = obj.GetPackageItinery(pid);
            model.DestinationID = "";
            model.DestinationName = "";
            model.OriginID = "";
            model.OriginID = "";
            model.Day = 0;
            model.Dep_Arr = "";
            return View(model);
            //return View("AddPackageItinery");
        }
        #endregion

        #region Getcity
        
        [HttpGet]
        public ActionResult GetCity()
        {
            try
            {
                ViewBag.CityList = obj.GetCityList().Select(e => new SelectListItem(){ Text = e.cityName, Value = e.cityID.ToString() });
                return View();

            }
            catch (Exception Ex)
            {
                return RedirectToAction("Error", "Admin");
            }
        }

        [HttpGet]
        public ActionResult GetDestination()
        {
            try
            {
                ViewBag.DestinationList = obj.GetCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                return View();

            }
            catch (Exception Ex)
            {
                return RedirectToAction("Error", "Admin");
            }
        }
        #endregion

        #region Get Package Itinery

        public ActionResult GetPackageItineryDetail(int PackageId)
        {
            PackageItinery model = new PackageItinery();
            try
            {
                model.IPackageItinery = obj.GetPackageItinery(PackageId);
            }
            catch
            { }
            return PartialView("_GetPackageItineryDetail", model.IPackageItinery);
           
        }
        #endregion       

        #region Delete Package Itinery
        public ActionResult DeletePackageItinery(int ItineryId)
        {
            try
            {
                int result = obj.DeletePackageItinery(ItineryId);
                if (result > 0)
                {
                    ViewBag.Message = Message.Delete;
                }
                else
                {
                    ViewBag.Message = Message.ErrorDelete; 
                }
                return RedirectToAction("AddPackageItinery");
            }
            catch
            {
                return JavaScript("window.location = '" + Url.Action("Error", "Admin") + "'");
            }

        }
        #endregion

        #region Edit Package Itinery
        public ActionResult EditPackageItinery(int itineryId)
        {
            PackageItinery model = new PackageItinery();
            try
            {
                GetCity();
                GetDestination();
                GetPackageList();
                model = obj.GetPackageItineryById(itineryId);
                model.IPackageItinery = obj.GetPackageItinery(0);
            }
            catch
            { 
            }
            return View("AddPackageItinery",model);
        }
        #endregion

        #region Add Package Amount
        public ActionResult AddPackageAmount()
        {
            PackageAmount model = new PackageAmount();
            GetPackageList();
            GetSeason();
            return View(model);
        
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddPackageAmount(PackageAmount model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int result = obj.AddPackageAmount(model);
                    if (result > 0)
                    {
                        TempData["Msg"] = (model.packageAmountID > 0) ? Message.Update : Message.Add;
                        GetPackageList();
                        GetSeason();
                        return RedirectToAction("AddPackageAmount");
                    }
                    else
                    {
                        TempData["Msg"] = (model.packageAmountID > 0) ? Message.ErrorUpdate : Message.ErrorAdd;
                        GetPackageList();
                        GetSeason();
                        return View(model);
                    }
                }
            }
            catch
            {
                
            }
            return View(model);
        }
        #endregion

        #region Get Season
        [HttpGet]
        public ActionResult GetSeason()
        {
            PackageSeason model = new PackageSeason();
            try
            {
                ViewBag.SeasonList = obj.GetSeasonBy().Select(e => new SelectListItem() { Text = e.SeasonName, Value = e.SeasonID.ToString() });
                return View("AddPackageAmount");
            }
            catch
            {
                return RedirectToAction("Error", "Admin");
            }
        }
        #endregion

        #region Method- Get Person
        public JsonResult GetPerson(string Tour)
        {

            List<SelectListItem> objPerson = new List<SelectListItem>();
            
            if (Tour == "City" || Tour == "PACK")
            {              
              for (int i = 1; i < 7; i++)
                {
                    SelectListItem Temp = new SelectListItem();
                    Temp.Text = i.ToString();
                    Temp.Value = i.ToString();
                    objPerson.Add(Temp);
                  
                }
             
            }
            if (Tour == "ACBUS")
            {
                SelectListItem Temp = new SelectListItem();
                Temp.Text = "1";
                Temp.Value = "1";               
                objPerson.Add(Temp);
            }
            return Json(objPerson, JsonRequestBehavior.AllowGet);
        }
        #endregion

        public ActionResult GetPackageAmount( int PackageId)
        {
             int packageimgId=0;
             List<PackageAmount> PA = obj.GetPackageAmount(PackageId, packageimgId).ToList();
             return PartialView("_GetPackageAmount", PA);
        }

        public string DeletePackageAmount(int PackgeAmountId)
        {
            int a =obj.DeletePackageAmount(PackgeAmountId);
            if (a > 0)
            {
                return "Record Deleted Sucessfully.";
            }
            else
            {
                return "Failed to  Delete Record.";
            }
           
        }

        public ActionResult EditAmount(int PackgeAmountId)
        {
            int PackageId = 0;
        PackageAmount PA = obj.GetPackageAmount(PackageId, PackgeAmountId).FirstOrDefault();
            GetPackageList();
            GetSeason();
            return PartialView("_EditPackageAmount", PA);
        }

        public ActionResult FilterPackageList(string PackageCatId, string PackageName)
        {
            int catid = 0;
            int.TryParse(PackageCatId, out catid);
            IEnumerable<PackageEntry> model = obj.GetPackageByCatIdAndname(catid, PackageName);
            return PartialView("_GetPackageList",model);
        }

        /*---------------------Special Deals for packages--------------------*/

        #region display package deals and special prices
        [HttpGet]
        public ActionResult PackageSpecialPriceDeals()
        {
            PackageSpecialPriceDeals model = new PackageSpecialPriceDeals();
            try
            {
                SetSpecialPackageData();
                model.lstPackageSpecialDeals = obj.GetSpecialDeals(2);
            }
            catch (Exception ex)
            {
                // ExceptionHandler.LogException("AdminEntry", "PackageSpecialPriceDeals-HttpGet", ex.Message);                
            }
            return View(model);
        } 
        #endregion


        #region display package deals and special prices
        [HttpPost]
        public ActionResult PackageSpecialPriceDeals(PackageSpecialPriceDeals model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int result = obj.InsertSpecialDeals(model);
                    if (result > 0)
                    {
                        TempData["message"] = "Deal saved successfully!";
                        return RedirectToAction("PackageSpecialPriceDeals", "AdminEntry");
                    }
                    else
                    {
                        ViewBag.Message = "Deal not saved!";
                    }
                }

                ViewBag.Packages = obj.GetPackageAdmin().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
                model.lstPackageSpecialDeals = obj.GetSpecialDeals(2);


            }
            catch (Exception ex)
            {
                // ExceptionHandler.LogException("AdminEntry", "PackageSpecialPriceDeals-HttpGet", ex.Message);                
            }
            return View(model);
        }
        #endregion


        private void SetSpecialPackageData()
        {
            ViewBag.Packages = obj.GetPackageAdmin().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageId.ToString() });
            ViewBag.NoOfTourists = new List<SelectListItem>() {
                                            new SelectListItem { Text="2", Value = "2"}, 
                                            new SelectListItem { Text="3", Value = "3"},
                                            new SelectListItem { Text="4", Value = "4"},
                                            new SelectListItem { Text="5", Value = "5"},
                                            new SelectListItem { Text="6", Value = "6"}};

            ViewBag.Nationality = new List<SelectListItem>() {
                                            new SelectListItem { Text="Indian", Value = "true"}, 
                                            new SelectListItem { Text="Foreigner", Value = "false"},
                                           };
        }

        /*-------------------End Special Deals for packages-------------------*/

        /*---------------------Special Deals for units--------------------*/

        #region display unit deals and special prices
        [HttpGet]
        public ActionResult UnitSpecialPriceDeals()
        {
            UnitSpecialPriceDeals model = new UnitSpecialPriceDeals();
            try
            {
                SetSpecialUnitDealData(0);
               // model.lstPackageSpecialDeals = obj.GetSpecialDeals(2);
            }
            catch (Exception ex)
            {
                // ExceptionHandler.LogException("AdminEntry", "PackageSpecialPriceDeals-HttpGet", ex.Message);                
            }
            return View(model);
        }
        #endregion


        #region save unit deals and special prices
        [HttpPost]
        public ActionResult UnitSpecialPriceDeals(UnitSpecialPriceDeals model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string roomXml = "<Deals>";

                    foreach (var item in model.roomType)
                    {
                        int totalDays = Convert.ToDateTime(model.dealToDate).Subtract(Convert.ToDateTime(model.dealToDate)).Days + 1;
                        DateTime bookingDate;
                        for (int i = 0; i < totalDays; i++)
                        {
                             bookingDate = Convert .ToDateTime(model.dealFromDate).AddDays(i);

                             roomXml += "<DealDetails>";
                             roomXml += "<roomID>" + item.ToString() + "</roomID>";
                             roomXml += "<dealDate>" + bookingDate.ToString("yyyy/MM/dd") + "</dealDate>";
                             roomXml += "</DealDetails>";
                        }
                    }
                    
                            
                    //foreach (var room in item.lstRoomNoDetail)
                    //{
                    //    if (checkedRooms.Contains(Convert.ToString(room.RoomNoId)))
                    //    {
                    //        strXML += "<RoomList>";
                    //        strXML += "<RequestId>" + item.requestID + "</RequestId>";
                    //        strXML += "<bookingDate>" + bookingDate.ToString("yyyy/MM/dd") + "</bookingDate>";
                    //        strXML += "<RoomNoId>" + room.RoomNoId + "</RoomNoId>";
                    //        strXML += "<extrabed>" + item.extrabed + "</extrabed>";
                    //        strXML += "</RoomList>";
                    //        //matchedRooms[count++] = Convert.ToString(room.RoomNoId);
                    //        if (i == 0)
                    //        {
                    //            matchedRooms.Add(Convert.ToString(room.RoomNoId));
                    //        }
                    //        _currSelectedRoom++;
                    //    }
                    //}

                    //var lst = model.roomType.Split(','); 
                    //var ProgXml = new XElement("Deals", from unl in lstUnlockAccounts
                    //                                    select new XElement("DealDetails",
                    //                                                        new XElement("Email", unl.email),
                    //                                                        new XElement("RoleID", unl.roleID)));

                    //int result = obj.InsertUnitSpecialDeals(model);
                    //if (result > 0)
                    //{
                    //    TempData["message"] = "Deal saved successfully!";
                    //    return RedirectToAction("UnitSpecialPriceDeals", "AdminEntry");
                    //}
                    //else
                    //{
                    //    ViewBag.Message = "Deal not saved!";
                    //}
                }

                SetSpecialUnitDealData(model.unitID);
              //  model.lstPackageSpecialDeals = obj.GetSpecialDeals(2);
            }
            catch (Exception ex)
            {
                // ExceptionHandler.LogException("AdminEntry", "PackageSpecialPriceDeals-HttpGet", ex.Message);                
            }
            return View(model);
        }
        #endregion


        private void SetSpecialUnitDealData(Int64 unitID)
        {
            if (unitID == 0)
            {
                ViewBag.RoomType = obj.GetUnitRoomType(unitID).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
            }
            else
            {
                ViewBag.RoomType = Enumerable.Empty<SelectListItem>();
            }
            ViewBag.Units = obj.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
        }

        /*-------------------End Special Deals for packages-------------------*/


        [HttpGet]
        public ActionResult addtaxidetails()
        {
            ViewBag.Uptours = obj.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            ViewBag.submit = "Save";
            taxidetails tdtls = new taxidetails();
            tdtls.maxcapacity = 0;
            if (TempData["msg"] != null)
            {
                ViewBag.msg = TempData["msg"];
            }
            return View(tdtls);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult addtaxidetails(taxidetails td, long? hddnId)
        {
            ViewBag.Uptours = obj.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            td.userid = SessionManager.UserID;
            if (hddnId != null)
            {
                ModelState.Clear();
                td = obj.GetTaxiDetailsByBusTaxiId(hddnId);
                ViewBag.submit = "Update";
                return View(td);
            }
            if (td.BusTaxiId == 0)
            {
                ModelState.Remove("BusTaxiId");
            }
            ViewBag.submit = "Save";
            if (ModelState.IsValid)
            {
                if (td.BusTaxiId != 0)
                {
                    int i = obj.UpdateTaxiDetails(td, this.Request.UserHostAddress);
                    if (i > 0)
                    {
                        ViewBag.msg = "Record updated successfully.";
                        ModelState.Clear();
                    }
                    else
                    {
                        ViewBag.msg = "Record Not Updated.Try Again.";
                    }
                }
                else
                {
                    int i = obj.InsertTaxiDetails(td, this.Request.UserHostAddress);
                    if (i > 0)
                    {
                        ViewBag.msg = "Record saved successfully.";
                        ModelState.Clear();
                    }
                    else
                    {
                        ViewBag.msg = "Record Not Saved.Try Again.";
                    }
                }
                
            }
            return View();
        }

        public ActionResult taxidetailslist()
        {
            List<taxidetails> tlist = obj.GetTaxiDetails();
            return View(tlist);
        }

        public ActionResult Deletetaxidetails(long? btid)
        {
            int i = obj.DeleteTaxiDetails(btid);
            if (i > 0)
            {
                TempData["msg"] = "Record Deleted Successfully.";
            }
            else
            {
                TempData["msg"] = "Record Not Deleted. Try Again.";
            }
            return RedirectToAction("addtaxidetails");
        }

        [HttpGet]
        public ActionResult addtariffdetails(long? tariffid)
        {
            ViewBag.Uptours = obj.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            tariffdetails td = new tariffdetails();
            ViewBag.submit = "Save";
            if (tariffid != null)
            {
                td = obj.GetTariffDetailsByTariffId(tariffid);
                ViewBag.taxiid = td.BusTaxiId;
                ViewBag.submit = "Update";
            }
            return View(td);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult addtariffdetails(tariffdetails td)
        {
            ViewBag.taxiid = td.BusTaxiId;
            td.UserId = SessionManager.UserID;
            if (td.TariffId == 0)
            {
                ModelState.Remove("TariffId");
            }
            ViewBag.Uptours = obj.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            if (ModelState.IsValid)
            {
                if (td.TariffId != 0)
                {
                    int i = obj.UpdateTariffDetails(td, this.Request.UserHostAddress);
                    if (i > 0)
                    {
                        TempData["msg"] = "Record updated successfully.";
                        ModelState.Clear();
                        return RedirectToAction("tariffdetailslist");
                    }
                    else
                    {
                        ViewBag.msg = "Record Not Updated.Try Again.";
                    }
                }
                else
                {
                    int i = obj.InsertTariffDetails(td, this.Request.UserHostAddress);
                    if (i > 0)
                    {
                        TempData["msg"] = "Record saved successfully.";
                        ModelState.Clear();
                        return RedirectToAction("tariffdetailslist");
                    }
                    else
                    {
                        ViewBag.msg = "Record Not Saved.Try Again.";
                    }
                }
            }
            return View();
        }

        public ActionResult Deletetariffdetails(long? tdid)
        {
            int i = obj.DeleteTariffDetails(tdid);
            if (i > 0)
            {
                TempData["msg"] = "Record Deleted Successfully.";
            }
            else
            {
                TempData["msg"] = "Record Not Deleted. Try Again.";
            }
            return RedirectToAction("tariffdetailslist");
        }


        public ActionResult tariffdetailslist()
        {
            List<tariffdetails> tdlist = obj.GetTariffDetails();
            if (TempData["msg"] != null)
            {
                ViewBag.msg = TempData["msg"];
            }
            return View(tdlist);
        }

        public JsonResult getTaxiByUptours(int? UptoursId)
        {
            List<SelectListItem> sli = obj.GetBusTaxiNameList("T", UptoursId).Select(e => new SelectListItem() { Text = e.BusTaxiName, Value = e.BusTaxiId.ToString() }).ToList();
            return Json(sli);
        }

        [HttpGet]
        public ActionResult addtaxiimagedetails()
        {
            ViewBag.submit = "Save";
            ViewBag.Uptours = obj.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            if (TempData["msg"] != null)
            {
                ViewBag.msg = TempData["msg"];
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult addtaxiimagedetails(taxiimagedetails tid, long? hddnId)
        {
            tid.UserId = SessionManager.UserID;
            ViewBag.submit = "Save";
            ViewBag.Uptours = obj.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            if (hddnId != null)
            {
                ModelState.Clear();
                tid = obj.GetTaxiImageDetailsByBusTaxiImgId(hddnId);
                ViewBag.taxiid = tid.BusTaxiId;
                ViewBag.submit = "Update";
                return View(tid);
            }
            if (tid.BusTaxiImgId == 0)
            {
                ModelState.Remove("BusTaxiImgId");
            }
            ViewBag.Uptours = obj.getpackagecategoryuptoursname().Select(e => new SelectListItem() { Text = e.UptoursName, Value = e.packageCategoryID.ToString() });
            if (ModelState.IsValid)
            {
                if (tid.BusTaxiImgId != 0)
                {
                    int i = obj.UpdateTaxiImageDetails(tid, this.Request.UserHostAddress);
                    if (i > 0)
                    {
                        ViewBag.msg = "Record updated successfully.";
                        ModelState.Clear();
                    }
                    else
                    {
                        ViewBag.msg = "Record Not Updated.Try Again.";
                    }
                }
                else
                {
                    int i = obj.InsertTaxiImageDetails(tid, this.Request.UserHostAddress);
                    if (i > 0)
                    {
                        ViewBag.msg = "Record saved successfully.";
                        ModelState.Clear();
                    }
                    else
                    {
                        ViewBag.msg = "Record Not Saved.Try Again.";
                    }
                }
            }
            return View();
        }


        public ActionResult taxiimagelist()
        {
            List<taxiimagedetails> tlist = obj.GetTaxiImageDetails();
            return View(tlist);
        }

        public ActionResult Deletetaxiimagedetails(long? btiid)
        {
            int i = obj.DeleteTaxiImageDetails(btiid);
            if (i > 0)
            {
                TempData["msg"] = "Record Deleted Successfully.";
            }
            else
            {
                TempData["msg"] = "Record Not Deleted. Try Again.";
            }
            return RedirectToAction("addtaxiimagedetails");
        }

        public JsonResult UploadFile(HttpPostedFileBase imgfile)
        {
            string msg = objcom.ValidateImageExt(imgfile, "");
            string path = "";
            string filename = "";
            if (msg == "Valid")
            {
                filename = Path.GetFileName(imgfile.FileName);
                string completepath = Path.Combine(Server.MapPath("~/Uploads/"), filename);
                imgfile.SaveAs(completepath);
                path = "~/Uploads/" + filename;
            }
            List<string> plist = new List<string> { msg, path,filename };
            return Json(plist);
        }

        public ActionResult taxiDashboard()
        {
            return View();
        }
    }   

}
