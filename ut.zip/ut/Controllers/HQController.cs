﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Mvc;
using UP_TourismBooking.Models.ProcessClasses;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models;
using System.Globalization;
using System.Data;
using System.IO;
using System.Xml.Linq;
using System.Configuration;
using System.Web.Hosting;
using System.Web.Helpers;
using CrystalDecisions.CrystalReports.Engine;
using CrystalDecisions.Shared;

namespace UP_TourismBooking.Controllers
{
    [AuthorizeHQ]
    public class HQController : Controller
    {
        #region Declarations
        BusinessClass objBusinessClass = new BusinessClass();
        Common objCommonClass = new Common();
        #endregion

        /*---------------------Unit wise booking count-------------*/

        #region Display unit wise booking count
        public ActionResult UnitWiseBookingCount()
        {
            HQBookingStatusReport model = new HQBookingStatusReport();

            model.bookingDate = DateTime.Now;
            model.bookingList = objBusinessClass.GetUnitWiseBookingStatus(model);

            return View(model);
        }
        #endregion

        #region bind booking count grid
        public ActionResult GetUnitWiseCount(string dtBooking, Int64 unitId)
        {
            HQBookingStatusReport model = new HQBookingStatusReport();
            try
            {
                model.bookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.unitID = unitId;
                model.bookingList = objBusinessClass.GetUnitWiseBookingStatus(model);
            }
            catch
            {

            }
            return PartialView("_UnitWiseBookingCountGrid", model.bookingList);
        }
        #endregion

        #region bind room type wise booking count
        public ActionResult GetRoomTypeWiseStatus(string dtBooking, Int64 unitID, DateTime dtBookingTime)
        {
            HQBookingStatusReport model = new HQBookingStatusReport();
            try
            {
                if (dtBookingTime.Hour < 12)
                {
                    model.bookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                }
                else
                {
                    model.bookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.unitID = unitID;

                model.roomList = objBusinessClass.GetRoomTypeWiseBookingStatus(model);
            }
            catch
            {
            }
            return PartialView("_UnitWiseBookingCountDetails", model.roomList);
        }
        #endregion

        #region export unit wise booking count excel
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UnitWiseBookingCount(HQBookingStatusReport obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            var dtresult = objBusinessClass.GetUnitWiseBookingStatus(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.unitName, Total_Rooms_Booked = e.totalCount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/UnitWiseBookingCount.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookingList = dtresult;
            return View(obj);
        }
        #endregion

        /*---------------------End Unit wise booking count-------------*/

        /* ---------------------------Revenue Report---------------------------------*/

        #region Display Booking Revenue
        [HttpGet]
        public ActionResult BookingRevenue()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway", Value = "1"},
                                            new SelectListItem { Text="Total Revenue Including Checkout (Gateway).", Value = "2"}, 
                                            new SelectListItem { Text="Online net Revenue after Checkout.", Value = "5"}, 
                                            new SelectListItem { Text="Revenue for Online Booked by Unit Level.", Value = "3"}, 
                                            new SelectListItem { Text="Total Revenue after Checkout booking by Unit.", Value = "4"},                                             
                                            new SelectListItem { Text="Revenue against cancelled booking.", Value = "6"},
                                            new SelectListItem { Text="Conciled Revenue Report", Value = "7"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding Booking Revenue grid
        public ActionResult GetBookingRevenue(int RevenueType, Int64? unitID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBookingRevenue(RevenueType, unitID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            if (RevenueType == 7) {
                return PartialView("_ConcilationRevenue", model.lstBookingRevenue);
            }
            return PartialView("_BookingRevenue", model.lstBookingRevenue);
        }
        #endregion

        #region Print Hotel Booking Revenue Detail by Syed
        public ActionResult PrintHotelBookingRevenueDetail(int RevenueType, Int64? unitID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBookingRevenue(RevenueType, unitID, _fromDate, _toDate).ToList().OrderBy(m => m.reqYear).ThenBy(m => m.reqMonth).ThenBy(m => m.unitID).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export Booking Revenue list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingRevenue(BookingRevenue model)
        {
            string excel = Request.Form["excel"];
            string pdf = Request.Form["pdf"];
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetBookingRevenue(model.RevenueType, model.unitID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                if (excel == "Export To Excel") {
                    gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Month = e.reqMonth, Year = e.reqYear, Total = e.Total }).ToList();
                    gv.DataBind();

                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingRevenueList.xls");
                    Response.ContentType = "application/ms-excel";
                    Response.Charset = "";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gv.RenderControl(htw);
                    Response.Output.Write(sw.ToString());
                    Response.Flush();
                    Response.End();
                }
                else if(pdf=="Export To PDF"){ //Create a dummy GridView\
                    var resultSet = objBusinessClass.GetBookingRevenueReportForPDF(model.RevenueType, model.unitID, _fromDate, _toDate).ToList().OrderBy(m => m.reqYear).ThenBy(m => m.reqMonth).ToList(); ;
                    string setPdfName = "";
                    TempData["Msg"] = "";
                    ReportDocument rd = new ReportDocument();
                    rd.Load(Path.Combine(Server.MapPath("~/Reports"), "revenueReportConcile.rpt"));
                    rd.SetDataSource(resultSet);
                    setPdfName = "RevenueReport";
                    String dtnow = (DateTime.Now.Date).ToString("dd-MM-yyyy");
                    string flName = "~/ReadWriteData/PDF/" + setPdfName + ".pdf";
                    rd.SetParameterValue("FilterTextDurstion", _fromDate.ToString("dd/MM/yyyy")+" - "+_toDate.ToString("dd/MM/yyyy"));
                    rd.ExportOptions.ExportFormatType = ExportFormatType.PortableDocFormat;
                    rd.ExportOptions.ExportDestinationType = ExportDestinationType.DiskFile;
                    rd.ExportOptions.DestinationOptions = new DiskFileDestinationOptions();
                    ((DiskFileDestinationOptions)rd.ExportOptions.DestinationOptions).DiskFileName = Server.MapPath(flName);
                    rd.Export();
                    FileInfo fileInfo = new FileInfo(Server.MapPath(flName));
                    rd.Close();
                    rd.Dispose();
                    {
                        Response.ClearContent();
                        Response.ClearHeaders();
                        Response.ContentType = "application/pdf";
                        Response.AppendHeader("Content-Disposition", "attachment; filename=" + dtnow + "" + setPdfName + ".pdf");
                        Response.AppendHeader("Content-Length", fileInfo.Length.ToString());
                        Response.WriteFile(flName);
                        Response.Flush();
                        Response.Close();
                        if (System.IO.File.Exists(Server.MapPath("~/ReadWriteData/PDF/" + setPdfName + ".pdf")))
                        {
                            System.IO.File.Delete(Server.MapPath("~/ReadWriteData/PDF/" + setPdfName + ".pdf"));
                        }
                    }
                }
                else{
                }
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Online Revenue for Hotel booking", Value = "1"},
                                            new SelectListItem { Text="Total Revenue for Online Hotel booking", Value = "2"}, 
                                            new SelectListItem { Text="Total Revenue for Unit Hotel booking", Value = "3"}, 
                                            new SelectListItem { Text="Total Revenue for Checked Out Unit Hotel booking", Value = "4"}, 
                                            new SelectListItem { Text="Total Revenue for Checked Out Online Hotel booking", Value = "5"}, 
                                            new SelectListItem { Text="Total Revenue by Cancelled Booking  ", Value = "6"}};
            return View(model);
        }

        #endregion

 

        /* ---------------------------End Booking Revenue---------------------------------*/

        /* ---------------------------Package Revenue Report---------------------------------*/

        #region Display Booking Revenue
        [HttpGet]
        public ActionResult PackageRevenue()
        {
            try
            {
                ViewBag.PackageList = objBusinessClass.GetPackagesList().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageID.ToString() });
                ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway Package booking", Value = "1"},
                                            new SelectListItem { Text="Total Revenue Including Checkout (Gateway). Package booking", Value = "2"}, 
                                            new SelectListItem { Text="Revenue through ARC, CRS, UPTOURS Package booking", Value = "3"}, 
                                            //new SelectListItem { Text="Total Revenue for Checked Out Unit Hotel booking", Value = "4"},  
                                            new SelectListItem { Text="Revenue against cancelled Package Booking  ", Value = "5"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding Booking Revenue grid
        public ActionResult GetPackageRevenue(int RevenueType, int? PackageCategoryID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetPackageRevenueReport(RevenueType, PackageCategoryID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_PackageRevenue", model.lstBookingRevenue);
        }
        #endregion


        #region Print Package Revenue Detail by Syed
        public ActionResult PrintPackageRevenueDetail(int RevenueType, int? PackageCategoryID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetPackageRevenueReport(RevenueType, PackageCategoryID, _fromDate, _toDate).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export Booking Revenue list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageRevenue(BookingRevenue model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetPackageRevenueReport(model.RevenueType, model.PackageCategoryID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Package_Name = e.PackageName, Month = e.reqMonth, Year = e.reqYear, Total = e.Total }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/PackageRevenueList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.PackageList = objBusinessClass.GetPackagesList().Select(e => new SelectListItem() { Text = e.PackageName, Value = e.PackageID.ToString() });
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Online Revenue for Package booking", Value = "1"},
                                            new SelectListItem { Text="Total Revenue for Online Package booking", Value = "2"}, 
                                            new SelectListItem { Text="Total Revenue for Unit Package booking", Value = "3"}, 
                                            //new SelectListItem { Text="Total Revenue for Checked Out Unit Hotel booking", Value = "4"},  
                                            new SelectListItem { Text="Total Revenue by Cancelled Package Booking  ", Value = "5"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Package Booking Revenue---------------------------------*/

        /* ---------------------------Special Package Revenue Report---------------------------------*/

        #region Display Booking Revenue
        [HttpGet]
        public ActionResult SpecialPackageRevenue()
        {
            try
            {
                ViewBag.PackageList = new List<SelectListItem>() {new SelectListItem { Text="AC Bus Tour Booking", Value = "ACBUS"},
                                            new SelectListItem { Text="One Day Tour Booking", Value = "CITY"}, 
                                            new SelectListItem { Text="Cycle Tour Booking", Value = "CYCLE"}, 
                                            new SelectListItem { Text="Tonga Booking", Value = "TONGA"},  
                                            new SelectListItem { Text="Heritage Walk Booking", Value = "WALK"}};
                ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway Special Package booking", Value = "1"}, 
                                            new SelectListItem { Text="Revenue for CRS, ARC, UPTOURS Special Package booking", Value = "2"},  
                                            new SelectListItem { Text="Revenue against cancelled Special Package Booking  ", Value = "3"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding Booking Revenue grid
        public ActionResult GetSpecialPackageRevenue(int RevenueType, string PackageName, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetSpecialPackageRevenueReport(RevenueType, PackageName, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_SpecialPackageRevenue", model.lstBookingRevenue);
        }
        #endregion

        #region Print Special Package Revenue Detail
        public ActionResult PrintSpecialPackageRevenueDetail(int RevenueType, string PackageName, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetSpecialPackageRevenueReport(RevenueType, PackageName, _fromDate, _toDate).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion


        #region export Booking Revenue list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SpecialPackageRevenue(BookingRevenue model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetSpecialPackageRevenueReport(model.RevenueType, model.packageType, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Package_Name = e.PackageName, Month = e.reqMonth, Year = e.reqYear, Total = e.Total }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/SpecialPackageRevenueList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.PackageList = new List<SelectListItem>() {new SelectListItem { Text="AC Bus Tour Booking", Value = "ACBUS"},
                                            new SelectListItem { Text="One Day Tour Booking", Value = "CITY"}, 
                                            new SelectListItem { Text="Cycle Tour Booking", Value = "CYCLE"}, 
                                            new SelectListItem { Text="Tonga Booking", Value = "TONGA"},  
                                            new SelectListItem { Text="Heritage Walk Booking", Value = "WALK"}};
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Online Revenue for Special Package booking", Value = "1"}, 
                                            new SelectListItem { Text="Revenue for Unit Special Package booking", Value = "2"},  
                                            new SelectListItem { Text="Total Revenue by Cancelled Special Package Booking  ", Value = "3"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Package Booking Revenue---------------------------------*/

        /*----------------------------Staff Booking------------------------------------------------*/
        #region To add customer registration details

        #region customer registration
        [HttpGet]
        public ActionResult CustomerRegistration()
        {
            try
            {
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
                ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
                ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
                CustomerRegistration model = new CustomerRegistration();
                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CustomerRegistration(CustomerRegistration model)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                #region Validate Uploaded Doc
                if (model.staffIdDoc != null)
                {
                    string ext = Path.GetExtension(model.staffIdDoc.FileName);
                    string filename = Path.GetFileName("StaffDoc_" + DateTime.Now.Ticks + ext);
                    string res = objCommonClass.ValidateImageWithCusomSize(model.staffIdDoc, 400);
                    if (res.Trim() != "Valid")
                    {
                        _isValid = false;
                        _msg = res;
                    }
                    else
                    {
                        model.staffIdDocPath = Path.Combine("~/Content/writereaddata/PrivilegeCard/", filename);
                        var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/PrivilegeCard/"), filename);
                        model.staffIdDoc.SaveAs(docPath);
                    }
                }

                #endregion
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                ModelState["checkInTime"].Errors.Clear();
                ModelState["checkOutTime"].Errors.Clear();
                ModelState["staffGrade"].Errors.Clear();
                ModelState["staffFacility"].Errors.Clear();
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.pincode))
                {
                    ModelState["pincode"].Errors.Clear();
                }
                //if (model.customerType == 'B')
                //{
                //    ModelState["roomType"].Errors.Clear();
                //    if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                //    {
                //    }
                //    else
                //    {
                //        _isValid = false;
                //        _msg = "Provide Room Details ";
                //        ModelState.AddModelError("", "Provide Room Details ");
                //    }
                //}
                //else
                //{
                if (string.IsNullOrEmpty(Convert.ToString(model.roomType)))
                {
                    _isValid = false;
                    _msg = "Select Room!! ";
                    ModelState.AddModelError("", "Select Room!! ");
                }
                //if (model.customerType == 'S')
                //{
                model.isStaff = true;
                if (model.staffId == null)
                {
                    _isValid = false;
                    _msg = "Enter Staff Id!! ";
                    ModelState.AddModelError("", "Enter Staff Id!! ");
                }
                else if (model.staffIdDoc == null)
                {
                    _isValid = false;
                    _msg = "Upload Staff Identity!! ";
                    ModelState.AddModelError("", "Upload Staff Identity!! ");
                }
                else if (model.staffGrade == null || model.staffGrade == 0)
                {
                    _isValid = false;
                    _msg = "Select Staff Grade!! ";
                    ModelState.AddModelError("", "Select Staff Grade!! ");
                }
                else if (model.staffFacility == null || model.staffFacility == 0)
                {
                    _isValid = false;
                    _msg = "Select Staff Tariff!! ";
                    ModelState.AddModelError("", "Select Staff Tariff!! ");
                }
                //}
                //}
                if (ModelState.IsValid && _isValid == true)
                {
                    model.roleID = "HQ";
                    model.userIP = this.Request.UserHostAddress;
                    string isValid = IsDateValid(model);
                    if (string.IsNullOrEmpty(isValid))
                    {
                        if (model.staffIdDoc != null)
                        {
                            string ext = Path.GetExtension(model.staffIdDoc.FileName);
                            string filename = Path.GetFileName(DateTime.Now.Ticks + ext);

                            model.staffIdDocPath = Path.Combine("/Content/writereaddata/Documents", filename);
                            var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                            model.staffIdDoc.SaveAs(docPath);
                        }
                        else
                        {
                            model.staffIdDocPath = "";
                            model.staffId = "";
                            model.staffGrade = 0;
                            model.staffFacility = 0;
                        }

                        #region changes for bulk booking
                        bool _isExtraBedAvail = true, _chkRoomLimit = true, _isDataChecked = true;
                        int _totalExtraBedRequire = 0;
                        //if (model.customerType == 'B')
                        //{
                        //    int _extraBedBulk = 0, _singleBulk = 0, _doubleBulk = 0, _totalRooms = 0, _maxCapacity = 0, _maxAllowedGuest = 0, _singleNonOc = 0;
                        //    foreach (var item in model.lstBookedRoomDetail)
                        //    {
                        //        _singleBulk += item.singleRoom;
                        //        _doubleBulk += item.doubleRoom;
                        //        //_extraBedBulk = _extraBedBulk + (item.hasOccupancy == true ? 1 * (item.doubleRoom) : 0);
                        //        _extraBedBulk += item.extrabed;
                        //        _maxCapacity = _maxCapacity + (item.hasOccupancy == false ? (item.maxCapacity) * (item.singleRoom) : 0);
                        //        _singleNonOc = _singleNonOc + (item.hasOccupancy == false ? (item.singleRoom) : 0);
                        //        if (item.hasOccupancy)
                        //        {
                        //            if (item.extrabed > (item.doubleRoom * item.maxExtraBed))
                        //            {
                        //                _isDataChecked = false;
                        //                _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";
                        //                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                        //                break;
                        //            }
                        //            _maxAllowedGuest += ((item.singleRoom + (item.doubleRoom * 2)) + (item.doubleRoom * item.maxExtraBed));
                        //        }
                        //        else
                        //        {
                        //            if (item.extrabed > (item.singleRoom * item.maxExtraBed))
                        //            {
                        //                _isDataChecked = false;
                        //                _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";
                        //                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                        //                break;
                        //            }
                        //            _maxAllowedGuest += ((item.singleRoom * item.maxCapacity) + (item.singleRoom * item.maxExtraBed));
                        //        }
                        //    }
                        //    if (_isDataChecked == true)
                        //    {
                        //        _totalRooms = _singleBulk + _doubleBulk;
                        //        _totalExtraBedRequire = model.noOfGuests - ((_singleBulk - _singleNonOc) + (_doubleBulk * 2) + _maxCapacity);
                        //        //_maxAllowedGuest = _singleBulk + (_doubleBulk * 2) + _extraBedBulk + (_maxCapacity - _singleNonOc); ;

                        //        #region max capacity for bulk booking
                        //        if (_totalRooms > model.noOfGuests)
                        //        {
                        //            _chkRoomLimit = false;
                        //            _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                        //            ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                        //        }
                        //        else if (model.noOfGuests > _maxAllowedGuest)
                        //        {
                        //            _chkRoomLimit = false;
                        //            _msg = "No. of selected rooms is not sufficient!!";
                        //            ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                        //        }
                        //        else if (_extraBedBulk < _totalExtraBedRequire)
                        //        {
                        //            _isExtraBedAvail = false;
                        //            _msg = "No. of selected rooms is not sufficient!!";
                        //            ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                        //        }
                        //        model.noOfRooms = _totalRooms;
                        //    }
                        //        #endregion
                        //}
                        //else
                        //{
                        model.noOfRooms = model.singleRoom + model.doubleRoom;
                        if (model.hasOccupancy)
                        {
                            if (model.noOfRooms > model.noOfGuests)
                            {
                                _isDataChecked = false;
                                _msg = "Total No. of Single and Double rooms should be less than equal to No. of Guests!";
                                ModelState.AddModelError("", "Total No. of Single and Double rooms should be less than equal to No. of Guests!");
                            }
                            else if (model.extrabed > (model.doubleRoom * model.maxExtraBed))
                            {
                                _isDataChecked = false;
                                _msg = "No. of selected rooms is not sufficient!!";
                                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                            }
                            else if (((model.singleRoom + (model.doubleRoom * 2)) + model.extrabed) < model.noOfGuests)
                            {
                                _isDataChecked = false;
                                _msg = "No. of selected rooms is not sufficient!!";
                                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                            }
                        }
                        else
                        {
                            if (model.noOfRooms > model.noOfGuests)
                            {
                                _isDataChecked = false;
                                _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                                ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                            }
                            else if (model.extrabed > (model.singleRoom * model.maxExtraBed))
                            {
                                _isDataChecked = false;
                                _msg = "No. of selected rooms is not sufficient!!";
                                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                            }
                            else if (((model.singleRoom * model.maxCapacity) + model.extrabed) < model.noOfGuests)
                            {
                                _isDataChecked = false;
                                _msg = "No. of selected rooms is not sufficient!!";
                                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                            }
                        }

                        RoomDetail objRoomList = new RoomDetail();
                        IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
                        objRoomList.roomType = model.roomType;
                        objRoomList.roomTypeDisplay = model.roomTypeDisplay;
                        objRoomList.singleRoom = model.singleRoom;
                        objRoomList.doubleRoom = model.doubleRoom;
                        objRoomList.hasOccupancy = model.hasOccupancy;
                        objRoomList.Sno = lstBookedRoom.Count + 1;

                        objRoomList.extrabed = model.extrabed;
                        lstBookedRoom.Add(objRoomList);
                        model.lstBookedRoomDetail = lstBookedRoom;
                        //}
                        model.noOfRooms = model.singleRoom + model.doubleRoom;
                        int totalDays = model.checkOutDate.Subtract(model.checkInDate).Days;
                        bool _isRoomAvl = true;
                        int _noOfRooms = 0;
                        //decimal reqAdvAmt = GetRequiredAdvanceAmount(model);
                        //if (model.customerType == 'B' && (model.advanceAmount == null || model.advanceAmount <= 0 || (model.advanceAmount < reqAdvAmt)))
                        //{
                        //    _isDataChecked = false;
                        //    _msg = "Insufficient Advance Amount. Minimum Advance Amount " + reqAdvAmt;
                        //    ModelState.AddModelError("", "Insufficient Advance Amount. Minimum Advance Amount " + reqAdvAmt);
                        //}
                        foreach (var item in model.lstBookedRoomDetail)
                        {
                            int _extrabedAdd = 0;
                            RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                            objRoom.roomTypeId = item.roomType;
                            objRoom.unitId = model.unitID;
                            _noOfRooms = item.singleRoom + item.doubleRoom;

                            for (int i = 0; i < totalDays; i++)
                            {
                                objRoom.bookingDate = model.checkInDate.AddDays(i);
                                var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                {
                                    _isRoomAvl = false;
                                    _msg = "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                    ModelState.AddModelError("", "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy"));
                                    break;
                                }
                            }
                            if (_isRoomAvl == false)
                            {
                                break;
                            }
                        }

                        var roomXml = new XElement("booking",
                                     from room in model.lstBookedRoomDetail
                                     select new XElement("customer",
                                                    new XElement("Sno", room.Sno),
                                                    new XElement("roomType", room.roomType),
                                                    new XElement("singleRoom", room.singleRoom),
                                                    new XElement("doubleRoom", room.doubleRoom),
                                                    new XElement("extrabed", room.extrabed)
                                                ));
                        model.bookingXML = roomXml.ToString();
                        #endregion
                        if (_isRoomAvl == true && _isDataChecked == true && _isExtraBedAvail == true && _chkRoomLimit == true)
                        {
                            model.userID = model.unitID;
                            model.bookingFor = "UNIT";
                            model.bookingBy = "HQ";
                            var user = objBusinessClass.InsertCustomerBooking(model);


                            if (user != null)
                            {
                                //#region send mail and sms
                                //IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(user.docketNo);

                                //foreach (var lst in IEContactDetails)
                                //{
                                //    if (lst.sendTo == "CUSTOMER")
                                //    {
                                //        SendUnitRoomMail(user.docketNo, "CUSTOMER", lst.Email);
                                //        SendUnitBookSms(user.docketNo, lst.MobileNo, "CUSTOMER");
                                //    }
                                //    else if (lst.sendTo == "UNIT")
                                //    {
                                //        SendUnitRoomMail(user.docketNo, "UNIT", lst.Email);
                                //        SendUnitBookSms(user.docketNo, lst.MobileNo, "UNIT");
                                //    }
                                //}
                                //#endregion
                                SessionManager.UnitID = model.unitID;
                                SessionManager.DocketNo = user.docketNo;

                                return RedirectToAction("RegistrationConfirmation");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Room Not Bookeed!");
                                _msg = "Room Not Bookeed!";
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", isValid);
                        _msg = isValid;
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Error in CustomerRegistration!");
                    _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
                }
            }
            catch
            {
                ModelState.AddModelError("", "Error in CustomerRegistration!");
                _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
            }
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
            ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
            //ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        #region customer registration Confirmation
        [HttpGet]
        public ActionResult RegistrationConfirmation()
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();
                model.unitID = SessionManager.UnitID;
                model.docketNo = SessionManager.DocketNo;

                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        #endregion
        #endregion
        /*--------------------------------------------------------End Staff Booking--------------------------------------*/

        /*--------------------Vacancy Status---------------------------*/

        #region display vacancy status
        [HttpGet]
        public ActionResult VacancyStatus()
        {
            UPTourVacancyStatus model = new UPTourVacancyStatus();
            try
            {
                model.dtBooking = DateTime.Now;
                model.BookingInTime = DateTime.Now;
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region bind vacancy status grid
        public ActionResult GetVacancyStatus(string dtBooking, Int64 UnitId, DateTime dtBookingTime)
        {
            UPTourVacancyStatus model = new UPTourVacancyStatus();
            try
            {
                if (dtBookingTime.Hour < 12)
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                }
                else
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.unitID = UnitId;
                model.bookingStatusList = objBusinessClass.GetUPTourVacancyStatus(model);
            }
            catch
            {

            }
            return PartialView("_VacancyStatusGrid", model.bookingStatusList);
        }
        #endregion

        #region export vacancy status excel
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult VacancyStatus(UnitVacancyStatus obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            UnitVacancyStatus objR = new UnitVacancyStatus();
            objR.BookingInTime = obj.BookingInTime;
            if (objR.BookingInTime.Hour < 12)
            {
                objR.dtBooking = obj.dtBooking.AddDays(-1);
            }
            else
            {
                objR.dtBooking = obj.dtBooking;
            }
            objR.unitID = obj.unitID;
            objR.bookingStatusList = obj.bookingStatusList;

            var dtresult = objBusinessClass.GetUnitVacancyStatus(objR);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Room_Type = e.roomType, Total_Rooms = e.totalRoom, Online_Booking = e.onlineBooked, Package_Tours_Booking = e.packageBooked, UP_Tours_Booking = e.upTourBooked, ARC_Booking = e.arcBooked, CRS_Booking = e.crsBooked, Counter_Booking = e.counterBooked, Out_of_Service = e.OutS, Hold = e.blocked, Vacant = e.vacant }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/VacancyStatus.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookingStatusList = dtresult;
            return View(obj);
        }
        #endregion

        /*--------------------End Vacancy Status---------------------------*/

        /*--------------------------------------------------------Common Method------------------------------------------*/
        #region methods to validate
        public string IsDateValid(CustomerRegistration model)
        {
            string returnMsg = string.Empty;
            DateTime currDate = DateTime.Now.AddDays(-1);
            DateTime maxCheckInDate = currDate.AddDays(178);
            DateTime maxCheckOutDate = currDate.AddDays(179);
            if (model.checkInDate.Date < currDate.Date)
            {
                returnMsg = "Check In Date could not be past date";
            }
            else if (model.checkOutDate < currDate)
            {
                returnMsg = "Check Out Date could not be past date";
            }
            else if (model.checkOutDate < model.checkInDate)
            {
                returnMsg = "Check Out Date should be greater than Check In Date";
            }
            else if (model.checkInDate > maxCheckInDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            else if (model.checkOutDate > maxCheckOutDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            return returnMsg;
        }
        #endregion

        #region Method to  bind staff tariff
        public JsonResult GetStaffTariff(int gradeId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffGrade().Where(a => a.gradeId == gradeId).Select(a => a.facilityId).FirstOrDefault();
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method to  bind staff Room
        public JsonResult GetStaffRoom(int facilityId, Int64 unitId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffRoom(unitId, facilityId).FirstOrDefault().roomTypeId;
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region to get room occupancy details
        [HttpGet]
        public ActionResult GetRoomOccupancy(int roomId, int UnitID)
        {
            CustomerRegistration model = new CustomerRegistration();
            try
            {
                UnitRooms objRoom = objBusinessClass.GetRoomInfo(roomId, UnitID);
                if (objRoom != null)
                {
                    model.maxCapacity = objRoom.maxCapacity;
                    model.hasOccupancy = objRoom.hasOccupancy;
                    model.maxExtraBed = objRoom.maxExtraBed;
                }
            }
            catch
            {

            }
            return PartialView("_RoomOccupancy", model);
        }
        #endregion

        #region get vacancy status details
        public ActionResult GetRoomVacancyDetail(string dtBooking, string roomtypeid, string unitId)
        {
            VacancyStatusDetail model = new VacancyStatusDetail();
            try
            {
                model.RoomTypeId = Convert.ToInt64(roomtypeid);
                try
                {
                    model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.BookingDate = DateTime.Now;
                }

                //model.unitID = SessionManager.UnitID;
                model.unitID = Convert.ToInt64(unitId);
                model = objBusinessClass.GetVacancyStatusDetail(model);
            }
            catch
            {

            }
            return PartialView("_RoomVacancy", model);
        }
        #endregion

        #region get unit and Package  booked room Details for CRS
        [HttpGet]
        public ActionResult GetBookingDetail(string docketNo, int UnitId)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            string _msg = "";
            try
            {

                obj_BookingList = objBusinessClass.GetUnitPackageBookingDetailsForCRS(docketNo, UnitId);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.BookedRoomList = objBusinessClass.GetBookedRoomDetailsForCRS(docketNo, UnitId);
                    return PartialView("_BookingListDetails", obj_BookingDetail);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }
        #endregion
        /*---------------------------------------------------------End Common Method-----------------------------------------*/


        /* ---------------------------Booking Count Report---------------------------------*/

        #region Display Booking Count
        [HttpGet]
        public ActionResult BookingCount()
        {
            BookingCountReport model = new BookingCountReport();
            try
            {
                DateTime a = new DateTime(1900, 01, 01);
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.CountCategory = new List<SelectListItem>() {new SelectListItem { Text="All", Value = ""},
                                            new SelectListItem { Text="Online Booking", Value = "O"}, 
                                            new SelectListItem { Text="Counter Booking", Value = "C"}};
                model.lstBookingCount = objBusinessClass.GetUnitWiseCount(0, "", a).ToList();
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region binding Booking Count grid
        public ActionResult GetBookingCount(Int64? unitID, string countFor, string Fromdate)
        {
            BookingCountReport model = new BookingCountReport();
            DateTime _fromDate;
            try
            {
                _fromDate = DateTime.ParseExact(Fromdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }

            try
            {
                model.lstBookingCount = objBusinessClass.GetUnitWiseCount(unitID, countFor, _fromDate).ToList();
            }
            catch
            {

            }
            return PartialView("_BookingCount", model.lstBookingCount);
        }
        #endregion


        #region Print Hotel Booking Count
        public ActionResult PrintHotelBookingCount(Int64? unitID, string countFor, string Fromdate)
        {
            BookingCountReport model = new BookingCountReport();
            DateTime _fromDate;
            ViewBag.fromdate = string.IsNullOrEmpty(Fromdate) ? "-" : Fromdate;
            try
            {
                _fromDate = DateTime.ParseExact(Fromdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }

            try
            {
                model.lstBookingCount = objBusinessClass.GetUnitWiseCount(unitID, countFor, _fromDate).ToList();
                return View(model.lstBookingCount);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export Booking Count list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingCount(BookingCountReport model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate;

            _fromDate = model.Fromdate ?? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);


            var dtresult = objBusinessClass.GetUnitWiseCount(model.unitID, model.countFor, _fromDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Year = e.bookingYear, Month = e.bookingMonthName, Total_Booked = e.TotalBooked, Total_CheckIn = e.TotalCheckIn, Total_CheckOut = e.TotalCheckOut }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingCountList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingCount = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.CountCategory = new List<SelectListItem>() {new SelectListItem { Text="All", Value = ""},
                                            new SelectListItem { Text="Online Booking", Value = "O"}, 
                                            new SelectListItem { Text="Counter Booking", Value = "C"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Booking Count Report---------------------------------*/

        /*------------------Online Bus/Taxi Enquiries Report----------------*/

        #region display online bus taxi enquiry list
        [HttpGet]
        public ActionResult OnlineBusTaxiEnquiry()
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            try
            {
                ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.uptourId = 0;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBusTaxiEnquiryList(string dateFrom, string dateTo, string enquiryNo, int uptourId)
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.uptourId = uptourId;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineBusTaxiEnquiry", model.busTaxiEnquiryList);
        }
        #endregion

        #region Print Online Bus Enquiry Details
        public ActionResult PrintOnlineBusEnquiryDetails(string dateFrom, string dateTo, string enquiryNo, int? uptourId)
        {
            BusTaxiEnquiryReport model = new BusTaxiEnquiryReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                uptourId = uptourId ?? 0;
                model.uptourId = uptourId;
                model.busTaxiEnquiryList = objBusinessClass.GetBusTaxiEnquiryList(model);
                return View(model.busTaxiEnquiryList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export bus/ taxi enquiry list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineBusTaxiEnquiry(BusTaxiEnquiryReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);

            var dtresult = objBusinessClass.GetBusTaxiEnquiryList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Enquiry_Date = e.enquiryDate, Enquiry_Type = e.enquiryType, Pickup_Date = e.pickupDate.ToString("dd/MM/yyyy"), Name = e.name, Mobile_No = e.mobileNo, From = e.fromCityName, To = e.toCity, Status = e.bookingStatus, Booked_By = e.bookingBySlug }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineBusTaxiEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.busTaxiEnquiryList = dtresult;
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });

            return View(model);
        }
        #endregion

        #region get bus/ taxi enquiry details
        [HttpGet]
        public ActionResult GetBusTaxiEnquiryDetail(string enquireNo)
        {
            BusTaxiEnquiry model = new BusTaxiEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetTaxiBusEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineBusTaxiEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion


        /*-----------------End Online Bus/Taxi Enquiries Report-------------*/

        /*------------------Online Lawn Enquiries Report----------------*/

        #region display online lawn enquiry list
        [HttpGet]
        public ActionResult OnlineLawnEnquiry()
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.unitID = 0;
                model.enquiryType = "Lawn";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetLawnEnquiryList(string dateFrom, string dateTo, string enquiryNo, Int64 unitId)
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.unitID = unitId;
                model.enquiryType = "Lawn";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineLawnEnquiry", model.lawnEnquiryList);
        }
        #endregion

        #region Print Online Lawn Enquiry by Syed
        public ActionResult PrintOnlineLawnEnquiry(string dateFrom, string dateTo, long? unitID, string enquiryNo)
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.unitID = unitID;
                model.enquiryType = "Lawn";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);
                return View(model.lawnEnquiryList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export lawn enquiry list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineLawnEnquiry(LawnEnquiryReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);
            model.enquiryType = "Lawn";

            var dtresult = objBusinessClass.GetLawnBanquetEnquiryList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Name = e.name, Mobile_No = e.mobileNo, Enquiry_Type = e.enquiryType, Booking_Date = e.lawnBookingDate.ToString("dd/MM/yyyy"), Hotel = e.unitName, Function_Type = e.functionName, Enquiry_Date = e.enquiryDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineLawnEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.lawnEnquiryList = dtresult;
            ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });


            return View(model);
        }
        #endregion

        #region get lawn enquiry details
        [HttpGet]
        public ActionResult GetLawnEnquiryDetail(string enquireNo)
        {
            LawnEnquiry model = new LawnEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetLawnBanquetEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineLawnEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        /*-----------------End Online Bus/Taxi Enquiries Report-------------*/

        /*------------------Online Banquet Enquiries Report----------------*/

        #region display online banquet enquiry list
        [HttpGet]
        public ActionResult OnlineBanquetEnquiry()
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.unitID = 0;
                model.enquiryType = "Banquet";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBanquetEnquiryList(string dateFrom, string dateTo, string enquiryNo, Int64 unitId)
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.unitID = unitId;
                model.enquiryType = "Banquet";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineBanquetEnquiry", model.lawnEnquiryList);
        }
        #endregion

        #region Print Online Banquet Enquiry by Syed
        public ActionResult PrintOnlineBanquetEnquiry(string dateFrom, string dateTo, long? unitID, string enquiryNo)
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.unitID = unitID;
                model.enquiryType = "Banquet";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);
                return View(model.lawnEnquiryList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export banquet enquiry list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineBanquetEnquiry(LawnEnquiryReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);
            model.enquiryType = "Banquet";

            var dtresult = objBusinessClass.GetLawnBanquetEnquiryList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Name = e.name, Mobile_No = e.mobileNo, Enquiry_Type = e.enquiryType, Booking_Date = e.lawnBookingDate.ToString("dd/MM/yyyy"), Hotel = e.unitName, Function_Type = e.functionName, Enquiry_Date = e.enquiryDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineBanquetEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.lawnEnquiryList = dtresult;
            ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });


            return View(model);
        }
        #endregion

        #region get banquet enquiry details
        [HttpGet]
        public ActionResult GetBanquetEnquiryDetail(string enquireNo)
        {
            LawnEnquiry model = new LawnEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetLawnBanquetEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineBanquetEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        /*-----------------End Online Bus/Taxi Enquiries Report-------------*/

        /*------------------Online Auditorium Enquiries Report----------------*/

        #region display online auditorium enquiry list
        [HttpGet]
        public ActionResult OnlineAuditoriumEnquiry()
        {
            AuditoriumReport model = new AuditoriumReport();
            try
            {
                ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;

                model.auditoriumEnquiryList = objBusinessClass.GetAuditoriumEnquiryList(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetAuditoriumEnquiryList(string dateFrom, string dateTo, string enquiryNo)
        {
            AuditoriumReport model = new AuditoriumReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();

                model.auditoriumEnquiryList = objBusinessClass.GetAuditoriumEnquiryList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineAuditoriumEnquiry", model.auditoriumEnquiryList);
        }
        #endregion

        #region Print Online Auditorium Enquiry by Syed
        public ActionResult PrintOnlineAuditoriumEnquiry(string dateFrom, string dateTo, string enquiryNo)
        {
            AuditoriumReport model = new AuditoriumReport();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();

                model.auditoriumEnquiryList = objBusinessClass.GetAuditoriumEnquiryList(model);
                return View(model.auditoriumEnquiryList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export auditorium enquiry list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineAuditoriumEnquiry(AuditoriumReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);
            model.enquiryType = "Auditorium";

            var dtresult = objBusinessClass.GetAuditoriumEnquiryList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Name = e.name, Mobile_No = e.mobileNo, Enquiry_Type = e.enquiryType, Booking_Date = e.audibookingDate.ToString("dd/MM/yyyy"), Function_Type = e.functionName, Enquiry_Date = e.enquiryDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineAuditoriumEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.auditoriumEnquiryList = dtresult;

            return View(model);
        }
        #endregion

        #region get auditorium enquiry details
        [HttpGet]
        public ActionResult GetAuditoriumEnquiryDetail(string enquireNo)
        {
            AuditoriumEnquiry model = new AuditoriumEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetAuditoriumEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineAuditoriumEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        /*-----------------End Online Auditorium Enquiries Report-------------*/

        /*------------------Online Unit Booking Guest Wise Report----------------*/

        #region display online unit booking guest wise list
        [HttpGet]
        public ActionResult OnlineUnitBookingGuestWiseRpt()
        {
            ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetOnlineUnitBookingGuestWiseList(Int64 unitID, int month, int year)
        {
            OnlineUnitGuestWiseBookingReport model = new OnlineUnitGuestWiseBookingReport();
            try
            {
                model.month = month;
                model.year = year;
                model.unitID = unitID;

                model.bookingList = objBusinessClass.GetOnlineUnitBookingGuestWiseList(model);
            }
            catch
            {
            }
            return PartialView("_OnlineUnitBookingGuestWiseRpt", model.bookingList);
        }
        #endregion

        #region Print Online Hotel Bookings by Syed
        public ActionResult PrintOnlineHotelBookings(Int64? unitID, int month, int year, string monthname)
        {
            OnlineUnitGuestWiseBookingReport model = new OnlineUnitGuestWiseBookingReport();
            ViewBag.monthname = monthname;
            ViewBag.year = year;
            try
            {
                model.month = month;
                model.year = year;
                unitID = unitID ?? 0;
                model.unitID = unitID;

                model.bookingList = objBusinessClass.GetOnlineUnitBookingGuestWiseList(model);
                return View(model.bookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineUnitBookingGuestWiseRpt(OnlineUnitGuestWiseBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            var dtresult = objBusinessClass.GetOnlineUnitBookingGuestWiseList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Email = e.email, Mobile_No = e.mobileNo, Amount = e.amount, Docket_No = e.docketNo, Hotel = e.packageName, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Amount_Quoted = e.amount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineUnitBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.bookingList = dtresult;
            ViewBag.Units = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(model);
        }
        #endregion

        /*-----------------End Online Booking Report-------------*/

        /*------------------Unlock accounts----------------*/

        #region display locked accounts
        [HttpGet]
        public ActionResult UnlockAccount()
        {
            UnlockAccount model = new UnlockAccount();
            try
            {
                if (TempData["message"] != null && Convert.ToString(TempData["message"]) != "")
                {
                    ViewBag.Message = Convert.ToString(TempData["message"]);
                }
                ViewBag.Role = new List<SelectListItem>() {new SelectListItem { Text="All", Value = ""},
                                            new SelectListItem { Text="ARC", Value = "ARC"}, 
                                            new SelectListItem { Text="Units", Value = "UNT"}, 
                                            new SelectListItem { Text="UPTours", Value = "UPT"},
                                            new SelectListItem { Text="CRS", Value = "CRS"},
                                            new SelectListItem { Text="Customer", Value = "CST"}};

                model.lstLockedAccount = objBusinessClass.GetLockedAccounts(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind locked account grid
        public ActionResult GetLockedAccountList(UnlockAccount model)
        {
            try
            {
                model.lstLockedAccount = objBusinessClass.GetLockedAccounts(model);
            }
            catch
            {
            }
            return PartialView("_UnlockAccount", model);
        }
        #endregion

        #region unlock accounts
        [HttpPost]
        public ActionResult UnlockAccount(UnlockAccount model)
        {
            try
            {
                var lstUnlockAccounts = model.lstLockedAccount.Where(m => m.unlock);
                if (lstUnlockAccounts.Count() > 0)
                {
                    var ProgXml = new XElement("UnlockList", from unl in lstUnlockAccounts
                                                             select new XElement("AccountDetails",
                                                                            new XElement("Email", unl.email),
                                                                            new XElement("RoleID", unl.roleID)));
                    int result = objBusinessClass.UnlockAccounts(ProgXml.ToString());
                    if (result > 0)
                    {
                        TempData["message"] = "Account unlocked successfully!";
                        return RedirectToAction("UnlockAccount", "HQ");
                    }
                    else
                    {
                        ViewBag.Message = "Unable to unlock account!";
                    }
                }
                else
                {
                    ViewBag.Message = "Select atleast one account to unlock!";
                }

                ViewBag.Role = new List<SelectListItem>() {new SelectListItem { Text="All", Value = ""},
                                            new SelectListItem { Text="ARC", Value = "ARC"}, 
                                            new SelectListItem { Text="Customer", Value = "CST"}};


            }
            catch
            {
            }
            return View(model);
        }
        #endregion


        /*-----------------End Unlock accounts-------------*/

        /*------------------Online Packages Booking Guest Wise Report----------------*/

        #region display online package booking guest wise list
        [HttpGet]
        public ActionResult OnlinePackBookingGuestWiseRpt()
        {
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetOnlinePackBookingGuestWiseList(int month, int year)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetOnlinePackBookingGuestWiseList(model);
            }
            catch
            {
            }
            return PartialView("_OnlinePackBookingGuestWiseRpt", model.bookingList);
        }
        #endregion

        #region Print Online Package Bookings by Syed
        public ActionResult PrintOnlinePackageBookings(int month, int year, string monthname)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            ViewBag.year = year;
            ViewBag.monthname = monthname;
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetOnlinePackBookingGuestWiseList(model);
                return View(model.bookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlinePackBookingGuestWiseRpt(OnlinePackGuestWiseBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            var dtresult = objBusinessClass.GetOnlinePackBookingGuestWiseList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Email = e.email, Mobile_No = e.mobileNo, Amount = e.amount, Docket_No = e.docketNo, Booking_Type = e.bookingType, Package_Name = e.packageName, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Booking_Status = e.bookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlinePackageBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.bookingList = dtresult;
            return View(model);
        }
        #endregion

        /*-----------------End Online Booking Report-------------*/


        /*------------------Taxi/Bus Booking Guest Wise Report----------------*/

        #region display Taxi/Bus booking guest wise list
        [HttpGet]
        public ActionResult TaxiBusBookingGuestWiseRpt()
        {
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetTaxiBusBookingGuestWiseList(int month, int year)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetTaxiBusBookingGuestWiseList(model);
            }
            catch
            {
            }
            return PartialView("_TaxiBusBookingGuestWiseRpt", model.bookingList);
        }
        #endregion


        #region Print Bus Bookings by Syed
        public ActionResult PrintBusBookings(int month, int year, string monthname)
        {
            OnlinePackGuestWiseBookingReport model = new OnlinePackGuestWiseBookingReport();
            ViewBag.year = year;
            ViewBag.monthname = monthname;
            try
            {
                model.month = month;
                model.year = year;

                model.bookingList = objBusinessClass.GetTaxiBusBookingGuestWiseList(model);
                return View(model.bookingList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusBookingGuestWiseRpt(OnlinePackGuestWiseBookingReport model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            var dtresult = objBusinessClass.GetTaxiBusBookingGuestWiseList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Email = e.email, Mobile_No = e.mobileNo, Amount = e.amount, Docket_No = e.docketNo, Booking_Type = e.bookingType, Bank_Reference_No = e.bankReferenceNo, BookingDate = e.bookingDate, Booking_Status = e.bookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/TaxiBusBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.bookingList = dtresult;
            return View(model);
        }
        #endregion

        /*-----------------End Taxi/Bus Booking Guest Wise Report-------------*/


        /*-------------------------SPECIALpACKAGES rEPORT----------------------*/
        #region Special booking payment list by Roop Kanwar
        [HttpGet]
        public ActionResult SpecialBookingPaymentList()
        {
            return View();
        }

        public ActionResult GetSpecialBookingPaymentList(string dtBookingFrom, string dtBookingTo, string docket, string bookingType)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket.Trim();

                model.type = bookingType.Trim().TrimEnd().TrimStart();
                model.paymentList = objBusinessClass.GetUPTourSpecialBookingPayment(model);
            }
            catch
            {

            }
            return PartialView("_SpecialBookingPaymentListGrid", model.paymentList);
        }


        #region Print Special Packages Payment
        public ActionResult PrintSpecialPackagesPayment(string dtBookingDateFrom, string dtBookingDateTo, string docketNo, string type)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBookingDateFrom) ? "-" : dtBookingDateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dtBookingDateTo) ? "-" : dtBookingDateTo;
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();

                model.type = type.Trim().TrimEnd().TrimStart();
                model.paymentList = objBusinessClass.GetUPTourSpecialBookingPayment(model);
                return View(model.paymentList);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SpecialBookingPaymentList(UPTourTotalBooking model)
        {
            try
            {
                GridView gv = new GridView();

                ModelState.Clear();

                model.dtBookingDateFrom = model.dtBookingDateFrom ?? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBookingDateTo = model.dtBookingDateTo ?? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.type = model.type ?? string.Empty;
                var dtresult = objBusinessClass.GetUPTourSpecialBookingPayment(model).ToList();

                if (dtresult != null && dtresult.Count() > 0)
                {
                    gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Amount = e.Amount, Mode = e.Mode, Booking_Type = e.bookingType, Guest_Name = e.name, Mobile_No = e.mobileNo }).ToList();
                    gv.DataBind();

                    Response.ClearContent();
                    Response.Buffer = true;
                    Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/SpecialPackagePaymentList.xls");
                    Response.ContentType = "application/ms-excel";
                    Response.Charset = "";
                    StringWriter sw = new StringWriter();
                    HtmlTextWriter htw = new HtmlTextWriter(sw);
                    gv.RenderControl(htw);
                    Response.Output.Write(sw.ToString());
                    Response.Flush();
                    Response.End();
                }
                else
                {
                    ViewBag.Show = "No record found!";
                }
            }
            catch
            {
            }
            model.paymentList = objBusinessClass.GetUPTourSpecialBookingPayment(model);
            return View(model);
        }
        #endregion

        #region special package details
        [HttpGet]
        public ActionResult SpecialBookingDetail(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            string _msg = "";
            try
            {
                obj_BookingList = objBusinessClass.GetUPTourSpecialDetails(docketNo, 0);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            return PartialView("_SpecialBookedDetails", obj_BookingDetail);
        }
        #endregion

        /*-------------------------END SPECIALpACKAGES rEPORT----------------------*/

        #region View BusTaxi Revenue Report
        public ActionResult BusTaxiRevenue()
        {
            ViewBag.UnitList = objBusinessClass.GetUptoursList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway", Value = "1"},
                                            new SelectListItem { Text="Revenue Booking By Other.", Value = "2"},                                                                                      
                                            new SelectListItem { Text="Total Revenue ", Value = "3"}};
            return View();
        }

        [HttpGet]
        public ActionResult getBusTaxiRevenue(int? UptoursId, int RevenueType, string Fromdate, string ToDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(Fromdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(ToDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.Now;
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBuxTaxiBookingRevenueReport(RevenueType, UptoursId, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_BuxtaxiBookingList", model.lstBookingRevenue);

            //GetBuxTaxiBookingRevenueReport
        }

        #region Print Taxi Booking Revenue Details by Syed
        public ActionResult PrintTaxiBookingRevenueDetail(string fromDate, string toDate, int RevenueType, int? UptoursId)
        {
            BookingRevenue model = new BookingRevenue();
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.Now; ;
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBuxTaxiBookingRevenueReport(RevenueType, UptoursId, _fromDate, _toDate).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BusTaxiRevenue(BookingRevenue model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.Now;
            }
            var dtresult = objBusinessClass.GetBuxTaxiBookingRevenueReport(model.RevenueType, model.unitID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, UPTours_Name = e.UptoursName, Month = e.reqMonth, Year = e.reqYear, Total = e.Total }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BusTaxiBookingRevenueList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUptoursList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
            ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway", Value = "1"},
                                            new SelectListItem { Text="Revenue Booking By Other.", Value = "2"},                                                                                      
                                            new SelectListItem { Text="Total Revenue ", Value = "3"}};
            return View(model);
        }
        #endregion


        /* --------------------------Hold Relese Date wise---------------------------*/

        #region display block and release
        [HttpGet]
        public ActionResult BlockRelease()
        {
            HQBlockRelease model = new HQBlockRelease();
            model.dtBlocking = DateTime.Now;
            model.dtBlockingTo = DateTime.Now;

            ViewBag.Units = objBusinessClass.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View(model);
        }
        #endregion

        #region bind block and release grid as per the date selected
        public ActionResult GetBlockedRoomsByDate(string dtBlocking, int unit)
        {
            HQBlockRelease model = new HQBlockRelease();
            try
            {
                model.dtBlocking = DateTime.ParseExact(dtBlocking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.unitID = unit;
                model.blockReleaseList = objBusinessClass.GetHQBlockedRooms(model);
                model.blockLimit = model.blockReleaseList.Select(p => p.blockLimit).Sum();

            }
            catch
            {

            }
            return PartialView("_BlockRelease", model);
        }
        #endregion

        #region save blocked and released rooms
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BlockRelease(HQBlockRelease model)
        {
            try
            {
                ViewBag.Units = objBusinessClass.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                if (ModelState.IsValid)
                {
                    List<BlockReleaseDetail> lstBlock = model.blockReleaseList.Where(m => m.blocked > 0).ToList();
                    var totalBlock = lstBlock.Sum(m => m.blocked);

                    if (totalBlock > model.blockLimit)
                    {
                        ViewBag.Show = "Maximum block limit exceeded!";
                    }
                    else
                    {
                        string BlockList = "<BlockDetail>";
                        int gap = Convert.ToInt32((model.dtBlockingTo - model.dtBlocking).TotalDays);
                        while (gap >= 0)
                        {
                            for (var i = 0; i < lstBlock.Count(); i++)
                            {

                                BlockList += "<BlockList>";
                                BlockList += "<RoomID>" + lstBlock[i].roomID + "</RoomID>";
                                BlockList += "<BlockedRoom>" + lstBlock[i].blocked + "</BlockedRoom>";
                                BlockList += "<BlockedDate>" + model.dtBlocking.AddDays(gap).ToString("yyyy-MM-dd") + "</BlockedDate>";
                                BlockList += "</BlockList>";
                            }
                            gap = gap - 1;
                        }
                        BlockList += "</BlockDetail>";

                        int result = objBusinessClass.InserthqBlockDetail(model.unitID, BlockList, model.dtBlocking, model.dtBlockingTo);
                        if (result > 0)
                        {
                            ViewBag.Show = "Record Saved Successfully!";
                            ModelState.Clear();

                        }
                        else
                        {
                            ViewBag.Show = "Error in Process!";
                        }
                    }

                }
            }
            catch
            {

            }
            return View(model);
        }
        #endregion




        [HttpGet]
        public ActionResult ViewBlockRooms()
        {
            HQBlockRelease model = new HQBlockRelease();
            model.dtBlocking = DateTime.Now;
            model.dtBlockingTo = DateTime.Now.AddDays(1);
            model.unitID = 0;
            ViewBag.Units = objBusinessClass.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View(model);
        }

        public ActionResult GetBlockedRoomsDetails(string dtBlocking, string dtBlockingTo, int unit)
        {
            HQBlockRelease model = new HQBlockRelease();
            try
            {
                model.dtBlocking = DateTime.ParseExact(dtBlocking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBlockingTo = DateTime.ParseExact(dtBlockingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.unitID = unit;
                model.blockReleaseList = objBusinessClass.GetHQBlockedRoomsDetails(model);
                model.blockLimit = model.blockReleaseList.Select(p => p.blockLimit).Sum();

            }
            catch
            {

            }
            return PartialView("_BlockReleseList", model.blockReleaseList);
        }

        public string Relese(int BlockId)
        {
            string msg = "";
            int res = objBusinessClass.ReleseBlockedRoom(BlockId);
            if (res > 0)
            {
                msg = "Room Relesed Successfully";
            }
            else
            {
                msg = "Fail to relese room";
            }
            return msg;
        }

        /* ------------------------End Hold Relese Date wise---------------------------*/
        #region created by Syed
        [HttpGet]
        public ActionResult banquetLawnBookingRevenue()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                //ViewBag.RevenueCategory = new List<SelectListItem>() {new SelectListItem { Text="Revenue through Gateway", Value = "1"},
                //                            new SelectListItem { Text="Total Revenue Including Checkout (Gateway).", Value = "2"}, 
                //                            new SelectListItem { Text="Online net Revenue after Checkout.", Value = "5"}, 
                //                            new SelectListItem { Text="Revenue for Online Booked by Unit Level.", Value = "3"}, 
                //                            new SelectListItem { Text="Total Revenue after Checkout booking by Unit.", Value = "4"},                                             
                //                            new SelectListItem { Text="Revenue against cancelled booking.", Value = "6"}};
            }
            catch
            {
            }
            return View();
        }

        public ActionResult GetBanquetLawnBookingRevenue(Int64? unitID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.Now;
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBanquetLawnBookingRevenue(unitID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_BanquetLawnBookingRevenue", model.lstBookingRevenue);
        }


        #region Print Banquet Lawn Booking Revenue Report by Syed
        public ActionResult PrintBanquetLawnBookingRevenueReport(Int64? unitID, string fromDate, string toDate)
        {
            BookingRevenue model = new BookingRevenue();
            DateTime _fromDate, _toDate;
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.Now;
            }
            try
            {
                model.lstBookingRevenue = objBusinessClass.GetBanquetLawnBookingRevenue(unitID, _fromDate, _toDate).ToList();
                return View(model.lstBookingRevenue);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult banquetLawnBookingRevenue(BookingRevenue model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.Now;
            }
            var dtresult = objBusinessClass.GetBanquetLawnBookingRevenue(model.unitID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Month = e.paymentMonth, Year = e.paymentYear, Total = e.advanceamount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BanquetLawnBookingRevenueList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstBookingRevenue = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View(model);
        }

        [HttpGet]
        public ActionResult LawnBanquetBookingAllDetails()
        {
            ViewBag.UnitList = objBusinessClass.GetUnitListByOnlineHasLawnHasBanquet().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LawnBanquetBookingAlldetails(LawnBanquetBooking model)
        {
            ViewBag.UnitList = objBusinessClass.GetUnitListByOnlineHasLawnHasBanquet().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ModelState.Clear();

            GridView gv = new GridView();
            model.UnitId = SessionManager.UnitID;
            var dtresult = objBusinessClass.GetLawnBanquetBookingList(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1,Unit_Name=e.UnitName, Docket_No = e.docketNo, Booking_Date = e.ForDate.ToString("dd/MM/yyyy"), Booking_For = e.BookingFor, Name = e.name, Mobile_No = e.mobileNo, Email = e.email, Function_Name = e.functionName, Amount = e.advanceAmount, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/LawnBanquetBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            IEnumerable<LawnBanquetBooking> modellist = dtresult;
            return View(modellist);
        }


        public ActionResult GetLawnBanquetBookingList(string dateFrom, string dateTo, string docketNo, long? UnitId)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            List<LawnBanquetBooking> modellist = new List<LawnBanquetBooking>();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.UnitId = UnitId;
                modellist = objBusinessClass.GetLawnBanquetBookingList(model).ToList();
            }
            catch
            {
            }
            return PartialView("_LawnBanquetBookingList", modellist);
        }

        #region Print Lawn Banquet Booking by Syed
        public ActionResult PrintLawnBanquetBookingList(string dateFrom, string dateTo, string docketNo, long? UnitId)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            List<LawnBanquetBooking> modellist = new List<LawnBanquetBooking>();
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                UnitId = UnitId ?? 0;
                model.docketNo = docketNo.Trim();
                model.UnitId = UnitId;
                modellist = objBusinessClass.GetLawnBanquetBookingList(model).ToList();
                return View(modellist);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        public ActionResult GetLawnBanquetBookingDetail(string docketNo, long? UnitId)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            string _msg = "";
            try
            {
                model.docketNo = docketNo;
                model.UnitId = UnitId;

                model = objBusinessClass.GetLawnBanquetBookingList(model).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_LawnBanquetBookingListDetail", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion


        #region AllUnitBookingList Month Wise
        public IEnumerable<SelectListItem> YearList()
        {
            var EnqTypeL = new List<SelectListItem>();
            for (int i = 2015; i <= DateTime.Now.Year; i++)
            {
                SelectListItem Temp;
                Temp = new SelectListItem();
                Temp.Text = i.ToString();
                Temp.Value = i.ToString();
                EnqTypeL.Add(Temp);
            }
            return EnqTypeL;
        }

        public ActionResult AllUnitBookingCount()
        {
            ViewBag.Year = YearList();
            AllUnitBookingHQ model = new AllUnitBookingHQ();
            model.MonthId = DateTime.Now.Month;
            model.YearId = DateTime.Now.Year;
            model.HeaderList = objBusinessClass.AllUnitBookingCountReportHeaders();
            model.DtReport = Common.GetAllUnitBookingCountReport(model.MonthId, model.YearId);
            return View(model);

        }

        [HttpPost]
        public ActionResult AllUnitBookingCount(AllUnitBookingHQ model)
        {
            ViewBag.Year = YearList();
            model.HeaderList = objBusinessClass.AllUnitBookingCountReportHeaders();
            model.DtReport = Common.GetAllUnitBookingCountReport(model.MonthId, model.YearId);
            return View(model);

        }

        public ActionResult PrintAllUnitBookingCount(string Month, string Year)
        {
            AllUnitBookingHQ model = new AllUnitBookingHQ();
            int m, y;
            int.TryParse(Month, out m);
            int.TryParse(Year, out y);
            ViewBag.Month = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(m);
            ViewBag.Year = Year;
            model.MonthId = m;
            model.YearId = y;
            model.HeaderList = objBusinessClass.AllUnitBookingCountReportHeaders();
            model.DtReport = Common.GetAllUnitBookingCountReport(model.MonthId, model.YearId);
            return View(model);
        }


        public ActionResult VacancyStatusPOPUP(string date, string unitid)
        {
            UnitVacancyStatus model = new UnitVacancyStatus();
            Int64 a = 0;
            Int64.TryParse(unitid, out a);
            try
            {
                model.dtBooking = DateTime.ParseExact(date, "dd/MM/yyyy", null);
            }
            catch
            {
                model.dtBooking = DateTime.Now;
            }
            model.unitID = a;
            try
            {

                model.bookingStatusList = objBusinessClass.GetUnitVacancyStatus(model);
                model.UnitDetails = objBusinessClass.GetallUnit(Convert.ToInt32(model.unitID)).ToList();
            }
            catch
            {

            }
            return View(model);
        }

        #endregion
        #region display booking list
        [HttpGet]
        public ActionResult BookedList()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region bind booking grid
        public ActionResult GetBookedList(string dtBookingFrom, string dtBookingTo, string docket, Int64 UnitId)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket.Trim();
                model.unitID = UnitId;
                model.bookedList = objBusinessClass.GetUPTourBookingStatus(model);
            }
            catch
            {
            }
            return PartialView("_BookedListGrid", model.bookedList);
        }
        #endregion

        #region Print Booking Done by Syed
        public ActionResult PrintBookingDone(string dtBookingDateFrom, string dtBookingDateTo, string docketNo, Int64? unitID)
        {
            UPTourTotalBooking model = new UPTourTotalBooking();
            ViewBag.fromdate = string.IsNullOrEmpty(dtBookingDateFrom) ? "-" : dtBookingDateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dtBookingDateTo) ? "-" : dtBookingDateTo;
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                unitID = unitID ?? 0;
                model.docketNo = docketNo.Trim();
                model.unitID = unitID;
                model.bookedList = objBusinessClass.GetUPTourBookingStatus(model);
                return View(model.bookedList);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region export booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookedList(UPTourTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetUPTourBookingStatus(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Docket_No = e.docketNo, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Total_Room = e.totalRoom, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Booking_Status = e.BookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookedList = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

            return View(obj);
        }
        #endregion

        /* ---------------------------Cancellation List---------------------------------*/

        #region Display cancelled booking list
        [HttpGet]
        public ActionResult CancelledBooking()
        {
            try
            {
                ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region binding cancelled booking grid
        public ActionResult GetCancelledBookingList(string docketNo, int bookingType, Int64? unitID, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCRSCancelledBooking(docketNo.Trim(), bookingType, unitID, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_CancelledBookingGrid", model.lstCanceRequest);
        }
        #endregion

        #region Print Cancellations by Syed
        public ActionResult PrintCancellations(string docketNo, int bookingType, Int64? unitID, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            ViewBag.fromdate = string.IsNullOrEmpty(fromDate) ? "-" : fromDate;
            ViewBag.todate = string.IsNullOrEmpty(toDate) ? "-" : toDate;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCRSCancelledBooking(docketNo.Trim(), bookingType, unitID, _fromDate, _toDate).ToList();
                return View(model.lstCanceRequest);
            }
            catch
            {

            }
            return View();
        }
        #endregion

        #region export cancelled booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CancelledBooking(CRSBookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetCRSCancelledBooking(model.docketNo, model.bookingType, model.unitID, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, Hotel_Package_Name = e.packageName, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/CancelledBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            ViewBag.UnitList = objBusinessClass.GetUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            ViewBag.BookingCategory = new List<SelectListItem>() {new SelectListItem { Text="Package Tour Booking", Value = "1"},
                                            new SelectListItem { Text="Room Booking", Value = "2"}, new SelectListItem { Text="Special Package Tour Booking", Value = "3"}};
            return View(model);
        }

        #endregion

        /* ---------------------------End Cancellation List---------------------------------*/

        /* ---------------------------Daily Sale  Report---------------------------------*/

        public ActionResult ViewDailySaleReport()
        {
            return View();
        }

        public ActionResult GetDailySalereport(string date)
        {

            FillSaleReport model = new FillSaleReport();

            IFormatProvider dfor = new CultureInfo("en-GB").DateTimeFormat;

            DateTime dateto = DateTime.ParseExact(date, "dd/MM/yyyy", dfor);

            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            model.CurrentMonthYear = "From " + System.Environment.NewLine + "01/" + Convert.ToString(dateto.Month) + "/" + Convert.ToString(dateto.Year) + System.Environment.NewLine + " To " + System.Environment.NewLine + dateto.ToString("dd/MM/yyyy");
            model.TotalRevenueHQPreviousYear = dt.AddYears(-1).ToString("dd/MM/yyyy");

            model.DalySalelist = objBusinessClass.GetDalySaleReportforView(0, DateTime.Now, dateto, 2);

            model.DalySalelist.ToList().FirstOrDefault().CurrentMonthYear = model.CurrentMonthYear;
            model.DalySalelist.ToList().FirstOrDefault().TotalRevenueHQPreviousYear = model.TotalRevenueHQPreviousYear;


            return View("_DailySaleReportGrid", model.DalySalelist);
        }

        public ActionResult printDailySaleReport(string date)
        {
            ViewBag.Date = date;
            FillSaleReport model = new FillSaleReport();
            IFormatProvider dfor = new CultureInfo("en-GB").DateTimeFormat;
            DateTime dateto = DateTime.ParseExact(date, "dd/MM/yyyy", dfor);

            DateTime dt = DateTime.ParseExact(date, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            model.CurrentMonthYear = "From " + System.Environment.NewLine + "01/" + Convert.ToString(dateto.Month) + "/" + Convert.ToString(dateto.Year) + System.Environment.NewLine + " To " + System.Environment.NewLine + dateto.ToString("dd/MM/yyyy");
            model.TotalRevenueHQPreviousYear = dt.AddYears(-1).ToString("dd/MM/yyyy");

            model.DalySalelist = objBusinessClass.GetDalySaleReportforView(0, DateTime.Now, dateto, 2);


            model.DalySalelist.ToList().FirstOrDefault().CurrentMonthYear = model.CurrentMonthYear;
            model.DalySalelist.ToList().FirstOrDefault().TotalRevenueHQPreviousYear = model.TotalRevenueHQPreviousYear;

            return View(model.DalySalelist);

        }

        /* ---------------------------End Daily Sale  Report---------------------------------*/

        [HttpGet]
        public ActionResult ViewGSTUnitWise()
        {
            GSTBookingDetail model = new GSTBookingDetail();
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View(model);
        }
        [HttpPost]
        public ActionResult ViewGSTUnitWise(GSTBookingDetail model)
        {
            ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            GridView gv = new GridView();
            model.fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            model.toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);

            var dtresult = objBusinessClass.GetGSTandTarrifView(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Total_Booking = e.BookingCount, CGST= e.CGST, SGST = e.SGST, Room_Rent = e.roomRent, Total_Amount = e.Amount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/GSTandTarrifDetails.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.BookingGSTList = dtresult;
            return View(model);
        }

        public ActionResult BindGSTandTarrif(string dateFrom, string dateTo, long? unitID)
        {
            GSTBookingDetail model = new GSTBookingDetail();

            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    //dateFrom = "01/01/1900";
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    //dateTo = "01/01/1900";
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
               
               
                model.UnitID = unitID ?? 0;
                model.BookingGSTList = objBusinessClass.GetGSTandTarrifView(model).ToList();
            }
            catch
            {
            }
            return PartialView("_ViewGSTUnitWise", model.BookingGSTList);

        }

        public ActionResult PrintGSTandTarrifList(string dateFrom, string dateTo, long? unitID)
        {
            GSTBookingDetail model = new GSTBookingDetail();
           
            ViewBag.fromdate = string.IsNullOrEmpty(dateFrom) ? "-" : dateFrom;
            ViewBag.todate = string.IsNullOrEmpty(dateTo) ? "-" : dateTo;
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    //dateFrom = "01/01/1900";
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    //dateTo = "01/01/1900";
                }
                
               
                model.UnitID = unitID ?? 0;

                model.BookingGSTList = objBusinessClass.GetGSTandTarrifView(model).ToList();
                return View(model.BookingGSTList);
            }
            catch
            {
            }
            return View();
        }


    }
}
