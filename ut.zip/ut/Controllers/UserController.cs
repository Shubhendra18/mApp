﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;
using OTPL_Imp;
using UP_TourismBooking.Models;
using System.Web.Hosting;
using System.Web.Security;
using System.Text;
using System.IO;
using System.Configuration;
using System.Text.RegularExpressions;
using System.Globalization;

namespace UP_TourismBooking.Controllers
{
     
    public class UserController : Controller
    {

        #region declarations

        BusinessClass objBusinessClass = new BusinessClass();
        private Regex pinCode = new Regex(@"^(\d{6})$", RegexOptions.Compiled);
        private Regex mobileNo = new Regex(@"^(\d{10})$", RegexOptions.Compiled);
        #endregion
        //
        // GET: /User/

        public ActionResult Index()
        {
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            return View();           
           
        }



        public ActionResult UserLogin()
        {
            try
            {
                ModelState.Clear();

                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();
                SessionManager.SeedValue = seed;

                UserLogin model = new UserLogin();
                model.seed = seed;

                return PartialView("_SignIn", model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ValidateUserLogin(UserLogin model)
        {
            try
            {

                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (ModelState.IsValid)
                    {
                        string oldseed = model.seed.ToString();
                        Random rd = new Random();
                        string seed = rd.Next(100000, 999999).ToString();
                        SessionManager.SeedValue = seed;
                        model.seed = seed;

                        var user = objBusinessClass.VerifyUserLogin(model.email);

                        if (user != null)
                        {
                            if (model.password.ToString().ToUpper().Trim() == FormsAuthentication.HashPasswordForStoringInConfigFile(user.password.ToUpper() + oldseed, "MD5").ToUpper().Trim())
                            {

                                //
                                bool isAllow = false;

                                var attemptDetails = objBusinessClass.GetAttemptDetails(model.email, "Invalid Username/Password");
                                if (attemptDetails != null)
                                {
                                    DateTime _wrongAttemptDate = Convert.ToDateTime(attemptDetails.attemptTime);
                                    DateTime _currentDate = DateTime.Now;

                                    double _diff = (_currentDate).Subtract(_wrongAttemptDate).TotalMinutes;
                                    if (_diff < 1440 && user.wrongAttemptsCount > 9)
                                    {
                                        isAllow = false;
                                    }
                                    else
                                    {
                                        isAllow = true;
                                    }
                                }
                                else
                                {
                                    isAllow = true;
                                }

                                if (isAllow)
                                {
                                    //
                                    objBusinessClass.ResetLoginAttempts(model.email);

                                    //FormsAuthentication.SetAuthCookie(model.UserLoginID.ToString(), false);
                                    SessionManager.UserID = user.userID;
                                    SessionManager.RoleID = user.roleID;
                                    SessionManager.Username = user.email;
                                    SessionManager.DisplayName = user.name;
                                    SessionManager.CustomerMobile = user.mobileNo;
                                    string guid = Guid.NewGuid().ToString();
                                    //set Auth Cookies
                                    Session["AuthToken"] = guid;
                                    Response.Cookies.Add(new HttpCookie("AuthToken", guid));

                                    //return Json(new { result = true, url = Url.Action("PackageTourPayment", "UPTourism") });

                                    if (Session["bookingType"] != null)
                                    {
                                        if (Session["bookingType"].ToString() == "PACK")
                                        {
                                            return RedirectToAction("PackageTourPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "UNIT")
                                        {
                                            return RedirectToAction("UnitPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "CITY")
                                        {
                                            return RedirectToAction("CityTourPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "ACBUS")
                                        {
                                            return RedirectToAction("ACBusTourPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "CYCLE")
                                        {
                                            return RedirectToAction("CycleTourPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "TONGA")
                                        {
                                            return RedirectToAction("TongaRidePayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "WALK")
                                        {
                                            return RedirectToAction("HeritageWalkPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "BUS" || Session["bookingType"].ToString() == "TAXI")
                                        {
                                            return RedirectToAction("TaxiBusPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "bustaxi")
                                        {
                                            return RedirectToAction("BusTaxiPayment", "UPTourism");
                                        }
                                        else if (Session["bookingType"].ToString() == "LAWN" || Session["bookingType"].ToString() == "BANQUET")
                                        {
                                            return RedirectToAction("LawnBanqPayment", "UPTourism");
                                        }
                                    }
                                    else
                                    {
                                        if (model.loginFrom == "FL")
                                        {
                                            return RedirectToAction("Index", "UPTourism");
                                        }
                                        else
                                        {
                                            return RedirectToAction("BookingHistory", "UPTourism");
                                        }
                                    }
                                }
                                else
                                {
                                    objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "This account is locked because of wrong password attempt.", 0);
                                    TempData["ErrorLog"] = "This account is locked because of wrong password attempts!";
                                    return RedirectToAction("Index", "UPTourism");
                                }
                            }
                            else
                            {
                                objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                                TempData["ErrorLog"] = "Incorrect username or password!";
                                return RedirectToAction("Index", "User");
                            }
                        }
                        else
                        {
                            objBusinessClass.UpdateLoginAttempts(Common.GetIPAddress(), DateTime.Now, model.email, Request.Url.AbsolutePath, "Invalid Username/Password", 1);
                            TempData["ErrorLog"] = "Incorrect username or password!";
                            return RedirectToAction("Index", "User");
                        }
                    }
                    TempData["ErrorLog"] = "Incorrect username or password!";
                    return RedirectToAction("Index", "User");
                }
                else
                {
                    TempData["ErrorLog"] = "Captcha Text did not Match!";
                   return RedirectToAction("Index", "User");
                }
            }
            catch
            {
                TempData["ErrorLog"] = "Error in process!";
                return RedirectToAction("Index", "User");
            }

            
        }

        public ActionResult Registration()
        {
            try
            {
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                Random rd = new Random();
                string seed = rd.Next(100000, 999999).ToString();
                SessionManager.SeedValue = seed;

                Registration model = new Registration();
                model.seed = seed;

                #region get values from Cookes
                try
                {
                    model.name = Convert.ToString(Request.Cookies["name"].Value);
                    model.email = Convert.ToString(Request.Cookies["email"].Value);
                    model.mobileNo = Convert.ToString(Request.Cookies["mobileNo"].Value);
                    model.address = Convert.ToString(Request.Cookies["address"].Value);
                    model.pincode = Convert.ToString(Request.Cookies["pincode"].Value);
                    model.countryID = Convert.ToString(Request.Cookies["countryID"].Value) != "" ? Convert.ToInt32(Request.Cookies["countryID"].Value) : 0;
                    
                    model.otherCity = Convert.ToString(Request.Cookies["otherCity"].Value);
                    model.otherState = Convert.ToString(Request.Cookies["otherState"].Value);
                    model.stateID = Convert.ToString(Request.Cookies["stateID"].Value) != "" ? Convert.ToInt32(Request.Cookies["stateID"].Value) : 0;
                    model.cityID = Convert.ToString(Request.Cookies["cityID"].Value) != "" ? Convert.ToInt32(Request.Cookies["cityID"].Value) : 0;

                    if (model != null && model.countryID == 98)
                    {
                        ViewBag.StateDATA = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                        if (model.stateID > 0)
                        {
                            ViewBag.CityDATA = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                        }
                        else
                        {
                            ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
                        }
                    }
                    else
                    {
                        ViewBag.StateDATA = Enumerable.Empty<SelectListItem>();
                        ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
                    }
                   
                   
                    
                }
                catch
                {
                    ViewBag.StateDATA = Enumerable.Empty<SelectListItem>();
                    ViewBag.CityDATA = Enumerable.Empty<SelectListItem>();
                }
                #endregion

                return PartialView("_SignUp", model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterCustomer(Registration model)
        {
            try
            {
                #region set Values in Cookes
                 Response.Cookies.Add(new HttpCookie("name", model.name));
                 Response.Cookies.Add(new HttpCookie("email", model.email));
                 Response.Cookies.Add(new HttpCookie("mobileNo", model.mobileNo));
                 Response.Cookies.Add(new HttpCookie("address", model.address));
                 Response.Cookies.Add(new HttpCookie("countryID", Convert.ToString(model.countryID)));
                 Response.Cookies.Add(new HttpCookie("stateID", Convert.ToString(model.stateID)));
                 Response.Cookies.Add(new HttpCookie("cityID", Convert.ToString(model.cityID)));
                 Response.Cookies.Add(new HttpCookie("otherCity", model.otherCity));
                 Response.Cookies.Add(new HttpCookie("otherState", model.otherState));
                 Response.Cookies.Add(new HttpCookie("pincode", model.pincode));
                #endregion
                if (Convert.ToString(Session["capimagetextReg"]) == model.Captcha)
                {
                    if (model.countryID == 98)
                    {
                        ModelState["otherState"].Errors.Clear();
                        ModelState["otherCity"].Errors.Clear();

                        if (!pinCode.IsMatch(model.pincode))
                        {
                            TempData["ErrorMsg"] = "Enter a valid 6 digit Pincode!";
                        }
                        else if (!mobileNo.IsMatch(model.mobileNo))
                        {
                            TempData["ErrorMsg"] = "Enter a valid 10 digit Mobile No.!";
                        }

                        model.otherState = "";
                        model.otherCity = "";
                    }
                    else
                    {
                        ModelState["stateID"].Errors.Clear();
                        ModelState["cityID"].Errors.Clear();

                        model.stateID = 0;
                        model.cityID = 0;
                    }

                    ModelState["password"].Errors.Clear();

                    if (ModelState.IsValid)
                    {
                        model.roleID = "CST";
                        var user = objBusinessClass.InsertUser(model);

                        if (user != null)
                        {
                            #region set Values in Cookes
                            if (Request.Cookies["name"] != null)
                            {
                                Response.Cookies["name"].Expires = DateTime.Now.AddDays(-1);
                            }
                            if (Request.Cookies["email"] != null)
                            {
                                Response.Cookies["email"].Expires = DateTime.Now.AddDays(-1);
                            }
                            if (Request.Cookies["mobileNo"] != null)
                            {
                                Response.Cookies["mobileNo"].Expires = DateTime.Now.AddDays(-1);
                            }
                            if (Request.Cookies["address"] != null)
                            {
                                Response.Cookies["address"].Expires = DateTime.Now.AddDays(-1);
                            }
                            if (Request.Cookies["countryID"] != null)
                            {
                                Response.Cookies["countryID"].Expires = DateTime.Now.AddDays(-1);
                            }
                            if (Request.Cookies["stateID"] != null)
                            {
                                Response.Cookies["stateID"].Expires = DateTime.Now.AddDays(-1);
                            }
                            if (Request.Cookies["cityID"] != null)
                            {
                                Response.Cookies["cityID"].Expires = DateTime.Now.AddDays(-1);
                            }

                            if (Request.Cookies["otherCity"] != null)
                            {
                                Response.Cookies["otherCity"].Expires = DateTime.Now.AddDays(-1);
                            }

                            if (Request.Cookies["otherState"] != null)
                            {
                                Response.Cookies["otherState"].Expires = DateTime.Now.AddDays(-1);
                            }


                            if (Request.Cookies["pincode"] != null)
                            {
                                Response.Cookies["pincode"].Expires = DateTime.Now.AddDays(-1);
                            }
                                                       
                            #endregion
                            SessionManager.UserID = user.userID;
                            SessionManager.Username = user.email;
                            SessionManager.DisplayName = user.name;
                            SessionManager.CustomerMobile = user.mobileNo;
                            SessionManager.RoleID = model.roleID;

                            return RedirectToAction("SignUpSuccess", "User");
                        }
                    }
                }
                else
                {
                    TempData["ErrorMsg"] = "Captcha Text did not Match!";
                    return RedirectToAction("Index", "User");
                }
            }
            catch
            { }
            TempData["ErrorMsg"] = "Error in registration!";
            return RedirectToAction("Index", "User");
        }


        public ActionResult SignUpSuccess()
        {
           
            return View();
        }
        
        public ActionResult ContiApp()
        {
            if (Session["bookingType"] != null)
            {

                if (Session["bookingType"].ToString() == "PACK")
                {
                    return RedirectToAction("PackageTourPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "UNIT")
                {
                    return RedirectToAction("UnitPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "CITY")
                {
                    return RedirectToAction("CityTourPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "ACBUS")
                {
                    return RedirectToAction("ACBusTourPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "CYCLE")
                {
                    return RedirectToAction("CycleTourPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "TONGA")
                {
                    return RedirectToAction("TongaRidePayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "WALK")
                {
                    return RedirectToAction("HeritageWalkPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "BUS" || Session["bookingType"].ToString() == "TAXI")
                {
                    return RedirectToAction("TaxiBusPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "bustaxi")
                {
                    return RedirectToAction("BusTaxiPayment", "UPTourism");
                }
                else if (Session["bookingType"].ToString() == "LAWN" || Session["bookingType"].ToString() == "BANQUET")
                {
                    return RedirectToAction("LawnBanqPayment", "UPTourism");
                }
               
            }
            else
            {
                
                    return RedirectToAction("BookingHistory", "UPTourism");
                
            }
            return RedirectToAction("BookingHistory", "UPTourism");
        }

    }
}
