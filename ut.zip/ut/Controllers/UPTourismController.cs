﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;
using System.Globalization;
using System.Configuration;
using System.Data;
using System.Collections;
using System.IO;
using System.Web.Hosting;
using System.Net;
using System.Xml;
using System.Text;

namespace UP_TourismBooking.Controllers
{

    public class UPTourismController : Controller
    {
        #region Declarations
        BusinessClass objBusinessClass = new BusinessClass();
        #endregion

        #region home page
        [HttpGet]
        public ActionResult Index()
        {
            ClearSession();
          
            return View();
        }
        #endregion

        #region display unit search
        [HttpGet]
        public ActionResult Hotels()
        {
            ViewBag.Destination = objBusinessClass.GetUnitDestinationsList(1).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
            ViewBag.LawnDestination = objBusinessClass.GetUnitDestinationsList(2).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
            ViewBag.BanquetDestination = objBusinessClass.GetUnitDestinationsList(3).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });

            ViewBag.FunctionType = objBusinessClass.GetFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });
            return PartialView("_Hotels");
        }
        #endregion

        #region display units search panel
        public ActionResult UnitSearch()
        {
            try
            {
                UnitBooking model = new UnitBooking();

                ViewBag.Destination = objBusinessClass.GetUnitDestinationsList(1).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });

                model.destinationID = Convert.ToInt32(Session["destination"].ToString());
                model.checkInDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                model.checkOutDate = Convert.ToDateTime(Session["checkOutDate"].ToString()).AddDays(1);
                model.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                model.noOfRooms = Convert.ToInt32(Session["noOfRooms"].ToString());

                return PartialView("_UnitSearch", model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }
        #endregion

        #region search units
        [HttpParamAction]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult Units(UnitBooking model)
        {
            try
            {
                ModelState["lawnDestinationID"].Errors.Clear();
                ModelState["noOfLawnGuest"].Errors.Clear();
                ModelState["functionID"].Errors.Clear();
                ModelState["banquetBookingDate"].Errors.Clear();
                ModelState["noOfBanquetGuest"].Errors.Clear();
                ModelState["banquetFunctionID"].Errors.Clear();
                ModelState["lawnBookingDate"].Errors.Clear();
                ModelState["banquetDestinationID"].Errors.Clear();

                if (ModelState.IsValid)
                {
                    if (!IsDateValid(model.checkInDate, model.checkOutDate, "UNIT"))
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }
                   // Session["IsSpecial"] = "False";
                    Session["destination"] = model.destinationID;
                    Session["checkInDate"] = model.checkInDate;
                    Session["checkOutDate"] = model.checkOutDate.AddDays(-1);
                    Session["noOfGuests"] = model.noOfGuests;
                    Session["noOfRooms"] = model.noOfRooms;

                    return RedirectToAction("UnitList", "UPTourism");
                }
                return RedirectToAction("Index", "UPTourism");
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display unit list
        [HttpGet]
        public ActionResult UnitList()
        {
            try
            {
                UnitBooking objUnit = new UnitBooking();

                if (SessionManager.IsSessionActive("destination") && SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("checkOutDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("noOfRooms"))
                {
                    objUnit.destinationID = Convert.ToInt32(Session["destination"].ToString());
                    objUnit.checkInDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                    objUnit.checkOutDate = Convert.ToDateTime(Session["checkOutDate"].ToString());
                    objUnit.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                    objUnit.noOfRooms = Convert.ToInt32(Session["noOfRooms"].ToString());


                    objUnit.IEunit = objBusinessClass.GetDestinationWiseUnitList(objUnit.destinationID, objUnit.checkInDate, objUnit.checkOutDate, objUnit.noOfGuests, objUnit.noOfRooms);
                    objUnit.destinationName = objUnit.IEunit.Select(p => p.destinationName).Distinct().FirstOrDefault();
                    objUnit.unitCount = objUnit.IEunit.Count();
                    Session["destinationName"] = objUnit.destinationName;

                    foreach (var lst in objUnit.IEunit)
                    {
                        lst.IEUnitAmenities = objBusinessClass.GetUnitWiseAmenitiesList(lst.unitID);
                        lst.IEUnitRooms = objBusinessClass.GetUnitWiseRoomList(lst.unitID, objUnit.checkInDate, objUnit.checkOutDate, objUnit.noOfRooms);
                        //lst.IEUnitRooms = objBusinessClass.GetUnitWiseRoomList(lst.unitID);

                        DataTable dt = new DataTable();
                        dt.AsEnumerable();
                    }


                    return View(objUnit);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }

        }
        #endregion

        #region display unit details
        [HttpGet]
        public ActionResult UnitDetails(int Id)
        {
            try
            {
                if (SessionManager.IsSessionActive("destination") && SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("checkOutDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("noOfRooms"))
                {
                    Session["unitID"] = Id;

                    UnitDetails obj_unit = new UnitDetails();
                    obj_unit = objBusinessClass.GetUnitDisplayinfo(Id);
                    obj_unit.IEAmenities = objBusinessClass.GetUnitWiseAmenitiesList(Id);
                    obj_unit.IERooms = objBusinessClass.GetUnitRoomList(Id, Convert.ToDateTime(Session["checkInDate"].ToString()), Convert.ToDateTime(Session["checkOutDate"].ToString()), Convert.ToInt32(Session["noOfRooms"].ToString()));

                    obj_unit.IEImages = objBusinessClass.GetUnitImageList(Id);

                    return View(obj_unit);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region unit room detail (displayed in popup)
        [HttpGet]
        public ActionResult UnitRoomDetail(int Id)
        {
            try
            {
                UnitPayment obj_UnitPayment = new UnitPayment();
                UnitRooms objRoom = objBusinessClass.GetRoomInfo(Id, Convert.ToInt64(Session["unitID"]));

                if (objRoom != null)
                {
                    obj_UnitPayment.noOfRooms = Convert.ToInt32(Session["noOfRooms"].ToString());
                    obj_UnitPayment.roomType = objRoom.roomType;
                    obj_UnitPayment.roomID = objRoom.roomID;
                    obj_UnitPayment.maxCapacity = objRoom.maxCapacity;
                    obj_UnitPayment.hasOccupancy = objRoom.hasOccupancy;

                    if (obj_UnitPayment.hasOccupancy)
                    {
                        obj_UnitPayment.doubleRoom = obj_UnitPayment.noOfRooms;
                    }
                    else
                    {
                        obj_UnitPayment.singleRoom = obj_UnitPayment.noOfRooms;
                    }
                    obj_UnitPayment.destination = Convert.ToString(Session["destinationName"]);
                    obj_UnitPayment.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                    obj_UnitPayment.checkInDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                    obj_UnitPayment.checkOutDate = Convert.ToDateTime(Session["checkOutDate"].ToString()).AddDays(1);

                }
                return PartialView("_RoomDetails", obj_UnitPayment);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        public ActionResult UnitRoomDetail(UnitPayment model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (model.hasOccupancy)
                    {
                        if (model.noOfGuests < (model.singleRoom + model.doubleRoom))
                        {
                            return Json(new { result = false, message = "Total No. of Single and Double rooms can't be more than No. of Guests!" }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {
                            int extraBed = 0;
                            extraBed = model.noOfGuests - (model.singleRoom + (model.doubleRoom * 2));
                            extraBed = (extraBed > 0) ? extraBed : 0;

                            if (extraBed > model.doubleRoom)
                            {
                                return Json(new { result = false, message = "No. of selected rooms is not sufficient!" }, JsonRequestBehavior.AllowGet);
                            }
                            else
                            {
                                Session["singleRoom"] = model.singleRoom;
                                Session["doubleRoom"] = model.doubleRoom;
                                Session["roomID"] = model.roomID;
                                Session["extraBed"] = extraBed;

                                if (!string.IsNullOrEmpty(model.privilegeCardNo))
                                {
                                    if (model.privilegeCardDate != null)
                                    {
                                        //if (Convert.ToDateTime(model.privilegeCardDate).Date <= DateTime.Now.Date)
                                        Session["privilegecard"] = model.privilegeCardNo;
                                        Session["privilegecarddate"] = model.privilegeCardDate;
                                    }
                                    else
                                    {
                                        return Json(new { result = false, message = "Enter Privilege Card Date!" }, JsonRequestBehavior.AllowGet);
                                    }
                                }

                                return Json(new { result = true, url = Url.Action("UnitBookNow", "UPTourism") });
                            }
                        }
                    }
                    else
                    {
                        if (model.noOfGuests < model.singleRoom)
                        {
                            return Json(new { result = false, message = "Total No. of Rooms can't be more than No. of Guests!" }, JsonRequestBehavior.AllowGet);
                        }
                        else
                        {

                            if ((model.singleRoom * model.maxCapacity) < model.noOfGuests)
                            {
                                return Json(new { result = false, message = "No. of selected rooms is not sufficient!" }, JsonRequestBehavior.AllowGet);
                            }
                            else
                            {
                                Session["singleRoom"] = model.singleRoom;
                                Session["doubleRoom"] = 0;
                                Session["roomID"] = model.roomID;
                                Session["extraBed"] = 0;

                                if (!string.IsNullOrEmpty(model.privilegeCardNo))
                                {
                                    Session["privilegecard"] = model.privilegeCardNo;
                                }
                                return Json(new { result = true, url = Url.Action("UnitBookNow", "UPTourism") });
                            }
                        }
                    }

                }
            }
            catch
            { }
            return Json(new { result = false, message = "Unable to process!" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region unit room booking
        [HttpGet]
        public ActionResult UnitBookNow()
        {
            try
            {
                UnitPayment obj_UnitPayment = new UnitPayment();

                DateTime dtCheckin = Convert.ToDateTime(Session["checkInDate"].ToString());
                DateTime dtCheckout = Convert.ToDateTime(Session["checkOutDate"].ToString());
                int roomId = Convert.ToInt32(Session["roomID"].ToString());
                Int64 unitId = Convert.ToInt32(Session["unitID"].ToString());
                int single = Convert.ToInt32(Session["singleRoom"].ToString());
                int doubles = Convert.ToInt32(Session["doubleRoom"].ToString());
                int extraBed = Convert.ToInt32(Session["extraBed"].ToString());

                obj_UnitPayment = objBusinessClass.GetUnitPaymentInfo(dtCheckin, dtCheckout, roomId, unitId, single, doubles, extraBed);

                if (Session["privilegecard"] != null && Session["privilegecard"].ToString() != "")
                {
                    DateTime privilegeCardDate = Convert.ToDateTime(Session["privilegecarddate"].ToString()).Date;
                    DateTime standardCardDate = Convert.ToDateTime(ConfigurationManager.AppSettings["PrivilegeDiscountCardDate"].ToString()).Date;
                    decimal discountPercent = 0;

                    if (privilegeCardDate < standardCardDate)
                    {
                        discountPercent = ConfigurationManager.AppSettings["PrivilegeInitialDiscount"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["PrivilegeInitialDiscount"].ToString()) : 0;
                    }
                    else
                    {
                        discountPercent = ConfigurationManager.AppSettings["PrivilegeLaterDiscount"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["PrivilegeLaterDiscount"].ToString()) : 0;
                    }
                    obj_UnitPayment.discountAmount = ((discountPercent * obj_UnitPayment.amount) / 100);
                    obj_UnitPayment.totalAmount = (obj_UnitPayment.amount - obj_UnitPayment.discountAmount) + obj_UnitPayment.taxAmount;
                    obj_UnitPayment.isPrivilege = true;
                }
                else
                {
                    obj_UnitPayment.totalAmount = obj_UnitPayment.amount + obj_UnitPayment.taxAmount;
                    obj_UnitPayment.isPrivilege = false;
                }
                obj_UnitPayment.checkInDate = dtCheckin;
                obj_UnitPayment.checkOutDate = dtCheckout.AddDays(1);
                obj_UnitPayment.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                obj_UnitPayment.singleRoom = single;
                obj_UnitPayment.doubleRoom = doubles;
                obj_UnitPayment.unitID = unitId;
                obj_UnitPayment.roomID = roomId;
                obj_UnitPayment.extraBed = extraBed;
                Session["PrevURL"] = this.HttpContext.Request.RawUrl;
                Session["bookingType"] = "UNIT";
                return View(obj_UnitPayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }

        #endregion

        #region display unit room payment after login
        [HttpGet]
        public ActionResult UnitPayment()
        {
            try
            {
                UnitPayment obj_UnitPayment = new UnitPayment();
                DateTime dtCheckin = Convert.ToDateTime(Session["checkInDate"].ToString());
                DateTime dtCheckout = Convert.ToDateTime(Session["checkOutDate"].ToString());
                int roomId = Convert.ToInt32(Session["roomID"].ToString());
                Int64 unitId = Convert.ToInt32(Session["unitID"].ToString());
                int single = Convert.ToInt32(Session["singleRoom"].ToString());
                int doubles = Convert.ToInt32(Session["doubleRoom"].ToString());
                int extraBed = Convert.ToInt32(Session["extraBed"].ToString());

                obj_UnitPayment = objBusinessClass.GetUnitPaymentInfo(dtCheckin, dtCheckout, roomId, unitId, single, doubles, extraBed);

                if (Session["privilegecard"] != null && Session["privilegecard"].ToString() != "")
                {
                    DateTime privilegeCardDate = Convert.ToDateTime(Session["privilegecarddate"].ToString()).Date;
                    DateTime standardCardDate = Convert.ToDateTime(ConfigurationManager.AppSettings["PrivilegeDiscountCardDate"].ToString()).Date;
                    decimal discountPercent = 0;

                    if (privilegeCardDate < standardCardDate)
                    {
                        discountPercent = ConfigurationManager.AppSettings["PrivilegeInitialDiscount"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["PrivilegeInitialDiscount"].ToString()) : 0;
                    }
                    else
                    {
                        discountPercent = ConfigurationManager.AppSettings["PrivilegeLaterDiscount"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["PrivilegeLaterDiscount"].ToString()) : 0;
                    }
                    obj_UnitPayment.discountAmount = ((discountPercent * obj_UnitPayment.amount) / 100);

                    obj_UnitPayment.totalAmount = (obj_UnitPayment.amount - obj_UnitPayment.discountAmount) + obj_UnitPayment.taxAmount;
                    obj_UnitPayment.isPrivilege = true;
                }
                else
                {
                    obj_UnitPayment.totalAmount = obj_UnitPayment.amount + obj_UnitPayment.taxAmount;
                    obj_UnitPayment.isPrivilege = false;
                }
                obj_UnitPayment.checkInDate = dtCheckin;
                obj_UnitPayment.checkOutDate = dtCheckout.AddDays(1);
                obj_UnitPayment.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                obj_UnitPayment.singleRoom = single;
                obj_UnitPayment.doubleRoom = doubles;
                obj_UnitPayment.unitID = unitId;
                obj_UnitPayment.roomID = roomId;
                obj_UnitPayment.extraBed = extraBed;

                obj_UnitPayment.customerName = SessionManager.DisplayName;
                obj_UnitPayment.customerEmail = SessionManager.Username;
                obj_UnitPayment.customerMobile = SessionManager.CustomerMobile;

                return View(obj_UnitPayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region save unit request and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UnitPayment(UnitPayment model)
        {
            try
            {
                ModelState.Clear();

                UnitPayment obj_UnitPayment = new UnitPayment();
                List<UnitAmountDetailsSlabWise> obj_unitPaymentDetailsSlabWise = new List<UnitAmountDetailsSlabWise>();
                DateTime dtCheckin = Convert.ToDateTime(Session["checkInDate"].ToString());
                DateTime dtCheckout = Convert.ToDateTime(Session["checkOutDate"].ToString());
                int roomId = Convert.ToInt32(Session["roomID"].ToString());
                Int64 unitId = Convert.ToInt32(Session["unitID"].ToString());
                int single = Convert.ToInt32(Session["singleRoom"].ToString());
                int doubles = Convert.ToInt32(Session["doubleRoom"].ToString());
                int extraBed = Convert.ToInt32(Session["extraBed"].ToString());

                obj_UnitPayment = objBusinessClass.GetUnitPaymentInfo(dtCheckin, dtCheckout, roomId, unitId, single, doubles, extraBed);

                /*Code By Manish*/
                obj_unitPaymentDetailsSlabWise = objBusinessClass.GetUnitPaymentInfoForTaxSlabsInsert(dtCheckin, dtCheckout, roomId, single, doubles, extraBed);
                string UnitPaymentsSlabXML = generateXMLForSlab(obj_unitPaymentDetailsSlabWise);
                /*Code By Manish*/

                if (Session["privilegecard"] != null && Session["privilegecard"].ToString() != "")
                {
                    DateTime privilegeCardDate = Convert.ToDateTime(Session["privilegecarddate"].ToString()).Date;
                    DateTime standardCardDate = Convert.ToDateTime(ConfigurationManager.AppSettings["PrivilegeDiscountCardDate"].ToString()).Date;
                    decimal discountPercent = 0;

                    if (privilegeCardDate < standardCardDate)
                    {
                        discountPercent = ConfigurationManager.AppSettings["PrivilegeInitialDiscount"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["PrivilegeInitialDiscount"].ToString()) : 0;
                    }
                    else
                    {
                        discountPercent = ConfigurationManager.AppSettings["PrivilegeLaterDiscount"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["PrivilegeLaterDiscount"].ToString()) : 0;
                    }
                    obj_UnitPayment.privilegeCardDate = privilegeCardDate;
                    obj_UnitPayment.discountAmount = ((discountPercent * obj_UnitPayment.amount) / 100);
                    obj_UnitPayment.totalAmount = (obj_UnitPayment.amount - obj_UnitPayment.discountAmount) + obj_UnitPayment.taxAmount;
                    obj_UnitPayment.isPrivilege = true;
                    obj_UnitPayment.discountPercent = discountPercent;
                }
                else
                {
                    obj_UnitPayment.totalAmount = obj_UnitPayment.amount + obj_UnitPayment.taxAmount; ;
                    obj_UnitPayment.isPrivilege = false;
                }
                obj_UnitPayment.checkInDate = dtCheckin;
                obj_UnitPayment.checkOutDate = dtCheckout;
                obj_UnitPayment.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                obj_UnitPayment.singleRoom = single;
                obj_UnitPayment.doubleRoom = doubles;
                obj_UnitPayment.unitID = unitId;
                obj_UnitPayment.roomID = roomId;
                obj_UnitPayment.noOfRooms = single + doubles;
                obj_UnitPayment.userIP = this.Request.UserHostAddress;
                obj_UnitPayment.extraBed = extraBed;
                obj_UnitPayment.privilegeCardNo = Session["privilegecard"] != null ? Session["privilegecard"].ToString() : "";

                obj_UnitPayment.customerName = SessionManager.DisplayName;
                obj_UnitPayment.customerEmail = SessionManager.Username;
                obj_UnitPayment.customerMobile = SessionManager.CustomerMobile;


                obj_UnitPayment.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                obj_UnitPayment.currency = "INR";
                obj_UnitPayment.description = "";

                PostPaymentData result = objBusinessClass.InsertUnitBookRequest(obj_UnitPayment, UnitPaymentsSlabXML);
                if (result != null)
                {
                    if (result.RequestID == 0 || result.docketNo == null || result.docketNo == "")
                    {
                        TempData["unavailableMessage"] = "Room Could Not Be Booked Due To Unavailability!";
                        return RedirectToAction("Unavailable", "UPTourism");
                    }
                    else
                    {
                        var reqID = HashValue(result.RequestID.ToString());
                        var docNo = HashValue(result.RequestID.ToString());

                        return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                    }
                }

                //if (result != null)
                //{                   
                //        var reqID = HashValue(result.RequestID.ToString());
                //        var docNo = HashValue(result.docketNo);

                //        return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);                    
                //}
                return View(obj_UnitPayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion
        string generateXMLForSlab(List<UnitAmountDetailsSlabWise> model)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (model != null)
            {
                sb.Append("<ArrayOfUnitAmountDetails>");
                foreach (var data in model)
                {
                    sb.Append("<UnitAmountDetails>");

                    sb.Append("<TaxFreeAmount>" + data.TaxFreeAmount + "</TaxFreeAmount>");
                    sb.Append("<taxAmountOnFree>" + data.taxAmountOnFree + "</taxAmountOnFree>");
                    sb.Append("<taxrateonFree>" + data.taxrateonFree + "</taxrateonFree>");

                    sb.Append("<SlabOneAmount>" + data.SlabOneAmount + "</SlabOneAmount>");
                    sb.Append("<SlabOneTaxAmount>" + data.SlabOneTaxAmount + "</SlabOneTaxAmount>");
                    sb.Append("<taxRateSlabOne>" + data.taxRateSlabOne + "</taxRateSlabOne>");

                    sb.Append("<SlabTwoAmount>" + data.SlabTwoAmount + "</SlabTwoAmount>");
                    sb.Append("<SlabTwoTaxAmount>" + data.SlabTwoTaxAmount + "</SlabTwoTaxAmount>");
                    sb.Append("<taxRateSlabTwo>" + data.taxRateSlabTwo + "</taxRateSlabTwo>");


                    sb.Append("<SlabThreeAmount>" + data.SlabThreeAmount + "</SlabThreeAmount>");
                    sb.Append("<SlabThreeTaxAmount>" + data.SlabThreeTaxAmount + "</SlabThreeTaxAmount>");
                    sb.Append("<taxRateSlabThree>" + data.taxRateSlabThree + "</taxRateSlabThree>");

                    sb.Append("</UnitAmountDetails>");

                }
                sb.Append("</ArrayOfUnitAmountDetails>");
            }

            return sb.ToString();
        }
        /*------------------------SpecialHotelRooms------------------------*/

        #region display units search panel
        [HttpPost]
        public ActionResult SpecialUnitSearch()
        {
            try
            {
                SpecialUnitBooking model = new SpecialUnitBooking();
                ViewBag.Units = objBusinessClass.GetAllunitdetails(0).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                // ViewBag.Destination = objBusinessClass.GetUnitDestinationsList(1).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });

                model.destinationID = Convert.ToInt32(Session["UnitName"].ToString());
                model.checkInDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                model.checkOutDate = Convert.ToDateTime(Session["checkOutDate"].ToString()).AddDays(1);
                model.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                model.noOfRooms = Convert.ToInt32(Session["noOfRooms"].ToString());

                return PartialView("_SpecialUnitSearch", model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }
        #endregion
        #region display unit list
        [HttpGet]
        public ActionResult SpecialUnitList()
        {
            try
            {
                UnitBooking objUnit = new UnitBooking();

                if (SessionManager.IsSessionActive("UnitName") && SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("checkOutDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("noOfRooms"))
                {
                    objUnit.destinationID = Convert.ToInt32(Session["UnitName"].ToString());
                    objUnit.checkInDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                    objUnit.checkOutDate = Convert.ToDateTime(Session["checkOutDate"].ToString());
                    objUnit.noOfGuests = Convert.ToInt32(Session["noOfGuests"].ToString());
                    objUnit.noOfRooms = Convert.ToInt32(Session["noOfRooms"].ToString());


                    objUnit.IEunit = objBusinessClass.GetDestinationWiseUnitList(objUnit.destinationID, objUnit.checkInDate, objUnit.checkOutDate, objUnit.noOfGuests, objUnit.noOfRooms);
                    objUnit.destinationName = objUnit.IEunit.Select(p => p.destinationName).Distinct().FirstOrDefault();
                    objUnit.unitCount = objUnit.IEunit.Count();
                    Session["destinationName"] = objUnit.destinationName;

                    foreach (var lst in objUnit.IEunit)
                    {
                        lst.IEUnitAmenities = objBusinessClass.GetUnitWiseAmenitiesList(lst.unitID);
                        lst.IEUnitRooms = objBusinessClass.GetUnitWiseRoomList(lst.unitID, objUnit.checkInDate, objUnit.checkOutDate, objUnit.noOfRooms);
                        //lst.IEUnitRooms = objBusinessClass.GetUnitWiseRoomList(lst.unitID);

                        DataTable dt = new DataTable();
                        dt.AsEnumerable();
                    }


                    return View(objUnit);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }

        }
        #endregion


        /*------------------------ens of SpecialHotelRooms------------------------*/
        /*-------------Lawn Booking Enquiry-------------*/

        #region display lawn details
        [HttpParamAction]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult Lawn(UnitBooking model)
        {
            try
            {
                if (ModelState.IsValidField("lawnDestinationID") && ModelState.IsValidField("lawnBookingDate") && ModelState.IsValidField("noOfLawnGuest") && ModelState.IsValidField("functionID"))
                {
                    if (!IsDateValid(model.lawnBookingDate, DateTime.Now, "LAWN"))
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }
                    Session["destination"] = model.lawnDestinationID;
                    Session["checkInDate"] = model.lawnBookingDate;
                    Session["noOfGuests"] = model.noOfLawnGuest;
                    Session["functionType"] = model.functionID;

                    return RedirectToAction("LawnEnquiry", "UPTourism");
                }

            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region display lawn search panel
        public ActionResult LawnSearch()
        {
            try
            {
                UnitBooking model = new UnitBooking();

                ViewBag.Destination = objBusinessClass.GetUnitDestinationsList(2).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
                ViewBag.FunctionType = objBusinessClass.GetFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });

                model.lawnDestinationID = Convert.ToInt32(Session["destination"].ToString());
                model.lawnBookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                model.functionID = Convert.ToInt32(Session["functionType"].ToString());
                model.noOfLawnGuest = Convert.ToInt32(Session["noOfGuests"].ToString());

                return PartialView("_LawnSearch", model);
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region display lawn enquiry
        [HttpGet]
        public ActionResult LawnEnquiry()
        {
            try
            {
                LawnEnquiry objUnit = new LawnEnquiry();

                if (SessionManager.IsSessionActive("destination") && SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("functionType"))
                {
                    objUnit.destinationID = Convert.ToInt32(Session["destination"].ToString());
                    objUnit.lawnBookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                    objUnit.noOfLawnGuest = Convert.ToInt32(Session["noOfGuests"].ToString());
                    objUnit.functionID = Convert.ToInt32(Session["functionType"].ToString());

                    ViewBag.Hotel = objBusinessClass.GetUnitsByDestination(objUnit.destinationID).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

                    return View(objUnit);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region save lawn enquiry
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LawnEnquiry(LawnEnquiry model)
        {
            try
            {
                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (SessionManager.IsSessionActive("destination") && SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("functionType"))
                    {
                        ModelState["amount"].Errors.Clear();
                        ModelState["remark"].Errors.Clear();
                        ModelState["document"].Errors.Clear();
                        if (ModelState.IsValid)
                        {
                            model.ipAddress = this.Request.UserHostAddress;
                            model.destinationID = Convert.ToInt32(Session["destination"].ToString());
                            model.lawnBookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                            model.noOfLawnGuest = Convert.ToInt32(Session["noOfGuests"].ToString());
                            model.functionID = Convert.ToInt32(Session["functionType"].ToString());
                            model.enquiryType = "Lawn";
                            LawnEnquiry result = objBusinessClass.InsertLawnEnquiry(model);
                            if (result != null)
                            {
                                try
                                {
                                    ModelState.Clear();
                                    TempData["enquiryNo"] = result.enquiryNo;
                                    SendLawnBanquetEnquiryEmail(result.enquiryNo);
                                    return RedirectToAction("LawnEnquiryConfirmation");
                                }
                                catch
                                { }
                            }
                        }

                        ViewBag.Hotel = objBusinessClass.GetUnitsByDestination(Convert.ToInt32(Session["destination"].ToString())).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

                        return View(model);
                    }
                    else
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }
                }
                else
                {
                    ViewBag.cMSG = "Captcha field - Entered text does not match";
                    ViewBag.Hotel = objBusinessClass.GetUnitsByDestination(Convert.ToInt32(Session["destination"].ToString())).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                    return View(model);
                }
            }
            catch
            { }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region lawn booking enquiry confirmation
        public ActionResult LawnEnquiryConfirmation()
        {
            LawnEnquiry model = new LawnEnquiry();
            try
            {
                if (TempData.Peek("enquiryNo") != null)
                {
                    model = objBusinessClass.GetLawnBanquetEnquiry(TempData.Peek("enquiryNo").ToString());
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        /*-------------End Lawn Booking Enquiry-------------*/

        /*-------------Banquet Booking Enquiry-------------*/

        #region display banquet details
        [HttpParamAction]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult Banquet(UnitBooking model)
        {
            try
            {
                if (ModelState.IsValidField("banquetDestinationID") && ModelState.IsValidField("banquetBookingDate") && ModelState.IsValidField("noOfBanquetGuest") && ModelState.IsValidField("banquetFunctionID"))
                {
                    if (!IsDateValid(model.lawnBookingDate, DateTime.Now, "BANQUET"))
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }
                    Session["destination"] = model.banquetDestinationID;
                    Session["checkInDate"] = model.banquetBookingDate;
                    Session["noOfGuests"] = model.noOfBanquetGuest;
                    Session["functionType"] = model.banquetFunctionID;

                    return RedirectToAction("BanquetEnquiry", "UPTourism");
                }
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region display banquet search panel
        public ActionResult BanquetSearch()
        {
            try
            {
                UnitBooking model = new UnitBooking();

                ViewBag.Destination = objBusinessClass.GetUnitDestinationsList(3).Select(e => new SelectListItem() { Text = e.DestinationName, Value = e.DestinationID.ToString() });
                ViewBag.FunctionType = objBusinessClass.GetFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });

                model.banquetDestinationID = Convert.ToInt32(Session["destination"].ToString());
                model.banquetBookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                model.banquetFunctionID = Convert.ToInt32(Session["functionType"].ToString());
                model.noOfBanquetGuest = Convert.ToInt32(Session["noOfGuests"].ToString());

                return PartialView("_BanquetSearch", model);
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region display banquet enquiry
        [HttpGet]
        public ActionResult BanquetEnquiry()
        {
            try
            {
                LawnEnquiry objUnit = new LawnEnquiry();

                if (SessionManager.IsSessionActive("destination") && SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("functionType"))
                {
                    objUnit.destinationID = Convert.ToInt32(Session["destination"].ToString());
                    objUnit.lawnBookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                    objUnit.noOfLawnGuest = Convert.ToInt32(Session["noOfGuests"].ToString());
                    objUnit.functionID = Convert.ToInt32(Session["functionType"].ToString());

                    ViewBag.Hotel = objBusinessClass.GetUnitsByDestination(objUnit.destinationID).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

                    return View(objUnit);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region save banquet enquiry
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BanquetEnquiry(LawnEnquiry model)
        {
            try
            {
                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (SessionManager.IsSessionActive("destination") && SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("functionType"))
                    {
                        ModelState["document"].Errors.Clear();
                        ModelState["remark"].Errors.Clear();
                        ModelState["amount"].Errors.Clear();

                        if (ModelState.IsValid)
                        {
                            model.ipAddress = this.Request.UserHostAddress;
                            model.destinationID = Convert.ToInt32(Session["destination"].ToString());
                            model.lawnBookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                            model.noOfLawnGuest = Convert.ToInt32(Session["noOfGuests"].ToString());
                            model.functionID = Convert.ToInt32(Session["functionType"].ToString());
                            model.enquiryType = "Banquet";
                            LawnEnquiry result = objBusinessClass.InsertLawnEnquiry(model);
                            if (result != null)
                            {
                                try
                                {
                                    ModelState.Clear();
                                    TempData["enquiryNo"] = result.enquiryNo;
                                    SendLawnBanquetEnquiryEmail(result.enquiryNo);
                                    return RedirectToAction("BanquetEnquiryConfirmation");
                                }
                                catch
                                { }
                            }
                        }

                        ViewBag.Hotel = objBusinessClass.GetUnitsByDestination(Convert.ToInt32(Session["destination"].ToString())).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });

                        return View(model);
                    }
                    else
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }
                }
                else
                {
                    ViewBag.cMSG = "Captcha field - Entered text does not match";
                    ViewBag.Hotel = objBusinessClass.GetUnitsByDestination(Convert.ToInt32(Session["destination"].ToString())).Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
                    return View(model);
                }
            }
            catch
            { }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region banquet booking enquiry confirmation
        public ActionResult BanquetEnquiryConfirmation()
        {
            LawnEnquiry model = new LawnEnquiry();
            try
            {
                if (TempData.Peek("enquiryNo") != null)
                {
                    model = objBusinessClass.GetLawnBanquetEnquiry(TempData.Peek("enquiryNo").ToString());
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        /*-------------End Banquet Booking Enquiry-------------*/

        /*-------------Package Tours-------------*/

        #region display package tours search
        [HttpGet]
        public ActionResult PackageTours()
        {
            try
            {
                ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.Nationality = GetNationality();

                return PartialView("_PackageTours");
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }
        #endregion

        #region display package tours search panel
        [HttpGet]
        public ActionResult PackageToursSearch()
        {
            try
            {
                PackageTours model = new PackageTours();

                ViewBag.Category = objBusinessClass.GetPackageCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.Nationality = GetNationality();

                model.packageCategoryID = Convert.ToInt32(Session["tourDestination"].ToString());
                model.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                model.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                model.isIndian = Convert.ToInt16(Session["isIndian"].ToString());

                return PartialView("_packageTourSearch", model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }
        #endregion

        #region search package tours
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageTours(PackageTours model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!IsDateValid(model.arrivalDate, DateTime.Now, "PACK"))
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }

                    Session["tourDestination"] = model.packageCategoryID;
                    Session["arrivalDate"] = model.arrivalDate;
                    Session["noOfTourists"] = model.noOfTourists;
                    Session["isIndian"] = model.isIndian;
                    Session["noOfRooms"] = (int)Math.Ceiling((double)model.noOfTourists);

                    return RedirectToAction("PackageTourList", "UPTourism");
                }
                return RedirectToAction("Index", "UPTourism");
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display package tour list
        [HttpGet]
        public ActionResult PackageTourList()
        {
            try
            {
                PackageTours objPackageTours = new PackageTours();

                if (SessionManager.IsSessionActive("tourDestination") && SessionManager.IsSessionActive("arrivalDate") && SessionManager.IsSessionActive("noOfTourists") && SessionManager.IsSessionActive("isIndian"))
                {
                    objPackageTours.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    objPackageTours.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                    objPackageTours.isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                    objPackageTours.packageCategoryID = Convert.ToInt32(Session["tourDestination"].ToString());
                    objPackageTours.nationality = objPackageTours.isIndian == 1 ? "Indian" : "Foreigner";
                    //objPackageTours.noOfRooms = Convert.ToInt32(Session["noOfRooms"].ToString());

                    objPackageTours.IEPackageTours = objBusinessClass.GetCategoryWisePackageList(objPackageTours.packageCategoryID, objPackageTours.isIndian, objPackageTours.noOfTourists, objPackageTours.arrivalDate.Month, objPackageTours.arrivalDate);
                    objPackageTours.packageCategoryName = objPackageTours.IEPackageTours.Select(p => p.packageCategoryName).Distinct().FirstOrDefault();
                    return View(objPackageTours);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }

        }
        #endregion

        #region display package tour send query
        [HttpGet]
        public ActionResult PackageTourQuery()
        {
            return PartialView("_SendQuery");
        }
        #endregion

        #region package tour save query
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageTourQuery(PackageQuery model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                    {
                        model.queryFor = "PACK";
                        //int result = objBusinessClass.InsertPackageTourQuery(model);
                        PackageQuery result = objBusinessClass.InsertPackageTourQuery(model);
                        if (result != null)
                        {
                            try
                            {
                                SendCustomerQueryEMail(result.name, result.emailID, result.mobileNo, result.query, result.queryDate, result.packageName, result.queryFor, result.packageID);
                            }
                            catch
                            { }
                            return Json(new { result = true }, JsonRequestBehavior.AllowGet);
                        }
                    }
                    else
                    {
                        return Json(new { result = false, message = "Enter correct captcha text!" }, JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch
            { }
            return Json(new { result = false, message = "Error in sending query!" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region display package tour details
        [HttpGet]
        public ActionResult PackageTourDetails(int Id)
        {
            try
            {
                PackageToursDetails obj_PackageTours = new PackageToursDetails();
                if (Session["arrivalDate"] != null)
                {
                    DateTime arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_PackageTours = objBusinessClass.GetPackageDisplayinfo(Id, Convert.ToInt32(Session["noOfTourists"]), arrivalDate);
                    obj_PackageTours.policyList = objBusinessClass.GetPackagePolicyList(Id);
                    obj_PackageTours.accomodationList = objBusinessClass.GetPackageAccomodationList(Id);
                    obj_PackageTours.contactList = objBusinessClass.GetPackageContactList(Id);
                    obj_PackageTours.itenararyList = objBusinessClass.GetPackageItenararyList(Id);
                    obj_PackageTours.imageList = objBusinessClass.GetPackageImageList(Id);

                    if (obj_PackageTours != null)
                    {
                        return View(obj_PackageTours);
                    }

                    return View();
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region package tour booking
        [HttpGet]
        public ActionResult PackageTourBookNow(int Id)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                Session["packageID"] = Id;

                PackagePayment obj_PackagePayment = objBusinessClass.GetPackagePayment(Id, isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month);
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                obj_PackagePayment.nationality = isIndian == 1 ? "Indian" : "Foreigner";
                decimal x = obj_PackagePayment.packageAmountIncludingGST;
                decimal y = obj_PackagePayment.totalAmount;
                decimal z = obj_PackagePayment.taxPercentage;
                if (obj_PackagePayment.isTaxCalculated == 1)
                {
                    obj_PackagePayment.CalculatedGST = Math.Ceiling(x - y);
                }
                else
                {
                    obj_PackagePayment.CalculatedGST = Math.Ceiling((y * z) / 100);

                    obj_PackagePayment.packageAmountIncludingGST = obj_PackagePayment.CalculatedGST + obj_PackagePayment.totalAmount;
                }
               
                //if (obj_PackagePayment.isTaxCalculated == 1)
                //{                    
                //    obj_PackagePayment.totalAmount = x - y;
                //}
                //else
                //{
                //    obj_PackagePayment.totalAmount = (x * z)/100;
                //}
                if (obj_PackagePayment.availability == "0" || !obj_PackagePayment.isBookable || obj_PackagePayment.totalAmount <= 0)
                {
                    return RedirectToAction("PackageTourList", "UPTourism");
                }

                Session["bookingType"] = "PACK";
                Session["PrevURL"] = this.HttpContext.Request.RawUrl;
                //obj_PackagePayment.noOfRooms = (int)Math.Ceiling((double)obj_PackagePayment.noOfTourists / 2);
                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display package tour payment after login
        [HttpGet]
        public ActionResult PackageTourPayment()
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                PackagePayment obj_PackagePayment = objBusinessClass.GetPackagePayment(Convert.ToInt32(Session["packageID"].ToString()), isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month);

                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                obj_PackagePayment.nationality = isIndian == 1 ? "Indian" : "Foreigner";
                //obj_PackagePayment.noOfRooms = (int)Math.Ceiling((double)obj_PackagePayment.noOfTourists / 2);
                decimal x = obj_PackagePayment.packageAmountIncludingGST;
                decimal y = obj_PackagePayment.totalAmount;
                decimal z = obj_PackagePayment.taxPercentage;
                if (obj_PackagePayment.isTaxCalculated == 1)
                {
                    obj_PackagePayment.CalculatedGST = Math.Ceiling(x - y);
                }
                else
                {
                    obj_PackagePayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                }
                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;

                if (obj_PackagePayment.availability == "0" || !obj_PackagePayment.isBookable || obj_PackagePayment.totalAmount <= 0)
                {
                    return RedirectToAction("PackageTourList", "UPTourism");
                }

                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region save package tour request and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageTourPayment(PackagePayment model)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                ModelState.Clear();

                PackagePayment obj_PackagePayment = objBusinessClass.GetPackagePayment(Convert.ToInt32(Session["packageID"].ToString()), isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month);
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.noOfTourists = noOfTourists;
                obj_PackagePayment.isIndian = isIndian;
                //obj_PackagePayment.noOfRooms = (int)Math.Ceiling((double)obj_PackagePayment.noOfTourists / 2);
                obj_PackagePayment.userIP = this.Request.UserHostAddress;
                decimal x = obj_PackagePayment.packageAmountIncludingGST;
                decimal y = obj_PackagePayment.totalAmount;
                decimal z = obj_PackagePayment.taxPercentage;
                if (obj_PackagePayment.isTaxCalculated == 1)
                {
                    obj_PackagePayment.CalculatedGST = Math.Ceiling(x - y);
                    obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                }
                else
                {
                    obj_PackagePayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                    obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                }
                if (obj_PackagePayment.availability == "0" || !obj_PackagePayment.isBookable || obj_PackagePayment.totalAmount <= 0)
                {
                    return RedirectToAction("PackageTourList", "UPTourism");
                }

                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;


                obj_PackagePayment.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                obj_PackagePayment.currency = "INR";
                obj_PackagePayment.description = "";

                PostPaymentData result = objBusinessClass.InsertPackageBookRequest(obj_PackagePayment);

                if (result != null)
                {
                    if (result.RequestID == 0 || result.docketNo == "")
                    {
                        TempData["unavailableMessage"] = "Your Package Could Not Be Booked Due To Unavailabiity!";
                        return RedirectToAction("Unavailable", "UPTourism");
                    }
                    else
                    {
                        var reqID = HashValue(result.RequestID.ToString());
                        var docNo = HashValue(result.RequestID.ToString());

                        return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                    }
                }
                return View(obj_PackagePayment);
                //if (result != null)
                //{
                //    //Session["RequestID"] = HashValue(result.RequestID.ToString());
                //    //Session["docketNo"] = HashValue(result.docketNo);
                //    //return RedirectToAction("PaymentPost", "Payment");
                //    var reqID = HashValue(result.RequestID.ToString());
                //    var docNo = HashValue(result.docketNo);
                //    //return Redirect("http://localhost:50796/PaymentRequest.aspx?refNo=" + reqID + "&dcNo=" + docNo);
                //    return Redirect(ConfigurationManager.AppSettings["PG_URL"] + reqID + "&dcNo=" + docNo);
                //}

            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        /*-------------End Package Tours-------------*/

        /*-------------City Tours-------------*/
        #region city tours
        [HttpGet]
        public ActionResult CityTours()
        {
            try
            {
                ViewBag.Category = objBusinessClass.GetCityTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.Nationality = GetNationality();

                return PartialView("_CityTours");
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }

        }
        #endregion

        #region display city tours search panel
        [HttpGet]
        public ActionResult CityToursSearch()
        {
            try
            {
                CityTours model = new CityTours();

                ViewBag.Category = objBusinessClass.GetCityTourCategoryList().Select(e => new SelectListItem() { Text = e.PackageCategoryName, Value = e.PackageCategoryID.ToString() });
                ViewBag.Nationality = GetNationality();

                model.packageCategoryID = Convert.ToInt32(Session["tourDestination"].ToString());
                model.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                model.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                model.isIndian = Convert.ToInt16(Session["isIndian"].ToString());

                return PartialView("_CityTourSearch", model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }
        #endregion

        #region search city tours
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CityTours(CityTours model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!IsDateValid(model.arrivalDate, DateTime.Now, "CITY"))
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }
                    Session["tourDestination"] = model.packageCategoryID;
                    Session["arrivalDate"] = model.arrivalDate;
                    Session["noOfTourists"] = model.noOfTourists;
                    Session["isIndian"] = model.isIndian;
                    Session["noOfRooms"] = (int)Math.Ceiling((double)model.noOfTourists);

                    return RedirectToAction("CityTourList", "UPTourism");
                }
                return RedirectToAction("Index", "UPTourism");
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display city tour list
        [HttpGet]
        public ActionResult CityTourList()
        {
            try
            {
                CityTours objCityTours = new CityTours();

                if (SessionManager.IsSessionActive("tourDestination") && SessionManager.IsSessionActive("arrivalDate") && SessionManager.IsSessionActive("noOfTourists") && SessionManager.IsSessionActive("isIndian"))
                {
                    objCityTours.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    objCityTours.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                    objCityTours.isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                    objCityTours.packageCategoryID = Convert.ToInt32(Session["tourDestination"].ToString());
                    objCityTours.nationality = objCityTours.isIndian == 1 ? "Indian" : "Foreigner";

                    objCityTours.IECityTours = objBusinessClass.GetCategoryWiseCityTourList(objCityTours.packageCategoryID, objCityTours.isIndian, objCityTours.noOfTourists, objCityTours.arrivalDate.Month, objCityTours.arrivalDate);
                    objCityTours.IECityTours = objCityTours.IECityTours.Select(c => { c.arrivalDate = objCityTours.arrivalDate; return c; }).ToList();
                    objCityTours.packageCategoryName = objCityTours.IECityTours.Select(p => p.packageCategoryName).Distinct().FirstOrDefault();
                    return View(objCityTours);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }

        }
        #endregion

        #region display city tour send query
        [HttpGet]
        public ActionResult CityTourQuery()
        {
            return PartialView("_CityTourSendQuery");
        }
        #endregion

        #region city tour save query
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CityTourQuery(CityTourQuery model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                    {
                        model.queryFor = "CITY";
                        //int result = objBusinessClass.InsertCityTourQuery(model);
                        CityTourQuery result = objBusinessClass.InsertCityTourQuery(model);
                        if (result != null)
                        {
                            try
                            {
                                SendCustomerQueryEMail(result.name, result.emailID, result.mobileNo, result.query, result.queryDate, result.packageName, result.queryFor, result.packageID);
                            }
                            catch
                            { }
                            return Json(new { result = true }, JsonRequestBehavior.AllowGet);
                        }
                    }
                    else
                    {
                        return Json(new { result = false, message = "Enter correct captcha text!" }, JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch
            { }
            return Json(new { result = false, message = "Error in sending query!" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region display city tour details
        [HttpGet]
        public ActionResult CityTourDetails(int Id)
        {
            try
            {
                CityToursDetails obj_CityTours = new CityToursDetails();
                obj_CityTours = objBusinessClass.GetCityTourDisplayinfo(Id, Convert.ToInt32(Session["noOfTourists"]), Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_CityTours != null)
                {
                    obj_CityTours.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_CityTours.policyList = objBusinessClass.GetCityToursPolicyList(Id);
                    // obj_PackageTours.accomodationList = objBusinessClass.GetPackageAccomodationList(Id);
                    obj_CityTours.contactList = objBusinessClass.GetCityToursContactList(Id);
                    obj_CityTours.itenararyList = objBusinessClass.GetCityToursItenararyList(Id);
                    obj_CityTours.imageList = objBusinessClass.GetPackageImageList(Id);

                    return View(obj_CityTours);
                }
                else
                {
                    return RedirectToAction("CityTourList", "UPTourism");
                }

            }
            catch
            {
                return View();
            }
        }
        #endregion

        #region city tour booking
        [HttpGet]
        public ActionResult CityTourBookNow(int Id)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                Session["packageID"] = Id;

                CityTourPayment obj_PackagePayment = objBusinessClass.GetCityToursPayment(Id, isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month, Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_PackagePayment != null)
                {
                    obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                    obj_PackagePayment.nationality = isIndian == 1 ? "Indian" : "Foreigner";
                    decimal x = obj_PackagePayment.packageAmountIncludingGST;
                    decimal y = obj_PackagePayment.totalAmount;
                    decimal z = obj_PackagePayment.taxPercentage;
                    if (obj_PackagePayment.isTaxCalculated == 1)
                    {
                        obj_PackagePayment.CalculatedGST = Math.Ceiling(x - y);
                        obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                    }
                    else
                    {
                        obj_PackagePayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                        obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                    }
                    if (obj_PackagePayment.availability == "0" || !obj_PackagePayment.isBookable || obj_PackagePayment.totalAmount <= 0 || (obj_PackagePayment.packageCategoryID == 1 && obj_PackagePayment.arrivalDate.DayOfWeek.ToString().ToLower() == "friday"))
                    {
                        return RedirectToAction("CityTourList", "UPTourism");
                    }
                    Session["bookingType"] = "CITY";
                    Session["PrevURL"] = this.HttpContext.Request.RawUrl;

                    return View(obj_PackagePayment);
                }
                else
                {
                    return RedirectToAction("CityTourList", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display city tour payment after login
        [HttpGet]
        public ActionResult CityTourPayment()
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                CityTourPayment obj_CityTourPayment = objBusinessClass.GetCityToursPayment(Convert.ToInt32(Session["packageID"].ToString()), isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month, Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_CityTourPayment != null)
                {
                    obj_CityTourPayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_CityTourPayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                    obj_CityTourPayment.nationality = isIndian == 1 ? "Indian" : "Foreigner";
                    //obj_PackagePayment.noOfRooms = (int)Math.Ceiling((double)obj_PackagePayment.noOfTourists / 2);
                    decimal x = obj_CityTourPayment.packageAmountIncludingGST;
                    decimal y = obj_CityTourPayment.totalAmount;
                    decimal z = obj_CityTourPayment.taxPercentage;
                    if (obj_CityTourPayment.isTaxCalculated == 1)
                    {
                        obj_CityTourPayment.CalculatedGST = Math.Ceiling(x - y);
                        obj_CityTourPayment.taxAmount = obj_CityTourPayment.CalculatedGST;
                    }
                    else
                    {
                        obj_CityTourPayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                        obj_CityTourPayment.taxAmount = obj_CityTourPayment.CalculatedGST;
                    }
                    obj_CityTourPayment.customerName = SessionManager.DisplayName;
                    obj_CityTourPayment.customerEmail = SessionManager.Username;
                    obj_CityTourPayment.customerMobile = SessionManager.CustomerMobile;

                    if (obj_CityTourPayment.availability == "0" || !obj_CityTourPayment.isBookable || obj_CityTourPayment.totalAmount <= 0 || (obj_CityTourPayment.packageCategoryID == 1 && obj_CityTourPayment.arrivalDate.DayOfWeek.ToString().ToLower() == "friday"))
                    {
                        TempData["MSG"] = "Package not Available";
                        return RedirectToAction("CityTourList", "UPTourism");
                    }

                    return View(obj_CityTourPayment);
                }
                else
                {
                    return RedirectToAction("CityTourList", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region save city tour request and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CityTourPayment(CityTourPayment model)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                ModelState.Clear();

                CityTourPayment obj_CityToursPayment = objBusinessClass.GetCityToursPayment(Convert.ToInt32(Session["packageID"].ToString()), isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month, Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_CityToursPayment != null)
                {
                    obj_CityToursPayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_CityToursPayment.noOfTourists = noOfTourists;
                    obj_CityToursPayment.isIndian = isIndian;
                    //obj_PackagePayment.noOfRooms = (int)Math.Ceiling((double)obj_PackagePayment.noOfTourists / 2);
                    obj_CityToursPayment.userIP = this.Request.UserHostAddress;
                    decimal x = obj_CityToursPayment.packageAmountIncludingGST;
                    decimal y = obj_CityToursPayment.totalAmount;
                    decimal z = obj_CityToursPayment.taxPercentage;
                    if (obj_CityToursPayment.isTaxCalculated == 1)
                    {
                        obj_CityToursPayment.CalculatedGST = Math.Ceiling(x - y);
                        obj_CityToursPayment.taxAmount = obj_CityToursPayment.CalculatedGST;
                    }
                    else
                    {
                        obj_CityToursPayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                        obj_CityToursPayment.taxAmount = obj_CityToursPayment.CalculatedGST;
                    }
                    obj_CityToursPayment.customerName = SessionManager.DisplayName;
                    obj_CityToursPayment.customerEmail = SessionManager.Username;
                    obj_CityToursPayment.customerMobile = SessionManager.CustomerMobile;

                    if (obj_CityToursPayment.availability == "0" || !obj_CityToursPayment.isBookable || obj_CityToursPayment.totalAmount <= 0 || (obj_CityToursPayment.packageCategoryID == 1 && obj_CityToursPayment.arrivalDate.DayOfWeek.ToString().ToLower() == "friday"))
                    {
                        TempData["MSG"] = "Package not Available";
                        return RedirectToAction("CityTourList", "UPTourism");
                    }

                    obj_CityToursPayment.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    obj_CityToursPayment.currency = "INR";
                    obj_CityToursPayment.description = "";

                    PostPaymentData result = objBusinessClass.InsertCityToursBookRequest(obj_CityToursPayment);
                    if (result != null)
                    {
                        if (result.RequestID == 0 || result.docketNo == "")
                        {
                            TempData["unavailableMessage"] = "Your Package Could Not Be Booked Due To Unavailabiity!";
                            return RedirectToAction("Unavailable", "UPTourism");
                        }
                        else
                        {
                            var reqID = HashValue(result.RequestID.ToString());
                            var docNo = HashValue(result.RequestID.ToString());

                            return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                        }
                    }
                    return View(obj_CityToursPayment);
                }
                else
                {
                    return RedirectToAction("CityTourList", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion


        /*-------------End City Tours-------------*/

        /*-------------Auditorium Enquiry------------*/

        #region display auditorium search
        [HttpGet]
        public ActionResult Auditorium()
        {
            try
            {
                ViewBag.AudiFunctionType = objBusinessClass.GetAuditoriumFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });
                return PartialView("_Auditorium");
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }
        #endregion

        #region display auditorium details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Auditorium(AuditoriumEnquiry model)
        {
            try
            {

                if (ModelState.IsValidField("audibookingDate") && ModelState.IsValidField("noOfAudiGuest") && ModelState.IsValidField("audiFunctionID"))
                {
                    if (!IsDateValid(model.audibookingDate, DateTime.Now, "AUDI"))
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }

                    Session["checkInDate"] = model.audibookingDate;
                    Session["noOfGuests"] = model.noOfAudiGuest;
                    Session["functionType"] = model.audiFunctionID;

                    return RedirectToAction("AuditoriumEnquiry", "UPTourism");
                }
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region display auditorium search panel
        [HttpGet]
        public ActionResult AuditoriumSearch()
        {
            try
            {
                AuditoriumEnquiry model = new AuditoriumEnquiry();

                ViewBag.AudiFunctionType = objBusinessClass.GetAuditoriumFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });

                model.audibookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                model.audiFunctionID = Convert.ToInt32(Session["functionType"].ToString());
                model.noOfAudiGuest = Convert.ToInt32(Session["noOfGuests"].ToString());

                return PartialView("_AuditoriumSearch", model);
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region display auditorium enquiry
        [HttpGet]
        public ActionResult AuditoriumEnquiry()
        {
            try
            {
                AuditoriumEnquiry objAuditorium = new AuditoriumEnquiry();

                if (SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("functionType"))
                {
                    objAuditorium.audibookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                    objAuditorium.noOfAudiGuest = Convert.ToInt32(Session["noOfGuests"].ToString());
                    objAuditorium.audiFunctionID = Convert.ToInt32(Session["functionType"].ToString());

                    return View(objAuditorium);
                }
            }
            catch
            {
            }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region save auditorium enquiry
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AuditoriumEnquiry(AuditoriumEnquiry model)
        {
            try
            {
                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (SessionManager.IsSessionActive("checkInDate") && SessionManager.IsSessionActive("noOfGuests") && SessionManager.IsSessionActive("functionType"))
                    {
                        if (ModelState.IsValid)
                        {
                            model.ipAddress = this.Request.UserHostAddress;
                            model.audibookingDate = Convert.ToDateTime(Session["checkInDate"].ToString());
                            model.noOfAudiGuest = Convert.ToInt32(Session["noOfGuests"].ToString());
                            model.audiFunctionID = Convert.ToInt32(Session["functionType"].ToString());
                            model.enquiryType = "Auditorium";

                            AuditoriumEnquiry result = objBusinessClass.InsertAuditoriumEnquiry(model);
                            if (result != null)
                            {
                                try
                                {
                                    ModelState.Clear();
                                    TempData["enquiryNo"] = result.enquiryNo;
                                    SendAuditoriumEnquiryEmail(result.enquiryNo);
                                    return RedirectToAction("AuditoriumConfirmation");
                                }
                                catch
                                { }
                            }
                        }
                        return View(model);
                    }
                }
                else
                {
                    TempData["cMSG"] = "Captcha field - Entered text does not match";
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            { }
            return RedirectToAction("Index", "UPTourism");
        }
        #endregion

        #region auditorium booking enquiry confirmation
        public ActionResult AuditoriumConfirmation()
        {
            AuditoriumEnquiry model = new AuditoriumEnquiry();
            try
            {
                if (TempData.Peek("enquiryNo") != null)
                {
                    model = objBusinessClass.GetAuditoriumEnquiry(TempData.Peek("enquiryNo").ToString());
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        /*-------------Auditorium Enquiry------------*/

        /*----------------AC Bus Tour------------------*/

        #region ac bus tour package
        public ActionResult ACBusTours()
        {
            ViewBag.Nationality = GetNationality();

            return View();
        }
        #endregion

        #region display ac bus tours search panel
        [HttpGet]
        public ActionResult ACBusToursSearch()
        {
            try
            {
                ACBusTours model = new ACBusTours();

                ViewBag.Nationality = GetNationality();

                model.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                model.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                model.isIndian = Convert.ToInt16(Session["isIndian"].ToString());

                return PartialView("_ACBusTourSearch", model);
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }
        #endregion

        #region search ac bus tours
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ACBusTours(ACBusTours model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (!IsDateValid(model.arrivalDate, DateTime.Now, "ACBUS"))
                    {
                        return RedirectToAction("Index", "UPTourism");
                    }
                    Session["arrivalDate"] = model.arrivalDate;
                    Session["noOfTourists"] = model.noOfTourists;
                    Session["isIndian"] = model.isIndian;

                    return RedirectToAction("ACBusTourList", "UPTourism");
                }
                return RedirectToAction("Index", "UPTourism");
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display ac bus tour list
        [HttpGet]
        public ActionResult ACBusTourList()
        {
            try
            {
                ACBusTours objACBusTours = new ACBusTours();

                if (SessionManager.IsSessionActive("arrivalDate") && SessionManager.IsSessionActive("noOfTourists") && SessionManager.IsSessionActive("isIndian"))
                {
                    objACBusTours.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    objACBusTours.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                    objACBusTours.isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                    objACBusTours.nationality = objACBusTours.isIndian == 1 ? "Indian" : "Foreigner";

                    objACBusTours.IEACBusTours = objBusinessClass.GetBusPackageList(objACBusTours.isIndian, objACBusTours.noOfTourists, objACBusTours.arrivalDate.Month, objACBusTours.arrivalDate);
                    objACBusTours.IEACBusTours = objACBusTours.IEACBusTours.Select(c => { c.arrivalDate = objACBusTours.arrivalDate; return c; }).ToList();

                    return View(objACBusTours);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }

        }
        #endregion

        #region display ac bus tour send query
        [HttpGet]
        public ActionResult ACBusTourQuery()
        {
            return PartialView("_ACBusTourSendQuery");
        }
        #endregion

        #region ac bus tour save query
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ACBusTourQuery(ACBusTourQuery model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                    {
                        model.queryFor = "ACBUS";
                        //int result = objBusinessClass.InsertSpecialTourQuery(model);
                        ACBusTourQuery result = objBusinessClass.InsertSpecialTourQuery(model);
                        if (result != null)
                        {
                            try
                            {
                                SendCustomerQueryEMail(result.name, result.emailID, result.mobileNo, result.query, result.queryDate, result.packageName, result.queryFor, result.packageID);
                            }
                            catch
                            { }
                            return Json(new { result = true }, JsonRequestBehavior.AllowGet);
                        }
                    }
                    else
                    {
                        return Json(new { result = false, message = "Enter correct captcha text!" }, JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch
            { }
            return Json(new { result = false, message = "Error in sending query!" }, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region display ac bus tour details
        [HttpGet]
        public ActionResult ACBusTourDetails(int Id)
        {
            try
            {
                ACBusToursDetails obj_ACBusTours = new ACBusToursDetails();
                obj_ACBusTours = objBusinessClass.GetACBusDisplayinfo(Id, Convert.ToInt32(Session["noOfTourists"]), Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_ACBusTours != null)
                {
                    obj_ACBusTours.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_ACBusTours.policyList = objBusinessClass.GetACBusToursPolicyList(Id);
                    obj_ACBusTours.contactList = objBusinessClass.GetACBusToursContactList(Id);
                    obj_ACBusTours.itenararyList = objBusinessClass.GetACBusToursItenararyList(Id);
                    obj_ACBusTours.imageList = objBusinessClass.GetPackageImageList(Id);

                    return View(obj_ACBusTours);
                }
                else
                {
                    return RedirectToAction("ACBusTourList", "UPTourism");
                }
            }
            catch
            {
                return View();
            }
        }
        #endregion

        #region ac bus tour booking
        [HttpGet]
        public ActionResult ACBusTourBookNow(int Id)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                Session["packageID"] = Id;

                ACBusTourPayment obj_PackagePayment = objBusinessClass.GetACBusToursPayment(Id, isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month, Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_PackagePayment != null)
                {
                    obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                    obj_PackagePayment.nationality = isIndian == 1 ? "Indian" : "Foreigner";
                    decimal x = obj_PackagePayment.packageAmountIncludingGST;
                    decimal y = obj_PackagePayment.totalAmount;
                    decimal z = obj_PackagePayment.taxPercentage;
                    if (obj_PackagePayment.isTaxCalculated == 1)
                    {
                        obj_PackagePayment.CalculatedGST = Math.Ceiling(x - y);
                        obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                    }
                    else
                    {
                        obj_PackagePayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                        obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                        obj_PackagePayment.packageAmountIncludingGST = obj_PackagePayment.CalculatedGST + obj_PackagePayment.totalAmount;
                    }

                    if (obj_PackagePayment.availability == "0" || obj_PackagePayment.totalAmount <= 0 || (obj_PackagePayment.packageCategoryID == 1 && obj_PackagePayment.arrivalDate.DayOfWeek.ToString().ToLower() == "friday"))
                    {
                        return RedirectToAction("ACBusTourList", "UPTourism");
                    }

                    string url = this.HttpContext.Request.RawUrl;
                    Session["bookingType"] = "ACBUS";
                    Session["PrevURL"] = url;



                    return View(obj_PackagePayment);
                }
                else
                {
                    return RedirectToAction("ACBusTourList", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display ac bus tour payment after login
        [HttpGet]
        public ActionResult ACBusTourPayment()
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                ACBusTourPayment obj_PackagePayment = objBusinessClass.GetACBusToursPayment(Convert.ToInt32(Session["packageID"].ToString()), isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month, Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_PackagePayment != null)
                {
                    obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                    obj_PackagePayment.nationality = isIndian == 1 ? "Indian" : "Foreigner";
                    decimal x = obj_PackagePayment.packageAmountIncludingGST;
                    decimal y = obj_PackagePayment.totalAmount;
                    decimal z = obj_PackagePayment.taxPercentage;
                    if (obj_PackagePayment.isTaxCalculated == 1)
                    {
                        obj_PackagePayment.CalculatedGST = Math.Ceiling(x - y);
                        obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                    }
                    else
                    {
                        obj_PackagePayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                        obj_PackagePayment.taxAmount = obj_PackagePayment.CalculatedGST;
                    }

                    if (obj_PackagePayment.availability == "0" || obj_PackagePayment.totalAmount <= 0 || (obj_PackagePayment.packageCategoryID == 1 && obj_PackagePayment.arrivalDate.DayOfWeek.ToString().ToLower() == "friday"))
                    {
                        return RedirectToAction("ACBusTourList", "UPTourism");
                    }

                    obj_PackagePayment.customerName = SessionManager.DisplayName;
                    obj_PackagePayment.customerEmail = SessionManager.Username;
                    obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;

                    return View(obj_PackagePayment);
                }
                else
                {
                    return RedirectToAction("ACBusTourList", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region save ac bus tour request and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ACBusTourPayment(ACBusTourPayment model)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                ModelState.Clear();

                ACBusTourPayment obj_ACBusToursPayment = objBusinessClass.GetACBusToursPayment(Convert.ToInt32(Session["packageID"].ToString()), isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month, Convert.ToDateTime(Session["arrivalDate"].ToString()));
                if (obj_ACBusToursPayment != null)
                {
                    obj_ACBusToursPayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                    obj_ACBusToursPayment.noOfTourists = noOfTourists;
                    obj_ACBusToursPayment.isIndian = isIndian;
                    decimal x = obj_ACBusToursPayment.packageAmountIncludingGST;
                    decimal y = obj_ACBusToursPayment.totalAmount;
                    decimal z = obj_ACBusToursPayment.taxPercentage;
                    if (obj_ACBusToursPayment.isTaxCalculated == 1)
                    {
                        obj_ACBusToursPayment.CalculatedGST = Math.Ceiling(x - y);
                        obj_ACBusToursPayment.taxAmount = obj_ACBusToursPayment.CalculatedGST;
                    }
                    else
                    {
                        obj_ACBusToursPayment.CalculatedGST = Math.Ceiling((y * z) / 100);
                        obj_ACBusToursPayment.taxAmount = obj_ACBusToursPayment.CalculatedGST;
                    }

                    obj_ACBusToursPayment.userIP = this.Request.UserHostAddress;

                    obj_ACBusToursPayment.customerName = SessionManager.DisplayName;
                    obj_ACBusToursPayment.customerEmail = SessionManager.Username;
                    obj_ACBusToursPayment.customerMobile = SessionManager.CustomerMobile;

                    if (obj_ACBusToursPayment.availability == "0" || obj_ACBusToursPayment.totalAmount <= 0 || (obj_ACBusToursPayment.packageCategoryID == 1 && obj_ACBusToursPayment.arrivalDate.DayOfWeek.ToString().ToLower() == "friday"))
                    {
                        return RedirectToAction("ACBusTourList", "UPTourism");
                    }

                    obj_ACBusToursPayment.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    obj_ACBusToursPayment.currency = "INR";
                    obj_ACBusToursPayment.description = "";

                    PostPaymentData result = objBusinessClass.InsertACBusToursBookRequest(obj_ACBusToursPayment);
                    if (result != null)
                    {
                        if (result.RequestID == 0 || result.docketNo == "")
                        {
                            TempData["unavailableMessage"] = "Your Package Could Not Be Booked Due To Unavailabiity!";
                            return RedirectToAction("Unavailable", "UPTourism");
                        }
                        else
                        {
                            var reqID = HashValue(result.RequestID.ToString());
                            var docNo = HashValue(result.RequestID.ToString());

                            return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                        }
                    }
                    return View(obj_ACBusToursPayment);
                }
                else
                {
                    return RedirectToAction("ACBusTourList", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion


        /*----------------End AC Bus Tour------------------*/


        /*-------------Packages at a Glance-------------*/

        #region display all package categories
        public ActionResult PackageAndTourList()
        {
            try
            {
                PackageAndTour objPackageTours = new PackageAndTour();

                objPackageTours.lstPackage = objBusinessClass.GetPackageCategoryList();
                objPackageTours.lstCity = objBusinessClass.GetCityTourCategoryList();
                return View(objPackageTours);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display list of selected package category
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PackageAndTourList(PackageAndTour objModel)
        {
            PackageAndTour objPackageTours = new PackageAndTour();
            objPackageTours.lstPackage = objBusinessClass.GetPackageCategoryList();
            objPackageTours.lstCity = objBusinessClass.GetCityTourCategoryList();
            try
            {
                if (objModel.tourType != "acbus")
                {
                    Session["tourDestination"] = objModel.tourId;

                }
                else
                {
                }
                Session["noOfTourists"] = 1;
                Session["arrivalDate"] = DateTime.Now;
                Session["isIndian"] = 1;

                if (SessionManager.IsSessionActive("arrivalDate") && SessionManager.IsSessionActive("noOfTourists") && SessionManager.IsSessionActive("isIndian"))
                {
                    if (objModel.tourType == "pack")
                    {
                        return RedirectToAction("PackageTourList", "UPTourism");
                    }
                    else if (objModel.tourType == "city")
                    {
                        return RedirectToAction("CityTourList", "UPTourism");
                    }
                    else if (objModel.tourType == "acbus")
                    {
                        return RedirectToAction("ACBusTourList", "UPTourism");
                    }
                }
            }
            catch (Exception)
            {

            }
            return View(objPackageTours);
        }
        #endregion

        /*-------------End Packages at a Glance-------------*/

        /*----------------Tonga Ride------------------*/

        #region display tonga ride
        [HttpGet]
        public ActionResult LKOTongaRide()
        {
            TongaRide obj = new TongaRide();
            obj.noOfTourists = 4;
            return View(obj);
        }
        #endregion

        #region select tonga ride
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LKOTongaRide(TongaRide obj)
        {
            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOTongaRide", "UPTourism");
                }

                Int16 isIndian = 1;
                decimal Amount = 0;

                isIndian = obj.RouteFare == 619 ? Convert.ToInt16(1) : (obj.RouteFare == 750 ? Convert.ToInt16(0) : Convert.ToInt16(2));
                int noOfTourists = obj.noOfTourists;
               
                if (!IsDateValid(obj.arrivalDate, DateTime.Now, "TANGA"))
                {
                    return RedirectToAction("Index", "UPTourism");
                }
                else
                {
                    PackagePayment obj_PackagePayment = new PackagePayment();
                    Amount = obj.RouteFare;//package
                    obj.taxPercentage = 5;
                    obj.taxAmount = Math.Ceiling((5 * Amount) / 100);//tax amount
                    obj.CalculatedGST = obj.taxAmount + Amount;
                    Session["arrivalDate"] = obj.arrivalDate;
                    Session["noOfTourists"] = obj.noOfTourists;
                    Session["packageName"] = obj.RouteType;
                    Session["totalAmount"] = obj.CalculatedGST;//total
                    Session["PackageAmount"] = Amount;//PackageAmount
                    Session["TaxAmont"] = obj.taxAmount;//Amount of tax
                    Session["arrivalTime"] = obj.arrivalTime;
                    return RedirectToAction("TongaRideBookNow");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region  Tonga Ride booking
        [HttpGet]
        public ActionResult TongaRideBookNow()
        {
            try
            {
                PackagePayment obj_PackagePayment = new PackagePayment();
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"]);
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"]);
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"]);
                obj_PackagePayment.packageAmountIncludingGST = Convert.ToDecimal(Session["totalAmount"]);
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOTongaRide", "UPTourism");
                }

                Session["bookingType"] = "TONGA";
                Session["PrevURL"] = this.HttpContext.Request.RawUrl;

                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display Tonga Ride payment after login
        [HttpGet]
        public ActionResult TongaRidePayment()
        {
            try
            {
                PackagePayment obj_PackagePayment = new PackagePayment();
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"]);
                obj_PackagePayment.packageAmountIncludingGST = Convert.ToDecimal(Session["totalAmount"].ToString());
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOTongaRide", "UPTourism");
                }
                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;
                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region save package tour request and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TongaRidePayment(PackagePayment model)
        {
            try
            {

                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                ModelState.Clear();

                PackagePayment obj_PackagePayment = new PackagePayment();
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.noOfTourists = noOfTourists;
                obj_PackagePayment.packageAmountIncludingGST = Convert.ToDecimal(Session["totalAmount"].ToString());
                obj_PackagePayment.totalAmount = obj_PackagePayment.packageAmountIncludingGST;
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"]);
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);
                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);
                obj_PackagePayment.taxPercentage = 5;

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOTongaRide", "UPTourism");
                }

                obj_PackagePayment.userIP = this.Request.UserHostAddress;
                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;
                obj_PackagePayment.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                obj_PackagePayment.currency = "INR";
                obj_PackagePayment.description = "";

                PostPaymentData result = objBusinessClass.InsertTongaRideBookRequest(obj_PackagePayment);
                if (result != null)
                {
                    var reqID = HashValue(result.RequestID.ToString());
                    var docNo = HashValue(result.RequestID.ToString());

                    return Redirect(ConfigurationManager.AppSettings["PG_URL"] + reqID + "&dcNo=" + docNo);
                }
                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        /*----------------End Tonga Ride------------------*/


        /*----------------Cycle Tour------------------*/

        #region display cycle tour
        public ActionResult LKOonCycle()
        {
            CycleTours obj = new CycleTours();
            //  obj.RouteType = "R1I";
            return View(obj);
        }
        #endregion

        #region select cycle tour
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LKOonCycle(CycleTours obj)
        {
            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOonCycle", "UPTourism");
                }

                Int16 isIndian = 1;
                decimal Amount = 0;
                //isIndian=obj.RouteFare==500?Convert.ToInt16(1):(obj.RouteFare == 750 ? Convert.ToInt16(0) : Convert.ToInt16(2));
                isIndian = obj.RouteFare == 500 ? Convert.ToInt16(1) : (obj.RouteFare == 750 ? Convert.ToInt16(0) : Convert.ToInt16(2));
                int noOfTourists = obj.noOfTourists;
                if (!IsDateValid(obj.arrivalDate, DateTime.Now, "CYCLE"))
                {
                    return RedirectToAction("Index", "UPTourism");
                }
                else
                {
                    PackagePayment obj_PackagePayment = new PackagePayment();
                    Amount = obj.RouteFare;
                    obj.taxPercentage = 5;
                    obj.taxAmount = Math.Ceiling((5 * Amount) / 100);//tax amount
                    obj.CalculatedGST = obj.noOfTourists*(obj.taxAmount + Amount);
                    Session["arrivalDate"] = obj.arrivalDate;
                    Session["noOfTourists"] = obj.noOfTourists;
                    Session["ApplicantType"] = isIndian == 1 ? "Indian" : (isIndian == 0 ? "Foreigner" : "Student");
                    Session["packageName"] = obj.RouteType;
                    Session["totalAmount"] = obj.CalculatedGST;//TOTAL
                    Session["PackageAmount"] = Amount;//PackageAmount
                    Session["TaxAmont"] = obj.taxAmount;//Amount of tax
                    Session["isIndian"] = isIndian;
                    Session["arrivalTime"] = obj.arrivalTime;
                    return RedirectToAction("CycleTourBookNow");

                    
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region Cycle tour booking
        [HttpGet]
        public ActionResult CycleTourBookNow()
        {
            try
            {
                PackagePayment obj_PackagePayment = new PackagePayment();
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"]);
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"]);
                obj_PackagePayment.ApplicantType = Convert.ToString(Session["ApplicantType"]);
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"]);
                obj_PackagePayment.totalAmount = Convert.ToDecimal(Session["totalAmount"]);

                obj_PackagePayment.isIndian = Convert.ToInt16(Session["isIndian"]);
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);
                obj_PackagePayment.taxPercentage = 5;

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOonCycle", "UPTourism");
                }
                Session["bookingType"] = "CYCLE";
                Session["PrevURL"] = this.HttpContext.Request.RawUrl;

                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display Cycle tour payment after login
        [HttpGet]
        public ActionResult CycleTourPayment()
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                PackagePayment obj_PackagePayment = new PackagePayment();// objBusinessClass.GetPackagePayment(Convert.ToInt32(Session["packageID"].ToString()), isIndian, noOfTourists, Convert.ToDateTime(Session["arrivalDate"].ToString()).Month);

                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                obj_PackagePayment.ApplicantType = Convert.ToString(Session["ApplicantType"].ToString());
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"].ToString());
                obj_PackagePayment.totalAmount = Convert.ToDecimal(Session["totalAmount"].ToString());
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);
                obj_PackagePayment.taxPercentage = 5;

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOonCycle", "UPTourism");
                }

                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;
                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region save package tour request and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CycleTourPayment(PackagePayment model)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                ModelState.Clear();

                PackagePayment obj_PackagePayment = new PackagePayment();
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"].ToString());
                obj_PackagePayment.noOfTourists = noOfTourists;
                obj_PackagePayment.totalAmount = Convert.ToDecimal(Session["totalAmount"].ToString());
                obj_PackagePayment.isIndian = isIndian;
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);
                obj_PackagePayment.ApplicantType = Convert.ToString(Session["ApplicantType"].ToString());

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);
                obj_PackagePayment.taxPercentage = 5;

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LKOonCycle", "UPTourism");
                }
                obj_PackagePayment.maxBookingAllowed = ConfigurationManager.AppSettings["TotalCycle"] != null ? Convert.ToInt32(ConfigurationManager.AppSettings["TotalCycle"]) : 10;
                obj_PackagePayment.userIP = this.Request.UserHostAddress;
                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;
                obj_PackagePayment.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                obj_PackagePayment.currency = "INR";
                obj_PackagePayment.description = "";

                PostPaymentData result = objBusinessClass.InsertCycleTourBookRequest(obj_PackagePayment);
                if (result != null && result.RequestID > 0)
                {
                    var reqID = HashValue(result.RequestID.ToString());
                    var docNo = HashValue(result.RequestID.ToString());

                    return Redirect(ConfigurationManager.AppSettings["PG_URL"] + reqID + "&dcNo=" + docNo);
                }
                else if (result != null && result.RequestID == 0)
                {
                    TempData["msg"] = "Selected Package is not available. Please select an other package.";
                    return RedirectToAction("LKOonCycle", "UPTourism");

                }

                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        /*----------------End Cycle Tour------------------*/

        /*----------------Heritage Walk------------------*/

        #region display heritage walk
        [HttpGet]
        public ActionResult LkoHeritageWalk()
        {
            return View();
        }
        #endregion

        #region select heritage walk
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LkoHeritageWalk(HeritageWalk obj)
        {
            try
            {
                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LkoHeritageWalk", "UPTourism");
                }

                Int16 isIndian = 1;
                decimal Amount = 0;
                isIndian = (obj.RouteFare == 220 ? Convert.ToInt16(1) : Convert.ToInt16(2));
                int noOfTourists = obj.noOfTourists;
                if (!IsDateValid(obj.arrivalDate, DateTime.Now, "WALK"))
                {
                    return RedirectToAction("Index", "UPTourism");
                }
                else
                {
                    PackagePayment obj_PackagePayment = new PackagePayment();
                    Amount = obj.RouteFare;
                    obj.taxPercentage = 5;
                    obj.taxAmount = Math.Ceiling((5 * Amount) / 100);//tax amount
                    obj.CalculatedGST = obj.noOfTourists * (obj.taxAmount + Amount);
                    Session["arrivalDate"] = obj.arrivalDate;
                    Session["noOfTourists"] = obj.noOfTourists;
                    Session["packageName"] = obj.RouteType;
                    Session["totalAmount"] = obj.CalculatedGST;//TOTAL
                    Session["PackageAmount"] = Amount;//PackageAmount
                    Session["TaxAmont"] = Math.Ceiling(obj.taxAmount);//Amount of tax
                    Session["isIndian"] = isIndian;
                    Session["nationality"] = isIndian == 1 ? "Indian" : "Foreigner";
                    Session["arrivalTime"] = obj.arrivalTime;
                    return RedirectToAction("HeritageWalkBookNow");

                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region  Heritage Walk booking
        [HttpGet]
        public ActionResult HeritageWalkBookNow()
        {
            try
            {
                PackagePayment obj_PackagePayment = new PackagePayment();
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"]);
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"]);
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"]);
                obj_PackagePayment.totalAmount = Convert.ToDecimal(Session["totalAmount"]);
                obj_PackagePayment.isIndian = Convert.ToInt16(Session["isIndian"]);
                obj_PackagePayment.nationality = Convert.ToString(Session["nationality"]);
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);
                obj_PackagePayment.taxPercentage = 5;

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LkoHeritageWalk", "UPTourism");
                }
                Session["bookingType"] = "WALK";
                Session["PrevURL"] = this.HttpContext.Request.RawUrl;

                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region display Heritage Walk payment after login
        [AuthorizeUser]
        [HttpGet]
        public ActionResult HeritageWalkPayment()
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                PackagePayment obj_PackagePayment = new PackagePayment();

                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                obj_PackagePayment.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
                obj_PackagePayment.nationality = Convert.ToString(Session["nationality"].ToString());
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"].ToString());
                obj_PackagePayment.totalAmount = Convert.ToDecimal(Session["totalAmount"].ToString());
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);
                obj_PackagePayment.taxPercentage = 5;

                
                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LkoHeritageWalk", "UPTourism");
                }

                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;
                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        #region save heritage walk request and proceed to payment gateway
        [AuthorizeUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult HeritageWalkPayment(PackagePayment model)
        {
            try
            {
                Int16 isIndian = Convert.ToInt16(Session["isIndian"].ToString());
                int noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());

                ModelState.Clear();

                PackagePayment obj_PackagePayment = new PackagePayment();
                obj_PackagePayment.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
                // obj_PackagePayment.arrivalDate = Convert.ToDateTime("08/09/2015");
                obj_PackagePayment.noOfTourists = noOfTourists;
                obj_PackagePayment.totalAmount = Convert.ToDecimal(Session["totalAmount"].ToString());
                obj_PackagePayment.isIndian = isIndian;
                obj_PackagePayment.nationality = Convert.ToString(Session["nationality"].ToString());
                obj_PackagePayment.arrivalTime = Convert.ToDateTime(Session["arrivalTime"]);

                obj_PackagePayment.packageAmount = Convert.ToDecimal(Session["PackageAmount"]);
                obj_PackagePayment.taxAmount = Convert.ToDecimal(Session["TaxAmont"]);
                obj_PackagePayment.taxPercentage = 5;

                DateTime minDate = DateTime.Now.AddDays(1);
                if (obj_PackagePayment.arrivalDate < minDate.Date)
                {
                    return RedirectToAction("LkoHeritageWalk", "UPTourism");
                }

                obj_PackagePayment.userIP = this.Request.UserHostAddress;
                obj_PackagePayment.customerName = SessionManager.DisplayName;
                obj_PackagePayment.customerEmail = SessionManager.Username;
                obj_PackagePayment.customerMobile = SessionManager.CustomerMobile;
                obj_PackagePayment.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                obj_PackagePayment.currency = "INR";
                obj_PackagePayment.description = "";
                obj_PackagePayment.packageName = Convert.ToString(Session["packageName"]);
                PostPaymentData result = objBusinessClass.InsertHeritageWalkBookRequest(obj_PackagePayment);
                if (result != null)
                {
                    var reqID = HashValue(result.RequestID.ToString());
                    var docNo = HashValue(result.RequestID.ToString());

                    return Redirect(ConfigurationManager.AppSettings["PG_URL"] + reqID + "&dcNo=" + docNo);
                }
                return View(obj_PackagePayment);
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion

        /*----------------End Heritage Walk------------------*/

        /*----------------Booking History------------------*/

        #region display booking history
        [AuthorizeUser]
        public ActionResult BookingHistory()
        {
            CancelBooking obj = new CancelBooking();
            try
            {
                if (TempData["message"] != null && TempData["message"].ToString() != "")
                {
                    ViewBag.Show = TempData["message"];
                }
                obj.userid = SessionManager.UserID;
                obj.lstCancelBookingDetails = objBusinessClass.GetBookingHistory(obj.userid);
            }
            catch
            { }
            return View(obj);



        }
        #endregion

        #region Print Booked and Checkout Details------------------------------By BRAMH
        [AuthorizeUser]
        public ActionResult PrintBookingdetails(string id)
        {
            BookingDetails objPay = new BookingDetails();
            try
            {
                objPay = PrintBookedCheckoutDetails(id);
                if (objPay != null)
                {
                    return View("PrintBookedCheckOutDetails", objPay);
                }

                else
                {
                    return RedirectToAction("BookingHistory", "UPTourism");
                }

            }
            catch
            {

            }
            return View("PrintBookedCheckOutDetails", objPay);

        }
        #endregion

        #region Print By Bramh On 26/10/2014
        [AuthorizeUser]
        public BookingDetails PrintBookedCheckoutDetails(string merchantRefNo)
        {
            BookingDetails objPay = new BookingDetails();
            try
            {
                objPay = objBusinessClass.GetbookedCheckoutDetailsForPrint(merchantRefNo);
                if (objPay != null)
                {
                    if (objPay.BookingFor == "PACK")
                    {
                        objPay.BookingFor = "Package";
                    }
                    else if (objPay.BookingFor == "UNIT")
                    {
                        objPay.BookingFor = "Hotel";
                    }
                    else if (objPay.BookingFor == "CITY")
                    {
                        objPay.BookingFor = "One Day Tour";
                    }
                    else if (objPay.BookingFor == "T")
                    {
                        objPay.BookingFor = "TAXI";
                    }
                    else if (objPay.BookingFor == "B")
                    {
                        objPay.BookingFor = "BUS";
                    }
                    else if (objPay.BookingFor == "ACBUS" || objPay.BookingFor == "CYCLE" || objPay.BookingFor == "TONGA" || objPay.BookingFor == "WALK")
                    {
                        objPay.BookingFor = "Special Package";
                    }
                    if (objPay.packageID != 0 && objPay.packageID > 0)
                    {
                        objPay.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(objPay.packageID);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objPay;
        }
        #endregion

        #region print cancelled details
        [AuthorizeUser]
        public ActionResult PrintCanceledDetails(string id)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            try
            {

                obj_BookingList = objBusinessClass.getDetailsOfCancellationConfirmation(id);
                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(id);
                }
            }
            catch
            {

            }

            return View(obj_BookingDetail);

        }
        #endregion

        /*----------------End Booking History------------------*/

        /*----------------Cancel Booking------------------*/

        #region display cancel booking confirmation
        [AuthorizeUser]
        [HttpGet]
        public ActionResult ConfirmCancelBooking(string id)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            try
            {
                // id = Request.QueryString["id"];
                //id = OTPL_Imp.CustomCryptography.Decrypt(id.ToString());
                Session["docketNoForCancel"] = id;

                obj_BookingList = objBusinessClass.DetailsOfBookingForCancellation(id);

                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    if (obj_BookingDetail.refaundAmountPer > 0)
                    {
                        obj_BookingDetail.refaundAmount = ((obj_BookingDetail.refaundAmountPer * obj_BookingDetail.amount) / 100);
                    }
                    else
                    {
                        obj_BookingDetail.refaundAmount = 0;
                    }
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(id);
                }
                return View("CancellationConfirmation", obj_BookingDetail);
            }
            catch
            {

            }
            return View("CancellationConfirmation", obj_BookingDetail);
        }
        #endregion

        #region confirm booking cancellation
        [AuthorizeUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ConfirmCancelBooking()
        {
            string id = Convert.ToString(Session["docketNoForCancel"]);

            #region Calculate cancilaton amount
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            obj_BookingList = objBusinessClass.DetailsOfBookingForCancellation(id);

            if (obj_BookingList != null && obj_BookingList.Count > 0)
            {
                obj_BookingDetail = obj_BookingList.FirstOrDefault();
                if (obj_BookingDetail.refaundAmountPer > 0)
                {
                    obj_BookingDetail.refaundAmount = ((obj_BookingDetail.refaundAmountPer * obj_BookingDetail.amount) / 100);
                }
                else
                {
                    obj_BookingDetail.refaundAmount = 0;
                }
                obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
            }
            #endregion

            var CancelDetails = objBusinessClass.CancelBooking(id, obj_BookingDetail.refaundAmountPer, obj_BookingDetail.refaundAmount);
            if (!string.IsNullOrEmpty(CancelDetails.cancelRefNo) && !string.IsNullOrEmpty(CancelDetails.BookingFor))
            {
                //Send Email
                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmail(id);
                // Send SMS to customer
                SendCancelRequestSMS(id, SessionManager.CustomerMobile, IEContactDetails, CancelDetails.BookingFor, CancelDetails.refaundAmount);
                SendCancelRequestEMail(id, SessionManager.Username, IEContactDetails, CancelDetails.BookingFor, CancelDetails.refaundPer.ToString(), CancelDetails.refaundAmount.ToString());

                // TempData["message"] = "Request Cancelled Successfully. Cancel Reference No. is: " + CancelDetails.cancelRefNo + " and Docket No. is: " + id;
                //return RedirectToAction("BookingHistory", "UPTourism");
                return RedirectToAction("CancellationConfirmation", "UPTourism");
            }
            else
            {
                TempData["message"] = "Request Not Cancelled.";
            }
            return RedirectToAction("BookingHistory", "UPTourism");
        }
        #endregion

        #region to send sms on booking cancellation
        protected void SendCancelRequestSMS(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails, string BookingFor, decimal refoundAmt)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["CancelBookingSMSByUser"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[Amount]", refoundAmt.ToString());

                string UntAndNodelMsg = ConfigurationManager.AppSettings["CancelBookingSMSByUserForCRS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UntAndNodelMsg = UntAndNodelMsg.Replace("[DocketNo]", docketNo);
                UntAndNodelMsg = UntAndNodelMsg.Replace("[Amount]", refoundAmt.ToString());
                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (BookingFor == "UNIT")
                            {
                                if (lst.sendTo == "UNIT")
                                {
                                    SMSStatus = SMS.SMSSend(UntAndNodelMsg, lst.MobileNo);    // Send SMS to Unit
                                    SMS.SMSLog(UntAndNodelMsg, lst.MobileNo, docketNo, SMSStatus);
                                }
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(UntAndNodelMsg, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UntAndNodelMsg, lst.MobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        //#region confirm booking cancellation      
        //public ActionResult BookingCancel()
        //{


        //        //Send Email
        //        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmail(id);
        //        SendCancelRequestEMail(id, "jodha.bs27@gmail.com", IEContactDetails, "UNIT");

        //        return View();
        //}
        //#endregion

        #region to send mail on booking cancellation
        protected void SendCancelRequestEMail(string docketNo, string mailTo, IEnumerable<OfficerContactDetails> contactDetails, string BookingFor, string refundPer, string refundAmount)
        {
            try
            {
                string MailBody, subject, MailBodyOthers;

                SpecialBookedDetail obj_BookingList = objBusinessClass.getDetailsOfCancellationConfirmation(docketNo).FirstOrDefault();

                if (obj_BookingList.BookingFor.ToUpper() == "UNIT")
                {
                    subject = "UP Tourism Room Booking Cancellation Request";
                    StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/RoomCancelRequest.html"));
                    MailBody = reader.ReadToEnd();
                    MailBody = MailBody.Replace("[docketno]", docketNo);
                    MailBody = MailBody.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBody = MailBody.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBody = MailBody.Replace("[hotelname]", obj_BookingList.UnitName);
                    MailBody = MailBody.Replace("[hoteladdress]", obj_BookingList.unitAddress);
                    MailBody = MailBody.Replace("[hotelphone]", obj_BookingList.unitMobile);
                    MailBody = MailBody.Replace("[roomtype]", obj_BookingList.roomType);
                    MailBody = MailBody.Replace("[noofrooms]", obj_BookingList.noOfRooms.ToString());
                    MailBody = MailBody.Replace("[extrabed]", obj_BookingList.extraBed.ToString());
                    MailBody = MailBody.Replace("[checkindate]", obj_BookingList.checkinDate);
                    MailBody = MailBody.Replace("[checkoutdate]", obj_BookingList.checkoutDate);
                    MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                    MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBody = MailBody.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBody = MailBody.Replace("[RefundPercent]", refundPer);
                    MailBody = MailBody.Replace("[refundAmount]", refundAmount);

                    StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/RoomCancelRequest.html"));
                    MailBodyOthers = readerOthers.ReadToEnd();
                    MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBodyOthers = MailBodyOthers.Replace("[hotelname]", obj_BookingList.UnitName);
                    MailBodyOthers = MailBodyOthers.Replace("[hoteladdress]", obj_BookingList.unitAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[hotelphone]", obj_BookingList.unitMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[roomtype]", obj_BookingList.roomType);
                    MailBodyOthers = MailBodyOthers.Replace("[noofrooms]", obj_BookingList.noOfRooms.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[extrabed]", obj_BookingList.extraBed.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[checkindate]", obj_BookingList.checkinDate);
                    MailBodyOthers = MailBodyOthers.Replace("[checkoutdate]", obj_BookingList.checkoutDate);
                    MailBodyOthers = MailBodyOthers.Replace("[customername]", obj_BookingList.name);
                    MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[RefundPercent]", refundPer);
                    MailBodyOthers = MailBodyOthers.Replace("[refundAmount]", refundAmount);
                }
                else if (obj_BookingList.BookingFor.ToUpper() == "PACK")
                {
                    obj_BookingList.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(obj_BookingList.packageID);

                    subject = "UP Tourism Package Booking Cancellation Request";
                    StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/PackageCancelRequest.html"));
                    MailBody = reader.ReadToEnd();
                    MailBody = MailBody.Replace("[docketno]", docketNo);
                    MailBody = MailBody.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBody = MailBody.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBody = MailBody.Replace("[packagename]", obj_BookingList.packageName);
                    MailBody = MailBody.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBody = MailBody.Replace("[duration]", obj_BookingList.duration);
                    MailBody = MailBody.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBody = MailBody.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBody = MailBody.Replace("[meetingpoint]", obj_BookingList.meetingPoint);
                    MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                    MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBody = MailBody.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBody = MailBody.Replace("[RefundPercent]", refundPer);
                    MailBody = MailBody.Replace("[refundAmount]", refundAmount);
                    StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/PackageCancelRequest.html"));
                    MailBodyOthers = readerOthers.ReadToEnd();
                    MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBodyOthers = MailBodyOthers.Replace("[packagename]", obj_BookingList.packageName);
                    MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBodyOthers = MailBodyOthers.Replace("[duration]", obj_BookingList.duration);
                    MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBodyOthers = MailBodyOthers.Replace("[meetingpoint]", obj_BookingList.meetingPoint);
                    MailBodyOthers = MailBodyOthers.Replace("[customername]", obj_BookingList.name);
                    MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[RefundPercent]", refundPer);
                    MailBodyOthers = MailBodyOthers.Replace("[refundAmount]", refundAmount);

                    string accomStr = "";
                    if (obj_BookingList.IEPackageAccomodation != null && obj_BookingList.IEPackageAccomodation.Count() > 0)
                    {
                        accomStr = "<table>";

                        foreach (var accom in obj_BookingList.IEPackageAccomodation)
                        {
                            accomStr += "<tr><td colspan='2' style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.daySequence + "</td></tr>" +
                                         "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>City Name</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.cityname + "</td></tr>" +
                                        "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Unit Name</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitName + "</td></tr>" +
                                        "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Address</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.unitAddress + "</td></tr>" +
                                        "<tr><td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>Room Type</td>" +
                                        "<td style='font-size: 12px; font-weight: 600; padding: 8px; color: #464646;'>" + accom.roomType + "</td></tr>";
                        }
                        accomStr += "</table>";
                    }

                    MailBody = MailBody.Replace("[accomodationdetails]", accomStr);
                    MailBodyOthers = MailBodyOthers.Replace("[accomodationdetails]", accomStr);
                }
                else
                {
                    subject = "UP Tourism Special Package Booking Cancellation Request";
                    StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/SplPackageCancelRequest.html"));
                    MailBody = reader.ReadToEnd();
                    MailBody = MailBody.Replace("[docketno]", docketNo);
                    MailBody = MailBody.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBody = MailBody.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBody = MailBody.Replace("[packagename]", obj_BookingList.packageName);
                    MailBody = MailBody.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBody = MailBody.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBody = MailBody.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                    MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBody = MailBody.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBody = MailBody.Replace("[RefundPercent]", refundPer);
                    MailBody = MailBody.Replace("[refundAmount]", refundAmount);

                    StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/SplPackageCancelRequest.html"));
                    MailBodyOthers = readerOthers.ReadToEnd();
                    MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                    MailBodyOthers = MailBodyOthers.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                    MailBodyOthers = MailBodyOthers.Replace("[packagename]", obj_BookingList.packageName);
                    MailBodyOthers = MailBodyOthers.Replace("[subpackagename]", obj_BookingList.subPackage);
                    MailBodyOthers = MailBodyOthers.Replace("[noofpersons]", obj_BookingList.noOfPerson.ToString());
                    MailBodyOthers = MailBodyOthers.Replace("[arrivaldate]", obj_BookingList.arrivalDate);
                    MailBodyOthers = MailBodyOthers.Replace("[customername]", obj_BookingList.name);
                    MailBodyOthers = MailBodyOthers.Replace("[customermobileno]", obj_BookingList.customerMobile);
                    MailBodyOthers = MailBodyOthers.Replace("[customeraddress]", obj_BookingList.customerAddress);
                    MailBodyOthers = MailBodyOthers.Replace("[RefundPercent]", refundPer);
                    MailBodyOthers = MailBodyOthers.Replace("[refundAmount]", refundAmount);

                }

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    SendMail.SendMailNew(mailTo, subject, MailBody);

                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                    //objService.sendMail(objMail);

                    //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                    //objService.sendMail(objMail);

                }

                foreach (var lst in contactDetails)
                {
                    try
                    {
                        if (BookingFor == "UNIT")
                        {
                            if (lst.sendTo == "UNIT")  // Send Email to Unit
                            {
                                SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                                //MailService.Service1 objService = new MailService.Service1();
                                //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                                //objService.sendMail(objMail);

                                //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = "gaurav@otpl.co.in" };
                                //objService.sendMail(objMail);

                            }
                        }
                        if (lst.sendTo == "NODAL")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);

                            //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = "gaurav@otpl.co.in" };
                            //objService.sendMail(objMail);

                        }
                        if (lst.sendTo == "UPTOURS")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);

                            //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = "gaurav@otpl.co.in" };
                            //objService.sendMail(objMail);

                        }
                    }
                    catch { }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region confirm cancellation
        [AuthorizeUser]
        [HttpGet]
        public ActionResult CancellationConfirmation()
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            try
            {
                //string docketNo =Convert.ToString(TempData["docketNo"]);
                string docketNo = Convert.ToString(Session["docketNoForCancel"]);

                obj_BookingList = objBusinessClass.getDetailsOfCancellationConfirmation(docketNo);
                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                }
                return View("CancellationConfirmation", obj_BookingDetail);
            }
            catch
            {

            }
            //BookingCancellation model = new BookingCancellation();
            return View("CancellationConfirmation", obj_BookingDetail);
            // return View();
        }
        #endregion

        #region print cancellation details
        [AuthorizeUser]
        public ActionResult PrintCancellationDetails(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            try
            {
                if (Session["docketNoForCancel"] != null)
                {
                    //string docketNo =Convert.ToString(TempData["docketNo"]);
                    docketNo = Convert.ToString(Session["docketNoForCancel"]);
                }
                Session["docketNoForCancel"] = null;
                obj_BookingList = objBusinessClass.getDetailsOfCancellationConfirmation(docketNo);
                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                }
            }
            catch
            {

            }
            //BookingCancellation model = new BookingCancellation();
            return View(obj_BookingDetail);
            // return View();
        }
        #endregion

        /*----------------End Cancel Booking------------------*/

        /*-----------------Cancellation Policy-------------------*/

        #region display cancellation policy
        [HttpGet]
        public ActionResult CancellationPolicy()
        {
            return View();
        }
        #endregion
        /*-----------------End Cancellation Policy-------------------*/

        //#region validate date 
        //public string IsDateValid(DateTime dtBooking)
        //{
        //    string returnMsg = string.Empty;
        //    DateTime minDate = DateTime.Now.AddDays(1);

        //    if (dtBooking < minDate.Date)
        //    {
        //        returnMsg = "Check In Date could not be past date";
        //    }          
        //    return returnMsg;
        //} 
        //#endregion

        //[HttpGet]
        //public JsonResult CancelBooking(string docketNo)
        //{
        //    string _msg = "";
        //   var CancelReffNo  = objBusinessClass.CancelBooking(docketNo);
        //   if (!string.IsNullOrEmpty(CancelReffNo.cancelRefNo))
        //    {
        //        TempData["message"] = "Request Cancelled Successfully. Cancel Refrence no. is: "+CancelReffNo.cancelRefNo +" and doceket no. is: "+docketNo;
        //        ViewBag.Show = TempData["message"];
        //       // return RedirectToAction("BookingHistory", "UPTourism");
        //       // _msg = TempData["message"];
        //        return Json(new { ViewBag.Show, JsonRequestBehavior.AllowGet });
        //    }
        //    else
        //    {
        //        ViewBag.Show = "Request Not Cancelled.";
        //    }
        //   // return RedirectToAction("BookingHistory", "UPTourism");
        //    ViewBag.Show = _msg;
        //    TempData["msg"] = _msg;
        //    return Json(new { result = true, message = "Unable to process!" });





        ////[AuthorizeUser]
        ////[HttpGet]
        ////public ActionResult CancelBooking()
        ////{
        ////    //CancelBooking obj = new CancelBooking();
        ////    //obj.userid = SessionManager.UserID;
        ////    //obj.lstCancelBookingDetails = objBusinessClass.GetBookingHistory(obj.userid);
        ////    string id = Convert.ToString(Session["docketNoForCancel"]);
        ////    var CancelDetails = objBusinessClass.CancelBooking(id);
        ////    if (!string.IsNullOrEmpty(CancelDetails.cancelRefNo) && !string.IsNullOrEmpty(CancelDetails.BookingFor))
        ////    {
        ////        //Send Email
        ////        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmail(id);
        ////        // Send SMS to customer
        ////        SendCancelRequestSMS(id, SessionManager.CustomerMobile, IEContactDetails, CancelDetails.BookingFor);
        ////        SendCancelRequestEMail(id, SessionManager.Username, IEContactDetails, CancelDetails.BookingFor);

        ////        // TempData["message"] = "Request Cancelled Successfully. Cancel Reference No. is: " + CancelDetails.cancelRefNo + " and Docket No. is: " + id;
        ////        //return RedirectToAction("BookingHistory", "UPTourism");
        ////        return RedirectToAction("CancellationConfirmation", "UPTourism");
        ////    }
        ////    else
        ////    {
        ////        TempData["message"] = "Request Not Cancelled.";
        ////    }
        ////    return RedirectToAction("BookingHistory", "UPTourism");
        ////}

        #region Method - get nationality
        public IEnumerable<SelectListItem> GetNationality()
        {
            var objNationality = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Indian";
            Temp.Value = "1";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Foreigner";
            Temp.Value = "0";
            objNationality.Add(Temp);

            return objNationality;
        }
        #endregion

        #region Method - hash value
        public string HashValue(string value)
        {
            return (Convert.ToInt64(value)).ToString("X");

        }
        #endregion

        //#region methods to validate
        //public string IsDateValid(UnitBooking model)
        //{
        //    string returnMsg = string.Empty;
        //    DateTime currDate = DateTime.Now.AddDays(-1);
        //    DateTime maxCheckInDate = currDate.AddDays(178);
        //    DateTime maxCheckOutDate = currDate.AddDays(179);
        //    if (model.checkInDate < currDate)
        //    {
        //        returnMsg = "Check In Date could not be past date";
        //    }
        //    else if (model.checkOutDate < currDate)
        //    {
        //        returnMsg = "Check Out Date could not be past date";
        //    }
        //    else if (model.checkOutDate < model.checkInDate)
        //    {
        //        returnMsg = "Check Out Date should be greater than Check In Date";
        //    }
        //    else if (model.checkInDate > maxCheckInDate)
        //    {
        //        returnMsg = "Booking can not be done for more than 180 days";
        //    }
        //    else if (model.checkOutDate > maxCheckOutDate)
        //    {
        //        returnMsg = "Booking can not be done for more than 180 days";
        //    }
        //    return returnMsg;
        //}

        //#endregion

        #region Method - to clear session
        private void ClearSession()
        {
            Session.Remove("destination");
            Session.Remove("checkInDate");
            Session.Remove("checkOutDate");
            Session.Remove("noOfGuests");
            Session.Remove("noOfRooms");
            Session.Remove("destinationName");
            Session.Remove("unitID");
            Session.Remove("singleRoom");
            Session.Remove("doubleRoom");
            Session.Remove("roomID");
            Session.Remove("extraBed");
            Session.Remove("privilegecard");
            Session.Remove("bookingType");
            Session.Remove("tourDestination");
            Session.Remove("arrivalDate");
            Session.Remove("noOfTourists");
            Session.Remove("isIndian");
            Session.Remove("packageID");
            Session.Remove("acbusArrivalDate");
            Session.Remove("acbusNoOfTourists");
            Session.Remove("acbusIsIndian");
            Session.Remove("acbusPackageID");
            Session.Remove("packageName");
            Session.Remove("totalAmount");
            Session.Remove("nationality");
            Session.Remove("ApplicantType");
            Session.Remove("paymentStatus");
            Session.Remove("PaymentID");
            Session.Remove("functionType");
            Session.Remove("enquiryNo");
        }
        #endregion

        #region Akhand-- Not in use now(Static Pages)
        public ActionResult PrayagDarshan()
        {
            return View();
        }
        public ActionResult LucknowDarshan()
        {
            return View();
        }
        public ActionResult AgraDarshan()
        {
            return View();
        }
        #endregion

        /*-----------------------Taxi Enquiry-------------------*/
        #region Display bus/ taxi enquiry
        [HttpGet]
        public ActionResult TaxiBusEnquiry()
        {
            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
            return View();
        }
        #endregion

        #region save bus/ taxi enquiry
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusEnquiry(BusTaxiEnquiry model)
        {
            try
            {
                ModelState["pickupTime"].Errors.Clear();
                if (Convert.ToString(Session["capimagetext"]) == model.Captcha)
                {
                    if (ModelState.IsValid)
                    {
                        model.ipAddress = this.Request.UserHostAddress;
                        BusTaxiEnquiry result = objBusinessClass.InsertBusTaxiEnquiry(model);
                        if (result != null)
                        {
                            try
                            {
                                ModelState.Clear();
                                TempData["enquiryNo"] = result.enquiryNo;
                                SendBusTaxiEnquiryEmail(result.enquiryNo);
                                return RedirectToAction("TaxiBusEnquiryConfirmation");
                            }
                            catch
                            { }
                            ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                            return View(model);
                        }
                    }
                }
                else
                {
                    ViewBag.Cmsg = "Captcha field - Entered text does not match";
                    ViewBag.UPTour = objBusinessClass.GetFromCityList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                    return View(model);
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region taxi/bus booking enquiry confirmation
        public ActionResult TaxiBusEnquiryConfirmation()
        {
            BusTaxiEnquiry model = new BusTaxiEnquiry();
            try
            {
                if (TempData.Peek("enquiryNo") != null)
                {
                    model = objBusinessClass.GetTaxiBusEnquiry(TempData.Peek("enquiryNo").ToString());
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region taxi/bus booking quotation
        public ActionResult TaxiBusQuotation(string id)
        {
            BusTaxiEnquiryReply model = new BusTaxiEnquiryReply();
            try
            {
                id = EncryptionDecryption.DecodeFrom64(Server.UrlDecode(id));

                model = objBusinessClass.GetTaxiBusEnquiryDetails(id);
                if (model != null)
                {
                    Session["bookingType"] = model.enquiryType.ToUpper();
                    Session["enquiryNo"] = model.enquiryNo;
                    Session["PrevURL"] = this.HttpContext.Request.RawUrl;
                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region taxi/bus booking proceed
        [HttpGet]
        public ActionResult TaxiBusPayment()
        {
            BusTaxiEnquiryReply model = new BusTaxiEnquiryReply();
            try
            {
                string enquiryNo = Convert.ToString(Session["enquiryNo"]);
                model = objBusinessClass.GetTaxiBusEnquiryDetails(enquiryNo);
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region save taxi/bus booking and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TaxiBusPayment(BusTaxiEnquiryReply model)
        {
            try
            {
                if (Session["enquiryNo"] != null && Convert.ToString(Session["enquiryNo"]) != "")
                {
                    ModelState.Clear();

                    string enquiryNo = Convert.ToString(Session["enquiryNo"]);
                    BusTaxiEnquiryReply obj_BusTaxi = objBusinessClass.GetTaxiBusEnquiryDetails(enquiryNo);
                    obj_BusTaxi.userIP = this.Request.UserHostAddress;
                    obj_BusTaxi.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    obj_BusTaxi.currency = "INR";
                    obj_BusTaxi.description = "";

                    PostPaymentData result = objBusinessClass.InsertBusTaxiBookRequest(obj_BusTaxi);

                    if (result != null && !string.IsNullOrEmpty(result.docketNo))
                    {
                        var reqID = HashValue(result.RequestID.ToString());
                        var docNo = HashValue(result.RequestID.ToString());

                        return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                    }
                    return View(obj_BusTaxi);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion
        /*-----------------------Taxi Enquiry-------------------*/


        //public ActionResult LKOonCycle()
        //{
        //    //CycleTours obj = new CycleTours();
        //    //obj.lstCycleToursProgram= objBusinessClass.GetCycleRouteDetails();
        //    //return View(obj);
        //}


        #region BOOKING CANCILATION
        [AuthorizeUser]
        [HttpGet]
        public ActionResult BookingCancellation()
        {
            return View();
        }

        [AuthorizeUser]
        [HttpGet]
        public ActionResult BookingDetailsCancellation(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            try
            {
                obj_BookingList = objBusinessClass.GetDetailsOfCancellation(docketNo);
                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                }
            }
            catch
            {

            }
            //BookingCancellation model = new BookingCancellation();
            return PartialView("_CancellationBooking", obj_BookingDetail);
        }

        [AuthorizeUser]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingCancellation(SpecialBookedDetail objCancellation)
        {
            string docketNo = objCancellation.docketNo;
            BookingCancellation obj_BookingCancellation = objBusinessClass.InsertBookingCancellationRequest(docketNo);
            return View("CancellationResponce", obj_BookingCancellation);
        }


        #endregion


        #region unavailable
        public ActionResult Unavailable()
        {
            return View();
        }
        #endregion

        //#region Roop Kanwar  On 19/09/2015 -- Not in Use
        //#region display list for At a glance
        //[HttpGet]
        //public ActionResult PackagesList()
        //{
        //    try
        //    {
        //        PackageTours objPackageTours = new PackageTours(); 
        //        Session["arrivalDate"] = DateTime.Now;
        //        Session["noOfTourists"] = 2;
        //        Session["isIndian"] = true; 

        //        if (SessionManager.IsSessionActive("tourDestination") && SessionManager.IsSessionActive("arrivalDate") && SessionManager.IsSessionActive("noOfTourists") && SessionManager.IsSessionActive("isIndian"))
        //        {
        //            objPackageTours.arrivalDate = Convert.ToDateTime(Session["arrivalDate"].ToString());
        //            objPackageTours.noOfTourists = Convert.ToInt32(Session["noOfTourists"].ToString());
        //            objPackageTours.isIndian = Convert.ToInt16(Session["isIndian"].ToString()); 
        //            objPackageTours.nationality = objPackageTours.isIndian == 1 ? "Indian" : "Foreigner";

        //            objPackageTours.IEPackageTours = objBusinessClass.GetAllPackageList(objPackageTours.isIndian, objPackageTours.noOfTourists, objPackageTours.arrivalDate.Month);

        //            return View(objPackageTours);
        //        }
        //        else
        //        {
        //            return RedirectToAction("Index", "UPTourism");
        //        }
        //    }
        //    catch
        //    {
        //        return View("_ErrorPageWebsite");
        //    }

        //}
        //#endregion
        //#endregion




        //#region Tonga Ride Booking
        //public ActionResult LucknowTongaRide()
        //{
        //    ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LTR").Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
        //    ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LTR").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
        //    TongaRide model = new TongaRide();
        //    model.noOfTourists = 4;
        //    model.arrivalDate = DateTime.Now;
        //    return View(model);
        //}
        //#endregion 
        //#region search ac bus tours
        //[HttpPost]
        //public ActionResult LucknowTongaRide(TongaRide model)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            Session["tongaArrivalDate"] = model.arrivalDate;
        //            Session["tongaNoOfTourists"] = model.noOfTourists;
        //            Session["tongaIsIndian"] = model.applicantTypeId;
        //            Session["tongaRoute"] = model.routeTypeId;
        //            return RedirectToAction("LucknowTongaRideDetails", "UPTourism");
        //        }
        //        return RedirectToAction("Index", "UPTourism");
        //    }
        //    catch
        //    {
        //        return View("_ErrorPageWebsite");
        //    }
        //}
        //#endregion


        //public ActionResult LucknowTongaRideDetails()
        //{

        //    try
        //    {
        //        TongaRide objTongaRide = new TongaRide();

        //        if (SessionManager.IsSessionActive("tongaArrivalDate") && SessionManager.IsSessionActive("tongaNoOfTourists") && SessionManager.IsSessionActive("tongaIsIndian") && SessionManager.IsSessionActive("tongaRoute"))
        //        {
        //            objTongaRide.arrivalDate = Convert.ToDateTime(Session["tongaArrivalDate"].ToString());
        //            objTongaRide.noOfTourists = Convert.ToInt32(Session["tongaNoOfTourists"].ToString());
        //            objTongaRide.applicantTypeId = Convert.ToInt16(Session["tongaIsIndian"].ToString());
        //            objTongaRide.routeTypeId = Convert.ToInt32(Session["tongaRoute"].ToString());
        //            objTongaRide.lstCycleToursProgram = objBusinessClass.GetCycleRouteDetails(objTongaRide.routeTypeId);
        //            return View(objTongaRide);
        //        }
        //        else
        //        {
        //            return RedirectToAction("Index", "UPTourism");
        //        }
        //    }
        //    catch
        //    {
        //        return View("_ErrorPageWebsite");
        //    }

        //}




        //#region cycle tour package by Roop Kanwar On 12/10/2015
        //public ActionResult CycleTours()
        //{
        //    ViewBag.Nationality = GetNationality();
        //    //ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC").Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
        //    //ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
        //    return View();
        //}

        //[HttpPost]
        //public ActionResult CycleTours(CycleTours model)
        //{
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            Session["cycleArrivalDate"] = model.arrivalDate;
        //            Session["cycleNoOfTourists"] = model.noOfTourists;
        //            //Session["cycleApplicantType"] = model.applicantTypeId;
        //            //Session["cycleRouteType"] = model.routeTypeId;
        //            Session["cycleIsIndian"] = model.isIndian;

        //            return RedirectToAction("CycleTourList", "UPTourism");
        //        }
        //        return RedirectToAction("Index", "UPTourism");
        //    }
        //    catch
        //    {
        //        return View("_ErrorPageWebsite");
        //    }
        //}

        //[HttpGet]
        //public ActionResult CycleTourList()
        //{
        //    try
        //    {
        //        CycleTours objCycleTours = new CycleTours();

        //        if (SessionManager.IsSessionActive("cycleArrivalDate") && SessionManager.IsSessionActive("cycleNoOfTourists") && SessionManager.IsSessionActive("cycleIsIndian"))
        //        {
        //            objCycleTours.arrivalDate = Convert.ToDateTime(Session["cycleArrivalDate"].ToString());
        //            objCycleTours.noOfTourists = Convert.ToInt32(Session["cycleNoOfTourists"].ToString());
        //            //objCycleTours.applicantTypeId = Convert.ToInt16(Session["cycleApplicantType"].ToString());
        //            //objCycleTours.routeTypeId = Convert.ToInt32(Session["cycleRouteType"].ToString());
        //            objCycleTours.isIndian = Convert.ToInt16(Session["cycleIsIndian"].ToString());
        //            objCycleTours.nationality = objCycleTours.isIndian == 1 ? "Indian" : "Foreigner";

        //            //objCycleTours.lstCycleToursProgram = objBusinessClass.GetCycleRouteDetails(objCycleTours.routeTypeId);
        //            ViewBag.Route = objBusinessClass.GetCycleToureRouteType("LOC").Select(e => new SelectListItem() { Text = e.routeTypeName, Value = e.routeTypeId.ToString() });
        //            ViewBag.applicantType = objBusinessClass.GetCycleApplicantType("LOC").Select(e => new SelectListItem() { Text = e.applicantTypeName, Value = e.applicantTypeId.ToString() });
        //            return View(objCycleTours);
        //        }
        //        else
        //        {
        //            return RedirectToAction("Index", "UPTourism");
        //        }
        //    }
        //    catch
        //    {
        //        return View("_ErrorPageWebsite");
        //    }

        //}
        //#endregion

        #region Print Cancelation History Start From here
        [AuthorizeUser]
        [HttpGet]
        public ActionResult PrintBooking(string id)
        {
            Payment objPay = new Payment();
            try
            {
                // string Getid = OTPL_Imp.CustomCryptography.Decrypt(id.ToString());
                // 'AGR15000176','43574700'
                objPay = PaymentConfirmationForPrintOnly(id, "");

                return View("PrintBooking", objPay);

            }
            catch
            {

            }
            return View("PrintBooking", objPay);
        }




        #region Payment Confirmation By Radhey On 17/10/2014
        [AuthorizeUser]
        public Payment PaymentConfirmationForPrintOnly(string merchantRefNo, string paymentId)
        {
            Payment objPay = new Payment();
            try
            {
                objPay = objBusinessClass.GetDetailsAfterPaymentForPrintOnly(merchantRefNo, paymentId);
                if (objPay != null)
                {
                    if (objPay.BookingFor == "PACK")
                    {
                        objPay.BookingFor = "Package";
                    }
                    else if (objPay.BookingFor == "UNIT")
                    {
                        objPay.BookingFor = "Hotel";
                    }
                    else if (objPay.BookingFor == "CITY")
                    {
                        objPay.BookingFor = "One Day Tour";
                    }
                    else if (objPay.BookingFor == "ACBUS" || objPay.BookingFor == "CYCLE" || objPay.BookingFor == "TONGA" || objPay.BookingFor == "WALK")
                    {
                        objPay.BookingFor = "Special Package";
                    }
                    if (objPay.packageID != null && objPay.packageID > 0)
                    {
                        objPay.IEPackageAccomodation = objBusinessClass.GetPackageAccomodationList(objPay.packageID);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return objPay;
        }
        #endregion







        #endregion

        #region to send mail on customer query
        protected void SendCustomerQueryEMail(string name, string email, string mobileNo, string query, string queryDate, string package, string queryType, int packageID)
        {
            try
            {
                string subject = "UP Tourism Package Tour Customer Query";
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/CustomerQuery.html"));

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[customername]", name);
                MailBody = MailBody.Replace("[customeremail]", email);
                MailBody = MailBody.Replace("[customermobileno]", mobileNo);
                MailBody = MailBody.Replace("[packagename]", package);
                MailBody = MailBody.Replace("[packagetype]", queryType);
                MailBody = MailBody.Replace("[querydate]", queryDate);
                MailBody = MailBody.Replace("[query]", query);

                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.GetContactForCustomerQuery(packageID);

                foreach (var lst in IEContactDetails)
                {
                    try
                    {
                        if (lst.sendTo == "NODAL")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);

                            //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = "gaurav@otpl.co.in" };
                            //objService.sendMail(objMail);

                        }
                        if (lst.sendTo == "UPTOURS")       // Send Email to Nodal Officer
                        {
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);

                            //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = "gaurav@otpl.co.in" };
                            //objService.sendMail(objMail);

                        }
                    }
                    catch { }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region check for valid date

        public bool IsDateValid(DateTime dtCheckin, DateTime dtCheckout, string type)
        {
            bool returnMsg = true;
            DateTime currDate = DateTime.Now;
            DateTime maxCheckInDate = currDate.AddDays(178);
            DateTime maxCheckOutDate = currDate.AddDays(179);
            DateTime minChekin = DateTime.Now.AddDays(1);

            if (type == "UNIT")
            {
                if ((dtCheckin < currDate.Date) || (dtCheckout < currDate) || (dtCheckout < dtCheckin) || (dtCheckin > maxCheckInDate) || (dtCheckout > maxCheckOutDate))
                {
                    returnMsg = false;
                }
            }
            if (type == "PACK" || type == "CITY" || type == "ACBUS" || type == "LAWN" || type == "CYCLE" || type == "CYCLE" || type == "WALK")
            {
                int cutoffTime = DateTime.Now.Hour;
                if (cutoffTime < 12)
                {
                    currDate = currDate.AddDays(1);
                }
                else
                {
                    currDate = currDate.AddDays(2);
                }
                if ((dtCheckin < currDate.Date) || (dtCheckin > maxCheckInDate))
                {
                    returnMsg = false;
                }
            }
            return returnMsg;
        }
        #endregion

        private void SendBusTaxiEnquiryEmail(string enquiryNo)
        {
            try
            {
                BusTaxiEnquiry model = objBusinessClass.GetTaxiBusEnquiry(enquiryNo);

                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/TaxiBusEnquiry.html"));
                string subject = "UP Tourism " + model.enquiryType + " Enquiry";

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[enquiryno]", model.enquiryNo);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);
                MailBody = MailBody.Replace("[message]", model.message);
                MailBody = MailBody.Replace("[fromcity]", model.fromCityName);
                MailBody = MailBody.Replace("[tocity]", model.toCity);
                MailBody = MailBody.Replace("[journeydate]", model.dateOfJourney.ToString("dd/MM/yyyy"));
                MailBody = MailBody.Replace("[returndate]", Convert.ToDateTime(model.dateOfReturn).ToString("dd/MM/yyyy"));
                MailBody = MailBody.Replace("[pickupdate]", model.pickupDate.ToString("dd/MM/yyyy"));
                MailBody = MailBody.Replace("[pickuptime]", model.pickupTime.ToShortTimeString());
                MailBody = MailBody.Replace("[pickupaddress]", model.pickupAddress);
                MailBody = MailBody.Replace("[enquirydate]", model.enquiryDate);

                try
                {

                    SendMail.SendMailNew(model.managerEmail, subject, MailBody);
                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.managerEmail };
                    //objService.sendMail(objMail);

                    SendMail.SendMailNew(model.CRSEmailID, subject, MailBody);
                    //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.CRSEmailID };
                    //objService.sendMail(objMail);


                }
                catch { }

            }
            catch (Exception)
            {
            }
        }

        private void SendLawnBanquetEnquiryEmail(string enquiryNo)
        {
            try
            {
                LawnEnquiry model = objBusinessClass.GetLawnBanquetEnquiry(enquiryNo);
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/LawnBanquetEnquiry.html"));
                string subject = "UP Tourism " + model.enquiryType + " Enquiry";

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[enquiryno]", model.enquiryNo);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);
                MailBody = MailBody.Replace("[message]", model.message);
                MailBody = MailBody.Replace("[hotel]", model.unitName);
                MailBody = MailBody.Replace("[bookingdate]", model.lawnBookingDate.ToString("dd/MM/yyyy"));
                MailBody = MailBody.Replace("[functiontype]", model.functionName);
                MailBody = MailBody.Replace("[noofguest]", model.noOfLawnGuest.ToString());
                MailBody = MailBody.Replace("[enquirydate]", model.enquiryDate);

                try
                {
                    SendMail.SendMailNew(model.unitEmail, subject, MailBody);
                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.unitEmail };
                    //objService.sendMail(objMail);
                    SendMail.SendMailNew(model.CRSEmailID, subject, MailBody);
                    //MailService.Service1 objService1 = new MailService.Service1();
                    //MailService.EmailData objMail1 = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.CRSEmailID };
                    //objService1.sendMail(objMail1);



                }
                catch { }

            }
            catch (Exception)
            {
            }
        }

        private void SendAuditoriumEnquiryEmail(string enquiryNo)
        {
            try
            {
                AuditoriumEnquiry model = objBusinessClass.GetAuditoriumEnquiry(enquiryNo);

                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/AuditoriumEnquiry.html"));
                string subject = "UP Tourism " + model.enquiryType + " Enquiry";

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[enquiryno]", model.enquiryNo);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);
                MailBody = MailBody.Replace("[message]", model.message);
                MailBody = MailBody.Replace("[bookingdate]", model.audibookingDate.ToString("dd/MM/yyyy"));
                MailBody = MailBody.Replace("[functiontype]", model.functionName);
                MailBody = MailBody.Replace("[noofguest]", model.noOfAudiGuest.ToString());
                MailBody = MailBody.Replace("[enquirydate]", model.enquiryDate);

                try
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.managerEmail };
                    //objService.sendMail(objMail);
                    SendMail.SendMailNew(model.managerEmail, subject, MailBody);

                }
                catch { }

            }
            catch (Exception)
            {
            }
        }

        #region display Taxi/Bus search
        [HttpGet]
        public ActionResult BusTaxi()
        {
            try
            {
                ViewBag.UPTour = objBusinessClass.GetFromCityBusTaxiList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                ViewBag.Nationality = GetTimeList();
                ViewBag.Duration = Duration();
                ViewBag.DurationLocal = DurationLocal();
                return PartialView("_BusTaxi");
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }
        }

        public JsonResult getOutStationDestinations()
        {
            var d = objBusinessClass.GetDestinationCityBusTaxiList();

            return Json(d, JsonRequestBehavior.AllowGet);
        }



        public JsonResult GetFromcityDet(int Cityid)
        {
            var d = objBusinessClass.GetFromCityDetails(Cityid);
            return Json(new { result = true, longitude = d.FirstOrDefault().Longitude, latitude = d.FirstOrDefault().Latitude });
        }
        public IEnumerable<SelectListItem> Duration()
        {
            var objDuration = new List<SelectListItem>();

            SelectListItem
              temp1 = new SelectListItem();
            temp1.Text = "Full Day";
            temp1.Value = "1";
            objDuration.Add(temp1);
            for (int i = 2; i <= 10; i++)
            {
                SelectListItem
               temp = new SelectListItem();
                temp.Text = i.ToString() + " " + "Days";
                temp.Value = i.ToString();
                objDuration.Add(temp);
            }

            return objDuration;
        }

        public IEnumerable<SelectListItem> DurationLocal()
        {
            var objDuration = new List<SelectListItem>();

            SelectListItem
              temp1 = new SelectListItem();
            temp1.Text = "Full Day";
            temp1.Value = "1";
            objDuration.Add(temp1);

            return objDuration;
        }

        [HttpParamAction]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult BusTaxi(BusTaxi model)
        {
            ModelState["enquiryTypeLocal"].Errors.Clear();
            ModelState["fromCityLocal"].Errors.Clear();

            ModelState["dateOfJourneyLocal"].Errors.Clear();
            ModelState["DurationLocal"].Errors.Clear();
            ModelState["noOfpersonLocal"].Errors.Clear();
            ModelState["AvilableTimeLocal"].Errors.Clear();
            ModelState["km"].Errors.Clear();
            if (ModelState.IsValid)
            {
                ModelState.Clear();
                model.km = CalculateDist(model.FromcityName, model.toCity);
                if (model.km > 0)
                {
                    Session["enquiryType"] = model.enquiryType;
                    Session["fromCity"] = model.fromCity;
                    Session["toCity"] = model.toCity;
                    Session["dateOfJourney"] = model.dateOfJourney;
                    Session["Duration"] = model.Duration;
                    Session["noOfperson"] = model.noOfperson;
                    Session["AvilableTime"] = model.AvilableTime;
                    Session["Type"] = "outstation";
                    Session["FromCityName"] = model.FromcityName;
                    Session["DispArrivtime"] = model.DispAvilableTime;
                    Session["KM"] = model.km;
                    Session["ToCityCode"] = model.ToCityCode;
                    Session["bookingType"] = "bustaxi";
                    Session["IsGuid"] = model.IsGuid;
                    return RedirectToAction("BusTaxiList");
                }
                else if (model.km == 1)
                {
                    return RedirectToAction("Index", "UPTourism");
                }
                else
                {
                    TempData["cMSG"] = "Distance Could Not calculated";
                    return RedirectToAction("Index", "UPTourism");
                }
            }

            return RedirectToAction("Index", "UPTourism");
        }
        decimal CalculateDist(string orgin, string Destination)
        {
            try
            {
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/GoogleSC.txt"));
                string Url = reader.ReadToEnd();
                Url = Url.Replace("[orgin]", orgin);
                Url = Url.Replace("[Destination]", Destination);

                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
                WebResponse response = request.GetResponse();
                Stream dataStream = response.GetResponseStream();
                StreamReader sreader = new StreamReader(dataStream);
                string responsereader = sreader.ReadToEnd();
                response.Close();

                XmlDocument xmldoc = new XmlDocument();
                xmldoc.LoadXml(responsereader);


                if (xmldoc.GetElementsByTagName("status")[0].ChildNodes[0].InnerText == "OK")
                {
                    XmlNodeList distance = xmldoc.GetElementsByTagName("distance");
                    decimal dd = Convert.ToDecimal(distance[0].ChildNodes[0].InnerText);
                    dd = dd / 1000;
                    dd = Math.Ceiling(dd);
                    decimal AdditionalKm = ConfigurationManager.AppSettings["AdditionalKM"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["AdditionalKM"]) : 30;
                    dd = dd + AdditionalKm;
                    return dd;
                }
                else
                {
                    return 0;
                }
            }
            catch (Exception ex)
            {
                TempData["cMSG"] = ex.Message;
                return 1;
            }

        }

        [HttpParamAction]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult LocalBusTaxi(BusTaxi model)
        {
            ModelState["enquiryType"].Errors.Clear();
            ModelState["fromCity"].Errors.Clear();
            ModelState["toCity"].Errors.Clear();
            ModelState["ToCityCode"].Errors.Clear();
            ModelState["dateOfJourney"].Errors.Clear();
            ModelState["Duration"].Errors.Clear();
            ModelState["noOfperson"].Errors.Clear();
            ModelState["AvilableTime"].Errors.Clear();
            ModelState["km"].Errors.Clear();

            if (ModelState.IsValid)
            {
                Session["enquiryType"] = model.enquiryTypeLocal;
                Session["fromCity"] = model.fromCityLocal;
                Session["toCity"] = model.FromcityName;
                Session["ToCityCode"] = model.fromCityLocal;
                Session["dateOfJourney"] = model.dateOfJourneyLocal;
                Session["Duration"] = model.DurationLocal;
                Session["noOfperson"] = model.noOfpersonLocal;
                Session["AvilableTime"] = model.AvilableTimeLocal;
                Session["Type"] = "local";
                Session["FromCityName"] = model.FromcityName;
                Session["DispArrivtime"] = model.DispAvilableTime;
                Session["KM"] = model.km;
                Session["bookingType"] = "bustaxi";
                Session["IsGuid"] = model.IsGuidLocal;
                return RedirectToAction("BusTaxiList");
            }

            return RedirectToAction("Index", "UPTourism");
        }

        [HttpGet]
        public ActionResult BusTaxiList()
        {
            if (SessionManager.IsSessionActive("enquiryType") && SessionManager.IsSessionActive("DispArrivtime") && SessionManager.IsSessionActive("FromCityName") && SessionManager.IsSessionActive("fromCity") && SessionManager.IsSessionActive("toCity") && SessionManager.IsSessionActive("dateOfJourney") && SessionManager.IsSessionActive("Duration") && SessionManager.IsSessionActive("noOfperson") && SessionManager.IsSessionActive("AvilableTime") && SessionManager.IsSessionActive("Type") && SessionManager.IsSessionActive("IsGuid"))
            {
                TaxiBusSearch model = new TaxiBusSearch();
                model.enquiryType = Convert.ToString(Session["enquiryType"]);
                model.fromCity = Convert.ToInt32(Session["fromCity"]);
                model.toCity = Convert.ToString(Session["toCity"]);
                model.dateOfJourney = Convert.ToDateTime(Session["dateOfJourney"]);
                model.Duration = Convert.ToString(Session["Duration"]);
                model.noOfperson = Convert.ToInt32(Session["noOfperson"]);
                model.AvilableTime = Convert.ToString(Session["AvilableTime"]);
                model.For = Convert.ToString(Session["Type"]);
                model.FromcityName = Convert.ToString(Session["FromCityName"]);
                model.DispAvilableTime = Convert.ToString(Session["DispArrivtime"]);
                model.ToCityCode = Convert.ToInt32(Session["ToCityCode"]);
                model.km = Convert.ToInt32(Session["KM"]);
                model.IsGuid = Convert.ToBoolean(Session["IsGuid"]);
                DateTime dd = Convert.ToDateTime(model.AvilableTime);
                model.HASGuid = model.IsGuid ? "Y" : "N";
                model.BusTaxi = objBusinessClass.GetBusTaxilist(model.fromCity, model.Duration, model.For, model.enquiryType, model.km, 0, dd, Convert.ToDateTime(Session["dateOfJourney"]), model.noOfperson);
                ViewBag.bookingFor = For();
                ViewBag.SenquiryType = EnqType();
                ViewBag.Uptours = objBusinessClass.GetFromCityBusTaxiList().Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityId.ToString() });
                if (Convert.ToString(Session["Type"]) == "local")
                {
                    ViewBag.SDuration = DurationLocal();
                }
                else
                {
                    ViewBag.SDuration = Duration();
                }

                ViewBag.Nationality = GetTimeList();
                return View(model);
            }
            else
            {
                return RedirectToAction("Index", "UPTourism");
            }

        }

        public IEnumerable<SelectListItem> For()
        {
            var BookingFor = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Local";
            Temp.Value = "local";
            BookingFor.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Outstation";
            Temp.Value = "outstation";
            BookingFor.Add(Temp);


            return BookingFor;
        }

        public IEnumerable<SelectListItem> EnqType()
        {
            var EnqTypeL = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "YES";
            Temp.Value = "Y";
            EnqTypeL.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "NO";
            Temp.Value = "N";
            EnqTypeL.Add(Temp);


            return EnqTypeL;
        }

        [HttpPost]
        public ActionResult ModifyBusTaxiSearch(TaxiBusSearch model)
        {



            Session["fromCity"] = model.fromCity;
            if (Convert.ToString(model.For) == "local")
            {
                Session["toCity"] = model.FromcityName;
                Session["ToCityCode"] = model.fromCity;
            }
            else
            {
                Session["toCity"] = model.toCity;
                Session["ToCityCode"] = model.ToCityCode;
                model.km = CalculateDist(model.FromcityName, model.toCity);
                if (model.km == 0)
                {
                    TempData["cMSG"] = "Distance Service is not working properly.";
                    return RedirectToAction("BusTaxiList");
                }
            }
            Session["dateOfJourney"] = model.dateOfJourney;
            Session["Duration"] = model.Duration;
            Session["noOfperson"] = model.noOfperson;
            Session["AvilableTime"] = model.AvilableTime;
            Session["Type"] = model.For;
            Session["FromCityName"] = model.FromcityName;
            Session["DispArrivtime"] = model.DispAvilableTime;
            Session["KM"] = model.km;

            Session["IsGuid"] = model.HASGuid == "Y" ? true : false;

            return RedirectToAction("BusTaxiList");


        }

        [HttpGet]
        public ActionResult BusTaxiBookingSummary(string id)
        {
            try
            {
                Int64 bustaxiid = Convert.ToInt32(id);
                if (SessionManager.IsSessionActive("enquiryType") && SessionManager.IsSessionActive("DispArrivtime") && SessionManager.IsSessionActive("FromCityName") && SessionManager.IsSessionActive("fromCity") && SessionManager.IsSessionActive("toCity") && SessionManager.IsSessionActive("dateOfJourney") && SessionManager.IsSessionActive("Duration") && SessionManager.IsSessionActive("noOfperson") && SessionManager.IsSessionActive("AvilableTime") && SessionManager.IsSessionActive("Type") && SessionManager.IsSessionActive("IsGuid"))
                {
                    BusTaxiPayment model = new BusTaxiPayment();
                    model.enquiryType = Convert.ToString(Session["enquiryType"]);
                    model.fromCity = Convert.ToInt32(Session["fromCity"]);
                    model.toCity = Convert.ToString(Session["toCity"]);
                    model.dateOfJourney = Convert.ToDateTime(Session["dateOfJourney"]);
                    model.Duration = Convert.ToString(Session["Duration"]);
                    model.noOfperson = Convert.ToInt32(Session["noOfperson"]);
                    model.AvilableTime = Convert.ToString(Session["AvilableTime"]);
                    model.For = Convert.ToString(Session["Type"]);
                    model.DispArrivalTime = Convert.ToString(Session["DispArrivtime"]);
                    model.FromCityName = Convert.ToString(Session["FromCityName"]);
                    model.km = Convert.ToInt32(Session["KM"]);
                    model.ToCityCode = Convert.ToInt32(Session["ToCityCode"]);
                    model.IsGuid = Convert.ToBoolean(Session["IsGuid"]);
                    Session["bustaxiid"] = bustaxiid;
                    DateTime dd = Convert.ToDateTime(model.AvilableTime);
                    model.BusTaxi = objBusinessClass.GetBusTaxilist(model.fromCity, model.Duration, model.For, model.enquiryType, model.km, bustaxiid, dd, Convert.ToDateTime(Session["dateOfJourney"]), model.noOfperson);

                    Session["PrevURL"] = this.HttpContext.Request.RawUrl;

                    return View(model);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return PartialView("_ErrorPagePartialWebsite");
            }


        }

        [HttpGet]
        public ActionResult BusTaxiPayment()
        {
            if (SessionManager.IsSessionActive("enquiryType") && SessionManager.IsSessionActive("DispArrivtime") && SessionManager.IsSessionActive("FromCityName") && SessionManager.IsSessionActive("fromCity") && SessionManager.IsSessionActive("toCity") && SessionManager.IsSessionActive("dateOfJourney") && SessionManager.IsSessionActive("Duration") && SessionManager.IsSessionActive("noOfperson") && SessionManager.IsSessionActive("AvilableTime") && SessionManager.IsSessionActive("Type"))
            {
                BusTaxiPayment model = new BusTaxiPayment();
                model.enquiryType = Convert.ToString(Session["enquiryType"]);
                model.fromCity = Convert.ToInt32(Session["fromCity"]);
                model.toCity = Convert.ToString(Session["toCity"]);
                model.dateOfJourney = Convert.ToDateTime(Session["dateOfJourney"]);
                model.Duration = Convert.ToString(Session["Duration"]);
                model.noOfperson = Convert.ToInt32(Session["noOfperson"]);
                model.AvilableTime = Convert.ToString(Session["AvilableTime"]);
                model.For = Convert.ToString(Session["Type"]);
                model.DispArrivalTime = Convert.ToString(Session["DispArrivtime"]);
                model.FromCityName = Convert.ToString(Session["FromCityName"]);
                Int64 bustaxiid = Convert.ToInt64(Session["bustaxiid"]);
                model.km = Convert.ToInt32(Session["KM"]);
                model.ToCityCode = Convert.ToInt32(Session["ToCityCode"]);
                model.IsGuid = Convert.ToBoolean(Session["IsGuid"]);
                DateTime dd = Convert.ToDateTime(model.AvilableTime);
                model.BusTaxi = objBusinessClass.GetBusTaxilist(model.fromCity, model.Duration, model.For, model.enquiryType, model.km, bustaxiid, dd, Convert.ToDateTime(Session["dateOfJourney"]), model.noOfperson);
                model.Tariff = model.BusTaxi[0].Tariff;
                model.customerName = SessionManager.DisplayName;
                model.customerEmail = SessionManager.Username;
                model.customerMobile = SessionManager.CustomerMobile;
                decimal servicetaxPer = ConfigurationManager.AppSettings["ServiceTaxBusTaxi"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["ServiceTaxBusTaxi"]) : 6;
                decimal guidetariff = model.IsGuid ? (model.BusTaxi[0].GuidTariff * Convert.ToDecimal(model.Duration)) : 0;

                model.Tariff = model.Tariff * model.BusTaxi[0].MaxCapacity;

                decimal servTaxAmt = ((model.Tariff + guidetariff) * servicetaxPer) / 100;
                model.serviceChargePer = servicetaxPer;
                model.amount = Math.Ceiling(model.Tariff + guidetariff + servTaxAmt);
                return View(model);
            }
            else
            {
                return RedirectToAction("Index", "UPTourism");
            }
        }

        public ActionResult fareBreakup(string id)
        {
            if (SessionManager.IsSessionActive("Duration") && SessionManager.IsSessionActive("Type") && SessionManager.IsSessionActive("KM") && SessionManager.IsSessionActive("DispArrivtime") && SessionManager.IsSessionActive("IsGuid") && SessionManager.IsSessionActive("noOfperson"))
            {
                FareBreakup obj = objBusinessClass.GetFareBreakup(Convert.ToString(Session["Duration"]), Convert.ToString(Session["Type"]), Convert.ToDecimal(Session["KM"]), Convert.ToInt64(id), Convert.ToDateTime(Convert.ToString(Session["DispArrivtime"])), Convert.ToInt32(Session["noOfperson"]));
                ModelState.Clear();
                decimal servicetaxPer = ConfigurationManager.AppSettings["ServiceTaxBusTaxi"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["ServiceTaxBusTaxi"]) : 6;
                obj.fromCityName = Convert.ToString(Session["FromCityName"]);
                obj.ToCityName = Convert.ToString(Session["toCity"]);
                int km = Math.Max(obj.KmByDuration, obj.KMDistance);
                obj.KMDistance = km;
                obj.IsGuid = Convert.ToBoolean(Session["IsGuid"]);
                obj.BasicTariff = obj.Tariff - obj.NightCharges;
                if (obj.IsGuid)
                {
                    obj.Tariff = (obj.busTaxiCount * obj.Tariff) + (obj.GuidTariff * obj.Duration);
                }

                obj.ServiceTaxPer = servicetaxPer;
                decimal servTaxAmt = (obj.Tariff * servicetaxPer) / 100;
                obj.ServiceTaxAmt = servTaxAmt;
                obj.TariffincludingSrTax = obj.Tariff + servTaxAmt;


                return View("_FareBreakup", obj);
            }
            else
            {
                return PartialView("_FareBreakup", null);
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BusTaxiPayment(BusTaxiPayment mo)
        {
            ModelState.Clear();
            BusTaxiPayment model = new BusTaxiPayment();
            model.enquiryType = Convert.ToString(Session["enquiryType"]);
            model.fromCity = Convert.ToInt32(Session["fromCity"]);
            model.toCity = Convert.ToString(Session["toCity"]);
            model.dateOfJourney = Convert.ToDateTime(Session["dateOfJourney"]);
            model.Duration = Convert.ToString(Session["Duration"]);
            model.noOfperson = Convert.ToInt32(Session["noOfperson"]);
            model.AvilableTime = Convert.ToString(Session["AvilableTime"]);
            model.For = Convert.ToString(Session["Type"]);
            model.IsGuid = Convert.ToBoolean(Session["IsGuid"]);
            model.DispArrivalTime = Convert.ToString(Session["DispArrivtime"]);
            model.FromCityName = Convert.ToString(Session["FromCityName"]);
            Int64 bustaxiid = Convert.ToInt64(Session["bustaxiid"]);
            model.km = Convert.ToInt32(Session["KM"]);
            model.ToCityCode = Convert.ToInt32(Session["ToCityCode"]);
            DateTime dd = Convert.ToDateTime(model.AvilableTime);
            var a = objBusinessClass.GetBusTaxilist(model.fromCity, model.Duration, model.For, model.enquiryType, model.km, bustaxiid, dd, Convert.ToDateTime(Session["dateOfJourney"]), model.noOfperson);
            model.customerName = SessionManager.DisplayName;
            model.customerEmail = SessionManager.Username;
            model.customerMobile = SessionManager.CustomerMobile;
            model.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
            model.BusTaxiId = a.FirstOrDefault().BusTaxiId;
            model.BusTaxiCount = a[0].MaxCapacity;
            decimal guidetariff = model.IsGuid ? (a[0].GuidTariff * Convert.ToDecimal(model.Duration)) : 0;
            model.GuidTariff = guidetariff;
            model.Tariff = a.FirstOrDefault().Tariff * a[0].MaxCapacity;
            model.currency = "INR";
            model.description = "";
            decimal servicetaxPer = ConfigurationManager.AppSettings["ServiceTaxBusTaxi"] != null ? Convert.ToDecimal(ConfigurationManager.AppSettings["ServiceTaxBusTaxi"]) : 6;
            decimal servTaxAmt = ((model.Tariff + model.GuidTariff) * servicetaxPer) / 100;
            model.serviceChargePer = servicetaxPer;
            model.amount = Math.Ceiling(model.Tariff + model.GuidTariff + servTaxAmt);
            model.servicetaxtAmt = servTaxAmt;

            PostPaymentData result = objBusinessClass.InsertBusTaxiBookRequest(model);

            if (result != null)
            {
                if (result.RequestID == 0 || result.docketNo == null || result.docketNo == "")
                {
                    TempData["unavailableMessage"] = "Taxi or Bus Could Not Be Booked Due To Unavailabiity!";
                    return RedirectToAction("Unavailable", "UPTourism");
                }
                else
                {
                    var reqID = HashValue(result.RequestID.ToString());
                    var docNo = HashValue(result.RequestID.ToString());

                    return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                }
            }
            return View();
        }
        #endregion



        #region Method - get Time Value in List
        public IEnumerable<SelectListItem> GetTimeList()
        {

            string Time24 = "";
            string Time12 = "";

            var objTimeList = new List<SelectListItem>();
            SelectListItem Temp;
            int SpanValue = 00;
            for (int i = 0; i < 96; i++)
            {
                TimeSpan spanetst = TimeSpan.FromMinutes(SpanValue);
                DateTime time = DateTime.Today + spanetst;
                Time12 = time.ToString("hh:mm tt");

                DateTime getTime24 = DateTime.Parse(Time12);
                getTime24.ToString("HH:mm");
                Time24 = getTime24.TimeOfDay.ToString();

                Temp = new SelectListItem();
                Temp.Text = Time12;
                Temp.Value = Time24;
                objTimeList.Add(Temp);
                SpanValue = SpanValue + 15;
            }

            return objTimeList;
        }
        #endregion



        #region Lawn/Banq booking quotation
        public ActionResult LawnBanqQuotation(string id)
        {
            LawnEnquiry model = new LawnEnquiry();
            try
            {
                id = EncryptionDecryption.DecodeFrom64(Server.UrlDecode(id));

                model = objBusinessClass.GetLawnBanquetEnquiry(id);
                if (model != null)
                {
                    Session["bookingType"] = model.enquiryType.ToUpper();
                    Session["enquiryNo"] = model.enquiryNo;
                    Session["PrevURL"] = this.HttpContext.Request.RawUrl;

                }
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region LawnBanq booking proceed
        [HttpGet]
        public ActionResult LawnBanqPayment()
        {
            LawnEnquiry model = new LawnEnquiry();
            if (Session["enquiryNo"] != null && Convert.ToString(Session["enquiryNo"]) != "")
            {
                try
                {
                    string enquiryNo = Convert.ToString(Session["enquiryNo"]);
                    model = objBusinessClass.GetLawnBanquetEnquiry(enquiryNo);
                }
                catch
                { }
            }
            else
            {
                return RedirectToAction("Index", "UPTourism");
            }
            return View(model);
        }
        #endregion

        #region save LawnBanq booking and proceed to payment gateway
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LawnBanqPayment(LawnEnquiry model)
        {
            try
            {
                if (Session["enquiryNo"] != null && Convert.ToString(Session["enquiryNo"]) != "")
                {
                    ModelState.Clear();

                    string enquiryNo = Convert.ToString(Session["enquiryNo"]);
                    LawnEnquiry obj_BusTaxi = objBusinessClass.GetLawnBanquetEnquiry(enquiryNo);
                    obj_BusTaxi.userIP = this.Request.UserHostAddress;
                    obj_BusTaxi.mode = ConfigurationManager.AppSettings["Mode"] != null ? ConfigurationManager.AppSettings["Mode"].ToString() : "LIVE";
                    obj_BusTaxi.currency = "INR";

                    obj_BusTaxi.description = "";

                    PostPaymentData result = objBusinessClass.InsertLawnBanquitBookRequest(obj_BusTaxi);

                    if (result != null && !string.IsNullOrEmpty(result.docketNo))
                    {
                        var reqID = HashValue(result.RequestID.ToString());
                        var docNo = HashValue(result.RequestID.ToString());

                        return Redirect(ConfigurationManager.AppSettings["PG_URL"].ToString() + reqID + "&dcNo=" + docNo);
                    }
                    return View(obj_BusTaxi);
                }
                else
                {
                    return RedirectToAction("Index", "UPTourism");
                }
            }
            catch
            {
                return View("_ErrorPageWebsite");
            }
        }
        #endregion


        #region DAILY SALE REPORT
        [AuthorizeOflineUnit]
        public ActionResult Dashboard()
        {
            return View();
        }

        [AuthorizeOflineUnit]
        public ActionResult FillSaleReport()
        {

            return View();
        }

        [AuthorizeOflineUnit]
        public ActionResult EditSale(string Date)
        {
            TempData["Date"] = DateTime.ParseExact(Date, "dd/MM/yyyy", null);
            return RedirectToAction("UnitDalySaleReport");
        }

        [AuthorizeOflineUnit]
        [HttpPost]
        public ActionResult FillSaleReport(FillSaleReport model)
        {
            if (ModelState.IsValid)
            {
                TempData["Date"] = model.saleDate;
                return RedirectToAction("UnitDalySaleReport", "UPTourism");
            }
            return View();
        }
        [AuthorizeOflineUnit]
        public ActionResult UnitDalySaleReport()
        {
            if (string.IsNullOrEmpty(Convert.ToString(TempData["Date"])))
            {
                return RedirectToAction("FillSaleReport");
            }
            else
            {
                DalySaleReportModel model1 = new DalySaleReportModel();
                try
                {
                    model1.SaleDate = (DateTime)TempData["Date"];
                }
                catch (Exception ex)
                {
                    TempData["msg"] = ex.Message;
                    return RedirectToAction("FillSaleReport");
                }
                DalySaleReportModel model = objBusinessClass.GetDalySaleReportforFillForm(SessionManager.UnitID, model1.SaleDate);
                model.SaleDate = model1.SaleDate;
                model.ViewSaleDate = model1.SaleDate.ToString("dd/MM/yyyy");

                model.TotalRevenuePreviousDate = model1.SaleDate.AddYears(-1).ToString("dd/MM/yyyy");

                return View(model);
            }
        }

        [AuthorizeOflineUnit]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UnitDalySaleReport(DalySaleReportModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    DalySaleReportModel msterData = objBusinessClass.GetDalySaleReportforFillForm(SessionManager.UnitID, model.SaleDate);
                    ModelState.Clear();
                    model.NameOfStation = msterData.NameOfStation;
                    model.NameofUnit = msterData.NameofUnit;
                    model.UnitId = msterData.UnitId;
                    model.TotalRooms = msterData.TotalRooms == 0 ? model.TotalRooms : msterData.TotalRooms;
                    model.TotalPerRoom = model.TotalRooms == 0 ? 0 : (model.OccupidRooms * 100) / model.TotalRooms;
                    model.Total = model.AccomodationCharges + model.Canteen + model.Bar + model.Miscellaneous + model.BanquitHallLawn;
                    model.Insertedby = SessionManager.UserID;
                    bool valid = true;
                    //if (model.TotalRooms < model.OccupidRooms)
                    //{
                    //    valid = false;
                    //    ModelState.AddModelError("OccupidRooms", "Occupied Rooms must less than Total Rooms !");
                    //    ViewBag.Show = "Occupied Rooms must less than Total Rooms !";
                    //}
                    if (valid && ModelState.IsValid)
                    {
                        int a = objBusinessClass.InsertUpdateDalySaleReport(model);
                        if (a > 0)
                        {
                            TempData["SD"] = model.SaleDate;
                            return RedirectToAction("DalyReportFillConfirmation");
                        }
                        else
                        {
                            ViewBag.Show = "Fail to insert Daly Report please try again !";
                        }
                    }

                }
                catch (Exception ex)
                {
                    ViewBag.Show = ex.Message;
                }
            }

            return View(model);

        }
        [AuthorizeOflineUnit]
        public ActionResult DalyReportFillConfirmation()
        {
            FillSaleReport model = new FillSaleReport();
            try
            {
                model.saleDate = (DateTime)TempData["SD"];
            }
            catch
            {

            }
            return View(model);
        }
        [AuthorizeOflineUnit]
        public ActionResult ViewDailySaleReport()
        {
            return View();
        }

        public ActionResult getDailySaleReportGrid(string fromdate, string Todate)
        {
            FillSaleReport model = new FillSaleReport();
            try
            {
                model.fromDate = DateTime.ParseExact(fromdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                //model.dtBookingDateFrom = null;
                model.fromDate = new DateTime(2016, 11, 1);
            }
            try
            {
                model.toDate = DateTime.ParseExact(Todate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                //model.dtBookingDateTo = null;
                model.toDate = DateTime.Now;
            }

            model.DalySalelist = objBusinessClass.GetDalySaleReportforView(SessionManager.UnitID, model.fromDate, model.toDate, 1);
            return PartialView("_DalySaleReportGrid", model.DalySalelist);
        }
        #endregion

        #region FOR VIEW TARIFF ON SELECTION OF UNIT AND DATES

        public ActionResult UnitListForTariff()
        {
            ViewBag.UnitList = objBusinessClass.GetallUnit(0).Where(e => e.IsOnline).ToList().Select(e => new SelectListItem() { Text = (e.UnitName + ", " + e.DestinationName), Value = e.UnitId.ToString() });
            return View();
        }

        public ActionResult BindUnitDetailsWithTariff(int unitId, string cDate, string cOutDate)
        {
            Session["unitID"] = unitId;

            UnitDetails obj_unit = new UnitDetails();
            obj_unit = objBusinessClass.GetUnitDisplayinfo(unitId);
            obj_unit.IEAmenities = objBusinessClass.GetUnitWiseAmenitiesList(unitId);
            obj_unit.IERooms = objBusinessClass.GetUnitRoomList(unitId, DateTime.ParseExact(cDate, "dd/MM/yyyy", null), DateTime.ParseExact(cOutDate, "dd/MM/yyyy", null), 2);

            obj_unit.IEImages = objBusinessClass.GetUnitImageList(unitId);

            return PartialView("_UnitListForTariffView", obj_unit);
        }

        #endregion

        #region Ankita Tripathi
        #region  View Online Booking Detail Without Login
        [HttpGet]
        public ActionResult ViewOnlineBooking()
        {

            OnlineBooking model = new OnlineBooking();
            // docketNo = model.docketNo;
            // model.ViewBooking = objBusinessClass.OnlineBooking(docketNo);

            return View(model);
        }
        public ActionResult DisplayOnlineDetail(string docketNo)
        {
            OnlineBooking model = new OnlineBooking();
            model.docketNo = docketNo;
            model.ViewBooking = objBusinessClass.OnlineBooking(model.docketNo);
            model.name = model.ViewBooking.FirstOrDefault().name;
            model.transDate = model.ViewBooking.FirstOrDefault().transDate;
            model.BookingFor = model.ViewBooking.FirstOrDefault().BookingFor;
            model.email = model.ViewBooking.FirstOrDefault().email;
            model.mobileNo = model.ViewBooking.FirstOrDefault().mobileNo;
            //string tempmob = model.mobileNo.ToString().Substring(8, 2);

            //  model.mobileNo = "********" + tempmob;
            //  model.mobileNo = string.Format("********{0}",
            //    model.mobileNo.Trim().Substring(10, 2));

            model.packageName = model.ViewBooking.FirstOrDefault().packageName;
            model.UnitName = model.ViewBooking.FirstOrDefault().UnitName;
            model.userId = model.ViewBooking.FirstOrDefault().userId;
            return View("ViewOnlineBooking", model);
        }
        [HttpPost]
        public ActionResult ViewOnlineBooking(OnlineBooking model, string Emails, string Mobiles)
        {
           
            if (Mobiles == "Sent OTP")
            {
                //fetching records for Mobile Number Verification
                model.flag = 1;
                var model1 = objBusinessClass.GetUserDetailsByEmailAndMobileNo(model.flag, model.userId, model.mobileNo, model.email, model.name); //
                if (model1 != null && model1.mobileNo != null)
                {
                    if (model1.mobileNo == model.mobileNo)
                    {

                        //Updating records for Mobile Number Verification and Sent OTP on Mobile No and Email
                        model.flag = 5;
                        //model1.RandomNo = Convert.ToInt32(generateno());
                        model1 = objBusinessClass.GetUserDetailsByEmailAndMobileNo(model.flag, model.userId, model.mobileNo, model.email, model.name);
                        DateTime datecheck = model1.modifiedOn ?? DateTime.Now;
                        datecheck = datecheck.AddHours(24);
                        if (datecheck < DateTime.Now)
                        {
                            model1.otpRequestCount = 0;
                        }

                        if (!(string.IsNullOrEmpty(Convert.ToString(model1.RandomNo))))
                        {

                            model1.otp = Convert.ToInt64(generateno());
                            model1.flag = 1;
                            model1.mobileNo = model.mobileNo;
                            model.OTPSend = Convert.ToInt32(model1.otp);
                            model1.otp = model.OTPSend;
                            // model1.otp = Convert.ToInt64(model.OTPSend);
                            // model.otp=model1.otp;
                            var a = objBusinessClass.SendOTPForMobile(model1).ToList();
                            SessionManager.CustomerMobile = model1.mobileNo;
                            SessionManager.OTP = Convert.ToString(model1.otp);
                            SessionManager.UserID = model1.userId;
                            return RedirectToAction("OTPVarification", "UPTourism");
                        }

                    }
                    else
                    {
                        TempData["msg"] = "Mobile No. is not Correct.. !";
                        return View(model);
                    }
                }
                else
                {
                    TempData["msg"] = "User Name is not Valid.. !";
                    return View(model);
                }

            }

            return View(model);
        }

        [HttpGet]
        public ActionResult OTPVarification()
        {
            OnlineBooking model = new OnlineBooking();
            model.userId = SessionManager.UserID;
            model.mobileNo = SessionManager.CustomerMobile;
            //string tempOTP = generateno();
            // SessionManager.OTP = tempOTP;
            model.OTPSend = Convert.ToInt32(SessionManager.OTP);
            model.flag = 2;
            var a = objBusinessClass.SendOTPForMobile(model).ToList().FirstOrDefault();
            model.email = a.email;
            model.name = a.name;
            //  model.mobileNo = a.mobileNo;
            if (SessionManager.OTP != "" && SessionManager.OTP != "0")
            {
                if (!SessionManager.isMSGSend)
                {
                    //string status = sendopt(SessionManager.OTP, SessionManager.CustomerMobile);
                    string status = sendopt(Convert.ToString(SessionManager.OTP), Convert.ToString(SessionManager.CustomerMobile));
                    sendotpEmail(Convert.ToString(SessionManager.OTP), model.email);
                    if (status.ToLower() == "success")
                    {
                        SessionManager.isMSGSend = true;

                        TempData["msg"] = "An OTP is send to your registered mobile no. and Email";
                    }
                    else
                    {
                        TempData["msg"] = "SMS service is not working please try again later. !";
                       
                    }
                }

            }
            else
            {
                TempData["msg"] = "We can't get generated OTP Please  try again.!";
               
            }

            return RedirectToAction("ViewOnlineBooking");
        }


        public ActionResult OTPVarificationA(int OTPNo)
        {
            OnlineBooking model = new OnlineBooking();
            //model.OTPNo = OTPNo;
            model.userId = SessionManager.UserID;
            model.mobileNo = SessionManager.CustomerMobile;

            model.flag = 2;
            var a = objBusinessClass.SendOTPForMobile(model).ToList();
            // model.otp = a.otp;
            if (a.FirstOrDefault().OTPSend == OTPNo)
            {

                // return RedirectToAction("ViewOnlineBooking");
            }
            else
            {
                TempData["msg"] = "OTP is not correct enter valid OTP";

            }
            return RedirectToAction("ViewOnlineBooking");
        }

        #region Generate OTP

        private string generateno()
        {
            string characters = string.Empty;
            string numbers = "1234567890";
            characters += numbers;
            string otp = string.Empty;
            string otpUser = string.Empty;
            for (int i = 0; i < 6; i++)
            {
                string character = string.Empty;
                do
                {
                    int index = new Random().Next(0, characters.Length);
                    character = characters.ToCharArray()[index].ToString();
                } while (otp.IndexOf(character) != -1);
                otp += character;
            }
            return otp;

        }
        #endregion
        private string sendopt(string otpNo, string mobileNo)
        {

            string txtmsg = "Dear User, your one time password(OTP) is " + otpNo + " and it is valid till next 15 mins please do not share this OTP with any one. Thank You! ";
            string status = SMS.SMSSend(txtmsg, mobileNo);
            return status;
        }
        private void sendotpEmail(string otpNo, string mailTo)
        {

            string subject = "OTP from UPTourism";
            string txtmsg = "Dear User, your one time password(OTP) is " + otpNo + " and it is valid till next 15 mins please do not share this OTP with any one. Thank You! ";
            SendMail.SendMailNew(mailTo, subject, txtmsg);

        }
        #endregion


        #endregion


        #region Display Detail Slab Wise
        [HttpGet]
        public ActionResult ViewOnlineGSTReportSlabWise()
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();

            return View();
        }
        public ActionResult ViewGSTSlabWise()
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWise(model);
            return PartialView("_ViewOnlineGSTSlabWise", model.SlabWiseDetail);
        }

        #endregion

    }


}
