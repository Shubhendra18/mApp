﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Web.UI.WebControls;
using UP_TourismBooking.Models.ProcessClasses;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models;
using System.Globalization;
using System.Data;
using System.IO;
using System.Xml.Linq;
using System.Net;
using System.Configuration;
using System.Web.Hosting;
using System.Text.RegularExpressions;

namespace UP_TourismBooking.Controllers
{
    [AuthorizeUnit]
    public class UnitController : Controller
    {
        #region Declarations
        BusinessClass objBusinessClass = new BusinessClass();
        Common objCommonClass = new Common();
        private Regex pinCode = new Regex(@"^(\d{6})$", RegexOptions.Compiled);
        private Regex mobileNo = new Regex(@"^(\d{10})$", RegexOptions.Compiled);
        private Regex numericCheck = new Regex(@"^(0|[1-9][0-9]*)$", RegexOptions.Compiled);

        #endregion

        public ActionResult Index()
        {
            return View();
        }

        #region Dashboard page
        [HttpGet]
        public ActionResult Dashboard()
        {
            return View();
        }
        #endregion

        #region vacancy status
        [HttpGet]
        public ActionResult VacancyStatus()
        {
            UnitVacancyStatus model = new UnitVacancyStatus();
            UnitVacancyStatus modeldt = new UnitVacancyStatus();
            try
            {
                model.dtBooking = DateTime.Now;
                model.BookingInTime = DateTime.Now;
                model.unitID = SessionManager.UnitID;

                model.BookingInTime = DateTime.Now;
                if (model.BookingInTime.Hour < 12)
                {
                    modeldt.dtBooking = DateTime.Now.AddDays(-1);
                }
                else
                {
                    modeldt.dtBooking = DateTime.Now;
                }
                modeldt.unitID = SessionManager.UnitID;

                model.bookingStatusList = objBusinessClass.GetUnitVacancyStatus(modeldt);
            }
            catch
            {

            }
            return View(model);
        }

        public ActionResult GetVacancyStatus(string dtBooking, DateTime dtBookingTime)
        {
            UnitVacancyStatus model = new UnitVacancyStatus();
            try
            {
                if (dtBookingTime.Hour < 12)
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                }
                else
                {
                    model.dtBooking = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.unitID = SessionManager.UnitID;
                model.bookingStatusList = objBusinessClass.GetUnitVacancyStatus(model);
            }
            catch
            {

            }
            return PartialView("_VacancyStatusGrid", model.bookingStatusList);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult VacancyStatus(UnitVacancyStatus obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();

            UnitVacancyStatus objR = new UnitVacancyStatus();
            objR.BookingInTime = obj.BookingInTime;
            if (objR.BookingInTime.Hour < 12)
            {
                objR.dtBooking = obj.dtBooking.AddDays(-1);
            }
            else
            {
                objR.dtBooking = obj.dtBooking;
            }
            objR.unitID = obj.unitID;
            objR.bookingStatusList = obj.bookingStatusList;

            var dtresult = objBusinessClass.GetUnitVacancyStatus(objR);

            if (dtresult != null && dtresult.Count > 0)
            {
                gv.DataSource = dtresult.Select(e => new { Room_Type = e.roomType, Total_Rooms = e.totalRoom, Online_Booking = e.onlineBooked, Package_Tours_Booking = e.packageBooked, UP_Tours_Booking = e.upTourBooked, ARC_Booking = e.arcBooked, CRS_Booking = e.crsBooked, Counter_Booking = e.counterBooked, Out_of_Service = e.OutS, Hold = e.blocked, Vacant = e.vacant }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/VacancyStatus.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            obj.bookingStatusList = dtresult;
            return View(obj);
        }
        #endregion

        #region display block and release
        [HttpGet]
        public ActionResult BlockRelease()
        {
            UnitBlockRelease model = new UnitBlockRelease();
            try
            {
                model.dtBlocking = DateTime.Now;
                model.unitID = SessionManager.UnitID;
                model.blockReleaseList = objBusinessClass.GetUnitBlockedRooms(model);
                model.blockLimit = model.blockReleaseList.Select(p => p.blockLimit).Distinct().FirstOrDefault();

                //if (TempData["message"] != null && TempData["message"].ToString() != "")
                //{
                //    ViewBag.Show = TempData["message"];
                //}
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region bind block and release grid as per the date selected
        public ActionResult GetBlockedRoomsByDate(string dtBlocking)
        {
            UnitBlockRelease model = new UnitBlockRelease();
            try
            {
                model.dtBlocking = DateTime.ParseExact(dtBlocking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.unitID = SessionManager.UnitID;
                model.blockReleaseList = objBusinessClass.GetUnitBlockedRooms(model);
                model.blockLimit = model.blockReleaseList.Select(p => p.blockLimit).Distinct().FirstOrDefault();

            }
            catch
            {

            }
            return PartialView("_BlockRelease", model);
        }
        #endregion

        #region save blocked and released rooms
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BlockRelease(UnitBlockRelease model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<BlockReleaseDetail> lstBlock = model.blockReleaseList.Where(m => m.blocked > 0).ToList();
                    var totalBlock = lstBlock.Sum(m => m.blocked);

                    if (totalBlock > model.blockLimit)
                    {
                        ViewBag.Show = "Maximum block limit exceeded!";
                    }
                    else
                    {
                        string BlockList = "<BlockDetail>";
                        for (var i = 0; i < lstBlock.Count(); i++)
                        {

                            BlockList += "<BlockList>";
                            BlockList += "<RoomID>" + lstBlock[i].roomID + "</RoomID>";
                            BlockList += "<BlockedRoom>" + lstBlock[i].blocked + "</BlockedRoom>";
                            BlockList += "</BlockList>";
                        }
                        BlockList += "</BlockDetail>";

                        int result = objBusinessClass.InsertBlockDetail(SessionManager.UnitID, BlockList, model.dtBlocking);
                        if (result > 0)
                        {
                            ViewBag.Show = "Record Saved Successfully!";
                            ModelState.Clear();
                            model.unitID = SessionManager.UnitID;
                            model.blockReleaseList = objBusinessClass.GetUnitBlockedRooms(model);
                            model.blockLimit = model.blockReleaseList.Select(p => p.blockLimit).Distinct().FirstOrDefault();

                            //return RedirectToAction("BlockRelease", "Unit");
                        }
                        else
                        {
                            ViewBag.Show = "Error in Process!";

                        }
                    }

                }
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region display unit search
        [HttpGet]
        public ActionResult Hotels()
        {
            return PartialView("_Hotels");
        }
        #endregion

        #region booking list
        [HttpGet]
        public ActionResult BookedList()
        {
            UnitTotalBooking model = new UnitTotalBooking();
            try
            {
                model.docketNo = "";
                model.unitID = SessionManager.UnitID;
                model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.bookedList = objBusinessClass.GetUnitBookingStatus(model);
                model.dtBookingDateFrom = null;
                model.dtBookingDateTo = null;
            }
            catch
            {

            }
            return View(model);
        }

        public ActionResult GetBookedList(string dtBookingFrom, string dtBookingTo, string docket)
        {
            UnitTotalBooking model = new UnitTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateFrom = null;
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateTo = null;
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket.Trim();
                model.unitID = SessionManager.UnitID;
                model.bookedList = objBusinessClass.GetUnitBookingStatus(model);
            }
            catch
            {

            }
            return PartialView("_BookedListGrid", model.bookedList);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookedList(UnitTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetUnitBookingStatus(obj);


            if (dtresult != null && dtresult.Count > 0)
            {

                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Name = e.name, Mobile_No = e.mobileNo, Email_Id = e.email, Date_Of_Birth = e.DateofBirth, Anniversary_Date = e.AnniversaryDate, City_Name = e.cityName, Country_Name = e.countryName, stateName = e.stateName, Docket_No = e.docketNo, Check_In_Date = e.checkInDate, Check_Out_Date = e.checkOutDate, Total_Room = e.totalRoom, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Booking_Status = e.BookingStatus }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/VacancyStatus.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ModelState.AddModelError("", "No data found for selected date");
            }
            obj.bookedList = objBusinessClass.GetUnitBookingStatus(obj);
            obj.dtBookingDateFrom = null;
            obj.dtBookingDateTo = null;
            return View(obj);
        }

        [HttpGet]
        public ActionResult GetBookingDetail(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();

            try
            {

                obj_BookingList = objBusinessClass.GetUnitBookingDetails(docketNo, SessionManager.UnitID);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.BookedRoomList = objBusinessClass.GetBookedRoomDetails(docketNo, SessionManager.UnitID);
                }
            }
            catch
            {
            }
            return PartialView("_BookingListDetails", obj_BookingDetail);
        }
        #endregion

        #region display advance payment
        [HttpGet]
        public ActionResult AdvancePayment()
        {
            try
            {
                if (TempData["message"] != null && TempData["message"].ToString() != "")
                {
                    ViewBag.Show = TempData["message"];
                }
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region get customer payment details for advance payment
        public ActionResult GetCustomerPaymentDetail(string docketNo)
        {
            AdvancePayment model = new AdvancePayment();
            try
            {
                ViewBag.AmountCategory = objBusinessClass.GetAdvanceAmountCategory().Select(e => new SelectListItem() { Text = e.AdvancePaymentCategory, Value = e.CatId.ToString() });
                model.docketNo = docketNo.Trim();
                model.unitID = SessionManager.UnitID;
                model = objBusinessClass.GetCounterPaymentInfo(model);
                if (model != null)
                {
                    model.paymentDate = DateTime.Now;
                }
            }
            catch
            {
            }
            return PartialView("_PaymentDetail", model);
        }
        #endregion

        #region save advance payment
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdvancePayment(AdvancePayment model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.unitID = SessionManager.UnitID;
                    model.userIP = this.Request.UserHostAddress;
                    int result = objBusinessClass.InsertAdvancePayment(model);
                    if (result > 0)
                    {
                        TempData["message"] = "Record Saved Successfully!";
                        return RedirectToAction("AdvancePayment", "Unit");
                    }
                    else
                    {
                        ViewBag.Show = "Error in Process!";
                    }
                }
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        [HttpGet]
        public ActionResult CancellationRequest(string docketNo)
        {
            BookingCancellation model = new BookingCancellation();
            //try
            //{
            //    Int64 _unitId = SessionManager.UnitID;

            //    model.lstCanceRequest = objBusinessClass.GetCancelRequest((docketNo == null) ? "" : docketNo, _unitId);
            //}
            //catch
            //{

            //}
            return View(model);
        }

        [HttpGet]
        public ActionResult CancellationRequestFiltered(string docketNo, string fromDate, string toDate)
        {
            BookingCancellation model = new BookingCancellation();
            try
            {
                Int64 _unitId = SessionManager.UnitID;
                DateTime _fromDate, _toDate;
                try
                {
                    _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                model.lstCanceRequest = objBusinessClass.GetCancelRequest(docketNo.Trim(), _unitId, _fromDate, _toDate);
            }
            catch
            {

            }
            return PartialView("_cancelRequestGrid", model.lstCanceRequest);
        }

        [HttpGet]
        public ActionResult CancellationRequestConfirmation(string id)
        {
            int status = objBusinessClass.InsertCancellationConfirmation(id.Trim(), this.Request.UserHostAddress);
            if (status > 0)
            {
                #region send mail and sms to user and nodal officer
                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.GetOfficerMobileNoForUnit(id.Trim());
                SendAcceptanceSMS(id.Trim(), IEContactDetails);
                SendAcceptanceEMail(id.Trim(), IEContactDetails);
                #endregion
                return Content("1");
            }
            else
            {
                ViewBag.Show = "Request Not Cancelled.";
            }
            return Content("0");
        }

        [HttpGet]
        public ActionResult CancelledRequest(string docketNo)
        {
            BookingCancellation model = new BookingCancellation();
            try
            {
                Int64 _unitId = SessionManager.UnitID;
                model.lstCanceRequest = objBusinessClass.GetCancelledRequest("", _unitId);
            }
            catch
            {

            }
            return View(model.lstCanceRequest);
        }

        #region to add customer registration details by Roop Kanwar

        #region customer registration
        [HttpGet]
        public ActionResult CustomerRegistration(string id)
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();
                model.countryID = 98;
                if (id != null)
                {
                    model = objBusinessClass.getCustomerDetailsAutoFill(Convert.ToInt64(id));

                }

                if (model != null && model.countryID == 98)
                {
                    ViewBag.StateList = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                    if (model.stateID > 0)
                    {
                        ViewBag.CityList = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                    }
                    else
                    {
                        ViewBag.CityList = Enumerable.Empty<SelectListItem>();

                    }
                }
                else
                {
                    ViewBag.StateList = Enumerable.Empty<SelectListItem>();
                    ViewBag.CityList = Enumerable.Empty<SelectListItem>();
                }
                Int64 _unitId = SessionManager.UnitID;
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                ViewBag.RoomType = objBusinessClass.GetRoomType(_unitId).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
                ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
                ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
                ViewBag.Nationality = GetNationality();
                ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });


                model.unitID = _unitId;
                //model.checkInDate = DateTime.Now.Date;
                //model.checkOutDate = DateTime.Now.Date.AddDays(1).Date;
                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CustomerRegistration(CustomerRegistration model)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                #region Validate Uploaded Doc
                if (model.staffIdDoc != null)
                {
                    string ext = Path.GetExtension(model.staffIdDoc.FileName);
                    string filename = Path.GetFileName("StaffDoc_" + DateTime.Now.Ticks + ext);
                    string res = objCommonClass.ValidateImageWithCusomSize(model.staffIdDoc, 400);
                    if (res.Trim() != "Valid")
                    {
                        _isValid = false;
                        _msg = res;
                    }
                    else
                    {
                        model.staffIdDocPath = Path.Combine("~/Content/writereaddata/PrivilegeCard/", filename);
                        var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/PrivilegeCard/"), filename);
                        model.staffIdDoc.SaveAs(docPath);
                    }
                }

                #endregion
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _isValid = false;
                        _msg = "Enter a valid 6 digit Pincode!";
                    }
                    else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                    {
                        _isValid = false;
                        _msg = "Enter a valid 10 digit Mobile No.!";
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.mobileNo) && !numericCheck.IsMatch(model.mobileNo))
                    {
                        _isValid = false;
                        _msg = "Enter a valid Mobile No.!";
                    }
                }
                ModelState["checkInTime"].Errors.Clear();
                ModelState["checkOutTime"].Errors.Clear();
                ModelState["staffGrade"].Errors.Clear();
                ModelState["staffFacility"].Errors.Clear();
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.pincode))
                {
                    ModelState["pincode"].Errors.Clear();
                }
                //if (string.IsNullOrEmpty(Convert.ToString(model.advanceAmount)))
                //{
                //    ModelState["advanceAmount"].Errors.Clear();
                //}
                if (model.customerType == 'B')
                {
                    ModelState["roomType"].Errors.Clear();
                    if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                    {
                    }
                    else
                    {
                        _isValid = false;
                        _msg = "Provide Room Details ";
                        ModelState.AddModelError("", "Provide Room Details ");
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(Convert.ToString(model.roomType)))
                    {
                        _isValid = false;
                        _msg = "Select Room!! ";
                        ModelState.AddModelError("", "Select Room!! ");
                    }
                    if (model.customerType == 'S')
                    {
                        model.isStaff = true;
                        //commented by Tabeen
                        //if (model.staffId == null)
                        //{
                        //    _isValid = false;
                        //    _msg = "Enter Staff Id!! ";
                        //    ModelState.AddModelError("", "Enter Staff Id!! ");
                        //}
                        //else if (model.staffIdDoc == null)
                        //{
                        //    _isValid = false;
                        //    _msg = "Upload Staff Identity!! ";
                        //    ModelState.AddModelError("", "Upload Staff Identity!! ");
                        //}
                        //else if (model.staffGrade == null || model.staffGrade == 0)
                        //{
                        //    _isValid = false;
                        //    _msg = "Select Staff Grade!! ";
                        //    ModelState.AddModelError("", "Select Staff Grade!! ");
                        //}
                        //end of comment by Tabeen
                        if (model.staffGrade == null || model.staffGrade == 0)
                        {
                            _isValid = false;
                            _msg = "Select Staff Grade!! ";
                            ModelState.AddModelError("", "Select Staff Grade!! ");
                        }
                        else if (model.staffFacility == null || model.staffFacility == 0)
                        {
                            _isValid = false;
                            _msg = "Select Staff Tariff!! ";
                            ModelState.AddModelError("", "Select Staff Tariff!! ");
                        }
                    }
                }

                if (model != null && model.countryID == 98)
                {
                    ViewBag.StateList = objBusinessClass.GetStateList(Convert.ToInt32(model.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                    if (model.stateID > 0)
                    {
                        ViewBag.CityList = objBusinessClass.GetCityList(Convert.ToInt32(model.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                    }
                    else
                    {
                        ViewBag.CityList = Enumerable.Empty<SelectListItem>();

                    }
                }
                else
                {
                    ViewBag.StateList = Enumerable.Empty<SelectListItem>();
                    ViewBag.CityList = Enumerable.Empty<SelectListItem>();
                }

                if (ModelState.IsValid && _isValid == true)
                {
                    model.roleID = "OCST";
                    model.userIP = this.Request.UserHostAddress;
                    string isValid = IsDateValid(model);

                    if (string.IsNullOrEmpty(isValid))
                    {
                        if (model.staffIdDoc != null)
                        {
                            string ext = Path.GetExtension(model.staffIdDoc.FileName);
                            string filename = Path.GetFileName(DateTime.Now.Ticks + ext);

                            model.staffIdDocPath = Path.Combine("/Content/writereaddata/Documents", filename);
                            var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                            model.staffIdDoc.SaveAs(docPath);
                        }
                        else
                        {
                            model.staffIdDocPath = "";
                            model.staffId = "";
                            //model.staffGrade = 0;
                            //model.staffFacility = 0;
                        }

                        #region changes for bulk booking
                        bool _isExtraBedAvail = true, _chkRoomLimit = true, _isDataChecked = true;
                        int _totalExtraBedRequire = 0;
                        if (model.customerType == 'B')
                        {
                            int _extraBedBulk = 0, _singleBulk = 0, _doubleBulk = 0, _totalRooms = 0, _maxCapacity = 0, _maxAllowedGuest = 0, _singleNonOc = 0;
                            foreach (var item in model.lstBookedRoomDetail)
                            {
                                _singleBulk += item.singleRoom;
                                _doubleBulk += item.doubleRoom;
                                //_extraBedBulk = _extraBedBulk + (item.hasOccupancy == true ? 1 * (item.doubleRoom) : 0);
                                _extraBedBulk += item.extrabed;
                                _maxCapacity = _maxCapacity + (item.hasOccupancy == false ? (item.maxCapacity) * (item.singleRoom) : 0);
                                _singleNonOc = _singleNonOc + (item.hasOccupancy == false ? (item.singleRoom) : 0);



                                if (item.hasOccupancy)
                                {
                                    if (item.extrabed > (item.doubleRoom * item.maxExtraBed))
                                    {
                                        _isDataChecked = false;
                                        _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";
                                        ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                        break;
                                    }
                                    _maxAllowedGuest += ((item.singleRoom + (item.doubleRoom * 2)) + (item.doubleRoom * item.maxExtraBed));
                                }
                                else
                                {
                                    if (item.extrabed > (item.singleRoom * item.maxExtraBed))
                                    {
                                        _isDataChecked = false;
                                        _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay + " !!";
                                        ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                        break;
                                    }
                                    _maxAllowedGuest += ((item.singleRoom * item.maxCapacity) + (item.singleRoom * item.maxExtraBed));
                                }
                            }
                            if (_isDataChecked == true)
                            {
                                _totalRooms = _singleBulk + _doubleBulk;
                                _totalExtraBedRequire = model.noOfGuests - ((_singleBulk - _singleNonOc) + (_doubleBulk * 2) + _maxCapacity);
                                //_maxAllowedGuest = _singleBulk + (_doubleBulk * 2) + _extraBedBulk + (_maxCapacity - _singleNonOc); ;

                                #region max capacity for bulk booking
                                if (_totalRooms > model.noOfGuests)
                                {
                                    _chkRoomLimit = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                                }
                                else if (model.noOfGuests > _maxAllowedGuest)
                                {
                                    _chkRoomLimit = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                else if (_extraBedBulk < _totalExtraBedRequire)
                                {
                                    _isExtraBedAvail = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                model.noOfRooms = _totalRooms;
                            }
                                #endregion
                        }
                        else
                        {
                            model.noOfRooms = model.singleRoom + model.doubleRoom;
                            if (model.hasOccupancy)
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Single and Double rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Single and Double rooms should be less than equal to No. of Guests!");
                                }
                                else if (model.extrabed > (model.doubleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                else if (((model.singleRoom + (model.doubleRoom * 2)) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                            }
                            else
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                                }
                                else if (model.extrabed > (model.singleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                                else if (((model.singleRoom * model.maxCapacity) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                            }

                            RoomDetail objRoomList = new RoomDetail();
                            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
                            objRoomList.roomType = model.roomType;
                            objRoomList.roomTypeDisplay = model.roomTypeDisplay;
                            objRoomList.singleRoom = model.singleRoom;
                            objRoomList.doubleRoom = model.doubleRoom;
                            objRoomList.hasOccupancy = model.hasOccupancy;
                            objRoomList.Sno = lstBookedRoom.Count + 1;

                            //if (model.hasOccupancy)
                            //{
                            //    model.extrabed = model.noOfGuests - (model.singleRoom + (model.doubleRoom * 2));
                            //    model.extrabed = (model.extrabed > 0) ? model.extrabed : 0;
                            //}
                            //else
                            //{
                            //    model.extrabed = 0;
                            //}
                            objRoomList.extrabed = model.extrabed;
                            lstBookedRoom.Add(objRoomList);
                            model.lstBookedRoomDetail = lstBookedRoom;
                        }
                        //model.noOfRooms = model.singleRoom + model.doubleRoom;
                        int totalDays = model.checkOutDate.Subtract(model.checkInDate).Days;
                        bool _isRoomAvl = true;
                        int _noOfRooms = 0;
                        decimal reqAdvAmt = GetRequiredAdvanceAmount(model);
                        if (model.customerType == 'B' && (model.advanceAmount == null || model.advanceAmount <= 0 || (model.advanceAmount < reqAdvAmt)))
                        {
                            _isDataChecked = false;
                            _msg = "Insufficient Advance Amount. Minimum Advance Amount " + reqAdvAmt;
                            ModelState.AddModelError("", "Insufficient Advance Amount. Minimum Advance Amount " + reqAdvAmt);
                        }
                        foreach (var item in model.lstBookedRoomDetail)
                        {
                            int _extrabedAdd = 0;
                            RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                            objRoom.roomTypeId = item.roomType;
                            objRoom.unitId = model.unitID;
                            _noOfRooms = item.singleRoom + item.doubleRoom;
                            //if (model.customerType == 'B' && _totalExtraBedRequire > 0)
                            //{
                            //    _extrabedAdd = item.hasOccupancy == true ? 1 * (item.doubleRoom) : 0;
                            //    if (_extrabedAdd > 0 && _extrabedAdd > _totalExtraBedRequire)
                            //    {
                            //        //_extrabedAdd = _extrabedAdd - _totalExtraBedRequire;
                            //        item.extrabed = _totalExtraBedRequire;
                            //        _totalExtraBedRequire = 0;
                            //    }
                            //    else
                            //    {
                            //        item.extrabed = _extrabedAdd;
                            //        //   _extrabedAdd = _totalExtraBedRequire - _extrabedAdd;
                            //        _totalExtraBedRequire = _totalExtraBedRequire - _extrabedAdd;
                            //    }

                            //}

                            for (int i = 0; i < totalDays; i++)
                            {
                                objRoom.bookingDate = model.checkInDate.AddDays(i);
                                var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                {
                                    _isRoomAvl = false;
                                    _msg = "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                    ModelState.AddModelError("", "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy"));
                                    break;
                                }
                            }
                            if (_isRoomAvl == false)
                            {
                                break;
                            }
                        }

                        var roomXml = new XElement("booking",
                                     from room in model.lstBookedRoomDetail
                                     select new XElement("customer",
                                                    new XElement("Sno", room.Sno),
                                                    new XElement("roomType", room.roomType),
                                                    new XElement("singleRoom", room.singleRoom),
                                                    new XElement("doubleRoom", room.doubleRoom),
                                                    new XElement("extrabed", room.extrabed)
                                                ));
                        model.bookingXML = roomXml.ToString();
                        #endregion
                        if (_isRoomAvl == true && _isDataChecked == true && _isExtraBedAvail == true && _chkRoomLimit == true)
                        {
                            model.userID = model.unitID;
                            //model.bookingFor = "CNTU";
                            model.bookingFor = "UNIT";
                            model.bookingBy = "UNT";
                            if (model.dateOfBirth != null)
                            {
                                var dob = model.dateOfBirth.Split('/');
                                model.dobDate = Convert.ToInt32(dob[0]);
                                model.dobMonth = Convert.ToInt32(dob[1]);
                                model.dobYear = Convert.ToInt32(dob[2]);

                                if (model.age == 0)
                                {
                                    DateTime dt = DateTime.ParseExact(model.dateOfBirth, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                                    DateTime today = DateTime.Today;
                                    int age = today.Year - dt.Year;

                                }
                            }

                            var user = objBusinessClass.InsertCustomerBooking(model);


                            if (user != null)
                            {
                                #region send mail and sms
                                IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(user.docketNo);

                                foreach (var lst in IEContactDetails)
                                {
                                    if (lst.sendTo == "CUSTOMER")
                                    {
                                        SendUnitRoomMail(user.docketNo, "CUSTOMER", lst.Email);
                                        SendUnitBookSms(user.docketNo, lst.MobileNo);
                                    }

                                }
                                #endregion
                                SessionManager.DocketNo = user.docketNo;

                                return RedirectToAction("RegistrationConfirmation");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Room Not Booked!");
                                _msg = "Room Not Booked!";
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", isValid);
                        _msg = isValid;
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Error in CustomerRegistration!");
                    _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
                }
            }
            catch (Exception ex)
            {
                //_msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
                _msg = string.IsNullOrEmpty(_msg) ? ex.Message : _msg;
            }
            Int64 _unitId = SessionManager.UnitID;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.RoomType = objBusinessClass.GetRoomType(_unitId).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
            ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().GroupBy(m => m.amount).Select(m => m.FirstOrDefault()).Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
            ViewBag.Nationality = GetNationality();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Show = _msg;
            return View(model);
        }

        [HttpGet]
        public ActionResult CheckAvailability(string checkinDate, string checkoutDate, int roomType, int noofGuest, int singleRoom, int doubleRoom, int extraBed, Int16 maxCapacity, bool hasOccupancy, int maxExtraBed, string roomTypeDisplay, char bookingType)
        {
            string _msg = "";
            bool _isValid = true;
            CustomerRegistration model = new CustomerRegistration();
            try
            {
                if (string.IsNullOrEmpty(checkinDate))
                {
                    _isValid = false;
                    _msg = "Select Check In Date!!";
                }
                if (string.IsNullOrEmpty(checkoutDate))
                {
                    _isValid = false;
                    _msg = "Select Check Out Date!! ";
                }
                if (roomType != null && roomType == 0)
                {
                    _isValid = false;
                    _msg = "Select Room!! ";
                }
                if (noofGuest != null && noofGuest == 0)
                {
                    _isValid = false;
                    _msg = "Enter No. of Guests!! ";
                }

                if (_isValid)
                {
                    model.checkInDate = DateTime.ParseExact(checkinDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.checkOutDate = DateTime.ParseExact(checkoutDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.singleRoom = singleRoom;
                    model.doubleRoom = doubleRoom;
                    model.roomType = roomType;
                    model.noOfGuests = noofGuest;
                    model.extrabed = extraBed;
                    model.maxCapacity = maxCapacity;
                    model.maxExtraBed = maxExtraBed;
                    model.hasOccupancy = hasOccupancy;
                    model.roomTypeDisplay = roomTypeDisplay;
                    model.unitID = SessionManager.UnitID;
                    model.customerType = bookingType;

                    if (_isValid == true)
                    {
                        string isValid = IsDateValid(model);
                        if (string.IsNullOrEmpty(isValid))
                        {
                            //bool _isExtraBedAvail = true, _chkRoomLimit = true;
                            bool _isDataChecked = true;

                            model.noOfRooms = model.singleRoom + model.doubleRoom;
                            if (model.hasOccupancy)
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Single and Double rooms should be less than equal to No. of Guests!";
                                }
                                else if (model.extrabed > (model.doubleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                                else if (((model.singleRoom + (model.doubleRoom * 2)) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                            }
                            else
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";

                                }
                                else if (model.extrabed > (model.singleRoom * model.maxExtraBed))
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                                else if (((model.singleRoom * model.maxCapacity) + model.extrabed) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                }
                            }

                            if (_isDataChecked)
                            {
                                RoomDetail objRoomList = new RoomDetail();
                                //IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
                                objRoomList.roomType = roomType;
                                objRoomList.roomTypeDisplay = model.roomTypeDisplay;
                                objRoomList.singleRoom = singleRoom;
                                objRoomList.doubleRoom = doubleRoom;
                                objRoomList.hasOccupancy = hasOccupancy;
                                objRoomList.extrabed = extraBed;
                                //lstBookedRoom.Add(objRoomList);
                                //model.lstBookedRoomDetail = lstBookedRoom;

                                int totalDays = model.checkOutDate.Subtract(model.checkInDate).Days;
                                bool _isRoomAvl = true;
                                int _noOfRooms = 0;


                                //foreach (var item in model.lstBookedRoomDetail)
                                //{
                                int _extrabedAdd = 0;
                                RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                                objRoom.roomTypeId = objRoomList.roomType;
                                objRoom.unitId = model.unitID;
                                _noOfRooms = objRoomList.singleRoom + objRoomList.doubleRoom;
                                int availableRooms = _noOfRooms;

                                for (int i = 0; i < totalDays; i++)
                                {
                                    objRoom.bookingDate = model.checkInDate.AddDays(i);
                                    var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                    if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                    {
                                        _isRoomAvl = false;
                                        availableRooms = isAvailable.TotalRoom;
                                        //_msg = "Room Not Available In " + item.roomTypeDisplay + " for date-" + objRoom.bookingDate.ToString("dd/MM/yyyy") + "<br/> new";                                    
                                        break;
                                    }
                                }
                                //if (_isRoomAvl == false)
                                //{
                                //    break;
                                //}
                                // }                                

                                model.availableRooms = availableRooms;
                                if (bookingType != 'S')
                                {
                                    if (availableRooms > 0)
                                    {
                                        //obj.roomDetailsList = objBusinessClass.GetRoomTariffDetails(Convert.ToInt32(objRoomList.roomType), model.checkInDate, model.checkOutDate.AddDays(-1));
                                        model.totalAmountPayable = objBusinessClass.GetTotalUnitRoomPrice(model.checkInDate, model.checkOutDate.AddDays(-1), objRoomList);
                                    }
                                }
                                if (bookingType != 'B')
                                {
                                    return PartialView("_RoomAvailabilityDetails", model);
                                }
                                else
                                {
                                    _msg = availableRooms + " Room(s) Available";
                                    if (availableRooms > 0)
                                    {
                                        _msg += ", Total Amount - " + model.totalAmountPayable;
                                    }
                                    return Content(_msg);
                                }
                            }
                            //if (_isRoomAvl == true && _isDataChecked == true && _isExtraBedAvail == true && _chkRoomLimit == true)
                            //{
                            //    _msg = "Room available!";
                            //}
                        }
                        else
                        {
                            _msg = isValid;
                        }
                    }
                }
            }
            catch
            {

            }
            return Content(_msg);
        }
        #endregion

        [HttpGet]
        public ActionResult GetRoomTariffDetails(string checkinDate, string checkoutDate, int roomType)
        {
            string _msg = "";
            bool _isValid = true;
            CustomerRegistration model = new CustomerRegistration();
            try
            {
                if (string.IsNullOrEmpty(checkinDate))
                {
                    _isValid = false;
                    _msg = "Select Check In Date!!";
                }
                if (string.IsNullOrEmpty(checkoutDate))
                {
                    _isValid = false;
                    _msg = "Select Check Out Date!! ";
                }
                if (roomType != null && roomType == 0)
                {
                    _isValid = false;
                    _msg = "Select Room!! ";
                }

                if (_isValid)
                {
                    model.checkInDate = DateTime.ParseExact(checkinDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.checkOutDate = DateTime.ParseExact(checkoutDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    model.roomType = roomType;
                    model.unitID = SessionManager.UnitID;
                    if (_isValid == true)
                    {
                        string isValid = IsDateValid(model);
                        if (string.IsNullOrEmpty(isValid))
                        {
                            List<RoomTariffDetails> objRoomTariffList = objBusinessClass.GetRoomTariffDetails(Convert.ToInt32(model.roomType), model.checkInDate, model.checkOutDate.AddDays(-1));
                            return PartialView("_RoomTariff", objRoomTariffList);
                        }
                        else
                        {
                            _msg = isValid;
                        }
                    }
                }
            }
            catch
            {

            }
            return Content(_msg);
        }

        #region customer registration Confirmation
        [HttpGet]
        public ActionResult RegistrationConfirmation()
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();
                //model.userID = SessionManager.UserID;
                model.docketNo = SessionManager.DocketNo;

                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        #endregion

        #endregion

        #region Check Out Process
        [HttpGet]
        public ActionResult CheckOut(string docketNo = null)
        {
            return RedirectToAction("CheckOutNew", new { @docketNo = docketNo });

            try
            {
                CustomerRegistration model = new CustomerRegistration();
                if (!string.IsNullOrEmpty(docketNo))
                {
                    model.docketNo = docketNo.Trim();
                }
                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpGet]
        public ActionResult CheckOutDetail(string docketNo)
        {
            CustomerRegistration obj_BookingDetail = new CustomerRegistration();
            string _msg = "";
            try
            {
                Int64 _unitId = SessionManager.UnitID;

                obj_BookingDetail = objBusinessClass.GetCustomerBookingDetails(docketNo.Trim(), _unitId);
                if (obj_BookingDetail.isCheckIn == true)
                {
                    IList<CustomerRegistration> lstCheckinDetails = objBusinessClass.GetCustomerBookingList(docketNo.Trim(), _unitId);
                    obj_BookingDetail.checkInDateShow = lstCheckinDetails.Min(c => c.checkInDate);
                    obj_BookingDetail.checkOutDateShow = lstCheckinDetails.Max(c => c.checkOutDateShow);
                    obj_BookingDetail.checkOutDateActual = DateTime.Now.Date;
                    obj_BookingDetail.checkOutTime = DateTime.Now;

                    List<BookedRoomDetails> objRoom = objBusinessClass.GetBookedRoomDetailsOnCheckOut(docketNo.Trim(), _unitId);
                    //List<BillDetails> objBil = null;
                    //if (obj_BookingDetail != null && objRoom != null && objRoom.Count > 0)
                    //{
                    //    foreach (var item in objRoom)
                    //    {
                    //        if (obj_BookingDetail.lstBill != null && obj_BookingDetail.lstBill.Count > 0)
                    //        {
                    //            objBil = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                    //            obj_BookingDetail.lstBill.AddRange(objBil);
                    //        }
                    //        else
                    //        {
                    //            obj_BookingDetail.lstBill = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                    //        }
                    //    }
                    //}

                    //if (obj_BookingDetail != null && obj_BookingDetail.lstBill != null && obj_BookingDetail.lstBill.Count > 0)
                    //{
                    if (obj_BookingDetail != null)
                    {
                        // obj_BookingDetail.lstBookedRoom = objRoom;

                        obj_BookingDetail.userID = _unitId;
                        return PartialView("_CheckOutDetails", obj_BookingDetail);
                    }
                    else
                    {
                        _msg = "Details Not Available!!";
                        return Content("NA");
                    }
                }
                else
                {
                    _msg = "Not Checked In!!";
                    return Content("NC");
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
                return Content("C");
            }
            ViewBag.Show = _msg;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CheckOut(CustomerRegistration model)
        {
            CustomerRegistration obj_BookingDetail = new CustomerRegistration();
            string _msg = "";
            try
            {
                Int64 _unitId = SessionManager.UnitID;
                model.unitID = _unitId;
                model.userIP = this.Request.UserHostAddress;
                #region save CheckOut Details
                int i = objBusinessClass.SaveCheckOutDetails(model);
                #endregion
                if (i > 0)
                {
                    int paybleAmt = 0;
                    double GSTR3Tax, GSTR2Tax, GSTR1Tax, GSTR1TaxAmount, luxuryTax, serviceTax, luxuryTaxAmt, serviceTaxAmt, totalAmount = 0, totalTaxAmt, discount, discountAmt, amtAfterDiscount, advanceAmount, privilegeDist, privilegeAmt = 0, totalAmountExtra = 0, totalAmountForTax = 0, discountAmtForTax = 0, netAmt = 0, totalAmountForTaxLuxury = 0, totalAmountForTaxService = 0, totalAmountForTaxLuxury_Extra = 0, discountAmtForTaxService = 0, discountAmtForTaxLuxury = 0, discountAmtForTaxLuxury_Extra = 0;
                    GSTR1TaxAmount = 0;
                    string GSTDisplayTax = "";
                    obj_BookingDetail = objBusinessClass.GetCustomerBookingDetails(model.docketNo, _unitId);
                    if (obj_BookingDetail.isCheckIn == true)
                    {
                        IList<CustomerRegistration> lstCheckinDetails = objBusinessClass.GetCustomerBookingList(model.docketNo, _unitId);
                        obj_BookingDetail.checkInDateShow = lstCheckinDetails.Min(c => c.checkInDate);
                        obj_BookingDetail.checkOutDateShow = lstCheckinDetails.Max(c => c.checkOutDateShow);

                        obj_BookingDetail.checkOutDateActual = model.checkOutDateActual;
                        obj_BookingDetail.checkOutTime = model.checkOutTime;


                        List<BookedRoomDetails> objRoom = objBusinessClass.GetBookedRoomDetailsOnCheckOut(model.docketNo, _unitId);
                        List<BillDetails> objBil = null;
                        if (obj_BookingDetail != null && objRoom != null && objRoom.Count > 0)
                        {
                            foreach (var item in objRoom)
                            {
                                if (obj_BookingDetail.lstBill != null && obj_BookingDetail.lstBill.Count > 0)
                                {
                                    objBil = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                                    obj_BookingDetail.lstBill.AddRange(objBil);
                                }
                                else
                                {
                                    obj_BookingDetail.lstBill = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                                }
                            }
                        }


                        if (obj_BookingDetail != null && obj_BookingDetail.lstBill != null && obj_BookingDetail.lstBill.Count > 0)
                        {
                            obj_BookingDetail.lstBookedRoom = objRoom;
                            obj_BookingDetail.isPrivilegeAvail = string.IsNullOrEmpty(obj_BookingDetail.privilegeCardNo) ? false : true;

                            String _luxuryTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["LuxuryTax"]);
                            if (!String.IsNullOrEmpty(_luxuryTax))
                                luxuryTax = Convert.ToDouble(_luxuryTax);
                            else
                                luxuryTax = 0;

                            String _serviceTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["ServiceTax"]);
                            if (!String.IsNullOrEmpty(_serviceTax))
                                serviceTax = Convert.ToDouble(_serviceTax);
                            else
                                serviceTax = 0;

                            //GST

                            String _GSTR1Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR1"]);
                            if (!String.IsNullOrEmpty(_GSTR1Tax))
                                GSTR1Tax = Convert.ToDouble(_GSTR1Tax);
                            else
                                GSTR1Tax = 12.00;

                            String _GSTR2Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR2"]);
                            if (!String.IsNullOrEmpty(_GSTR2Tax))
                                GSTR2Tax = Convert.ToDouble(_GSTR2Tax);
                            else
                                GSTR2Tax = 18.00;

                            String _GSTR3Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR3"]);
                            if (!String.IsNullOrEmpty(_GSTR3Tax))
                                GSTR3Tax = Convert.ToDouble(_GSTR3Tax);
                            else
                                GSTR3Tax = 28.00;

                            //String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                            privilegeDist = obj_BookingDetail.discountPercent;
                            //if (!String.IsNullOrEmpty(_privilegeDist))
                            //    privilegeDist = Convert.ToDouble(_privilegeDist);
                            //else
                            //    privilegeDist = 15;

                            String _UnitForTax = System.Configuration.ConfigurationManager.AppSettings["UnitForTax"].ToString();
                            bool _isExtraTax = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? true : false;

                            obj_BookingDetail.luxuryTax = luxuryTax;
                            obj_BookingDetail.luxuryTaxDisplay = luxuryTax.ToString() + " %";
                            obj_BookingDetail.serviceTax = serviceTax;

                            String _billXML = "<bill>";
                            foreach (BillDetails item in obj_BookingDetail.lstBill)
                            {
                                _billXML += "<billDetails>";
                                _billXML += "<billDetail>" + item.BillDescription + "</billDetail>";
                                _billXML += "<amount>" + item.Amount + "</amount>";
                                _billXML += "<requestId>" + item.requestId + "</requestId>";
                                _billXML += "</billDetails>";
                                totalAmount += Convert.ToDouble(item.Amount);
                                totalAmountExtra += Convert.ToDouble(item.ExtraBedAmount);
                                if (_isExtraTax == true && item.basetariff >= 3500)
                                {
                                    obj_BookingDetail.luxuryTaxDisplay = luxuryTax.ToString() + " / 0 %";
                                    totalAmountForTaxLuxury_Extra += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff) + Convert.ToDouble(item.baseExtraBedAmount)) : 0;
                                    discountAmtForTaxLuxury_Extra += (item.isTaxEligible == true) ? Convert.ToDouble(item.Amountbasetariff) : 0;

                                }
                                else
                                {
                                    totalAmountForTaxLuxury += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff) + Convert.ToDouble(item.baseExtraBedAmount)) : 0;
                                    discountAmtForTaxLuxury += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                                }
                                // FOR GST

                                if (item.basetariff < 1000)
                                {
                                    GSTR1TaxAmount += 0;

                                }
                                //else if (item.basetariff >= 1000 && item.basetariff <= 2499)
                                //{
                                //    GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, ";
                                //    discount = obj_BookingDetail.discount;
                                //    var DiscAmt = Convert.ToDouble(item.Amountbasetariff);

                                //    discountAmt = (DiscAmt * discount) / 100;
                                //    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);



                                //}

                                //else if (item.basetariff >= 2500 && item.basetariff <= 7499)
                                //{
                                //    GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, ";
                                //    discount = obj_BookingDetail.discount;
                                //    var DiscAmt = (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                                //    discountAmt = (DiscAmt * discount) / 100;
                                //    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);


                                //}
                                //else
                                //{
                                //    GSTDisplayTax = GSTDisplayTax + GSTR3Tax.ToString() + "%, ";
                                //    discount = obj_BookingDetail.discount;
                                //    var DiscAmt = (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                                //    discountAmt = (DiscAmt * discount) / 100;
                                //    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);

                                //    GSTR1TaxAmount += ((tamount * GSTR3Tax) / 100);


                                //}
                                else if (item.basetariff >= 1000 && item.basetariff <= 7500)
                                {
                                    GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, ";
                                    discount = obj_BookingDetail.discount;
                                    var DiscAmt = Convert.ToDouble(item.Amountbasetariff);

                                    discountAmt = (DiscAmt * discount) / 100;
                                    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);



                                }

                                else if (item.basetariff > 7500)
                                {
                                    GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, ";
                                    discount = obj_BookingDetail.discount;
                                    var DiscAmt = (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                                    discountAmt = (DiscAmt * discount) / 100;
                                    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);


                                }

                                totalAmountForTaxService += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff) + Convert.ToDouble(item.baseExtraBedAmount)) : 0;
                                discountAmtForTaxService += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                            }
                            _billXML += "</bill>";
                            obj_BookingDetail.totalAmount = totalAmount;
                            obj_BookingDetail.totalAmountActual = totalAmount;
                            obj_BookingDetail.totalAmountExtra = totalAmountExtra;
                            obj_BookingDetail.discountAmtForTaxLuxury_Extra = discountAmtForTaxLuxury_Extra;
                            obj_BookingDetail.discountAmtForTaxLuxury = discountAmtForTaxLuxury;
                            obj_BookingDetail.discountAmtForTaxService = discountAmtForTaxService;

                            //obj_BookingDetail.totalAmountForTax = totalAmountForTax;
                            obj_BookingDetail.totalAmountForTaxLuxury = totalAmountForTaxLuxury;
                            obj_BookingDetail.totalAmountForTaxService = totalAmountForTaxService;
                            obj_BookingDetail.totalAmountForTaxLuxury_Extra = totalAmountForTaxLuxury_Extra;

                            discount = obj_BookingDetail.discount;
                            discountAmt = (totalAmount * discount) / 100;
                            //discountAmtForTax = (totalAmountForTax * discount) / 100;
                            discountAmtForTaxLuxury = (discountAmtForTaxLuxury * discount) / 100;
                            discountAmtForTaxService = (discountAmtForTaxService * discount) / 100;
                            discountAmtForTaxLuxury_Extra = (discountAmtForTaxLuxury_Extra * discount) / 100;
                            amtAfterDiscount = (totalAmount - discountAmt) + totalAmountExtra;
                            //totalAmountForTax = (totalAmountForTax - discountAmtForTax);
                            totalAmountForTaxLuxury = (totalAmountForTaxLuxury - discountAmtForTaxLuxury);
                            totalAmountForTaxService = (totalAmountForTaxService - discountAmtForTaxService);
                            totalAmountForTaxLuxury_Extra = (totalAmountForTaxLuxury_Extra - discountAmtForTaxLuxury_Extra);
                            netAmt = amtAfterDiscount;
                            if (obj_BookingDetail.isPrivilegeAvail == true)
                            {
                                double privilegeAmtLuxury, privilegeAmtLuxury_Extra, privilegeAmtService;
                                privilegeAmt = (totalAmount * privilegeDist) / 100;
                                privilegeAmtLuxury = (totalAmountForTaxLuxury * privilegeDist) / 100;
                                privilegeAmtLuxury_Extra = (totalAmountForTaxLuxury_Extra * privilegeDist) / 100;
                                privilegeAmtService = (totalAmountForTaxService * privilegeDist) / 100;
                                netAmt = (obj_BookingDetail.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;
                                amtAfterDiscount = (obj_BookingDetail.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;
                                //totalAmountForTax = (obj_BookingDetail.isPrivilegeVerified == true) ? (totalAmountForTax - privilegeAmt) : totalAmountForTax;
                                totalAmountForTaxLuxury = (obj_BookingDetail.isPrivilegeVerified == true) ? (totalAmountForTaxLuxury - privilegeAmtLuxury) : totalAmountForTaxLuxury;
                                totalAmountForTaxService = (obj_BookingDetail.isPrivilegeVerified == true) ? (totalAmountForTaxService - privilegeAmtService) : totalAmountForTaxService;
                                totalAmountForTaxLuxury_Extra = (obj_BookingDetail.isPrivilegeVerified == true) ? (totalAmountForTaxLuxury_Extra - privilegeAmtLuxury_Extra) : totalAmountForTaxLuxury_Extra;
                            }
                            //luxuryTaxAmt = (totalAmountForTax * luxuryTax) / 100;
                            //serviceTaxAmt = (totalAmountForTax * serviceTax) / 100;
                            luxuryTaxAmt = ((totalAmountForTaxLuxury * luxuryTax) / 100) + ((totalAmountForTaxLuxury_Extra * 0) / 100);
                            //serviceTaxAmt = (totalAmountForTaxService * serviceTax) / 100;
                            //totalTaxAmt = luxuryTaxAmt + serviceTaxAmt;
                            serviceTaxAmt = GSTR1TaxAmount;
                            totalTaxAmt = serviceTaxAmt;
                            netAmt = netAmt + totalTaxAmt;
                            advanceAmount = Convert.ToDouble(obj_BookingDetail.advanceAmount);
                            netAmt = netAmt - advanceAmount;
                            netAmt += (obj_BookingDetail.fAndBAmt + obj_BookingDetail.laundryAmt + obj_BookingDetail.roomServiceAmt + obj_BookingDetail.otherAmt);
                            obj_BookingDetail.luxuryTaxAmt = luxuryTaxAmt;
                            obj_BookingDetail.serviceTaxAmt = serviceTaxAmt;
                            obj_BookingDetail.totalTaxAmt = totalTaxAmt;
                            obj_BookingDetail.billDetailXML = _billXML;


                            //paybleAmt = (totalAmount + totalTaxAmt) - (discountAmt + advanceAmount);
                            paybleAmt = Convert.ToInt32(Math.Round(netAmt, 2));
                            obj_BookingDetail.discount = discount;
                            obj_BookingDetail.discountAmount = discountAmt;
                            obj_BookingDetail.amountAfterDis = amtAfterDiscount;
                            obj_BookingDetail.netPayable = paybleAmt;
                            obj_BookingDetail.userID = _unitId;

                            obj_BookingDetail.privilegeAmt = privilegeAmt;
                            obj_BookingDetail.privilegeDist = privilegeDist;

                            ViewBag.spclDiscount = objBusinessClass.GetSpecialDiscount().Select(e => new SelectListItem() { Text = e.SpclDiscountName, Value = e.spclDiscountType.ToString() });
                            //return PartialView("_BookingDetails", obj_BookingDetail);
                            obj_BookingDetail.IsSaved = "Y";
                        }
                    }
                }
            }
            catch
            {
                ViewBag.Show = "There is some error in the system. Please try after sometime!";
            }
            //return Content("0");
            return View(obj_BookingDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RoomBookingDetail(CustomerRegistration model, FormCollection frmChkIn)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                //ModelState["checkInTime"].Errors.Clear();
                //if (ModelState.IsValid)
                //{
                string[] checkedRooms = string.IsNullOrEmpty(Convert.ToString(frmChkIn["CheckedRooms"])) ? null : Convert.ToString(frmChkIn["CheckedRooms"]).Split(',');
                _isValid = (checkedRooms != null && checkedRooms.Length > 0) ? true : false;
                if (_isValid == true)
                {
                    String _checkedRooms = "<Room>";
                    foreach (var item in checkedRooms)
                    {
                        _checkedRooms += "<RoomDetails>";
                        _checkedRooms += "<RequestId>" + Convert.ToInt64(item) + "</RequestId>";
                        _checkedRooms += "</RoomDetails>";
                    }
                    _checkedRooms += "</Room>";
                    model.requestXML = _checkedRooms;
                    Int64 _unitId = SessionManager.UnitID;
                    double GSTR3Tax, GSTR2Tax, GSTR1Tax, GSTR1TaxAmount = 0, luxuryTax, serviceTax, luxuryTaxAmt, serviceTaxAmt, totalAmount = 0, totalTaxAmt, discount, discountAmt, amtAfterDiscount, paybleAmt, advanceAmount, privilegeDist, privilegeAmt = 0, totalOtherAmt = 0, netAmt = 0, totalAmountExtra = 0, totalAmountForTax = 0, discountAmtForTax = 0
                        , totalAmountForTaxLuxury = 0, totalAmountForTaxService = 0, totalAmountForTaxLuxury_Extra = 0, discountAmtForTaxService = 0, discountAmtForTaxLuxury = 0, discountAmtForTaxLuxury_Extra = 0;
                    string GSTDisplayTax = "";
                    List<BookedRoomDetails> objRoom = objBusinessClass.GetBookedRoomDetailsOnCheckOut(model.docketNo, _unitId);
                    List<BillDetails> objBil = null;
                    if (model != null && objRoom != null && objRoom.Count > 0)
                    {
                        foreach (var item in objRoom)
                        {
                            if (model.lstBill != null && model.lstBill.Count > 0)
                            {
                                objBil = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                                model.lstBill.AddRange(objBil);
                            }
                            else
                            {
                                model.lstBill = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                            }
                        }
                    }
                    model.unitID = _unitId;

                    model.isPrivilegeAvail = string.IsNullOrEmpty(model.privilegeCardNo) ? false : true;

                    String _luxuryTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["LuxuryTax"]);
                    if (!String.IsNullOrEmpty(_luxuryTax))
                        luxuryTax = Convert.ToDouble(_luxuryTax);
                    else
                        luxuryTax = 0.0;

                    String _serviceTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["ServiceTax"]);
                    if (!String.IsNullOrEmpty(_serviceTax))
                        serviceTax = Convert.ToDouble(_serviceTax);
                    else
                        serviceTax = 0.0;


                    String _GSTR1Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR1"]);
                    if (!String.IsNullOrEmpty(_GSTR1Tax))
                        GSTR1Tax = Convert.ToDouble(_GSTR1Tax);
                    else
                        GSTR1Tax = 12.00;

                    String _GSTR2Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR2"]);
                    if (!String.IsNullOrEmpty(_GSTR2Tax))
                        GSTR2Tax = Convert.ToDouble(_GSTR2Tax);
                    else
                        GSTR2Tax = 18.00;

                    String _GSTR3Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR3"]);
                    if (!String.IsNullOrEmpty(_GSTR3Tax))
                        GSTR3Tax = Convert.ToDouble(_GSTR3Tax);
                    else
                        GSTR3Tax = 28.00;

                    //String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                    //if (!String.IsNullOrEmpty(_privilegeDist))
                    //    privilegeDist = Convert.ToDouble(_privilegeDist);
                    //else
                    //    privilegeDist = 15;
                    privilegeDist = model.discountPercent;

                    String _UnitForTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["UnitForTax"]);
                    bool _isExtraTax = false;

                    model.luxuryTax = luxuryTax;
                    model.luxuryTaxDisplay = luxuryTax.ToString() + " %";
                    model.serviceTax = serviceTax;
                    model.fAndBAmt = model.fAndBAmt > 0 ? model.fAndBAmt : 0;
                    model.laundryAmt = model.laundryAmt > 0 ? model.laundryAmt : 0;
                    model.roomServiceAmt = model.roomServiceAmt > 0 ? model.roomServiceAmt : 0;
                    model.otherAmt = model.otherAmt > 0 ? model.otherAmt : 0;

                    String _billXML = "<bill>";
                    foreach (BillDetails item in model.lstBill)
                    {
                        _billXML += "<billDetails>";
                        _billXML += "<BillDate>" + item.RentDate + "</BillDate>";
                        _billXML += "<billDetail>" + item.BillDescription + "</billDetail>";
                        _billXML += "<amount>" + item.Amount + "</amount>";
                        _billXML += "<roomNo>" + item.RoomNo + "</roomNo>";
                        _billXML += "<requestId>" + item.requestId + "</requestId>";
                        _billXML += "<ExtraBedAmount>" + item.ExtraBedAmount + "</ExtraBedAmount>";
                        _billXML += "</billDetails>";
                        totalAmount += Convert.ToDouble(item.Amount);
                        totalAmountExtra += Convert.ToDouble(item.ExtraBedAmount);
                        ////totalAmountForTax += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amount) + Convert.ToDouble(item.ExtraBedAmount)) : 0;
                        if (_isExtraTax == true && item.basetariff >= 3500)
                        {
                            model.luxuryTaxDisplay = luxuryTax.ToString() + " / 10 %";
                            totalAmountForTaxLuxury_Extra += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff) + Convert.ToDouble(item.baseExtraBedAmount)) : 0;
                            discountAmtForTaxLuxury_Extra += (item.isTaxEligible == true) ? Convert.ToDouble(item.Amountbasetariff) : 0;
                        }
                        else
                        {
                            totalAmountForTaxLuxury += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff) + Convert.ToDouble(item.baseExtraBedAmount)) : 0;
                            discountAmtForTaxLuxury += (item.isTaxEligible == true) ? Convert.ToDouble(item.Amountbasetariff) : 0;
                        }

                        // FOR GST

                        if (item.basetariff < 1000)
                        {

                            GSTR1TaxAmount += 0;
                            if (!GSTDisplayTax.Contains("0%"))
                            {
                                GSTDisplayTax = GSTDisplayTax + "0%, ";
                            }

                        }
                        //else if (item.basetariff >= 1000 && item.basetariff <= 2499)
                        //{
                        //    if (!GSTDisplayTax.Contains(GSTR1Tax.ToString()))
                        //    {
                        //        GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, ";
                        //    }
                        //    discount = model.discount;
                        //    var DiscAmt = Convert.ToDouble(item.Amountbasetariff);
                        //    discountAmt = (DiscAmt * discount) / 100;
                        //    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);

                        //    GSTR1TaxAmount += ((tamount * GSTR1Tax) / 100);

                        //}

                        //else if (item.basetariff >= 2500 && item.basetariff <= 7499)
                        //{
                        //    if (!GSTDisplayTax.Contains(GSTR2Tax.ToString()))
                        //    {
                        //        GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, ";
                        //    }
                        //    discount = model.discount;
                        //    var DiscAmt = (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                        //    discountAmt = (DiscAmt * discount) / 100;
                        //    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);

                        //    GSTR1TaxAmount += ((tamount * GSTR2Tax) / 100);
                        //}
                        //else
                        //{
                        //    if (!GSTDisplayTax.Contains(GSTR3Tax.ToString()))
                        //    {
                        //        GSTDisplayTax = GSTDisplayTax + GSTR3Tax.ToString() + "%, ";
                        //    }
                        //    discount = model.discount;
                        //    var DiscAmt = (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                        //    discountAmt = (DiscAmt * discount) / 100;
                        //    var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);

                        //    GSTR1TaxAmount += ((tamount * GSTR3Tax) / 100);
                        //}
                        else if (item.basetariff >= 1000 && item.basetariff <= 7500)
                        {
                            if (!GSTDisplayTax.Contains(GSTR1Tax.ToString()))
                            {
                                GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, ";
                            }
                            discount = model.discount;
                            var DiscAmt = Convert.ToDouble(item.Amountbasetariff);
                            discountAmt = (DiscAmt * discount) / 100;
                            var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);

                            GSTR1TaxAmount += ((tamount * GSTR1Tax) / 100);

                        }

                        else if (item.basetariff > 7500)
                        {
                            if (!GSTDisplayTax.Contains(GSTR2Tax.ToString()))
                            {
                                GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, ";
                            }
                            discount = model.discount;
                            var DiscAmt = (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff)) : 0;
                            discountAmt = (DiscAmt * discount) / 100;
                            var tamount = (Convert.ToDouble(item.Amountbasetariff) - discountAmt) + Convert.ToDouble(item.baseExtraBedAmount);

                            GSTR1TaxAmount += ((tamount * GSTR2Tax) / 100);
                        }

                        totalAmountForTaxService += (item.isTaxEligible == true) ? (Convert.ToDouble(item.Amountbasetariff) + Convert.ToDouble(item.baseExtraBedAmount)) : 0;
                        discountAmtForTaxService += (item.isTaxEligible == true) ? Convert.ToDouble(item.Amountbasetariff) : 0;
                    }
                    _billXML += "</bill>";

                    model.totalAmountExtra = totalAmountExtra;
                    model.totalAmount = totalAmount;
                    //model.totalAmountForTax = totalAmountForTax;
                    model.discountAmtForTaxLuxury_Extra = discountAmtForTaxLuxury_Extra;
                    model.discountAmtForTaxLuxury = discountAmtForTaxLuxury;
                    model.discountAmtForTaxService = discountAmtForTaxService;
                    model.totalAmountForTaxLuxury = totalAmountForTaxLuxury;
                    model.totalAmountForTaxService = totalAmountForTaxService;
                    model.totalAmountForTaxLuxury_Extra = totalAmountForTaxLuxury_Extra;
                    if (model.spclDiscount > 80)
                    {
                        model.spclDiscount = 80;
                    }
                    discount = model.discount + model.spclDiscount;
                    discountAmt = (totalAmount * discount) / 100;
                    //discountAmtForTax = (totalAmountForTax * discount) / 100;
                    discountAmtForTaxLuxury = (discountAmtForTaxLuxury * discount) / 100;
                    discountAmtForTaxService = (discountAmtForTaxService * discount) / 100;
                    discountAmtForTaxLuxury_Extra = (discountAmtForTaxLuxury_Extra * discount) / 100;

                    amtAfterDiscount = (totalAmount - discountAmt) + totalAmountExtra;
                    //totalAmountForTax = (totalAmountForTax - discountAmtForTax);
                    totalAmountForTaxLuxury = (totalAmountForTaxLuxury - discountAmtForTaxLuxury);
                    totalAmountForTaxService = (totalAmountForTaxService - discountAmtForTaxService);
                    totalAmountForTaxLuxury_Extra = (totalAmountForTaxLuxury_Extra - discountAmtForTaxLuxury_Extra);

                    netAmt = amtAfterDiscount;
                    if (model.isPrivilegeAvail == true)
                    {
                        double privilegeAmtLuxury, privilegeAmtLuxury_Extra, privilegeAmtService;
                        privilegeAmt = (totalAmount * privilegeDist) / 100;
                        privilegeAmtLuxury = (totalAmountForTaxLuxury * privilegeDist) / 100;
                        privilegeAmtLuxury_Extra = (totalAmountForTaxLuxury_Extra * privilegeDist) / 100;
                        privilegeAmtService = (totalAmountForTaxService * privilegeDist) / 100;
                        netAmt = (model.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;
                        amtAfterDiscount = (model.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;
                        //totalAmountForTax = (model.isPrivilegeVerified == true) ? (totalAmountForTax - privilegeAmt) : totalAmountForTax;
                        totalAmountForTaxLuxury = (model.isPrivilegeVerified == true) ? (totalAmountForTaxLuxury - privilegeAmtLuxury) : totalAmountForTaxLuxury;
                        totalAmountForTaxService = (model.isPrivilegeVerified == true) ? (totalAmountForTaxService - privilegeAmtService) : totalAmountForTaxService;
                        totalAmountForTaxLuxury_Extra = (model.isPrivilegeVerified == true) ? (totalAmountForTaxLuxury_Extra - privilegeAmtLuxury_Extra) : totalAmountForTaxLuxury_Extra;
                    }
                    //luxuryTaxAmt = (totalAmountForTax * luxuryTax) / 100;
                    //serviceTaxAmt = (totalAmountForTax * serviceTax) / 100;
                    luxuryTaxAmt = ((totalAmountForTaxLuxury * luxuryTax) / 100) + ((totalAmountForTaxLuxury_Extra * 10) / 100);
                    serviceTaxAmt = GSTR1TaxAmount;

                    totalTaxAmt = GSTR1TaxAmount;
                    netAmt = netAmt + totalTaxAmt;
                    advanceAmount = Convert.ToDouble(model.advanceAmount);
                    netAmt = netAmt - advanceAmount;
                    netAmt += (model.fAndBAmt + model.laundryAmt + model.roomServiceAmt + model.otherAmt);
                    model.luxuryTaxAmt = luxuryTaxAmt;
                    model.serviceTaxAmt = GSTR1TaxAmount;
                    model.totalTaxAmt = totalTaxAmt;
                    model.billDetailXML = _billXML;


                    //paybleAmt = (totalAmount + totalTaxAmt) - (discountAmt + advanceAmount);
                    paybleAmt = netAmt;
                    //model.discount = discount;
                    model.discountAmount = discountAmt;
                    model.amountAfterDis = amtAfterDiscount;
                    model.totalPayable = Math.Round(paybleAmt, 2);
                    model.netPayable = Convert.ToInt32(Math.Round(paybleAmt, 2));
                    model.userID = model.unitID;
                    string UnitPaymentsSlabXML = "";
                    model.privilegeAmt = privilegeAmt;
                    model.privilegeDist = privilegeDist;
                    model.roundOffValue = (model.netPayable - model.totalPayable);
                    model.GstApplyed = GSTDisplayTax;
                    var user = objBusinessClass.InsertCheckOutDetails(model, UnitPaymentsSlabXML);
                    if (user != null)
                    {
                        SessionManager.BillNo = user.billNo;
                        SessionManager.DocketNo = model.docketNo;
                        return RedirectToAction("CheckOutConfirmation");
                    }
                }
                else
                {
                    _msg = "No Room Selected for Check Out!! ";
                }
            }
            catch
            { _msg = "Unable to process!"; }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            //return Json(new { result = false, message = "Unable to process!" }, JsonRequestBehavior.AllowGet);
            ViewBag.spclDiscount = objBusinessClass.GetSpecialDiscount().Select(e => new SelectListItem() { Text = e.SpclDiscountName, Value = e.spclDiscountType.ToString() });
            return RedirectToAction("CheckOut");
        }

        #region check out Confirmation
        [HttpGet]
        public ActionResult CheckOutConfirmation()
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();
                model.billNo = SessionManager.BillNo;
                model.docketNo = SessionManager.DocketNo;

                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        #endregion

        #endregion

        #region payment details
        [HttpGet]
        public ActionResult PaymentDetails()
        {
            try
            {
                if (TempData["msg"] != null && TempData["msg"].ToString() != "")
                {
                    ViewBag.Show = TempData["message"];
                }
                return View();
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpGet]
        public ActionResult PaymentList(string paymentDateFrom, string paymentDateTo, string docketNo)
        {
            string _msg;
            DateTime _payDateFrom, _payDateTo;
            try
            {
                Int64 _unitId = SessionManager.UnitID;
                try
                {
                    _payDateFrom = DateTime.ParseExact(paymentDateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateFrom = null;
                    _payDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    _payDateTo = DateTime.ParseExact(paymentDateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateTo = null;
                    _payDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                List<PaymentDetails> objPayment = objBusinessClass.GetPaymentDetails(_payDateFrom, _payDateTo, _unitId, docketNo.Trim());
                if (objPayment != null && objPayment.Count > 0)
                {
                    return PartialView("_PaymentList", objPayment);
                }
                else
                {
                    _msg = "Details Not Found!!";
                }
            }
            catch
            {
                //return PartialView("_ErrorPagePartialWebsite");
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }

        [HttpGet]
        public ActionResult AdvancePaymentList(string docketNo)
        {
            string _msg;
            try
            {
                Int64 _unitId = SessionManager.UnitID;
                List<PaymentDetails> objPayment = objBusinessClass.GetAdvancePaymentDetails(docketNo.Trim(), _unitId);
                if (objPayment != null && objPayment.Count > 0)
                {
                    return PartialView("_AdvancePaymentList", objPayment);
                }
                else
                {
                    _msg = "Details Not Found!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }


        #endregion

        #region Added by Samreen
        #region Generate Receipt
        [HttpGet]
        public ActionResult GenerateCheckoutReceipt(string docketNo)
        {

            CheckOutBillDetails objDetails = new CheckOutBillDetails();
            try
            {
                //string docketNo = SessionManager.DocketNo;              
                decimal totalAmount = 0, discountedAmount = 0, billAmount = 0, luxuryTax = 0, luxuryTaxAmt = 0, ServiceTax = 0, serviceTaxAmt = 0, netAmount = 0, advanceAmount = 0, discount = 0, discountAmount = 0, netpayableAmount = 0, privilegeAmt = 0, privilegeDist = 0;
                Int64 _unitId = SessionManager.UnitID;
                var objDetailsList = objBusinessClass.GetCheckOutBillDetails(docketNo, _unitId).ToList();
                ViewBag.details = objDetailsList;
                objDetails.discountedAmount = objDetailsList.FirstOrDefault().discountedAmount;
                ServiceTax = objDetailsList.FirstOrDefault().serviceTax;
                serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.discountPer = objDetailsList.FirstOrDefault().discountPer;

                if (DateTime.ParseExact(objDetailsList.FirstOrDefault().arrivalDate, "dd/MM/yyyy", null) >= new DateTime(2017, 07, 01))
                {
                    return RedirectToAction("GenerateCheckoutReceiptGST", new { docketNo = docketNo });
                }

                foreach (var i in objDetailsList)
                {
                    netAmount += i.Amount;
                }
                //netAmount = netAmount + objDetailsList.FirstOrDefault().fAndBAmt + objDetailsList.FirstOrDefault().laundryAmt + objDetailsList.FirstOrDefault().roomServiceAmt + objDetailsList.FirstOrDefault().otherAmt;
                //String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                //if (!String.IsNullOrEmpty(_privilegeDist))
                //    privilegeDist = Convert.ToDecimal(_privilegeDist);
                //else
                //    privilegeDist = 15;

                //if (objDetails.isPrivilegeVerified == true)
                //{
                //    privilegeAmt = (netAmount * privilegeDist) / 100;
                //    netAmount = (netAmount - privilegeAmt);
                //    //objDetails.totalAmount = (objDetails.isPrivilegeVerified == true) ? (objDetails.totalAmount - privilegeAmt) : objDetails.totalAmount;
                //    objDetails.privilegeAmt = privilegeAmt;
                //}
                //discountedAmount = (netAmount - discountAmount);
                //billAmount = discountedAmount;
                //objDetails.billAmount = discountedAmount; 
                objDetails.serviceTax = objDetailsList.FirstOrDefault().serviceTax;
                objDetails.serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                objDetails.luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                objDetails.luxuryTaxDisplay = objDetailsList.FirstOrDefault().luxuryTax.ToString();
                objDetails.luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                // totalAmount = billAmount + serviceTaxAmt + luxuryTaxAmt;

                //if (totalAmount > advanceAmount)
                //{
                //    netpayableAmount = Math.Ceiling(totalAmount - advanceAmount);
                //}
                //else
                //{
                //    netpayableAmount = Math.Ceiling(advanceAmount - totalAmount);
                //}
                objDetails.netpayableAmount = objDetailsList.FirstOrDefault().netpayableAmount;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                //objDetails.totalAmount = totalAmount;
                objDetails.discountAmount = objDetailsList.FirstOrDefault().discountAmount;
                objDetails.netAmount = netAmount;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.AdvRecNo = objDetailsList.FirstOrDefault().AdvRecNo;
                objDetails.arrivalDate = objDetailsList.FirstOrDefault().arrivalDate;
                objDetails.arrivalTime = objDetailsList.FirstOrDefault().arrivalTime;
                objDetails.BillDate = objDetailsList.FirstOrDefault().BillDate;
                objDetails.BillDetail = objDetailsList.FirstOrDefault().BillDetail;
                objDetails.billNo = objDetailsList.FirstOrDefault().billNo;
                objDetails.bookedThrough = objDetailsList.FirstOrDefault().bookedThrough;
                objDetails.CheckoutDate = objDetailsList.FirstOrDefault().CheckoutDate;
                objDetails.CheckoutTime = objDetailsList.FirstOrDefault().CheckoutTime;
                objDetails.guestName = objDetailsList.FirstOrDefault().guestName;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.nationality = objDetailsList.FirstOrDefault().nationality;
                objDetails.docketNo = objDetailsList.FirstOrDefault().docketNo;
                objDetails.roomNo = objDetailsList.FirstOrDefault().roomNo;
                objDetails.unitAddress = objDetailsList.FirstOrDefault().unitAddress;
                objDetails.UnitName = objDetailsList.FirstOrDefault().UnitName;
                objDetails.tinNo = objDetailsList.FirstOrDefault().tinNo;
                objDetails.tanNo = objDetailsList.FirstOrDefault().tanNo;
                objDetails.panNo = objDetailsList.FirstOrDefault().panNo;
                objDetails.serTaxNo = objDetailsList.FirstOrDefault().serTaxNo;
                objDetails.fAndBAmt = objDetailsList.FirstOrDefault().fAndBAmt;
                objDetails.laundryAmt = objDetailsList.FirstOrDefault().laundryAmt;
                objDetails.roomServiceAmt = objDetailsList.FirstOrDefault().roomServiceAmt;
                objDetails.otherAmt = objDetailsList.FirstOrDefault().otherAmt;
                objDetails.totalPayable = objDetailsList.FirstOrDefault().totalPayable;
                objDetails.roundOffValue = objDetailsList.FirstOrDefault().roundOffValue;
                objDetails.spclDiscount = objDetailsList.FirstOrDefault().spclDiscount;
                objDetails.SpclDiscountName = objDetailsList.FirstOrDefault().SpclDiscountName;
                objDetails.isPrivilegeVerified = objDetailsList.FirstOrDefault().isPrivilegeVerified;
                objDetails.privilegeCardNo = objDetailsList.FirstOrDefault().privilegeCardNo;
                objDetails.privilegeCardDate = objDetailsList.FirstOrDefault().privilegeCardDate;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                objDetails.privilegeDist = objDetailsList.FirstOrDefault().privilegeDist;
                objDetails.unitContact = objDetailsList.FirstOrDefault().unitContact;
                String _UnitForTax = System.Configuration.ConfigurationManager.AppSettings["UnitForTax"].ToString();
                //bool _isExtraTax = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? true : false;
                objDetails.luxuryTaxDisplay = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? objDetailsList.FirstOrDefault().luxuryTax.ToString() + " / 10.00" : objDetailsList.FirstOrDefault().luxuryTax.ToString();
                objDetails.advPayment = objDetailsList.FirstOrDefault().advPayment;

            }
            catch
            { }


            return View(objDetails);
        }
        #endregion

        #region Generate Receipt GST
        [HttpGet]
        public ActionResult GenerateCheckoutReceiptGST(string docketNo)
        {

            CheckOutBillDetails objDetails = new CheckOutBillDetails();
            try
            {
                //string docketNo = SessionManager.DocketNo;              
                decimal totalAmount = 0, discountedAmount = 0, billAmount = 0, luxuryTax = 0, luxuryTaxAmt = 0, ServiceTax = 0, serviceTaxAmt = 0, netAmount = 0, advanceAmount = 0, discount = 0, discountAmount = 0, netpayableAmount = 0, privilegeAmt = 0, privilegeDist = 0;
                Int64 _unitId = SessionManager.UnitID;
                var objDetailsList = objBusinessClass.GetCheckOutBillDetails(docketNo, _unitId).ToList();
                ViewBag.details = objDetailsList;
                objDetails.discountedAmount = objDetailsList.FirstOrDefault().discountedAmount;
                ServiceTax = objDetailsList.FirstOrDefault().serviceTax;
                serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.discountPer = objDetailsList.FirstOrDefault().discountPer;
                foreach (var i in objDetailsList)
                {
                    netAmount += i.Amount;
                }
                //netAmount = netAmount + objDetailsList.FirstOrDefault().fAndBAmt + objDetailsList.FirstOrDefault().laundryAmt + objDetailsList.FirstOrDefault().roomServiceAmt + objDetailsList.FirstOrDefault().otherAmt;
                //String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                //if (!String.IsNullOrEmpty(_privilegeDist))
                //    privilegeDist = Convert.ToDecimal(_privilegeDist);
                //else
                //    privilegeDist = 15;

                //if (objDetails.isPrivilegeVerified == true)
                //{
                //    privilegeAmt = (netAmount * privilegeDist) / 100;
                //    netAmount = (netAmount - privilegeAmt);
                //    //objDetails.totalAmount = (objDetails.isPrivilegeVerified == true) ? (objDetails.totalAmount - privilegeAmt) : objDetails.totalAmount;
                //    objDetails.privilegeAmt = privilegeAmt;
                //}
                //discountedAmount = (netAmount - discountAmount);
                //billAmount = discountedAmount;
                //objDetails.billAmount = discountedAmount; 
                objDetails.serviceTax = objDetailsList.FirstOrDefault().serviceTax;
                objDetails.serviceTaxAmt = objDetailsList.FirstOrDefault().serviceTaxAmt;
                objDetails.luxuryTax = objDetailsList.FirstOrDefault().luxuryTax;
                objDetails.luxuryTaxDisplay = objDetailsList.FirstOrDefault().luxuryTax.ToString();
                objDetails.luxuryTaxAmt = objDetailsList.FirstOrDefault().luxuryTaxAmt;
                // totalAmount = billAmount + serviceTaxAmt + luxuryTaxAmt;

                //if (totalAmount > advanceAmount)
                //{
                //    netpayableAmount = Math.Ceiling(totalAmount - advanceAmount);
                //}
                //else
                //{
                //    netpayableAmount = Math.Ceiling(advanceAmount - totalAmount);
                //}
                objDetails.netpayableAmount = objDetailsList.FirstOrDefault().netpayableAmount;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                //objDetails.totalAmount = totalAmount;
                objDetails.discountAmount = objDetailsList.FirstOrDefault().discountAmount;
                objDetails.netAmount = netAmount;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.advanceAmount = objDetailsList.FirstOrDefault().advanceAmount;
                objDetails.AdvRecNo = objDetailsList.FirstOrDefault().AdvRecNo;
                objDetails.arrivalDate = objDetailsList.FirstOrDefault().arrivalDate;
                objDetails.arrivalTime = objDetailsList.FirstOrDefault().arrivalTime;
                objDetails.BillDate = objDetailsList.FirstOrDefault().BillDate;
                objDetails.BillDetail = objDetailsList.FirstOrDefault().BillDetail;
                objDetails.billNo = objDetailsList.FirstOrDefault().billNo;
                objDetails.bookedThrough = objDetailsList.FirstOrDefault().bookedThrough;
                objDetails.CheckoutDate = objDetailsList.FirstOrDefault().CheckoutDate;
                objDetails.CheckoutTime = objDetailsList.FirstOrDefault().CheckoutTime;
                objDetails.guestName = objDetailsList.FirstOrDefault().guestName;
                objDetails.address = objDetailsList.FirstOrDefault().address;
                objDetails.nationality = objDetailsList.FirstOrDefault().nationality;
                objDetails.docketNo = objDetailsList.FirstOrDefault().docketNo;
                objDetails.roomNo = objDetailsList.FirstOrDefault().roomNo;
                objDetails.unitAddress = objDetailsList.FirstOrDefault().unitAddress;
                objDetails.UnitName = objDetailsList.FirstOrDefault().UnitName;
                objDetails.tinNo = objDetailsList.FirstOrDefault().tinNo;
                objDetails.tanNo = objDetailsList.FirstOrDefault().tanNo;
                objDetails.panNo = objDetailsList.FirstOrDefault().panNo;
                objDetails.serTaxNo = objDetailsList.FirstOrDefault().serTaxNo;
                objDetails.fAndBAmt = objDetailsList.FirstOrDefault().fAndBAmt;
                objDetails.laundryAmt = objDetailsList.FirstOrDefault().laundryAmt;
                objDetails.roomServiceAmt = objDetailsList.FirstOrDefault().roomServiceAmt;
                objDetails.otherAmt = objDetailsList.FirstOrDefault().otherAmt;
                objDetails.totalPayable = objDetailsList.FirstOrDefault().totalPayable;
                objDetails.roundOffValue = objDetailsList.FirstOrDefault().roundOffValue;
                objDetails.spclDiscount = objDetailsList.FirstOrDefault().spclDiscount;
                objDetails.SpclDiscountName = objDetailsList.FirstOrDefault().SpclDiscountName;
                objDetails.isPrivilegeVerified = objDetailsList.FirstOrDefault().isPrivilegeVerified;
                objDetails.privilegeCardNo = objDetailsList.FirstOrDefault().privilegeCardNo;
                objDetails.privilegeCardDate = objDetailsList.FirstOrDefault().privilegeCardDate;
                objDetails.privilegeAmt = objDetailsList.FirstOrDefault().privilegeAmt;
                objDetails.privilegeDist = objDetailsList.FirstOrDefault().privilegeDist;
                objDetails.unitContact = objDetailsList.FirstOrDefault().unitContact;
                objDetails.GSTApplyed = objDetailsList.FirstOrDefault().GSTApplyed.TrimEnd(',');

                objDetails.GSTApplyed = objCommonClass.GetCGSTandSGSTSepration(objDetails.GSTApplyed).Trim().TrimEnd(',');

                String _UnitForTax = System.Configuration.ConfigurationManager.AppSettings["UnitForTax"].ToString();
                //bool _isExtraTax = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? true : false;
                //objDetails.luxuryTaxDisplay = _UnitForTax.Split(',').Contains(_unitId.ToString()) ? objDetailsList.FirstOrDefault().luxuryTax.ToString() + " / 10.00" : objDetailsList.FirstOrDefault().luxuryTax.ToString();
                objDetails.advPayment = objDetailsList.FirstOrDefault().advPayment;

            }
            catch
            { }


            return View(objDetails);
        }
        #endregion
        #endregion

        #region checkin
        [HttpGet]
        public ActionResult Checkin(string docketNo = null)
        {
            CheckinDetails obj = new CheckinDetails();
            obj.docketNo = docketNo;
            return View(obj);
        }
        #endregion

        #region get booking details for checkin
        [HttpGet]
        public ActionResult BookingDetailForCheckIn(string docketNo)
        {
            CheckinDetails model = new CheckinDetails();

            try
            {
                Int64 _unitId = SessionManager.UnitID;
                model.unitID = _unitId;
                model.docketNo = docketNo.Trim();

                model = objBusinessClass.GetBookingDetailsForCheckin(model);
                if (model != null)
                {
                    model.unitID = _unitId;
                    model.lstBookedRoomDetail = objBusinessClass.GetBookedRoomDetails(model);
                    foreach (var lstRoom in model.lstBookedRoomDetail)
                    {
                        lstRoom.lstRoomNoDetail = objBusinessClass.GetRoomsOnCheckIn(_unitId, lstRoom.requestID, Convert.ToInt32(lstRoom.roomType));
                    }
                    IList<CheckinDetails> lstCheckinDetails = objBusinessClass.GetBookingDetailsList(model);
                    model.checkInDateShow = lstCheckinDetails.Min(c => c.checkInDate);
                    model.checkOutDateShow = lstCheckinDetails.Max(c => c.checkOutDateShow);
                    model.checkInDateActual = DateTime.Now.Date;
                    model.duration = model.checkOutDateShow.Subtract(model.checkInDateShow).Days.ToString();
                    model.checkInTime = DateTime.Now;
                }
                else
                {

                }
            }
            catch
            {
            }
            return PartialView("_Checkin", model);
        }
        #endregion

        #region save checkin details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Checkin(CheckinDetails model, FormCollection frmChkIn)
        {
            string _msg = string.Empty;
            bool _isValid = true;
            string[] checkedRooms = null;
            try
            {
                ModelState["checkInTime"].Errors.Clear();
                //if (frmChkIn["SelectedRooms"] == null)
                //{
                //    _isValid = false;
                //}
                //else
                //{
                //    checkedRooms = frmChkIn["SelectedRooms"].Split(',');
                //    _isValid = model.lstBookedRoomDetail.Sum(c => c.totalRoom) > checkedRooms.Length ? false : true;
                //}

                //if (_isValid == true)
                //{
                //if (model.lstBookedRoomDetail.Sum(c => c.totalRoom) < checkedRooms.Length)
                //{
                //    _msg = "Total No. of selected rooms is more than required rooms!!";
                //}
                //else
                //{
                #region Validate Uploaded Doc
                if (model.isPrivilegeVerified)
                {
                    if (model.privilegeCard != null)
                    {
                        string ext = Path.GetExtension(model.privilegeCard.FileName);
                        string filename = Path.GetFileName("Priv_" + model.docketNo + DateTime.Now.Ticks + ext);
                        string res = objCommonClass.ValidateImageWithCusomSize(model.privilegeCard, 400);
                        if (res.Trim() != "Valid")
                        {
                            _isValid = false;
                            _msg = res;
                        }
                        else
                        {
                            model.privilegeCardPath = Path.Combine("~/Content/writereaddata/PrivilegeCard/", filename);
                            var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/PrivilegeCard/"), filename);
                            model.privilegeCard.SaveAs(docPath);
                        }
                    }
                }
                #endregion

                if (ModelState.IsValid && _isValid)
                {
                    //if (model.advancePayment == null || model.advancePayment <= 0)
                    //{
                    //    _isValid = false;
                    //    _msg = "Enter Valid Advance Amount ";
                    //    ModelState.AddModelError("", "Enter Valid Advance Amount ");
                    //}
                    //else
                    //{
                    model.userIP = this.Request.UserHostAddress;
                    model.unitID = SessionManager.UnitID;
                    String strXML = string.Empty;

                    #region add rooms date wise and request Id wise
                    Int64 reqId = 0; int _roomId = 0;
                    //IList<CheckinDetails> lstCheckinDetails = objBusinessClass.GetBookingDetailsList(model);
                    var _matchedRooms = model.lstBookedRoomDetail;
                    if (_matchedRooms != null && _matchedRooms.Count > 0)
                    {
                        List<string> matchedRooms = new List<string>();
                        strXML = "<RoomDetail>";
                        foreach (var item in _matchedRooms)
                        {
                            int totalDays = item.checkOutDate.Subtract(item.checkInDate).Days + 1;
                            DateTime bookingDate;
                            for (int i = 0; i < totalDays; i++)
                            {
                                bookingDate = item.checkInDate.AddDays(i);
                                //reqId = item.requestID;
                                //_roomId = item.roomTypeId;
                                //var _matchedRooms = model.lstBookedRoomDetail.Where(m => m.roomType == _roomId).FirstOrDefault();
                                //var _matchedRooms = model.lstBookedRoomDetail.Where(m => m.roomType == _roomId && m.requestID == item.requestID).ToList();
                                //if (_matchedRooms != null && _matchedRooms.Count > 0)
                                //{
                                int count = 0;
                                //for (int j = 0; j < _matchedRooms.Count; j++)
                                //{
                                if (item.lstRoomNoDetail != null && item.lstRoomNoDetail.Count > 0)
                                {
                                    int noOfRooms = item.totalRoom, _currSelectedRoom = 0;
                                    if (frmChkIn["SelectedRooms_" + item.requestID + ""] != null && frmChkIn["SelectedRooms_" + item.requestID + ""].Split(',').Length > 0)
                                    {
                                        checkedRooms = frmChkIn["SelectedRooms_" + item.requestID + ""].Split(',');
                                        foreach (var room in item.lstRoomNoDetail)
                                        {
                                            if (checkedRooms.Contains(Convert.ToString(room.RoomNoId)))
                                            {
                                                strXML += "<RoomList>";
                                                strXML += "<RequestId>" + item.requestID + "</RequestId>";
                                                strXML += "<bookingDate>" + bookingDate.ToString("yyyy/MM/dd") + "</bookingDate>";
                                                strXML += "<RoomNoId>" + room.RoomNoId + "</RoomNoId>";
                                                strXML += "<extrabed>" + item.extrabed + "</extrabed>";
                                                strXML += "</RoomList>";
                                                //matchedRooms[count++] = Convert.ToString(room.RoomNoId);
                                                if (i == 0)
                                                {
                                                    matchedRooms.Add(Convert.ToString(room.RoomNoId));
                                                }
                                                _currSelectedRoom++;
                                            }
                                        }
                                        if (_currSelectedRoom == 0)
                                        {
                                            _isValid = false;
                                            _msg = "No room selected for " + item.roomTypeDisplay;
                                            break;
                                        }
                                        else if (_currSelectedRoom < noOfRooms)
                                        {
                                            _isValid = false;
                                            _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay;
                                            break;
                                        }
                                        else if (_currSelectedRoom > noOfRooms)
                                        {
                                            _isValid = false;
                                            _msg = "Total No. of selected rooms is more than required rooms for " + item.roomTypeDisplay;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        _isValid = false;
                                        _msg = "No room selected for " + item.roomTypeDisplay;
                                        break;
                                    }
                                }
                                else
                                {
                                    _isValid = false;
                                    _msg = "Details Not Valid.Try Again..";
                                }
                                //}
                                //if (_isValid == false)
                                //{
                                //    break;
                                //}
                                //}
                                //if (_isValid == false)
                                //{
                                //    break;
                                //}
                            }
                            if (_isValid == false)
                            {
                                break;
                            }
                        }

                        #region for check duplicate values for rooms
                        var chkItems = matchedRooms.Distinct().ToArray();
                        if (matchedRooms.ToArray().Length != chkItems.Length)
                        {
                            for (int k = 0; k < matchedRooms.ToArray().Length; k++)
                            {
                                try
                                {
                                    if (matchedRooms[k].ToString() != chkItems[k].ToString())
                                    {
                                        _isValid = false;
                                        //_msg = "Found duplicate Room " + matchedRooms[j].ToString();
                                        _msg = "Select distinct rooms!!";
                                        break;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    _isValid = false;
                                    _msg = "Select distinct rooms!!";
                                    break;
                                }
                            }
                        }
                        #endregion
                        //if (_isValid == false)
                        //{
                        //    break;
                        //}
                        strXML += "</RoomDetail>";
                    }
                    else
                    {
                        _isValid = false;
                        _msg = "Details Not Valid.Try Again..";
                    }
                    #endregion

                    //var roomXml = new XElement("RoomDetail",
                    //  from room in model.lstRoomNoDetail
                    //  select new XElement("RoomList",
                    //                 new XElement("noOfBed", room.noOfBed),
                    //                 new XElement("RoomNoId", room.RoomNoId)
                    //             ));
                    if (_isValid == true)
                    {
                        int result = objBusinessClass.InsertCheckinDetail(model, strXML);
                        if (result > 0)
                        {
                            TempData["docketNo"] = model.docketNo;
                            return RedirectToAction("CheckInConfirmation", "Unit");
                        }
                        else
                        {
                            _msg = "Rooms Not Available.Try Again..";
                        }
                    }
                    //}
                    //}
                    //}
                    //else
                    //{
                    //    _msg = "Total No. of selected rooms is not sufficient";
                    //}
                }
            }
            catch
            {
                _msg = "Error in Process!";
            }
            Int64 _unitId = SessionManager.UnitID;
            //model = objBusinessClass.GetBookingDetailsForCheckin(model);
            model.unitID = _unitId;
            model.lstBookedRoomDetail = objBusinessClass.GetBookedRoomDetails(model);
            foreach (var lstRoom in model.lstBookedRoomDetail)
            {
                lstRoom.lstRoomNoDetail = objBusinessClass.GetRoomsOnCheckIn(_unitId, lstRoom.requestID, Convert.ToInt32(lstRoom.roomType));
            }
            IList<CheckinDetails> lstCheckinDetailsNew = objBusinessClass.GetBookingDetailsList(model);
            model.checkInDateShow = lstCheckinDetailsNew.Min(c => c.checkInDate);
            model.checkOutDateShow = lstCheckinDetailsNew.Max(c => c.checkOutDateShow);
            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        #region check in Confirmation
        [HttpGet]
        public ActionResult CheckInConfirmation()
        {
            CheckinDetails model = new CheckinDetails();
            try
            {
                model.unitID = SessionManager.UnitID;
                model = objBusinessClass.GetCheckinDetails(TempData.Peek("docketNo").ToString());
            }
            catch
            {

            }
            return View(model);
        }

        #endregion

        /*----------------------------Extend Booking-------------------------------*/

        #region Display Extend Booking
        [HttpGet]
        public ActionResult ExtendBooking()
        {
            return View();
        }
        #endregion

        #region get booking details to Extend Booking
        [HttpGet]
        public ActionResult BookingDetailToExtendBooking(string docketNo)
        {
            ExtendBookingDetails model = new ExtendBookingDetails();
            try
            {
                model.unitID = SessionManager.UnitID;
                model.docketNo = docketNo.Trim();

                model = objBusinessClass.GetBookingDetailsToExtendBooking(model);
                if (model != null)
                {
                    if (model.isCheckIn == true)
                    {
                        model.extendedDate = model.checkOutDate.AddDays(1);
                        model.roomExtendDetailList = objBusinessClass.GetExtendedRoomDetails(docketNo.Trim(), SessionManager.UnitID);
                        ViewBag.RoomType = objBusinessClass.GetRoomType(model.unitID).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
                    }
                    else
                    {
                        // "Not Checked In!!";
                        return Content("NC");
                    }
                }
                else
                {
                    // "Not Found!!";
                    return Content("NA");
                }
            }
            catch
            {  // "Not Found!!";
                return Content("NA");
            }
            return PartialView("_ExtendBooking", model);
        }
        #endregion

        #region save Extend details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ExtendBooking(ExtendBookingDetails model, FormCollection frmExtend)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string[] checkedRooms = null;
                    string _msg = string.Empty;
                    DateTime currDate = DateTime.Now.AddDays(-1);
                    DateTime maxCheckOutDate = currDate.AddDays(179);

                    var extendedRoomList = model.lstBookedRoomDetail;
                    if (extendedRoomList != null && extendedRoomList.Count() > 0)
                    {
                        bool _isRoomAvl = true;
                        bool _isValidDate = true;
                        string roomXml = "", bookingXml = "";
                        roomXml = "<RoomDetail>";
                        bookingXml = "<booking>";
                        List<string> matchedRooms = new List<string>();
                        foreach (var lst in extendedRoomList)
                        {
                            if (lst.extendedDate > model.checkOutDate)
                            {
                                if (lst.extendedDate > currDate)
                                {
                                    if (lst.extendedDate <= maxCheckOutDate)
                                    {
                                        bookingXml += "<bookingList>";
                                        bookingXml += "<RequestId>" + lst.Sno + "</RequestId>";
                                        bookingXml += "<roomType>" + lst.roomType + "</roomType>";
                                        bookingXml += "<singleRoom>" + lst.singleRoom + "</singleRoom>";
                                        bookingXml += "<doubleRoom>" + lst.doubleRoom + "</doubleRoom>";
                                        bookingXml += "<checkinDate>" + model.checkOutDate.ToString("yyyy/MM/dd") + "</checkinDate>";
                                        bookingXml += "<noOfGuests>" + lst.noOfGuests + "</noOfGuests>";
                                        bookingXml += "<checkOutDate>" + Convert.ToDateTime(lst.extendedDate).AddDays(-1).ToString("yyyy/MM/dd") + "</checkOutDate>";
                                        bookingXml += "<extrabed>" + lst.extrabed + "</extrabed>";
                                        bookingXml += "</bookingList>";

                                        int totalDays = Convert.ToDateTime(lst.extendedDate).Subtract(model.checkOutDate).Days;

                                        int _noOfRooms = 0;

                                        // int _extrabedAdd = 0;
                                        RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                                        objRoom.roomTypeId = lst.roomType;
                                        objRoom.unitId = SessionManager.UnitID;
                                        _noOfRooms = lst.singleRoom + lst.doubleRoom;

                                        DateTime fromDate = model.checkOutDate;

                                        for (int i = 0; i < totalDays; i++)
                                        {
                                            int _currSelectedRoom = 0;
                                            objRoom.bookingDate = fromDate.AddDays(i);
                                            var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                            if (isAvailable == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                            {
                                                _isRoomAvl = false;
                                                _msg = "Room Not Available In " + lst.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                                break;
                                            }
                                            else
                                            {
                                                #region test
                                                if (lst.lstRoomNoDetail != null && lst.lstRoomNoDetail.Count > 0)
                                                {
                                                    if (frmExtend["SelectedRooms_" + lst.Sno + ""] != null && frmExtend["SelectedRooms_" + lst.Sno + ""].Split(',').Length > 0)
                                                    {

                                                        checkedRooms = frmExtend["SelectedRooms_" + lst.Sno + ""].Split(',');
                                                        foreach (var room in lst.lstRoomNoDetail)
                                                        {
                                                            if (checkedRooms.Contains(Convert.ToString(room.RoomNoId)))
                                                            {
                                                                roomXml += "<RoomList>";
                                                                roomXml += "<RequestId>" + lst.Sno + "</RequestId>";
                                                                roomXml += "<bookingDate>" + objRoom.bookingDate.ToString("yyyy/MM/dd") + "</bookingDate>";
                                                                roomXml += "<RoomNoId>" + room.RoomNoId + "</RoomNoId>";
                                                                roomXml += "</RoomList>";
                                                                if (i == 0)
                                                                {
                                                                    matchedRooms.Add(Convert.ToString(room.RoomNoId));
                                                                }
                                                                _currSelectedRoom++;
                                                            }
                                                        }
                                                        if (_currSelectedRoom == 0)
                                                        {
                                                            _isValidDate = false;
                                                            _msg = "No room selected for " + lst.roomTypeDisplay;
                                                            break;
                                                        }
                                                        else if (_currSelectedRoom < _noOfRooms)
                                                        {
                                                            _isValidDate = false;
                                                            _msg = "No. of selected rooms is not sufficient for " + lst.roomTypeDisplay;
                                                            break;
                                                        }
                                                        else if (_currSelectedRoom > _noOfRooms)
                                                        {
                                                            _isValidDate = false;
                                                            _msg = "Total No. of selected rooms is more than required rooms for " + lst.roomTypeDisplay;
                                                            break;
                                                        }
                                                    }
                                                    else
                                                    {
                                                        _isValidDate = false;
                                                        _msg = "No room selected for " + lst.roomTypeDisplay;
                                                        break;
                                                    }
                                                }
                                                else
                                                {
                                                    _isValidDate = false;
                                                    _msg = "Details Not Valid.Try Again..";
                                                }
                                                #endregion
                                            }
                                        }
                                        if (_isRoomAvl == false)
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        _isValidDate = false;
                                        _msg = "Booking can not be done for more than 180 days!";
                                        break;
                                    }
                                }
                                else
                                {
                                    _isValidDate = false;
                                    _msg = "Extended date could not be past date!";
                                    break;
                                }
                            }
                            else
                            {
                                _isValidDate = false;
                                _msg = "Extended date should be greater than checkout date!";
                                break;
                            }
                            if (_isRoomAvl == false)
                            {
                                break;
                            }
                        }
                        #region for check duplicate values for rooms
                        var chkItems = matchedRooms.Distinct().ToArray();
                        if (matchedRooms.ToArray().Length != chkItems.Length)
                        {
                            for (int k = 0; k < matchedRooms.ToArray().Length; k++)
                            {
                                try
                                {
                                    if (matchedRooms[k].ToString() != chkItems[k].ToString())
                                    {
                                        _isValidDate = false;
                                        _msg = "Select distinct rooms!!";
                                        break;
                                    }
                                }
                                catch (Exception ex)
                                {
                                    _isValidDate = false;
                                    _msg = "Select distinct rooms!!";
                                    break;
                                }
                            }
                        }
                        #endregion
                        roomXml += "</RoomDetail>";
                        bookingXml += "</booking>";
                        model.roomDetailXml = roomXml.ToString();
                        model.bookingDetails = bookingXml.ToString();
                        model.unitID = SessionManager.UnitID;
                        //model.BookingFor = "CNTU";
                        model.BookingFor = "UNIT";
                        model.bookingBy = "UNT";
                        model.userIP = this.Request.UserHostAddress;
                        if (_isRoomAvl == true && _isValidDate == true)
                        {
                            int result = objBusinessClass.UpdateExtendDetail(model);

                            if (result > 0)
                            {
                                TempData["DocketNo"] = model.docketNo;

                                return RedirectToAction("ExtendConfirmation");
                            }
                            else
                            {
                                _msg = "Room Not Booked!";
                            }
                        }
                    }
                    else
                    {
                        _msg = "Select atleast one room to extend date!";
                    }
                    ViewBag.Show = _msg;
                }
                else
                {
                    ViewBag.Show = "Invalid details!";
                }
            }
            catch
            {
                ViewBag.Show = "Error in Process!";
            }
            ViewBag.RoomType = objBusinessClass.GetRoomType(SessionManager.UnitID).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
            return View(model);
        }
        #endregion

        #region Extend Confirmation
        [HttpGet]
        public ActionResult ExtendConfirmation()
        {
            ExtendBookingDetails model = new ExtendBookingDetails();
            try
            {
                model.unitID = SessionManager.UnitID;
                model.docketNo = TempData["DocketNo"].ToString();

                model = objBusinessClass.GetBookingDetailsToExtendBooking(model);
                model.roomExtendDetailList = objBusinessClass.GetExtendedRoomDetails(model.docketNo, SessionManager.UnitID);
            }
            catch
            {

            }
            return View(model);
        }

        #endregion

        /*----------------------------End Extend Booking-------------------------------*/

        #region Counter Booking Cancellation

        [HttpGet]
        public ActionResult BookingCancellation()
        {
            return View();
        }

        [HttpGet]
        public ActionResult BookingDetailsCancellation(string docketNo, string fromDate, string toDate)
        {
            BookingCancellation model = new BookingCancellation();
            Int64 _unitId = SessionManager.UnitID;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCounterBookingAndUnitBookingInfo(_unitId, docketNo.Trim(), _fromDate, _toDate).ToList();
            }
            catch
            {
            }
            return PartialView("_cancelBookingGrid", model.lstCanceRequest);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookingCancellation(BookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            Int64 _unitId = SessionManager.UnitID;
            try
            {
                _fromDate = model.FromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.FromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.ToDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.ToDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetCounterBookingAndUnitBookingInfo(_unitId, model.docketNo, _fromDate, _toDate).ToList();

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate.ToString("dd/MM/yyyy"), Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/BookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            return View(model);
        }

        [HttpGet]
        public ActionResult CancellationConfirmation(string id)
        {
            try
            {
                CRSBookingCancellation model = new CRSBookingCancellation();
                string ipAddress = this.Request.UserHostAddress;
                model = objBusinessClass.CancelCRSBooking(id.Trim(), ipAddress);
                if (model != null && model.cancelRefNo != null && model.cancelRefNo != "")
                {
                    IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(id.Trim());
                    // Send SMS to customer
                    //SendCancelRequestSMS(docketNo, SessionManager.CustomerMobile, IEContactDetails, model.BookingFor);
                    //SendCancelRequestEMail(docketNo, SessionManager.Username, IEContactDetails, model.BookingFor);
                    return Content(model.cancelRefNo);
                }
            }
            catch
            { }
            return Content("0");
        }
        #endregion
        /* ---------------------------Cancellation List---------------------------------*/

        #region Display cancelled booking list
        [HttpGet]
        public ActionResult CancelledBooking()
        {
            return View();
        }
        #endregion

        #region binding cancelled booking grid
        public ActionResult GetCancelledBookingList(string docketNo, string fromDate, string toDate)
        {
            CRSBookingCancellation model = new CRSBookingCancellation();
            Int64 _unit = SessionManager.UnitID;
            DateTime _fromDate, _toDate;
            try
            {
                _fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                model.lstCanceRequest = objBusinessClass.GetCancelledBooking(docketNo.Trim(), _unit, _fromDate, _toDate).ToList();
            }
            catch
            {

            }
            return PartialView("_CancelledBookingGrid", model.lstCanceRequest);
        }
        #endregion

        #region export cancelled booking list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CancelledBooking(CRSBookingCancellation model)
        {
            GridView gv = new GridView();
            ModelState.Clear();
            DateTime _fromDate, _toDate;
            Int64 _unit = SessionManager.UnitID;
            try
            {
                _fromDate = model.fromDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.fromDate);
            }
            catch
            {
                _fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                _toDate = model.toDate == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.toDate);
            }
            catch
            {
                _toDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetCancelledBooking(model.docketNo, _unit, _fromDate, _toDate).ToList();
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, Name = e.name, No_of_Rooms = e.totalRooms, No_of_Guests = e.noOfPerson, Check_In_Date = e.checkInDate.ToString("dd/MM/yyyy"), Check_Out_Date = e.checkOutDate, Booking_Type = e.bookingType, Booking_By = e.bookingBy, Cancellation_Reference_No = e.cancelRefNo, Cancellation_Date = e.cancelConfirmationDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/CancelledBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No record found!";
            }
            model.lstCanceRequest = dtresult;
            return View(model);
        }

        #endregion

        /* ---------------------------End Cancellation List---------------------------------*/


        #region methods to validate

        //public string IsDateValid(CustomerRegistration model)
        //{
        //    string returnMsg = string.Empty;
        //    DateTime currDate = DateTime.Now.AddDays(-1);
        //    DateTime maxCheckInDate = currDate.AddDays(178);
        //    DateTime maxCheckOutDate = currDate.AddDays(179);
        //    if (model.checkInDate < currDate)
        //    {
        //        returnMsg = "Check In Date could not be past date";
        //    }
        //    else if (model.checkOutDate < currDate)
        //    {
        //        returnMsg = "Check Out Date could not be past date";
        //    }
        //    else if (model.checkOutDate < model.checkInDate)
        //    {
        //        returnMsg = "Check Out Date should be greater than Check In Date";
        //    }
        //    else if (model.checkInDate > maxCheckInDate)
        //    {
        //        returnMsg = "Booking can not be done for more than 180 days";
        //    }
        //    else if (model.checkOutDate > maxCheckOutDate)
        //    {
        //        returnMsg = "Booking can not be done for more than 180 days";
        //    }
        //    return returnMsg;
        //}

        public string IsDateValid(CustomerRegistration model)
        {
            string returnMsg = string.Empty;
            DateTime currDate = DateTime.Now.AddDays(-1);
            DateTime maxCheckInDate = currDate.AddDays(178);
            DateTime maxCheckOutDate = currDate.AddDays(179);
            if (model.checkInDate.Date < currDate.Date)
            {
                returnMsg = "Check In Date could not be past date";
            }
            else if (model.checkOutDate < currDate)
            {
                returnMsg = "Check Out Date could not be past date";
            }
            else if (model.checkOutDate < model.checkInDate)
            {
                returnMsg = "Check Out Date should be greater than Check In Date";
            }
            else if (model.checkInDate > maxCheckInDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            else if (model.checkOutDate > maxCheckOutDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            return returnMsg;
        }

        public string IsNewDateValid(PreponePostpone model)
        {
            string returnMsg = string.Empty;
            DateTime currDate = DateTime.Now.AddDays(-1);
            DateTime maxCheckInDate = currDate.AddDays(178);
            DateTime maxCheckOutDate = currDate.AddDays(179);
            if (model.newCheckInDate < currDate)
            {
                returnMsg = "Check In Date could not be past date";
            }
            else if (model.newCheckOutDate < currDate)
            {
                returnMsg = "Check Out Date could not be past date";
            }
            else if (model.newCheckOutDate < model.newCheckInDate)
            {
                returnMsg = "Check Out Date should be greater than Check In Date";
            }
            else if (model.newCheckInDate > maxCheckInDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            else if (model.newCheckOutDate > maxCheckOutDate)
            {
                returnMsg = "Booking can not be done for more than 180 days";
            }
            return returnMsg;
        }

        #endregion

        #region Method to  bind staff tariff
        public JsonResult GetStaffTariff(int gradeId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffGrade().Where(a => a.gradeId == gradeId).Select(a => a.facilityId).FirstOrDefault();
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region Method to  bind staff Room
        public JsonResult GetStaffRoom(int facilityId, Int64 unitId)
        {
            int obj = 0;
            try
            {
                obj = objBusinessClass.GetStaffRoom(unitId, facilityId).FirstOrDefault().roomTypeId;
            }
            catch
            {

            }

            return Json(obj, JsonRequestBehavior.AllowGet);
        }
        #endregion

        #region send mail
        private void AccessOtherServerPage(string docketNo, string userType, string mailTo, string mailType)
        {

            WebRequest request = WebRequest.Create(string.Format("{0}?docketNo={1}&userType={2}&mailTo={3}&mailType={4}", ConfigurationManager.AppSettings["mailURL"].ToString(), docketNo, userType, mailTo, mailType));
            // If required by the server, set the credentials.
            request.Credentials = CredentialCache.DefaultCredentials;
            // Get the response.
            WebResponse response = request.GetResponse();
            // Display the status.
            //Console.WriteLine(((HttpWebResponse)response).StatusDescription);
            // Get the stream containing content returned by the server.
            Stream dataStream = response.GetResponseStream();
            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);
            // Read the content.
            string responseFromServer = reader.ReadToEnd();
            // Display the content.
            // Console.WriteLine(responseFromServer);
            // Clean up the streams and the response.
            reader.Close();
            response.Close();
        }
        #endregion

        #region to send sms
        protected void SendCancellationSms(string docketNo, string mobileNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["PackageBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string ConcernPersonSMS = ConfigurationManager.AppSettings["PackageConcernPersonSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                ConcernPersonSMS = ConcernPersonSMS.Replace("[DocketNo]", docketNo);

                string NodalOfficerSMS = ConfigurationManager.AppSettings["PackageNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                NodalOfficerSMS = NodalOfficerSMS.Replace("[DocketNo]", docketNo);

                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (lst.sendTo == "UNIT")
                            {
                                SMSStatus = SMS.SMSSend(ConcernPersonSMS, lst.MobileNo);    // Send SMS to Unit
                                SMS.SMSLog(ConcernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(NodalOfficerSMS, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(NodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                            }
                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to get room occupancy details

        [HttpGet]
        public ActionResult GetRoomOccupancy(int roomId)
        {
            CustomerRegistration model = new CustomerRegistration();
            try
            {
                UnitRooms objRoom = objBusinessClass.GetRoomInfo(roomId, SessionManager.UnitID);
                if (objRoom != null)
                {
                    model.maxCapacity = objRoom.maxCapacity;
                    model.hasOccupancy = objRoom.hasOccupancy;
                    model.maxExtraBed = objRoom.maxExtraBed;
                }
            }
            catch
            {

            }
            return PartialView("_RoomOccupancy", model);
        }
        #endregion


        #region to send sms on booking cancellation
        protected void SendAcceptanceSMS(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["AcceptCancelBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                string customerOthers = ConfigurationManager.AppSettings["AcceptCancelBookingSMSOther"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerOthers = customerOthers.Replace("[DocketNo]", docketNo);

                try
                {
                    string SMSStatus = "";

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            //if (lst.sendTo == "UNIT")
                            //{
                            //    SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);    // Send SMS to Unit
                            //    SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
                            //}
                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(customerOthers, lst.MobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(customerOthers, lst.MobileNo, docketNo, SMSStatus);
                            }
                            if (lst.sendTo == "CUSTOMER")
                            {
                                SMSStatus = SMS.SMSSend(customerSms, lst.MobileNo);     // Send SMS to Customer
                                SMS.SMSLog(customerSms, lst.MobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send mail on booking cancellation
        protected void SendAcceptanceEMail(string docketNo, IEnumerable<OfficerContactDetails> contactDetails)
        {
            try
            {

                //StreamReader reader;
                //string subject = "";
                //reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/AcceptCancelRequest.html"));
                //subject = "UP Tourism Booking Cancellation Status";

                //string MailBody = reader.ReadToEnd();
                //MailBody = MailBody.Replace("[docketno]", docketNo);

                string subject = "UP Tourism Booking Cancellation Status";
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/AcceptCancelRequest.html"));
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", docketNo);

                StreamReader readerOthers = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Unit/AcceptCancelRequest.html"));
                string MailBodyOthers = readerOthers.ReadToEnd();
                MailBodyOthers = MailBodyOthers.Replace("[docketno]", docketNo);

                foreach (var lst in contactDetails)
                {
                    try
                    {
                        //if (lst.sendTo == "UNIT")  // Send Email to Unit
                        //{
                        //    MailService.Service1 objService = new MailService.Service1();
                        //    MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                        //    objService.sendMail(objMail);
                        //}
                        if (lst.sendTo == "NODAL")       // Send Email to Nodal Officer
                        {
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBodyOthers, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                            SendMail.SendMailNew(lst.Email, subject, MailBodyOthers);
                        }
                        if (lst.sendTo == "CUSTOMER")       // Send Email to Nodal Officer
                        {
                            //MailService.Service1 objService = new MailService.Service1();
                            //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = lst.Email };
                            //objService.sendMail(objMail);
                            SendMail.SendMailNew(lst.Email, subject, MailBody);
                        }

                    }
                    catch { }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        //#region Get Booking List To Cancel
        // public ActionResult CounterBookingHistory()
        // {
        //         if (TempData["message"] != null && TempData["message"].ToString() != "")
        //         {
        //             ViewBag.Show = TempData["message"];
        //         }
        //         CancelBooking obj = new CancelBooking();
        //         obj.userid = SessionManager.UnitID;
        //         obj.lstCancelBookingDetails = objBusinessClass.GetCounterBookingHistory(obj.userid);
        //         return View(obj);

        // }
        //#endregion

        #region to add booked room details

        [HttpGet]
        public ActionResult GetBookedRoom(CustomerRegistration objCustomer)
        {
            //CustomerRegistration model = new CustomerRegistration();
            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
            if (objCustomer != null && objCustomer.lstBookedRoomDetail != null && objCustomer.lstBookedRoomDetail.Count > 0 && objCustomer.lstBookedRoomDetail[0] != null)
            {
                lstBookedRoom = objCustomer.lstBookedRoomDetail;
            }

            RoomDetail objRoom = new RoomDetail();
            objRoom.roomType = objCustomer.roomType;
            objRoom.roomTypeDisplay = objCustomer.roomTypeDisplay;
            objRoom.singleRoom = objCustomer.singleRoom;
            objRoom.doubleRoom = objCustomer.doubleRoom;
            objRoom.extrabed = objCustomer.extrabed;
            objRoom.hasOccupancy = objCustomer.hasOccupancy;
            objRoom.maxCapacity = objCustomer.maxCapacity;
            objRoom.maxExtraBed = objCustomer.maxExtraBed;
            objRoom.Sno = lstBookedRoom.Count + 1;
            lstBookedRoom.Add(objRoom);
            objCustomer.lstBookedRoomDetail = lstBookedRoom;
            return PartialView("_BookedRoom", objCustomer);
        }
        #endregion

        #region to delete booked room

        [HttpGet]
        public ActionResult DeleteBookedRoom(CustomerRegistration objCustomer)
        {
            var itemsToRemove = objCustomer.lstBookedRoomDetail.Where(m => m.Sno == objCustomer.tempRoomId).ToList();
            int? _roomId = itemsToRemove.FirstOrDefault().roomType;
            string _roomName = itemsToRemove.FirstOrDefault().roomTypeDisplay;
            foreach (var itemToRemove in itemsToRemove)
                objCustomer.lstBookedRoomDetail.Remove(itemToRemove);

            ModelState.Clear();

            objCustomer.tempRoomId2 = Convert.ToInt32(_roomId);
            objCustomer.tempRoomIdName = _roomName;
            return PartialView("_BookedRoom", objCustomer);
        }
        #endregion

        #region booking list Copy

        [HttpGet]
        public ActionResult BookedListOldRoomType()
        {
            UnitTotalBooking model = new UnitTotalBooking();
            try
            {
                //model.dtBookingDateFrom = DateTime.Now;
                //model.dtBookingDateTo = DateTime.Now;
                model.docketNo = "";
                model.unitID = SessionManager.UnitID;
                model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.bookedList = objBusinessClass.GetUnitBookingStatusOldRoomType(model);
                model.dtBookingDateFrom = null;
                model.dtBookingDateTo = null;
            }
            catch
            {

            }
            return View(model);
        }

        public ActionResult GetBookedListOldRoomType(string dtBookingFrom, string dtBookingTo, string docket)
        {
            UnitTotalBooking model = new UnitTotalBooking();
            try
            {
                try
                {
                    model.dtBookingDateFrom = DateTime.ParseExact(dtBookingFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateFrom = null;
                    model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.dtBookingDateTo = DateTime.ParseExact(dtBookingTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateTo = null;
                    model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docket;
                model.unitID = SessionManager.UnitID;
                model.bookedList = objBusinessClass.GetUnitBookingStatusOldRoomType(model);
            }
            catch
            {

            }
            return PartialView("_BookedListGridOldRoomType", model.bookedList);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult BookedListOldRoomType(UnitTotalBooking obj)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateFrom.ToString()))
                {
                    obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                //model.dtBookingDateFrom = null;
                obj.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            try
            {
                if (string.IsNullOrEmpty(obj.dtBookingDateTo.ToString()))
                {
                    obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
            }
            catch
            {
                //model.dtBookingDateTo = null;
                obj.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            var dtresult = objBusinessClass.GetUnitBookingStatusOldRoomType(obj);

            if (dtresult != null && dtresult.Count > 0)
            {
                // gv.DataSource = dtresult.ToList();
                gv.DataSource = dtresult.Select(e => new { e.name, e.docketNo, e.checkInDate, e.checkOutDate, e.totalRoom, e.bookingType, e.bookingBy, e.BookingStatus }).ToList();

                gv.DataBind();
                //foreach (GridViewRow gvrow in gv.Rows)
                //{
                //    gvrow.Cells[16].Style.Add("mso-number-format", "\\@");
                //}
                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/VacancyStatus.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ModelState.AddModelError("", "No data found for selected date");
            }
            obj.bookedList = dtresult;
            return View(obj);
        }


        [HttpGet]
        public ActionResult GetBookingDetailOldRoomType(string docketNo)
        {
            SpecialBookedDetail obj_BookingDetail = new SpecialBookedDetail();
            List<SpecialBookedDetail> obj_BookingList = new List<SpecialBookedDetail>();
            string _msg = "";
            try
            {

                obj_BookingList = objBusinessClass.GetUnitBookingDetailsOldRoomType(docketNo, SessionManager.UnitID);
                if (obj_BookingList != null)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                if (obj_BookingDetail != null)
                {
                    obj_BookingDetail.BookedRoomList = objBusinessClass.GetBookedRoomDetailsOldRoomType(docketNo, SessionManager.UnitID);
                    return PartialView("_BookingListDetailsOldRoomType", obj_BookingDetail);
                }
                //if (obj_BookingDetail != null)
                //{
                //    obj_BookingDetail.PackageDetailList = objBusinessClass.GetpackagedetailUnitwise(docketNo);
                //    return PartialView("_BookingListDetails", obj_BookingDetail);
                //}
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            return Json(new { result = true, message = "Unable to process!" });
        }
        #endregion

        /*----------------------------Room Change -------------------------------*/

        #region Display room change
        [HttpGet]
        public ActionResult RoomChange()
        {
            RoomChange model = new RoomChange();
            model.allotedRoomList = objBusinessClass.GetAllAllottedRooms(SessionManager.UnitID);
            model.isPostBack = false;
            return View(model);
        }
        #endregion

        #region get booking details for room change
        [HttpGet]
        public ActionResult BookingDetailToChangeRoom(Int64 bookRooomID)
        {
            RoomChange model = new RoomChange();
            try
            {
                model.unitID = SessionManager.UnitID;
                model.bookedRoomID = bookRooomID;

                model = objBusinessClass.GetBookingDetailsToChangeRoom(model);
                model.roomDetailList = objBusinessClass.GetRoomDetailsForChange(model.docketNo, SessionManager.UnitID);
                model.availableRoomList = objBusinessClass.GetAllAvailableRoom(SessionManager.UnitID, bookRooomID);
                model.isPostBack = true;
            }
            catch
            { }
            return PartialView("_RoomChange", model);
        }
        #endregion

        #region to get new room occupancy
        [HttpGet]
        public ActionResult GetNewRoomOccupancy(int roomId, int roomOccupancy)
        {
            RoomChange model = new RoomChange();
            try
            {
                UnitRooms objRoom = objBusinessClass.GetRoomInfo(roomId, SessionManager.UnitID);
                if (objRoom != null)
                {
                    model.hasOccupancy = objRoom.hasOccupancy;
                    model.maxExtraBed = objRoom.maxExtraBed;
                    model.roomID = roomId;
                    model.roomOccupancy = roomOccupancy;
                }
            }
            catch
            {

            }
            return PartialView("_RoomChangeDetails", model);
        }
        #endregion

        #region Save room change details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RoomChange(RoomChange model)
        {
            string _msg = string.Empty;

            string[] checkedRooms = null;
            try
            {
                if (ModelState.IsValid)
                {
                    if (Request.Form["changedRoom"] != null && Request.Form["changedRoom"].Split(',').Length > 0)
                    {
                        if (model.roomOccupancy != 1 || model.isSingle != null)
                        {
                            if (model.currentExtraBed <= model.extraBed)
                            {
                                if (model.extraBed <= model.maxExtraBed)
                                {
                                    checkedRooms = Request.Form["changedRoom"].Split(',');
                                    model.userIP = this.Request.UserHostAddress;
                                    model.unitID = SessionManager.UnitID;
                                    String strXML = string.Empty;

                                    strXML = "<RoomDetail>";
                                    int totalDays = model.toDate.AddDays(1).Subtract(DateTime.Now).Days + 1;

                                    DateTime bookingDate = DateTime.Now;
                                    model.checkInDate = DateTime.Now.Date;
                                    model.oldCheckoutDate = model.checkInDate.AddDays(-1).Date;

                                    for (int i = 0; i < totalDays; i++)
                                    {
                                        bookingDate = DateTime.Now.AddDays(i);

                                        strXML += "<RoomList>";
                                        strXML += "<RequestId>" + model.requestID + "</RequestId>";
                                        strXML += "<bookingDate>" + bookingDate.ToString("yyyy/MM/dd") + "</bookingDate>";
                                        strXML += "<RoomNoId>" + checkedRooms[0] + "</RoomNoId>";
                                        strXML += "</RoomList>";
                                    }

                                    strXML += "</RoomDetail>";

                                    if (model.roomOccupancy == 1)
                                    {
                                        if (Convert.ToBoolean(model.isSingle))
                                        {
                                            model.singleRoom = 1;
                                        }
                                        else
                                        {
                                            model.doubleRoom = 1;
                                        }
                                    }
                                    else if (model.roomOccupancy == 2)
                                    {
                                        model.singleRoom = 1;
                                    }
                                    else if (model.roomOccupancy == 3)
                                    {
                                        model.doubleRoom = 1;
                                    }

                                    var ret = objBusinessClass.InsertRoomChangeDetails(model, strXML);
                                    //RoomChange ret = null;

                                    if (ret != null)
                                    {
                                        if (ret.result == 0)
                                        {
                                            _msg = "Rooms Not Available!";
                                        }
                                        else if (ret.result == 1)
                                        {
                                            _msg = "Room No. Not Available!";
                                        }
                                        else if (ret.result == 3)
                                        {
                                            TempData["requestID"] = ret.requestID;
                                            return RedirectToAction("RoomChangeConfirmation", "Unit");
                                        }
                                        else
                                        {
                                            _msg = "Error in Process!";
                                        }
                                    }
                                    else
                                    {
                                        _msg = "Error in Process!";
                                    }
                                }
                                else
                                {
                                    _msg = "Extra Bed should not be more than " + model.maxExtraBed + "!";
                                }
                            }
                            else
                            {
                                _msg = "Extra Bed should not be less than " + model.currentExtraBed + "!";
                            }
                        }
                        else
                        {
                            _msg = "Select Room Occupancy!";
                        }
                    }
                    else
                    {
                        _msg = "Select Room No.!";
                    }
                }
            }
            catch
            {
                _msg = "Error in Process!";
            }

            model.allotedRoomList = objBusinessClass.GetAllAllottedRooms(SessionManager.UnitID);
            model.availableRoomList = objBusinessClass.GetAllAvailableRoom(SessionManager.UnitID, model.bookedRoomID);
            model.isPostBack = true;

            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        #region room change Confirmation
        [HttpGet]
        public ActionResult RoomChangeConfirmation()
        {
            RoomChange model = new RoomChange();
            try
            {
                model.unitID = SessionManager.UnitID;
                model.requestID = Convert.ToInt64(TempData["requestID"].ToString());

                model = objBusinessClass.GetChangeDetails(model);
                model.roomDetailList = objBusinessClass.GetRoomDetailsForChange(model.docketNo, SessionManager.UnitID);
            }
            catch
            { }
            return View(model);
        }

        #endregion

        /*----------------------------End Room Change -------------------------------*/

        #region customer registration copy 4 Backup
        [HttpGet]
        public ActionResult CustomerRegistrationBackup()
        {
            try
            {
                Int64 _unitId = SessionManager.UnitID;
                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
                ViewBag.RoomType = objBusinessClass.GetRoomType(_unitId).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
                ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
                ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });

                CustomerRegistration model = new CustomerRegistration();
                model.unitID = _unitId;
                //model.checkInDate = DateTime.Now.Date;
                //model.checkOutDate = DateTime.Now.Date.AddDays(1).Date;
                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpPost]
        public ActionResult CustomerRegistrationBackup(CustomerRegistration model)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {

                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();
                }
                ModelState["checkInTime"].Errors.Clear();
                ModelState["checkOutTime"].Errors.Clear();
                ModelState["staffGrade"].Errors.Clear();
                ModelState["staffFacility"].Errors.Clear();
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.pincode))
                {
                    ModelState["pincode"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(Convert.ToString(model.advanceAmount)))
                {
                    ModelState["advanceAmount"].Errors.Clear();
                }
                if (model.customerType == 'B')
                {
                    ModelState["roomType"].Errors.Clear();
                    if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                    {
                    }
                    else
                    {
                        _isValid = false;
                        _msg = "Provide Room Details ";
                        ModelState.AddModelError("", "Provide Room Details ");
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(Convert.ToString(model.roomType)))
                    {
                        _isValid = false;
                        _msg = "Select Room!! ";
                        ModelState.AddModelError("", "Select Room!! ");
                    }
                    if (model.customerType == 'S')
                    {
                        if (model.staffId == null)
                        {
                            _isValid = false;
                            _msg = "Enter Staff Id!! ";
                            ModelState.AddModelError("", "Enter Staff Id!! ");
                        }
                        else if (model.staffIdDoc == null)
                        {
                            _isValid = false;
                            _msg = "Upload Staff Identity!! ";
                            ModelState.AddModelError("", "Upload Staff Identity!! ");
                        }
                        else if (model.staffGrade == null || model.staffGrade == 0)
                        {
                            _isValid = false;
                            _msg = "Select Staff Grade!! ";
                            ModelState.AddModelError("", "Select Staff Grade!! ");
                        }
                        else if (model.staffFacility == null || model.staffFacility == 0)
                        {
                            _isValid = false;
                            _msg = "Select Staff Tariff!! ";
                            ModelState.AddModelError("", "Select Staff Tariff!! ");
                        }
                    }
                }

                if (ModelState.IsValid && _isValid == true)
                {
                    model.roleID = "OCST";
                    model.userIP = this.Request.UserHostAddress;
                    string isValid = IsDateValid(model);
                    if (string.IsNullOrEmpty(isValid))
                    {
                        if (model.staffIdDoc != null)
                        {
                            string ext = Path.GetExtension(model.staffIdDoc.FileName);
                            string filename = Path.GetFileName(DateTime.Now.Ticks + ext);

                            model.staffIdDocPath = Path.Combine("/Content/writereaddata/Documents", filename);
                            var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                            model.staffIdDoc.SaveAs(docPath);
                        }
                        else
                        {
                            model.staffIdDocPath = "";
                            model.staffId = "";
                            model.staffGrade = 0;
                            model.staffFacility = 0;
                        }

                        #region changes for bulk booking
                        bool _isExtraBedAvail = true, _chkRoomLimit = true;
                        int _totalExtraBedRequire = 0;
                        if (model.customerType == 'B')
                        {
                            int _extraBedBulk = 0, _singleBulk = 0, _doubleBulk = 0, _totalRooms = 0, _maxCapacity = 0, _maxAllowedGuest = 0, _singleNonOc = 0;
                            foreach (var item in model.lstBookedRoomDetail)
                            {
                                _singleBulk += item.singleRoom;
                                _doubleBulk += item.doubleRoom;
                                _extraBedBulk = _extraBedBulk + (item.hasOccupancy == true ? 1 * (item.doubleRoom) : 0);
                                _maxCapacity = _maxCapacity + (item.hasOccupancy == false ? (item.maxCapacity) * (item.singleRoom) : 0);
                                _singleNonOc = _singleNonOc + (item.hasOccupancy == false ? (item.singleRoom) : 0);
                            }
                            _totalRooms = _singleBulk + _doubleBulk;
                            _totalExtraBedRequire = model.noOfGuests - ((_singleBulk - _singleNonOc) + (_doubleBulk * 2) + _maxCapacity);
                            _maxAllowedGuest = _singleBulk + (_doubleBulk * 2) + _extraBedBulk + (_maxCapacity - _singleNonOc); ;

                            #region max capacity for bulk booking
                            if (_totalRooms > model.noOfGuests)
                            {
                                _chkRoomLimit = false;
                                _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                                ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                            }
                            else if (model.noOfGuests > _maxAllowedGuest)
                            {
                                _chkRoomLimit = false;
                                _msg = "No. of selected rooms is not sufficient!!";
                                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                            }
                            else if (_extraBedBulk < _totalExtraBedRequire)
                            {
                                _isExtraBedAvail = false;
                                _msg = "No. of selected rooms is not sufficient!!";
                                ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                            }
                            #endregion
                        }
                        else
                        {
                            RoomDetail objRoomList = new RoomDetail();
                            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
                            objRoomList.roomType = model.roomType;
                            objRoomList.roomTypeDisplay = model.roomTypeDisplay;
                            objRoomList.singleRoom = model.singleRoom;
                            objRoomList.doubleRoom = model.doubleRoom;
                            objRoomList.hasOccupancy = model.hasOccupancy;
                            objRoomList.Sno = lstBookedRoom.Count + 1;

                            if (model.hasOccupancy)
                            {
                                model.extrabed = model.noOfGuests - (model.singleRoom + (model.doubleRoom * 2));
                                model.extrabed = (model.extrabed > 0) ? model.extrabed : 0;
                            }
                            else
                            {
                                model.extrabed = 0;
                            }
                            objRoomList.extrabed = model.extrabed;
                            lstBookedRoom.Add(objRoomList);
                            model.lstBookedRoomDetail = lstBookedRoom;
                        }
                        //model.noOfRooms = model.singleRoom + model.doubleRoom;
                        int totalDays = model.checkOutDate.Subtract(model.checkInDate).Days;
                        bool _isRoomAvl = true;
                        int _noOfRooms = 0;
                        foreach (var item in model.lstBookedRoomDetail)
                        {
                            int _extrabedAdd = 0;
                            RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                            objRoom.roomTypeId = item.roomType;
                            objRoom.unitId = model.unitID;
                            _noOfRooms = item.singleRoom + item.doubleRoom;
                            if (model.customerType == 'B' && _totalExtraBedRequire > 0)
                            {
                                _extrabedAdd = item.hasOccupancy == true ? 1 * (item.doubleRoom) : 0;
                                if (_extrabedAdd > 0 && _extrabedAdd > _totalExtraBedRequire)
                                {
                                    //_extrabedAdd = _extrabedAdd - _totalExtraBedRequire;
                                    item.extrabed = _totalExtraBedRequire;
                                    _totalExtraBedRequire = 0;
                                }
                                else
                                {
                                    item.extrabed = _extrabedAdd;
                                    //   _extrabedAdd = _totalExtraBedRequire - _extrabedAdd;
                                    _totalExtraBedRequire = _totalExtraBedRequire - _extrabedAdd;
                                }

                            }

                            for (int i = 0; i < totalDays; i++)
                            {
                                objRoom.bookingDate = model.checkInDate.AddDays(i);
                                var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                {
                                    _isRoomAvl = false;
                                    _msg = "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                    ModelState.AddModelError("", "Room Not Available In " + item.roomTypeDisplay + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy"));
                                    break;
                                }
                            }
                            if (_isRoomAvl == false)
                            {
                                break;
                            }
                        }

                        var roomXml = new XElement("booking",
                                     from room in model.lstBookedRoomDetail
                                     select new XElement("customer",
                                                    new XElement("Sno", room.Sno),
                                                    new XElement("roomType", room.roomType),
                                                    new XElement("singleRoom", room.singleRoom),
                                                    new XElement("doubleRoom", room.doubleRoom),
                                                    new XElement("extrabed", room.extrabed)
                                                ));
                        model.bookingXML = roomXml.ToString();
                        #endregion
                        bool _isDataChecked = true;
                        if (model.customerType != 'B')
                        {
                            if (model.hasOccupancy)
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Single and Double rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Single and Double rooms should be less than equal to No. of Guests!");
                                }
                                else if (model.extrabed > model.doubleRoom)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                            }
                            else
                            {
                                if (model.noOfRooms > model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "Total No. of Rooms should be less than equal to No. of Guests!";
                                    ModelState.AddModelError("", "Total No. of Rooms should be less than equal to No. of Guests!");
                                }
                                else if ((model.singleRoom * model.maxCapacity) < model.noOfGuests)
                                {
                                    _isDataChecked = false;
                                    _msg = "No. of selected rooms is not sufficient!!";
                                    ModelState.AddModelError("", "No. of selected rooms is not sufficient!!");
                                }
                            }
                        }
                        else
                        {

                        }

                        if (_isRoomAvl == true && _isDataChecked == true && _isExtraBedAvail == true && _chkRoomLimit == true)
                        {
                            model.userID = model.unitID;
                            model.bookingFor = "CNTU";
                            var user = objBusinessClass.InsertCustomerBooking(model);


                            if (user != null)
                            {
                                //SessionManager.UserID = user.userID;
                                SessionManager.DocketNo = user.docketNo;

                                return RedirectToAction("RegistrationConfirmation");
                            }
                            else
                            {
                                ModelState.AddModelError("", "Room Not Bookeed!");
                                _msg = "Room Not Bookeed!";
                            }
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", isValid);
                        _msg = isValid;
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Error in CustomerRegistration!");
                    _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
                }
            }
            catch
            {
                ModelState.AddModelError("", "Error in CustomerRegistration!");
                _msg = string.IsNullOrEmpty(_msg) ? "Error in Customer Registration!" : _msg;
            }
            Int64 _unitId = SessionManager.UnitID;
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.RoomType = objBusinessClass.GetRoomType(_unitId).Select(e => new SelectListItem() { Text = e.roomTypeName, Value = e.roomTypeId.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
            ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        /*----------------------------Edit Customer Details-------------------------------*/

        #region Display search panel for editing
        public ActionResult GetCustomerDetails()
        {
            return View();
        }
        #endregion

        #region Get customer details for editing

        public ActionResult EditCustomerDetails(string DocketNo)
        {
            Customer mc = objBusinessClass.GetCustomerDetailsForEdit(DocketNo).FirstOrDefault();
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });

            if (mc != null && mc.countryID == 98)
            {
                ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(mc.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                if (mc.stateID > 0)
                {
                    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(mc.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                }
                else
                {
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
            }
            else
            {
                ViewBag.State = Enumerable.Empty<SelectListItem>();
                ViewBag.City = Enumerable.Empty<SelectListItem>();
            }

            ViewBag.Identity = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.StaffGrade = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.grade, Value = e.gradeId.ToString() });
            ViewBag.StaffTariff = objBusinessClass.GetStaffGrade().Select(e => new SelectListItem() { Text = e.amount.ToString(), Value = e.facilityId.ToString() });
            var l = objBusinessClass.GetSeason().Where(e => e.SeasonId != 13);
            ViewBag.Month = l.Select(e => new SelectListItem() { Text = e.Seasonname, Value = e.SeasonId.ToString() });
            ViewBag.date = objCommonClass.getMonthdate().Select(e => new SelectListItem() { Text = e.dateId.ToString(), Value = e.dateId.ToString() });
            return PartialView("_ViewEditCustomerdetails", mc);
        }
        #endregion

        #region Update customer details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateCustomer(Customer cust)
        {
            try
            {
                int result = objBusinessClass.UpdateCustomerDetails(cust);

                ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });


                if (cust != null && cust.countryID != null && cust.countryID == 98)
                {
                    ViewBag.State = objBusinessClass.GetStateList(Convert.ToInt32(cust.countryID)).Select(e => new SelectListItem() { Text = e.stateName, Value = e.stateID.ToString() });
                    if (cust.stateID > 0)
                    {
                        ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(cust.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                    }
                    else
                    {
                        ViewBag.City = Enumerable.Empty<SelectListItem>();
                    }

                }
                else
                {
                    ViewBag.State = Enumerable.Empty<SelectListItem>();
                    ViewBag.City = Enumerable.Empty<SelectListItem>();
                }
                //if (cust.stateID != null && cust.stateID > 0)
                //{
                //    ViewBag.City = objBusinessClass.GetCityList(Convert.ToInt32(cust.stateID)).Select(e => new SelectListItem() { Text = e.cityName, Value = e.cityID.ToString() });
                //}
                //else
                //{
                //    ViewBag.City = Enumerable.Empty<SelectListItem>();
                //}

                ViewBag.Identity = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
                var l = objBusinessClass.GetSeason().Where(e => e.SeasonId != 13);
                ViewBag.Month = l.Select(e => new SelectListItem() { Text = e.Seasonname, Value = e.SeasonId.ToString() });
                ViewBag.date = objCommonClass.getMonthdate().Select(e => new SelectListItem() { Text = e.dateId.ToString(), Value = e.dateId.ToString() });

                if (result > 0)
                {
                    ModelState.Clear();
                    ViewBag.Show = "Customer Details Updated Successfully!";

                    return PartialView("_ViewEditCustomerdetails", cust);
                }
                else
                {
                    ViewBag.Show = "Customer Details Not Updated!";

                }

            }
            catch
            {
                ViewBag.Show = "Error in Updating Customer Details!";
            }
            return PartialView("_ViewEditCustomerdetails", cust);
        }
        #endregion

        /*----------------------------End Edit Customer Details-------------------------------*/

        [HttpPost]
        public ActionResult CheckinBackup(CheckinDetails model, FormCollection frmChkIn)
        {
            string _msg = string.Empty;
            bool _isValid = true;
            string[] checkedRooms = null;
            try
            {
                ModelState["checkInTime"].Errors.Clear();
                if (frmChkIn["SelectedRooms"] == null)
                {
                    _isValid = false;
                }
                else
                {
                    checkedRooms = frmChkIn["SelectedRooms"].Split(',');
                    _isValid = model.lstBookedRoomDetail.Sum(c => c.totalRoom) > checkedRooms.Length ? false : true;
                }

                if (_isValid == true)
                {
                    if (model.lstBookedRoomDetail.Sum(c => c.totalRoom) < checkedRooms.Length)
                    {
                        _msg = "Total No. of selected rooms is more than required rooms!!";
                    }
                    else
                    {
                        if (ModelState.IsValid)
                        {
                            model.userIP = this.Request.UserHostAddress;
                            model.unitID = SessionManager.UnitID;
                            String strXML = string.Empty;

                            #region add rooms date wise and request Id wise
                            Int64 reqId = 0; int _roomId = 0;
                            IList<CheckinDetails> lstCheckinDetails = objBusinessClass.GetBookingDetailsList(model);
                            if (lstCheckinDetails != null && lstCheckinDetails.Count > 0)
                            {
                                strXML = "<RoomDetail>";
                                foreach (var item in lstCheckinDetails)
                                {
                                    int totalDays = item.checkOutDate.Subtract(item.checkInDate).Days + 1;
                                    DateTime bookingDate;
                                    for (int i = 0; i < totalDays; i++)
                                    {
                                        bookingDate = item.checkInDate.AddDays(i);
                                        reqId = item.requestID;
                                        _roomId = item.roomTypeId;
                                        var _matchedRooms = model.lstBookedRoomDetail.Where(m => m.roomType == _roomId).FirstOrDefault();
                                        if (_matchedRooms != null && _matchedRooms.lstRoomNoDetail.Count > 0)
                                        {
                                            int noOfRooms = _matchedRooms.totalRoom, _currSelectedRoom = 0;
                                            foreach (var room in _matchedRooms.lstRoomNoDetail)
                                            {
                                                if (checkedRooms.Contains(Convert.ToString(room.RoomNoId)))
                                                {
                                                    strXML += "<RoomList>";
                                                    strXML += "<RequestId>" + item.requestID + "</RequestId>";
                                                    strXML += "<bookingDate>" + bookingDate.ToString("yyyy/MM/dd") + "</bookingDate>";
                                                    strXML += "<RoomNoId>" + room.RoomNoId + "</RoomNoId>";
                                                    strXML += "<extrabed>" + _matchedRooms.extrabed + "</extrabed>";
                                                    strXML += "</RoomList>";
                                                    _currSelectedRoom++;
                                                }
                                            }
                                            if (_currSelectedRoom == 0)
                                            {
                                                _isValid = false;
                                                _msg = "No room selected for " + _matchedRooms.roomTypeDisplay;
                                            }
                                            else if (_currSelectedRoom < noOfRooms)
                                            {
                                                _isValid = false;
                                                _msg = "No. of selected rooms is not sufficient for " + _matchedRooms.roomTypeDisplay;
                                            }
                                            else if (_currSelectedRoom > noOfRooms)
                                            {
                                                _isValid = false;
                                                _msg = "Total No. of selected rooms is more than required rooms for " + _matchedRooms.roomTypeDisplay;
                                            }
                                        }
                                    }
                                }
                                strXML += "</RoomDetail>";
                            }

                            #endregion

                            //var roomXml = new XElement("RoomDetail",
                            //  from room in model.lstRoomNoDetail
                            //  select new XElement("RoomList",
                            //                 new XElement("noOfBed", room.noOfBed),
                            //                 new XElement("RoomNoId", room.RoomNoId)
                            //             ));
                            if (_isValid == true)
                            {
                                int result = objBusinessClass.InsertCheckinDetail(model, strXML);
                                if (result > 0)
                                {
                                    TempData["docketNo"] = model.docketNo;
                                    return RedirectToAction("CheckInConfirmation", "Unit");
                                }
                                else
                                {
                                    _msg = "Rooms Not Available.Try Again..";
                                }
                            }
                        }
                    }
                }
                else
                {
                    _msg = "Total No. of selected rooms is not sufficient";
                }
            }
            catch
            {
                _msg = "Error in Process!";
            }
            Int64 _unitId = SessionManager.UnitID;
            //model = objBusinessClass.GetBookingDetailsForCheckin(model);
            model.unitID = _unitId;
            model.lstBookedRoomDetail = objBusinessClass.GetBookedRoomDetails(model);
            foreach (var lstRoom in model.lstBookedRoomDetail)
            {
                lstRoom.lstRoomNoDetail = objBusinessClass.GetRoomsOnCheckIn(_unitId, lstRoom.requestID, Convert.ToInt32(lstRoom.roomType));
            }
            IList<CheckinDetails> lstCheckinDetailsNew = objBusinessClass.GetBookingDetailsList(model);
            model.checkInDateShow = lstCheckinDetailsNew.Min(c => c.checkInDate);
            model.checkOutDateShow = lstCheckinDetailsNew.Max(c => c.checkOutDateShow);
            ViewBag.Show = _msg;
            return View(model);
        }

        #region Method - get nationality
        public IEnumerable<SelectListItem> GetNationality()
        {
            var objNationality = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Indian";
            Temp.Value = "1";
            objNationality.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Foreigner";
            Temp.Value = "0";
            objNationality.Add(Temp);

            return objNationality;
        }
        #endregion

        [HttpPost]
        public ActionResult RoomBookingDetailBackup(CustomerRegistration model, FormCollection frmChkIn)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                //ModelState["checkInTime"].Errors.Clear();
                //if (ModelState.IsValid)
                //{
                string[] checkedRooms = string.IsNullOrEmpty(Convert.ToString(frmChkIn["CheckedRooms"])) ? null : Convert.ToString(frmChkIn["CheckedRooms"]).Split(',');
                _isValid = (checkedRooms != null && checkedRooms.Length > 0) ? true : false;
                if (_isValid == true)
                {
                    String _checkedRooms = "<Room>";
                    foreach (var item in checkedRooms)
                    {
                        _checkedRooms += "<RoomDetails>";
                        _checkedRooms += "<RequestId>" + Convert.ToInt64(item) + "</RequestId>";
                        _checkedRooms += "</RoomDetails>";
                    }
                    _checkedRooms += "</Room>";
                    model.requestXML = _checkedRooms;
                    Int64 _unitId = SessionManager.UnitID;
                    double luxuryTax, serviceTax, luxuryTaxAmt, serviceTaxAmt, totalAmount = 0, totalTaxAmt, discount, discountAmt, amtAfterDiscount, paybleAmt, advanceAmount, privilegeDist, privilegeAmt = 0, totalOtherAmt = 0;
                    List<BookedRoomDetails> objRoom = objBusinessClass.GetBookedRoomDetailsOnCheckOut(model.docketNo, _unitId);
                    List<BillDetails> objBil = null;
                    if (model != null && objRoom != null && objRoom.Count > 0)
                    {
                        foreach (var item in objRoom)
                        {
                            if (model.lstBill != null && model.lstBill.Count > 0)
                            {
                                objBil = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                                model.lstBill.AddRange(objBil);
                            }
                            else
                            {
                                model.lstBill = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                            }
                        }
                    }
                    model.unitID = _unitId;

                    model.isPrivilegeAvail = string.IsNullOrEmpty(model.privilegeCardNo) ? false : true;

                    String _luxuryTax = System.Configuration.ConfigurationManager.AppSettings["LuxuryTax"].ToString();
                    if (!String.IsNullOrEmpty(_luxuryTax))
                        luxuryTax = Convert.ToDouble(_luxuryTax);
                    else
                        luxuryTax = 5;

                    String _serviceTax = System.Configuration.ConfigurationManager.AppSettings["ServiceTax"].ToString();
                    if (!String.IsNullOrEmpty(_serviceTax))
                        serviceTax = Convert.ToDouble(_serviceTax);
                    else
                        serviceTax = 8.40;

                    String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                    if (!String.IsNullOrEmpty(_privilegeDist))
                        privilegeDist = Convert.ToDouble(_privilegeDist);
                    else
                        privilegeDist = 15;

                    model.luxuryTax = luxuryTax;
                    model.serviceTax = serviceTax;
                    model.fAndBAmt = model.fAndBAmt > 0 ? model.fAndBAmt : 0;
                    model.laundryAmt = model.laundryAmt > 0 ? model.laundryAmt : 0;
                    model.roomServiceAmt = model.roomServiceAmt > 0 ? model.roomServiceAmt : 0;
                    model.otherAmt = model.otherAmt > 0 ? model.otherAmt : 0;

                    String _billXML = "<bill>";
                    foreach (BillDetails item in model.lstBill)
                    {
                        _billXML += "<billDetails>";
                        _billXML += "<BillDate>" + item.RentDate + "</BillDate>";
                        _billXML += "<billDetail>" + item.BillDescription + "</billDetail>";
                        _billXML += "<amount>" + item.Amount + "</amount>";
                        _billXML += "<roomNo>" + item.RoomNo + "</roomNo>";
                        _billXML += "<requestId>" + item.requestId + "</requestId>";
                        _billXML += "</billDetails>";
                        totalAmount += Convert.ToDouble(item.Amount);
                    }
                    _billXML += "</bill>";

                    totalAmount += (model.fAndBAmt + model.laundryAmt + model.roomServiceAmt + model.otherAmt);
                    model.totalAmount = totalAmount;
                    if (model.isPrivilegeAvail == true)
                    {
                        privilegeAmt = (totalAmount * privilegeDist) / 100;
                        totalAmount = (model.isPrivilegeVerified == true) ? (model.totalAmount - privilegeAmt) : model.totalAmount;
                        model.totalAmount = (model.isPrivilegeVerified == true) ? (model.totalAmount - privilegeAmt) : model.totalAmount;
                    }
                    luxuryTaxAmt = (totalAmount * luxuryTax) / 100;
                    serviceTaxAmt = (totalAmount * serviceTax) / 100;
                    totalTaxAmt = luxuryTaxAmt + serviceTaxAmt;

                    model.luxuryTaxAmt = luxuryTaxAmt;
                    model.serviceTaxAmt = serviceTaxAmt;
                    model.totalTaxAmt = totalTaxAmt;
                    model.billDetailXML = _billXML;

                    advanceAmount = Convert.ToDouble(model.advanceAmount);
                    discount = model.discount;
                    discountAmt = (totalAmount * discount) / 100;
                    amtAfterDiscount = (totalAmount - discountAmt);
                    paybleAmt = (totalAmount + totalTaxAmt) - (discountAmt + advanceAmount);

                    model.discount = discount;
                    model.discountAmount = discountAmt;
                    model.amountAfterDis = amtAfterDiscount;
                    model.netPayable = Convert.ToInt32(Math.Round(paybleAmt, 2));
                    model.userID = model.unitID;
                    string UnitPaymentsSlabXML = "";
                    model.privilegeAmt = privilegeAmt;
                    model.privilegeDist = privilegeDist;

                    var user = objBusinessClass.InsertCheckOutDetails(model, UnitPaymentsSlabXML);
                    if (user != null)
                    {
                        SessionManager.BillNo = user.billNo;
                        SessionManager.DocketNo = model.docketNo;
                        return RedirectToAction("CheckOutConfirmation");
                    }
                }
                else
                {
                    _msg = "No Room Selected for Check Out!! ";
                }
            }
            catch
            { _msg = "Unable to process!"; }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            //return Json(new { result = false, message = "Unable to process!" }, JsonRequestBehavior.AllowGet);
            return RedirectToAction("CheckOut");
        }


        #region Get Todays CheckedIn and Arrive CustomerList
        [HttpGet]
        public ActionResult CurrentGuestList()
        {
            UnitTotalBooking model = new UnitTotalBooking();
            try
            {
                model.docketNo = "";
                model.unitID = SessionManager.UnitID;
                model.dtBookingDateFrom = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dtBookingDateTo = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.bookedList = objBusinessClass.GetGuestStatus(model);
                model.dtBookingDateFrom = null;
                model.dtBookingDateTo = null;
                model.dtCurrent = DateTime.Now.Date;
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region to calculate 25% of total room rent
        private decimal GetRequiredAdvanceAmount(CustomerRegistration model)
        {
            decimal advAmt = 0, totalAmt = 0;
            try
            {
                if (model != null && model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0 && model.lstBookedRoomDetail[0] != null)
                {
                    foreach (var item in model.lstBookedRoomDetail)
                    {
                        totalAmt += objBusinessClass.GetTotalUnitRoomPrice(model.checkInDate, model.checkOutDate.AddDays(-1), item);
                    }
                    advAmt = (totalAmt * 25) / 100;
                }
            }
            catch
            {
                advAmt = 0;
            }
            return advAmt;
        }
        #endregion

        #region get vacancy status details
        public ActionResult GetRoomVacancyDetail(string dtBooking, string roomtypeid, DateTime dtBookingTime)
        {
            VacancyStatusDetail model = new VacancyStatusDetail();
            try
            {
                model.RoomTypeId = Convert.ToInt64(roomtypeid);
                try
                {
                    if (dtBookingTime.Hour < 12)
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture).AddDays(-1);
                    }
                    else
                    {
                        model.BookingDate = DateTime.ParseExact(dtBooking, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                    }
                }
                catch
                {
                    model.BookingDate = DateTime.Now;
                }

                model.unitID = SessionManager.UnitID;
                model = objBusinessClass.GetVacancyStatusDetail(model);
            }
            catch
            {

            }
            return PartialView("_RoomVacancy", model);
        }
        #endregion

        /*------------------Prepone-Postpone Booking-----------------*/

        #region Display prepone-postpone booking
        [HttpGet]
        public ActionResult PreponePostpone()
        {
            return View();
        }
        #endregion

        #region Get booking current details
        [HttpGet]
        public ActionResult ExistingBookingDetails(string docketNo)
        {
            PreponePostpone model = new PreponePostpone();

            var unitID = SessionManager.UnitID;

            model = objBusinessClass.GetBookingDetailsForPrePostpone(docketNo.Trim(), unitID);
            if (model != null)
            {
                model.unitID = unitID;
                model.bookedRoomList = objBusinessClass.GetBookedRoomDetails(docketNo.Trim(), SessionManager.UnitID);
                model.duration = model.checkOutDateShow.Subtract(model.checkInDate).Days.ToString();
            }
            return PartialView("_PreponePostpone", model);
        }
        #endregion

        #region save prepone-postpone booking
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult PreponePostpone(PreponePostpone model)
        {
            string _msg = "";
            bool _isValid = true;
            try
            {
                if (ModelState.IsValid)
                {
                    model.userIP = this.Request.UserHostAddress;
                    string isValid = IsNewDateValid(model);
                    if (string.IsNullOrEmpty(isValid))
                    {
                        model.bookedRoomList = objBusinessClass.GetBookedRoomDetails(model.docketNo, SessionManager.UnitID);
                        if (model.bookedRoomList != null && model.bookedRoomList.Count > 0)
                        {
                            var oldDuration = model.checkOutDateShow.Subtract(model.checkInDate).Days;

                            int totalDays = Convert.ToDateTime(model.newCheckOutDate).Subtract(Convert.ToDateTime(model.newCheckInDate)).Days;

                            if (totalDays != oldDuration)
                            {
                                _isValid = false;
                                _msg = "Booking Duration cannot be changed! ";
                            }
                            if (_isValid)
                            {
                                bool _isRoomAvl = true;
                                int _noOfRooms = 0;

                                foreach (var item in model.bookedRoomList)
                                {
                                    int _extrabedAdd = 0;
                                    RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                                    objRoom.roomTypeId = item.roomID;
                                    objRoom.unitId = model.unitID;
                                    _noOfRooms = item.singleRoom + item.doubleRoom;

                                    for (int i = 0; i < totalDays; i++)
                                    {
                                        objRoom.bookingDate = Convert.ToDateTime(model.newCheckInDate).AddDays(i);
                                        var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                        if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                        {
                                            _isRoomAvl = false;
                                            _msg = "Room Not Available In " + item.roomType + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                            break;
                                        }
                                    }
                                    if (_isRoomAvl == false)
                                    {
                                        break;
                                    }
                                }
                                if (_isRoomAvl == true)
                                {
                                    int result = objBusinessClass.SavePreponePostponeBooking(model);

                                    if (result > 0)
                                    {
                                        SessionManager.DocketNo = model.docketNo;

                                        //Code For Email
                                        #region send mail and sms
                                        IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.getMobileNosEmailIdForSMSEmailCRS(model.docketNo);

                                        foreach (var lst in IEContactDetails)
                                        {
                                            if (lst.sendTo == "CUSTOMER")
                                            {
                                                SendUnitRoomMail(model.docketNo, "CUSTOMER", lst.Email);
                                                //SendUnitBookSms(model.docketNo, lst.MobileNo);
                                            }

                                        }
                                        #endregion


                                        return RedirectToAction("PreponePostponeConfirmation");
                                    }
                                    else
                                    {
                                        _msg = "Booking Schedule not changed!";
                                    }
                                }
                            }
                        }
                        else
                        {
                            _msg = "Room Details Not Found!";
                        }
                    }
                    else
                    {
                        _msg = isValid;
                    }
                }
                else
                {
                    _msg = string.IsNullOrEmpty(_msg) ? "Error in Process!" : _msg;
                }
            }
            catch
            {
                _msg = string.IsNullOrEmpty(_msg) ? "Error in Process!" : _msg;
            }

            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        //pre pone post pone Send mail

        #region Prepone-postpone booking Confirmation
        [HttpGet]
        public ActionResult PreponePostponeConfirmation()
        {
            PreponePostpone model = new PreponePostpone();
            try
            {
                model.docketNo = SessionManager.DocketNo;
            }
            catch
            {
            }
            return View(model);
        }

        #endregion

        /*------------------End Prepone-Postpone Booking-----------------*/

        #region to add booked room details

        [HttpGet]
        public ActionResult GetBookedRoomForExtend(ExtendBookingDetails objCustomer)
        {
            //CustomerRegistration model = new CustomerRegistration();
            IList<RoomDetail> lstBookedRoom = new List<RoomDetail>();
            if (objCustomer != null && objCustomer.lstBookedRoomDetail != null && objCustomer.lstBookedRoomDetail.Count > 0 && objCustomer.lstBookedRoomDetail[0] != null)
            {
                lstBookedRoom = objCustomer.lstBookedRoomDetail;
            }

            RoomDetail objRoom = new RoomDetail();
            objRoom.roomType = objCustomer.roomType;
            objRoom.roomTypeDisplay = objCustomer.roomTypeDisplay;
            objRoom.singleRoom = objCustomer.singleRoom;
            objRoom.doubleRoom = objCustomer.doubleRoom;
            objRoom.extrabed = objCustomer.extrabed;
            objRoom.hasOccupancy = objCustomer.hasOccupancy;
            objRoom.maxCapacity = objCustomer.maxCapacity;
            objRoom.maxExtraBed = objCustomer.maxExtraBed;
            objRoom.noOfGuests = Convert.ToInt32(objCustomer.noOfGuests);
            objRoom.totalRoom = objCustomer.singleRoom + objCustomer.doubleRoom;
            //objRoom.extendedDate = objCustomer.extendedDate;
            objRoom.extendedDate = DateTime.ParseExact(objCustomer.tmpextendedDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            objRoom.checkInDate = DateTime.ParseExact(objCustomer.tmpcheckInDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            objRoom.Sno = lstBookedRoom.Count + 1;
            objRoom.lstRoomNoDetail = objBusinessClass.GetRoomsOnCheckInByDate(SessionManager.UnitID, objRoom.checkInDate, objRoom.extendedDate, Convert.ToInt32(objRoom.roomType));
            lstBookedRoom.Add(objRoom);
            objCustomer.lstBookedRoomDetail = lstBookedRoom;
            return PartialView("_ExtendedBookedRoom", objCustomer);
        }
        #endregion

        #region to delete booked room

        [HttpGet]
        public ActionResult DeleteBookedRoomForExtend(ExtendBookingDetails objCustomer)
        {
            var itemsToRemove = objCustomer.lstBookedRoomDetail.Where(m => m.Sno == objCustomer.tempRoomId).ToList();
            int? _roomId = itemsToRemove.FirstOrDefault().roomType;
            string _roomName = itemsToRemove.FirstOrDefault().roomTypeDisplay;

            foreach (var itemToRemove in itemsToRemove)
                objCustomer.lstBookedRoomDetail.Remove(itemToRemove);

            ModelState.Clear();

            //objCustomer.tempRoomId2 = Convert.ToInt32(_roomId);
            objCustomer.tempRoomIdName = _roomName;
            return PartialView("_ExtendedBookedRoom", objCustomer);
        }
        #endregion

        public ActionResult ExtendBookingBackup(ExtendBookingDetails model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string _msg = string.Empty;
                    DateTime currDate = DateTime.Now.AddDays(-1);
                    DateTime maxCheckOutDate = currDate.AddDays(179);

                    var extendedRoomList = model.roomExtendDetailList.Where(m => m.extendedDate != null);
                    if (extendedRoomList != null && extendedRoomList.Count() > 0)
                    {
                        bool _isRoomAvl = true;
                        bool _isValidDate = true;

                        foreach (var lst in extendedRoomList)
                        {
                            if (lst.extendedDate > lst.checkoutDate.AddDays(1))
                            {
                                if (lst.extendedDate > currDate)
                                {
                                    if (lst.extendedDate <= maxCheckOutDate)
                                    {
                                        int totalDays = Convert.ToDateTime(lst.extendedDate).Subtract(lst.checkoutDate.AddDays(1)).Days;

                                        int _noOfRooms = 0;

                                        // int _extrabedAdd = 0;
                                        RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                                        objRoom.roomTypeId = lst.roomID;
                                        objRoom.unitId = SessionManager.UnitID;
                                        _noOfRooms = lst.totalRooms;

                                        DateTime fromDate = lst.checkoutDate.AddDays(1);

                                        for (int i = 0; i < totalDays; i++)
                                        {
                                            objRoom.bookingDate = fromDate.AddDays(i);
                                            var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                                            if (isAvailable == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < _noOfRooms)
                                            {
                                                _isRoomAvl = false;
                                                _msg = "Room Not Available In " + lst.roomType + " for date- " + objRoom.bookingDate.ToString("dd/MM/yyyy");
                                                break;
                                            }
                                        }
                                        if (_isRoomAvl == false)
                                        {
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        _isValidDate = false;
                                        _msg = "Booking can not be done for more than 180 days!";
                                        break;
                                    }
                                }
                                else
                                {
                                    _isValidDate = false;
                                    _msg = "Extended date could not be past date!";
                                    break;
                                }
                            }
                            else
                            {
                                _isValidDate = false;
                                _msg = "Extended date should be greater than checkout date!";
                                break;
                            }
                        }

                        if (_isRoomAvl == true && _isValidDate == true)
                        {
                            string roomXml = "";
                            roomXml = "<RoomDetail>";

                            foreach (var lst in extendedRoomList)
                            {
                                int totalDays = Convert.ToDateTime(lst.extendedDate).Subtract(lst.checkoutDate.AddDays(1)).Days;
                                DateTime fromDate = lst.checkoutDate.AddDays(1);

                                DateTime bookingDate;

                                List<RoomDetails> lstRooms = objBusinessClass.GetAllottedRooms(lst.requestID);


                                for (int i = 0; i < totalDays; i++)
                                {
                                    bookingDate = fromDate.AddDays(i);
                                    foreach (var room in lstRooms)
                                    {
                                        roomXml += "<RoomList>";
                                        roomXml += "<RequestId>" + lst.requestID + "</RequestId>";
                                        roomXml += "<BookingDate>" + bookingDate.ToString("yyyy/MM/dd") + "</BookingDate>";
                                        roomXml += "<RoomNoId>" + room.RoomNoId + "</RoomNoId>";
                                        roomXml += "<CheckoutDate>" + Convert.ToDateTime(lst.extendedDate).AddDays(-1).ToString("yyyy/MM/dd") + "</CheckoutDate>";
                                        roomXml += "</RoomList>";
                                    }
                                }

                            }
                            roomXml += "</RoomDetail>";
                            //var roomXml = new XElement("ExtendBooking",
                            //        from room in extendedRoomList
                            //        select new XElement("Booking",
                            //                       new XElement("RequestID", room.requestID),
                            //                       new XElement("CheckoutDate", Convert.ToDateTime(room.extendedDate).AddDays(-1))
                            //                   ));
                            //model.extendDetailXML = roomXml.ToString();
                            model.unitID = SessionManager.UnitID; ;

                            // int result = 1;
                            int result = objBusinessClass.UpdateExtendDetail(model);

                            if (result > 0)
                            {
                                TempData["DocketNo"] = model.docketNo;

                                return RedirectToAction("ExtendConfirmation");
                            }
                            else
                            {
                                _msg = "Room Not Booked!";
                            }
                        }
                    }
                    else
                    {
                        _msg = "Select atleast one room to extend date!";
                    }
                    //RoomAvailabilityDetails objRoom = new RoomAvailabilityDetails();
                    //bool _isRoomAvl = true;
                    //objRoom.roomTypeId = model.roomExtendDetailList;
                    //objRoom.unitId = SessionManager.UnitID;
                    //model.unitID = SessionManager.UnitID;
                    //int totalDays = model.extendDate.Subtract(model.checkOutDate).Days;
                    //for (int i = 0; i < totalDays; i++)
                    //{
                    //    objRoom.bookingDate = model.checkOutDate.AddDays(i);
                    //   var isAvailable = objBusinessClass.ChkRoomAvailability(objRoom);
                    //    if (isAvailable == null || isAvailable.TotalRoom == null || isAvailable.TotalRoom <= 0 || isAvailable.TotalRoom < model.noOfRooms)
                    //    {
                    //        _isRoomAvl = false;
                    //        _msg = "Room Not Available for date- " + objRoom.bookingDate;
                    //        ModelState.AddModelError("", "Room Not Available for date- " + objRoom.bookingDate.ToShortDateString());
                    //        break;
                    //    }
                    //}
                    //if (_isRoomAvl == true)
                    //{
                    //    int result = objBusinessClass.UpdateExtendDetail(model);
                    //    if (result > 0)
                    //    {
                    //        TempData["docketNo"] = model.docketNo;
                    //        return RedirectToAction("ExtendConfirmation", "Unit");
                    //    }
                    //    else
                    //    {
                    //        ViewBag.Error = "Error in Process!";
                    //    }
                    //}
                    //else
                    //{
                    //    ViewBag.Error = _msg;
                    //}
                    ViewBag.Show = _msg;
                }
                else
                {
                    ViewBag.Show = "Invalid details!";
                }
            }
            catch
            {
                ViewBag.Show = "Error in Process!";
            }
            return View(model);
        }

        #region Set guest detailsroomwise
        [HttpGet]
        public ActionResult RoomDetails()
        {
            return View();
        }
        [HttpGet]
        public ActionResult GetRoomDetails(string docketNo)
        {
            GuesRoomtDetails grd = new GuesRoomtDetails();
            DateTime bookingdate = DateTime.Now;
            grd.GuestList = objBusinessClass.GetCheckinRoomDetails(docketNo, bookingdate).ToList();
            if (grd.GuestList != null && grd.GuestList.Count > 0)
            {
                return PartialView("_getGuestRoomDetails", grd);
            }
            else
            {
                return Content("N");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RoomDetails(GuesRoomtDetails rl)
        {
            //if (ModelState.IsValid)
            //{
            var ProgXml = new XElement("CheckinList",
            from gl in rl.GuestList
            select new XElement("GuestDetails",
                           new XElement("RequestId", gl.RequestId),
                           new XElement("RoomNoId", gl.RoomNoId),
                           new XElement("GuestName", gl.GuestName),
                           new XElement("MobileNo", gl.MobileNo),
                           new XElement("ChekInTime", Convert.ToDateTime(gl.ChekInTime).ToShortTimeString()),
                           new XElement("ChekInDate", gl.ChekInDate))
                               );
            string xml = ProgXml.ToString();
            int i = 0;
            rl.ChekInDate = DateTime.Now;
            i = objBusinessClass.InsertUpdateGuestRoomDetails(xml, rl);
            if (i > 0)
            {
                ViewBag.Show = "Data Saved Successfully";
            }
            else
            {
                ViewBag.Show = "Error in Save Guset Room Details!";
            }
            //}           
            return View();
        }
        #endregion

        #region Prepone/postpone Booking
        //public ActionResult PreponePostpone()
        //{
        //   return View();
        //}

        public ActionResult BookingDetails()
        {
            return View();
        }
        #endregion

        #region Help For using Software
        public ActionResult help()
        {
            return View();
        }
        #endregion

        #region to send unit room booking mail
        protected void SendUnitRoomMail(string docketNo, string type, string mailTo)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                StreamReader reader;
                string subject = "";

                if (type == "CUSTOMER")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/UnitRoomBookingConfirmation_Customer.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/UnitRoomBookingConfirmation_Other.html"));
                    subject = "Room Booking Docket No. " + docketNo + " Booked by Unit.";
                }
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[hotelname]", model.unitName);
                MailBody = MailBody.Replace("[hoteladdress]", model.unitAddress);
                MailBody = MailBody.Replace("[hotelphone]", model.unitMobile);
                MailBody = MailBody.Replace("[roomtype]", model.roomType);
                MailBody = MailBody.Replace("[noofrooms]", model.noOfRooms.ToString());
                MailBody = MailBody.Replace("[extrabed]", model.extraBed.ToString());

                MailBody = MailBody.Replace("[checkindate]", model.checkinDate);
                MailBody = MailBody.Replace("[checkoutdate]", model.checkoutDate);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                //MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                if (type != "CUSTOMER")
                {
                    MailBody = MailBody.Replace("[bookedby]", model.bookingBy);
                }
                // MailBody = MailBody.Replace("[transactionid]", model.transactionID); 
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                //MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "CUSTOMER")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                    //else
                    //{
                    //    MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "anuj@otpl.co.in", mailbody = MailBody, subject = subject, toemail = mailTo };
                    //    objService.sendMail(objMail);
                    //}
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send unit booking sms
        protected void SendUnitBookSms(string docketNo, string customerMobileNo)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                var checkInDate = model.checkinDate;
                var roomInfo = model.roomType;
                var unitName = model.unitName;
                string customerName = model.name;

                string customerSms = ConfigurationManager.AppSettings["UnitBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[CustomerName]", customerName);
                customerSms = customerSms.Replace("[noOfRoomsAndType]", roomInfo);
                customerSms = customerSms.Replace("[UnitName]", unitName);
                customerSms = customerSms.Replace("[CheckinDate]", checkInDate);
                customerSms = customerSms.Replace("[DocketNo]", docketNo);

                //string concernPersonSMS = ConfigurationManager.AppSettings["UnitConcernPersonSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                //concernPersonSMS = concernPersonSMS.Replace("[noOfRoomsAndType]", roomInfo);
                //concernPersonSMS = concernPersonSMS.Replace("[UnitName]", unitName);
                //concernPersonSMS = concernPersonSMS.Replace("[CheckinDate]", checkInDate);
                //concernPersonSMS = concernPersonSMS.Replace("[DocketNo]", docketNo);

                //string nodalOfficerSMS = ConfigurationManager.AppSettings["UnitNodalOfficerSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[noOfRoomsAndType]", roomInfo);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[UnitName]", unitName);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[CheckinDate]", checkInDate);
                //nodalOfficerSMS = nodalOfficerSMS.Replace("[DocketNo]", docketNo);

                string SMSStatus = SMS.SMSSend(customerSms, customerMobileNo);              // Send SMS to Customer
                SMS.SMSLog(customerSms, customerMobileNo, docketNo, SMSStatus);

                //foreach (var lst in contactDetails)
                //{
                //    SMSStatus = string.Empty;
                //    if (lst.sendTo == "UNIT")
                //    {
                //        SMSStatus = SMS.SMSSend(concernPersonSMS, lst.MobileNo);         // Send SMS to Unit
                //        SMS.SMSLog(concernPersonSMS, lst.MobileNo, docketNo, SMSStatus);
                //    }
                //    if (lst.sendTo == "NODAL")
                //    {
                //        SMSStatus = SMS.SMSSend(nodalOfficerSMS, lst.MobileNo);          // Send SMS to Nodal Officer
                //        SMS.SMSLog(nodalOfficerSMS, lst.MobileNo, docketNo, SMSStatus);
                //    }
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region block and release room date wise
        #region display block and release date wise
        [HttpGet]
        public ActionResult BlockReleaseDateWise()
        {
            UnitBlockRelease model = new UnitBlockRelease();
            try
            {
                model.unitID = SessionManager.UnitID;
                model.dtBlocking = DateTime.Now;
                model.blockReleaseList = objBusinessClass.GetUnitBlockedRoomsOnDate(model);
                model.blockLimit = model.blockReleaseList.Select(p => p.blockLimit).Distinct().FirstOrDefault();

                if (TempData["message"] != null && TempData["message"].ToString() != "")
                {
                    ViewBag.Show = TempData["message"];
                }
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region save blocked and released rooms date wise
        [HttpPost]
        public ActionResult BlockReleaseDateWise(UnitBlockRelease model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    List<BlockReleaseDetail> lstBlock = model.blockReleaseList.Where(m => m.blocked > 0).ToList();
                    var totalBlock = lstBlock.Sum(m => m.blocked);

                    if (totalBlock > model.blockLimit)
                    {
                        ViewBag.Show = "Maximum block limit exceeded!";
                    }
                    else
                    {
                        string BlockList = "<BlockDetail>";
                        for (var i = 0; i < lstBlock.Count(); i++)
                        {

                            BlockList += "<BlockList>";
                            BlockList += "<RoomID>" + lstBlock[i].roomID + "</RoomID>";
                            BlockList += "<BlockedRoom>" + lstBlock[i].blocked + "</BlockedRoom>";
                            BlockList += "</BlockList>";
                        }
                        BlockList += "</BlockDetail>";

                        int result = objBusinessClass.InsertBlockDetailOnDate(SessionManager.UnitID, BlockList, model.dtBlocking);
                        if (result > 0)
                        {
                            TempData["message"] = "Record Saved Successfully!";
                            return RedirectToAction("BlockReleaseDateWise", "Unit");
                        }
                        else
                        {
                            ViewBag.Show = "Error in Process!";

                        }
                    }

                }
            }
            catch
            {

            }
            return View(model);
        }
        #endregion
        #endregion

        public ActionResult StatusDashboard()
        {
            return View();
        }

        public ActionResult BookingDashboard()
        {
            return View();
        }

        public ActionResult ChangeDashboard()
        {
            return View();
        }

        public ActionResult PaymentDashboard()
        {
            return View();
        }

        public ActionResult CancelDashboard()
        {
            return View();
        }


        #region display advance payment
        [HttpGet]
        public ActionResult AdvancePaymentRoomWise()
        {
            try
            {
                AdvancePaymentRoomWise model = new AdvancePaymentRoomWise();
                model.allotedRoomList = objBusinessClass.GetAllAllottedRooms(SessionManager.UnitID);
                model.isPostBack = false;

                return View(model);
            }
            catch
            {
            }
            return View();
        }
        #endregion

        #region get booking details room wise
        [HttpGet]
        public ActionResult BookingDetailByRoom(Int64 bookRooomID)
        {
            AdvancePaymentRoomWise model = new AdvancePaymentRoomWise();
            try
            {
                ViewBag.AmountCategory = objBusinessClass.GetAdvanceAmountCategory().Select(e => new SelectListItem() { Text = e.AdvancePaymentCategory, Value = e.CatId.ToString() });

                model.unitID = SessionManager.UnitID;
                model.bookedRoomID = bookRooomID;

                model = objBusinessClass.GetBookingDetailsByRoom(model);
                if (model != null)
                {
                    model.roomDetailList = objBusinessClass.GetRoomDetailsForChange(model.docketNo, SessionManager.UnitID);
                    model.paymentDate = DateTime.Now;
                }
                //model = objBusinessClass.GetCounterPaymentInfo(model);

                model.isPostBack = true;
            }
            catch
            { }
            return PartialView("_AdvancePaymentRoomWise", model);
        }
        #endregion

        //#region get customer payment details for advance payment
        //public ActionResult GetCustomerPaymentDetail(string docketNo)
        //{
        //    AdvancePayment model = new AdvancePayment();
        //    try
        //    {
        //        ViewBag.AmountCategory = objBusinessClass.GetAdvanceAmountCategory().Select(e => new SelectListItem() { Text = e.AdvancePaymentCategory, Value = e.CatId.ToString() });
        //        model.docketNo = docketNo.Trim();
        //        model.unitID = SessionManager.UnitID;
        //        model = objBusinessClass.GetCounterPaymentInfo(model);
        //        if (model != null)
        //        {
        //            model.paymentDate = DateTime.Now;
        //        }
        //    }
        //    catch
        //    {
        //    }
        //    return PartialView("_PaymentDetail", model);
        //}
        //#endregion

        #region save advance payment
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AdvancePaymentRoomWise(AdvancePaymentRoomWise model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.unitID = SessionManager.UnitID;
                    model.userIP = this.Request.UserHostAddress;
                    int result = objBusinessClass.InsertAdvancePaymentByRoom(model);
                    if (result > 0)
                    {
                        TempData["docketNo"] = model.docketNo;
                        return RedirectToAction("AdvancePaymentConfirmation", "Unit");
                    }
                    else
                    {
                        ViewBag.Show = "Error in Process!";
                    }
                }
            }
            catch
            {

            }
            return View(model);
        }
        #endregion

        #region advance payment Confirmation
        [HttpGet]
        public ActionResult AdvancePaymentConfirmation()
        {
            AdvancePaymentRoomWise model = new AdvancePaymentRoomWise();
            try
            {
                model.unitID = SessionManager.UnitID;
                model.docketNo = TempData["docketNo"] != null ? TempData["docketNo"].ToString() : "";

                model.paymentDetailList = objBusinessClass.GetAdvancePaymentDetails(model.docketNo.Trim(), model.unitID);
            }
            catch
            { }
            return View(model);
        }

        #endregion


        /* By Bramh on 20-02-2016--------------------------------------*/

        #region display online lawn/Banquit enquiry list
        [HttpGet]
        public ActionResult OnlineLawnEnquiry()
        {

            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                GetEnQList();
                model.dateFrom = DateTime.Now;
                model.dateTo = DateTime.Now;
                model.unitID = SessionManager.UnitID;
                model.enquiryType = "All";
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);
            }
            catch
            {
            }
            return View(model);
        }
        #endregion

        #region bind booking grid
        public ActionResult GetLawnEnquiryList(string dateFrom, string dateTo, string enquiryNo, string EnquiryType)
        {
            LawnEnquiryReport model = new LawnEnquiryReport();
            try
            {
                if (string.IsNullOrEmpty(dateFrom))
                {
                    dateFrom = "01/01/1900";
                }
                if (string.IsNullOrEmpty(dateTo))
                {
                    dateTo = "01/01/1900";
                }
                model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                model.enquiryNo = enquiryNo.Trim();
                model.unitID = SessionManager.UnitID;
                model.enquiryType = EnquiryType;
                model.lawnEnquiryList = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);
            }
            catch
            {
            }
            return PartialView("_OnlineLawnEnquiry", model.lawnEnquiryList);
        }
        #endregion

        #region export lawn enquiry list
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult OnlineLawnEnquiry(LawnEnquiryReport model)
        {
            ModelState.Clear();
            GridView gv = new GridView();
            model.dateFrom = model.dateFrom == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateFrom);
            model.dateTo = model.dateTo == null ? DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture) : Convert.ToDateTime(model.dateTo);
            model.enquiryType = "All";
            model.unitID = SessionManager.UnitID;
            var dtresult = objBusinessClass.GetLawnBanquetEnquiryListforUnit(model);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Enquiry_No = e.enquiryNo, Name = e.name, Mobile_No = e.mobileNo, Enquiry_Type = e.enquiryType, Booking_Date = e.lawnBookingDate.ToString("dd/MM/yyyy"), Hotel = e.unitName, Function_Type = e.functionName, Enquiry_Date = e.enquiryDate }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/OnlineLawnEnquiryList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            model.lawnEnquiryList = dtresult;


            GetEnQList();
            return View(model);
        }
        #endregion

        #region get lawn enquiry details
        [HttpGet]
        public ActionResult GetLawnEnquiryDetail(string enquireNo)
        {
            LawnEnquiry model = new LawnEnquiry();
            string _msg = "";
            try
            {
                model = objBusinessClass.GetLawnBanquetEnquiry(enquireNo);
                if (model != null)
                {
                    return PartialView("_OnlineLawnEnquiryDetails", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion

        void GetEnQList()
        {
            ViewBag.EnQtype = new List<SelectListItem>() {new SelectListItem { Text="All", Value = "All"},
                                            new SelectListItem { Text="Lawn", Value = "Lawn"}, 
                                            new SelectListItem { Text="Banquet", Value = "Banquet"}};
        }

        #region checkin of packages
        [HttpGet]
        public ActionResult CheckinPackage(string docketNo = null)
        {
            PackageCheckin obj = new PackageCheckin();
            obj.docketNo = docketNo;
            return View(obj);
        }
        #endregion

        #region get booking details for checkin of packages
        [HttpGet]
        public ActionResult PackBookingDetailForCheckIn(string docketNo)
        {
            PackageCheckin model = new PackageCheckin();

            try
            {
                Int64 _unitId = SessionManager.UnitID;
                model.unitID = _unitId;
                model.docketNo = docketNo.Trim();

                model = objBusinessClass.GetPackageBookingDetailsForCheckin(docketNo.Trim(), _unitId);
                if (model != null)
                {
                    model.unitID = _unitId;
                    model.lstBookedRoomDetail = objBusinessClass.GetPackageBookedRoomDetails(model);
                    foreach (var lstRoom in model.lstBookedRoomDetail)
                    {
                        if (!lstRoom.isCheckIn)
                        {
                            lstRoom.lstRoomNoDetail = objBusinessClass.GetRoomsOnCheckIn(_unitId, lstRoom.requestID, Convert.ToInt32(lstRoom.roomType));
                        }
                    }
                }
            }
            catch
            {
            }
            return PartialView("_CheckinPackage", model);
        }
        #endregion

        #region save checkin details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CheckinPackage(PackageCheckin model)
        {
            string _msg = string.Empty;
            bool _isValid = true;
            try
            {
                if (model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0)
                {
                    for (int i = 0; i < model.lstBookedRoomDetail.Count; i++)
                    {
                        ModelState["lstBookedRoomDetail[" + i + "].checkInTime"].Errors.Clear();
                        ModelState["lstBookedRoomDetail[" + i + "].actualCheckInDate"].Errors.Clear();
                    }
                }
                else
                {
                    _isValid = false;
                    _msg = "Invalid Details!";
                }


                if (ModelState.IsValid && _isValid)
                {

                    model.userIP = Common.GetIPAddress();
                    model.unitID = SessionManager.UnitID;
                    String strXML = string.Empty;

                    #region add rooms date wise and request Id wise

                    var _matchedRooms = model.lstBookedRoomDetail.Where(m => m.isSelected).ToList();
                    if (_matchedRooms != null && _matchedRooms.Count > 0)
                    {
                        List<string> matchedRooms = new List<string>();
                        List<ChkInRooms> lstChkInRoom = new List<ChkInRooms>();
                        strXML = "<RoomDetail>";
                        foreach (var item in _matchedRooms)
                        {
                            int totalDays = item.checkOutDate.Subtract(item.checkInDate).Days + 1;
                            DateTime bookingDate;
                            for (int i = 0; i < totalDays; i++)
                            {
                                bookingDate = item.checkInDate.AddDays(i);

                                int count = 0;

                                if (item.lstRoomNoDetail != null && item.lstRoomNoDetail.Count > 0)
                                {
                                    int noOfRooms = item.totalRoom, _currSelectedRoom = 0;
                                    var _selectedRooms = item.lstRoomNoDetail.Where(m => m.isSelected).ToList();
                                    if (_selectedRooms != null && _selectedRooms.Count > 0)
                                    {
                                        foreach (var room in _selectedRooms)
                                        {
                                            ChkInRooms objChkRoom = new ChkInRooms();
                                            objChkRoom.bookingDate = bookingDate;
                                            objChkRoom.RoomNoId = room.RoomNoId;

                                            strXML += "<RoomList>";
                                            strXML += "<RequestId>" + item.requestID + "</RequestId>";
                                            strXML += "<BookingDate>" + bookingDate.ToString("yyyy/MM/dd") + "</BookingDate>";
                                            strXML += "<RoomNoId>" + room.RoomNoId + "</RoomNoId>";
                                            strXML += "<FromTime>" + Convert.ToDateTime(item.checkInTime).ToString("HH:mm:ss") + "</FromTime>";
                                            strXML += "<CheckInDate>" + Convert.ToDateTime(item.actualCheckInDate).ToString("yyyy/MM/dd") + "</CheckInDate>";
                                            strXML += "</RoomList>";

                                            if (i == 0)
                                            {
                                                matchedRooms.Add(Convert.ToString(room.RoomNoId));
                                            }
                                            _currSelectedRoom++;
                                            lstChkInRoom.Add(objChkRoom);
                                        }
                                        if (_currSelectedRoom == 0)
                                        {
                                            _isValid = false;
                                            _msg = "No room selected for " + item.roomTypeDisplay;
                                            break;
                                        }
                                        else if (_currSelectedRoom < noOfRooms)
                                        {
                                            _isValid = false;
                                            _msg = "No. of selected rooms is not sufficient for " + item.roomTypeDisplay;
                                            break;
                                        }
                                        else if (_currSelectedRoom > noOfRooms)
                                        {
                                            _isValid = false;
                                            _msg = "Total No. of selected rooms is more than required rooms for " + item.roomTypeDisplay;
                                            break;
                                        }
                                    }
                                    else
                                    {
                                        _isValid = false;
                                        _msg = "No room selected for " + item.roomTypeDisplay;
                                        break;
                                    }
                                }
                                else
                                {
                                    _isValid = false;
                                    _msg = "Select Room No.!";
                                }

                            }
                            if (_isValid == false)
                            {
                                break;
                            }
                        }

                        var query = lstChkInRoom
                           .GroupBy(f => new { f.bookingDate, f.RoomNoId })
                           .Select(group => new { cc = group.Count(), bookingDate = group.Key.bookingDate, roomTypeId = group.Key.RoomNoId });

                        foreach (var result in query)
                        {
                            if (result.cc > 1)
                            {
                                _isValid = false;
                                _msg = "Select distinct rooms for date " + result.bookingDate.ToString("dd/MM/yyyy") + "!!";
                                break;
                            }
                        }

                        //#region for check duplicate values for rooms
                        //var chkItems = matchedRooms.Distinct().ToArray();
                        //if (matchedRooms.ToArray().Length != chkItems.Length)
                        //{
                        //    for (int k = 0; k < matchedRooms.ToArray().Length; k++)
                        //    {
                        //        try
                        //        {
                        //            if (matchedRooms[k].ToString() != chkItems[k].ToString())
                        //            {
                        //                _isValid = false;

                        //                _msg = "Select distinct rooms!!";
                        //                break;
                        //            }
                        //        }
                        //        catch (Exception ex)
                        //        {
                        //            _isValid = false;
                        //            _msg = "Select distinct rooms!!";
                        //            break;
                        //        }
                        //    }
                        //}
                        //#endregion

                        strXML += "</RoomDetail>";
                    }
                    else
                    {
                        _isValid = false;
                        _msg = "Select atleast one booking to checkin!";
                    }
                    #endregion


                    if (_isValid == true)
                    {
                        int result = objBusinessClass.InsertPackageCheckinDetail(model, strXML);
                        if (result > 0)
                        {
                            TempData["docketNo"] = model.docketNo;
                            return RedirectToAction("PackageCheckinConfirmation", "Unit");
                        }
                        else
                        {
                            _msg = "Rooms Not Available.Try Again..";
                        }
                    }

                }
            }
            catch
            {
                _msg = "Error in Process!";
            }
            Int64 _unitId = SessionManager.UnitID;
            model.unitID = _unitId;
            model.lstBookedRoomDetail = objBusinessClass.GetPackageBookedRoomDetails(model);
            foreach (var lstRoom in model.lstBookedRoomDetail)
            {
                if (!lstRoom.isCheckIn)
                {
                    lstRoom.lstRoomNoDetail = objBusinessClass.GetRoomsOnCheckIn(_unitId, lstRoom.requestID, Convert.ToInt32(lstRoom.roomType));
                }
            }
            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        #region check in Confirmation
        [HttpGet]
        public ActionResult PackageCheckinConfirmation()
        {
            List<PackageRoomDetail> model = new List<PackageRoomDetail>();
            try
            {
                model = objBusinessClass.GetPackCheckinDetails(TempData.Peek("docketNo").ToString());
            }
            catch
            {

            }
            return View(model);
        }

        #endregion

        /*--------------Checkout of packages-----------------------*/

        #region checkout of packages
        [HttpGet]
        public ActionResult CheckoutPackage(string docketNo = null)
        {
            PackageCheckout obj = new PackageCheckout();
            obj.docketNo = docketNo;
            return View(obj);
        }
        #endregion

        #region get booking details for checkout of packages
        [HttpGet]
        public ActionResult PackBookingDetailForCheckOut(string docketNo)
        {
            PackageCheckout model = new PackageCheckout();

            try
            {
                Int64 _unitId = SessionManager.UnitID;
                model.unitID = _unitId;
                model.docketNo = docketNo.Trim();

                model = objBusinessClass.GetPackageBookingDetailsForCheckout(docketNo.Trim(), _unitId);
                if (model != null)
                {
                    model.unitID = _unitId;
                    model.lstBookedRoomDetail = objBusinessClass.GetPackageCheckoutRoomDetails(model);
                }
            }
            catch
            {
            }
            return PartialView("_CheckoutPackage", model);
        }
        #endregion

        #region save checkin details
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CheckoutPackage(PackageCheckout model)
        {
            string _msg = string.Empty;
            bool _isValid = true;
            try
            {
                if (model.lstBookedRoomDetail != null && model.lstBookedRoomDetail.Count > 0)
                {
                    for (int i = 0; i < model.lstBookedRoomDetail.Count; i++)
                    {
                        ModelState["lstBookedRoomDetail[" + i + "].checkOutTime"].Errors.Clear();
                        ModelState["lstBookedRoomDetail[" + i + "].actualCheckOutDate"].Errors.Clear();
                    }
                }
                else
                {
                    _isValid = false;
                    _msg = "Invalid Details!";
                }


                if (ModelState.IsValid && _isValid)
                {

                    model.userIP = Common.GetIPAddress();
                    model.unitID = SessionManager.UnitID;
                    String strXML = string.Empty;

                    #region add rooms date wise and request Id wise

                    var _matchedRooms = model.lstBookedRoomDetail.Where(m => m.isSelected).ToList();
                    if (_matchedRooms != null && _matchedRooms.Count > 0)
                    {
                        List<string> matchedRooms = new List<string>();
                        strXML = "<RoomDetail>";
                        foreach (var item in _matchedRooms)
                        {
                            strXML += "<RoomList>";
                            strXML += "<RequestId>" + item.requestID + "</RequestId>";
                            strXML += "<ToTime>" + Convert.ToDateTime(item.checkOutTime).ToString("HH:mm:ss") + "</ToTime>";
                            strXML += "<CheckOutDate>" + Convert.ToDateTime(item.actualCheckOutDate).ToString("yyyy/MM/dd") + "</CheckOutDate>";
                            strXML += "</RoomList>";

                        }
                        strXML += "</RoomDetail>";
                    }
                    else
                    {
                        _isValid = false;
                        _msg = "Select atleast one booking to checkout!";
                    }
                    #endregion

                    if (_isValid == true)
                    {
                        int result = objBusinessClass.InsertPackageCheckoutDetail(model, strXML);
                        if (result > 0)
                        {
                            TempData["docketNo"] = model.docketNo;
                            return RedirectToAction("PackageCheckoutConfirmation", "Unit");
                        }
                        else
                        {
                            _msg = "Unable to Check Out.Try Again..";
                        }
                    }
                }
            }
            catch
            {
                _msg = "Error in Process!";
            }
            Int64 _unitId = SessionManager.UnitID;
            model.unitID = _unitId;
            model.lstBookedRoomDetail = objBusinessClass.GetPackageCheckoutRoomDetails(model);
            ViewBag.Show = _msg;
            return View(model);
        }
        #endregion

        #region check in Confirmation
        [HttpGet]
        public ActionResult PackageCheckoutConfirmation()
        {
            List<PackageCheckOutRoomDetail> model = new List<PackageCheckOutRoomDetail>();
            try
            {
                model = objBusinessClass.GetPackCheckoutDetails(TempData.Peek("docketNo").ToString());
            }
            catch
            {

            }
            return View(model);
        }

        #endregion

        /*--------------End Checkout of packages-----------------------*/



        /*--------------------------Set Reply for Lawn and Banquet----------------*/


        #region display reply screen
        [HttpGet]
        public ActionResult ReplyLawnBanqEnquiry(string id)
        {
            LawnEnquiry model = new LawnEnquiry();
            try
            {
                if (TempData["message"] != null)
                {
                    ViewBag.Message = TempData["message"];
                }
                model = objBusinessClass.GetLawnBanquetEnquiry(id);
            }
            catch
            { }
            return View(model);
        }
        #endregion

        #region save reply
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ReplyLawnBanqEnquiry(LawnEnquiry model)
        {
            string returnMessage = "";
            try
            {
                ModelState["firstName"].Errors.Clear();
                ModelState["lastName"].Errors.Clear();
                ModelState["mobileNo"].Errors.Clear();
                ModelState["message"].Errors.Clear();
                ModelState["email"].Errors.Clear();

                ModelState["Captcha"].Errors.Clear();

                if (ModelState.IsValid)
                {
                    model.userIP = this.Request.UserHostAddress;
                    model.userID = SessionManager.UserID;
                    string documentPath = "";
                    string res = objCommonClass.ValidateFile(model.document);
                    if (res != "Valid")
                    {
                        returnMessage = res;
                        return View(model);
                    }
                    else
                    {
                        documentPath = SaveDocument(model.document);
                        model.documentPath = documentPath;
                    }

                    var user = objBusinessClass.SaveBanqLawnEnquiryReply(model);
                    if (user > 0)
                    {
                        model = objBusinessClass.GetLawnBanquetEnquiry(model.enquiryNo);
                        if (model != null)
                        {
                            model.documentPath = documentPath;
                            try
                            {
                                SendReplyMail(model);
                                TempData["message"] = "Reply successfully done to Enquiry No. " + model.enquiryNo;
                                return RedirectToAction("ReplyLawnBanqEnquiry");
                            }
                            catch
                            {
                                returnMessage = "Mail not sent.";
                            }
                        }
                        else
                        {
                            returnMessage = "Mail not sent.";
                        }
                    }
                    else
                    {
                        returnMessage = "Error in sending reply.";
                    }
                    ViewBag.Message = returnMessage;
                }
            }
            catch
            {
                return RedirectToAction("ReplyLawnBanqEnquiry", model.enquiryNo);
            }
            return View(model);
        }
        #endregion

        #region Save uploaded document
        public string SaveDocument(HttpPostedFileBase document)
        {
            string documentPath = "";
            try
            {
                if (document != null)
                {
                    string ext = Path.GetExtension(document.FileName);
                    string filename = Path.GetFileName("Quotation" + DateTime.Now.Ticks + ext);

                    documentPath = Path.Combine("Content/writereaddata/Documents", filename);
                    var docPath = Path.Combine(Server.MapPath("~/Content/writereaddata/Documents"), filename);
                    document.SaveAs(docPath);
                }
            }
            catch
            { }
            return documentPath;
        }
        #endregion

        #region to send special package booking mail
        protected void SendReplyMail(LawnEnquiry model)
        {
            try
            {
                StreamReader readerCust = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BusTaxiEnquiryReply.html"));
                string subject = "Quotation for UP Tourism " + model.enquiryType + " Booking.";

                string MailBody = readerCust.ReadToEnd();
                MailBody = MailBody.Replace("[name]", model.name);
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[enquiryno]", model.enquiryNo);
                MailBody = MailBody.Replace("[amount]", model.amount.ToString());
                MailBody = MailBody.Replace("[remark]", model.remark);
                MailBody = MailBody.Replace("[document]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + model.documentPath);
                MailBody = MailBody.Replace("[url]", ConfigurationManager.AppSettings["EnquiryReplyUrl"].ToString() + "UPTourism/LawnBanqQuotation/" + Server.UrlEncode(EncryptionDecryption.EncodeTo64(model.enquiryNo)));

                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(model.email)))
                {
                    //MailService.Service1 objService = new MailService.Service1();

                    try
                    {
                        SendMail.SendMailNew(model.email, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = model.email };
                        //objService.sendMail(objMail);

                        //MailService.EmailData objMailNew = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMailNew);
                    }
                    catch
                    {

                    }
                }

            }
            catch (Exception)
            {
            }
        }
        #endregion

        /*--------------------------End Set Reply for Lawn and Banquet----------------*/


        #region by Syed
        [HttpGet]
        public ActionResult LawnBanquetBookingDetails()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LawnBanquetBookingDetails(UnitBanqlawnBooking model)
        {
            ModelState.Clear();

            GridView gv = new GridView();
            model.unitID = SessionManager.UnitID;
            LawnBanquetBooking mod = new LawnBanquetBooking();
            mod.dateFrom = model.dtBookingDateFrom;
            mod.dateTo = model.dtBookingDateTo;
            mod.docketNo = model.docketNo;
            mod.UnitId = model.unitID;
            var dtresult = objBusinessClass.GetLawnBanquetBookingList(mod);

            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Unit_Name = e.UnitName, Docket_No = e.docketNo, Booking_Date = e.ForDate.ToString("dd/MM/yyyy"), Booking_For = e.BookingFor, Name = e.name, Mobile_No = e.mobileNo, Email = e.email, Function_Name = e.functionName, Amount = e.advanceAmount, Booking_By = e.bookingBy }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/LawnBanquetBookingList.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }
            IEnumerable<LawnBanquetBooking> modellist = dtresult;
            return View(modellist);
        }

        public ActionResult GetLawnBanquetBookingList(string dateFrom, string dateTo, string docketNo)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            List<LawnBanquetBooking> modellist = new List<LawnBanquetBooking>();
            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.dateFrom = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.dateTo = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.docketNo = docketNo.Trim();
                model.UnitId = SessionManager.UnitID;
                modellist = objBusinessClass.GetLawnBanquetBookingList(model).ToList();
            }
            catch
            {
            }
            return PartialView("_LawnBanquetBookingList", modellist);
        }

        public ActionResult GetLawnBanquetBookingDetail(string docketNo)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            string _msg = "";
            try
            {
                model.docketNo = docketNo;
                model.UnitId = SessionManager.UnitID;

                model = objBusinessClass.GetLawnBanquetBookingList(model).FirstOrDefault();
                if (model != null)
                {
                    return PartialView("_LawnBanquetBookingListDetail", model);
                }
                else
                {
                    _msg = "Details Not Available!!";
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
            }

            return Content(_msg);
        }
        #endregion


        #region Lawn Banquit Booking
        public ActionResult BanquetLawnBooking()
        {
            ViewBag.FunctionType = objBusinessClass.GetFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });
            ViewBag.BookinforList = BookFor();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Nationality = GetNationality();

            return View();
        }

        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult BanquetLawnBooking(UnitLawnBanquetBooking model)
        {
            ViewBag.FunctionType = objBusinessClass.GetFunctionList().Select(e => new SelectListItem() { Text = e.functionName, Value = e.functionID.ToString() });
            ViewBag.BookinforList = BookFor();
            ViewBag.NameTitle = objBusinessClass.GetTitle().Select(e => new SelectListItem() { Text = e.TitleName, Value = e.TitleId.ToString() });
            ViewBag.Country = objBusinessClass.GetCountryList().Select(e => new SelectListItem() { Text = e.countryName, Value = e.countryID.ToString() });
            ViewBag.IdentityType = objBusinessClass.GetPersonalIdentityType().Select(e => new SelectListItem() { Text = e.pName, Value = e.pId.ToString() });
            ViewBag.Nationality = GetNationality();
            string _msg = "";
            bool _isValid = true;
            try
            {
                if (model.countryID == 98)
                {
                    ModelState["otherState"].Errors.Clear();
                    ModelState["otherCity"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.pincode) && !pinCode.IsMatch(model.pincode))
                    {
                        _isValid = false;
                        _msg = "Enter a valid 6 digit Pincode!";
                    }
                    else if (!string.IsNullOrEmpty(model.mobileNo) && !mobileNo.IsMatch(model.mobileNo))
                    {
                        _isValid = false;
                        _msg = "Enter a valid 10 digit Mobile No.!";
                    }
                }
                else
                {
                    ModelState["stateID"].Errors.Clear();
                    ModelState["cityID"].Errors.Clear();

                    if (!string.IsNullOrEmpty(model.mobileNo) && !numericCheck.IsMatch(model.mobileNo))
                    {
                        _isValid = false;
                        _msg = "Enter a valid Mobile No.!";
                    }
                }
                if (string.IsNullOrEmpty(model.email))
                {
                    ModelState["email"].Errors.Clear();
                }
                if (string.IsNullOrEmpty(model.pincode))
                {
                    ModelState["pincode"].Errors.Clear();
                }
                if (ModelState.IsValid && _isValid == true)
                {
                    var RESULT = objBusinessClass.insertLawnBanquietbookingdetails(model, Common.GetIPAddress());

                    try
                    {
                        SendLawnBanquidSMSMail(RESULT.docketNo, model.Bookingfor);
                    }
                    catch
                    {
                    }

                    return RedirectToAction("BanquetLawnBookingConfirmation", new { @id = RESULT.docketNo });
                }
                else
                {
                    ModelState.AddModelError("", "Check Inputs");
                    return View(model);
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = ex.Message;
                return View(model);
            }

            return View(model);
        }

        public IEnumerable<SelectListItem> BookFor()
        {
            var BookingFor = new List<SelectListItem>();

            SelectListItem Temp;
            Temp = new SelectListItem();
            Temp.Text = "Lawn";
            Temp.Value = "Lawn";
            BookingFor.Add(Temp);

            Temp = new SelectListItem();
            Temp.Text = "Banquet";
            Temp.Value = "Banquet";
            BookingFor.Add(Temp);


            return BookingFor;
        }
        #endregion

        public ActionResult BanquetLawnBookingConfirmation(string id)
        {
            LawnBanquetBooking model = new LawnBanquetBooking();
            model.docketNo = id;
            model.UnitId = SessionManager.UnitID;

            model = objBusinessClass.GetLawnBanquetBookingList(model).FirstOrDefault();
            return View(model);
        }

        #region Guest History

        public ActionResult SearchGuest()
        {
            return View();
        }

        [HttpGet]
        public ActionResult GetGuestList(string name, string email, string mobile)
        {
            int UserId = 0;
            List<GuestList> ggl = objBusinessClass.getGuestListUNIT(UserId, name, mobile, email, Convert.ToInt32(SessionManager.UnitID)).ToList();

            return PartialView("_GuestList", ggl);
        }
        #endregion


        #region ChaneRoomDetails
        public ActionResult ChangeRoomDetails()
        {
            return View();
        }
        [ValidateAntiForgeryToken]
        [HttpPost]
        public ActionResult ChangeRoomDetails(BookingChange model)
        {
            model = objBusinessClass.GetUnitBookingDetailseEDIT(model.DocketNo, SessionManager.UnitID).FirstOrDefault();
            model.roomdetList = objBusinessClass.getRoomBookingList(model.DocketNo, 0, SessionManager.UnitID);
            model.AdvanceAmountdetList = objBusinessClass.GetAdvanceAmountList(model.DocketNo, 0, SessionManager.UnitID);
            return View(model);
        }

        [HttpGet]
        public ActionResult GetAdvanceAmountList(string DoscketNo)
        {
            List<AdvanceAmountDetails> Model = objBusinessClass.GetAdvanceAmountList(DoscketNo, 0, SessionManager.UnitID);
            return PartialView("_AdvanceAmountList", Model);
        }

        [HttpGet]
        public ActionResult GetRoomBookingdetlsList(string DoscketNo)
        {
            List<RoomBookingDetails> Model = objBusinessClass.getRoomBookingList(DoscketNo, 0, SessionManager.UnitID);
            return PartialView("_ChangeBookingDetails", Model);
        }

        [HttpGet]
        public ActionResult GetAllBookingDetails()
        {
            return View();
        }

        public ActionResult UpdateRoomOccupancy(string id)
        {
            int reqId = 0;
            int.TryParse(id, out reqId);
            if (reqId > 0)
            {
                RoomBookingDetails mode = objBusinessClass.getRoomBookingList("", reqId, SessionManager.UnitID).FirstOrDefault();
                return View("_UpdateRoomOccupancy", mode);
            }
            else
            {
                return Content("NA");
            }
        }

        [HttpPost]
        public ActionResult UpdateRoomOccupancy(RoomBookingDetails model)
        {
            try
            {
                if (model.noOfRooms == model.doubleRoom + model.singleRoom)
                {
                    int a = objBusinessClass.UpdateRoomOccupancyByReqId(model);
                    if (a > 0)
                    {
                        return Content("Room(s) updated successfully.");
                    }
                    else
                    {
                        return Content("Fail to Update because either room is Checked-in or booking by online.");
                    }
                }
                else
                {
                    return Content("Sum of Rooms must equal to total rooms.");
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }
        }

        public ActionResult UpdateAdvanceAmount(string id)
        {
            int AdvanceAmtID = 0;
            int.TryParse(id, out AdvanceAmtID);
            if (AdvanceAmtID > 0)
            {
                AdvanceAmountDetails mode = objBusinessClass.GetAdvanceAmountList("", AdvanceAmtID, SessionManager.UnitID).FirstOrDefault();
                return View("_UpdateAdvanceAmount", mode);
            }
            else
            {
                return Content("NA");
            }
        }

        [HttpPost]

        public ActionResult UpdateAdvanceAmount(AdvanceAmountDetails model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    int i = 0;
                    i = objBusinessClass.UpdateAdvanceAmountByAdvanceAmtId(model);
                    if (i > 0)
                    {
                        return Content("Amount Updated Successfully");
                    }
                    else
                    {
                        return Content("fail to Update Amount");
                    }
                }
                else
                {
                    return Content("Check Inputs");
                }
            }
            catch (Exception ex)
            {
                return Content(ex.Message);
            }

        }
        #endregion

        public ActionResult BookingAtAGlance()
        {
            ViewBag.Year = YearList();
            BookingatAglance model = new BookingatAglance();
            model.MonthId = DateTime.Now.Month;
            model.YearId = DateTime.Now.Year;
            model.HeaderList = objBusinessClass.getUnitBookingAtAGlanceHeaders(Convert.ToInt32(SessionManager.UnitID));
            model.DtReport = Common.GetRoomBookingList(Convert.ToInt32(SessionManager.UnitID), model.MonthId, model.YearId);
            return View(model);

        }

        [HttpPost]
        public ActionResult BookingAtAGlance(BookingatAglance model)
        {
            ViewBag.Year = YearList();
            model.HeaderList = objBusinessClass.getUnitBookingAtAGlanceHeaders(Convert.ToInt32(SessionManager.UnitID));
            model.DtReport = Common.GetRoomBookingList(Convert.ToInt32(SessionManager.UnitID), model.MonthId, model.YearId);
            return View(model);

        }

        public IEnumerable<SelectListItem> YearList()
        {
            var EnqTypeL = new List<SelectListItem>();
            for (int i = 2015; i <= DateTime.Now.Year; i++)
            {
                SelectListItem Temp;
                Temp = new SelectListItem();
                Temp.Text = i.ToString();
                Temp.Value = i.ToString();
                EnqTypeL.Add(Temp);
            }
            return EnqTypeL;
        }

        public ActionResult PrintBookingAtAGlance(string Month, string Year)
        {
            BookingatAglance model = new BookingatAglance();
            int m, y;
            int.TryParse(Month, out m);
            int.TryParse(Year, out y);
            ViewBag.Month = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(m);
            ViewBag.Year = Year;
            model.MonthId = m;
            model.YearId = y;
            model.HeaderList = objBusinessClass.getUnitBookingAtAGlanceHeaders(Convert.ToInt32(SessionManager.UnitID));
            model.DtReport = Common.GetRoomBookingList(Convert.ToInt32(SessionManager.UnitID), model.MonthId, model.YearId);
            return View(model);
        }

        [HttpGet]
        public ActionResult UnitReport()
        {
            UnitRevenueRepoprt model = new UnitRevenueRepoprt();
            model.fromDate = DateTime.Now.AddDays(-5);
            model.Todate = DateTime.Now;
            model.UnitId = SessionManager.UnitID;
            model.billList = objBusinessClass.getUnitRevenueAndTaxReport(model);
            return View(model);
        }
        [HttpPost]
        public ActionResult UnitReport(UnitRevenueRepoprt model)
        {
            if (ModelState.IsValid)
            {
                ModelState.Clear();
                model.UnitId = SessionManager.UnitID;
                model.billList = objBusinessClass.getUnitRevenueAndTaxReport(model);
            }
            return View(model);
        }

        public ActionResult GetUnitReportList(string fromDate, string Todate)
        {
            UnitRevenueRepoprt model = new UnitRevenueRepoprt();
            try
            {
                try
                {
                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateFrom = null;
                    model.fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    model.Todate = DateTime.ParseExact(Todate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                catch
                {
                    //model.dtBookingDateTo = null;
                    model.Todate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.UnitId = SessionManager.UnitID;
                model.billList = objBusinessClass.getUnitRevenueAndTaxReport(model);

            }
            catch
            {

            }
            return PartialView("_RevenueReportGrid", model.billList);
        }

        public ActionResult printUnitReportList(string fromDate, string Todate)
        {
            UnitRevenueRepoprt model = new UnitRevenueRepoprt();
            try
            {
                try
                {
                    ViewBag.fromDate = fromDate;
                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                catch
                {
                    //model.dtBookingDateFrom = null;
                    model.fromDate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                try
                {
                    ViewBag.todate = Todate;
                    model.Todate = DateTime.ParseExact(Todate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                catch
                {
                    //model.dtBookingDateTo = null;
                    model.Todate = DateTime.ParseExact("01/01/1900", "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }

                model.UnitId = SessionManager.UnitID;
                model.billList = objBusinessClass.getUnitRevenueAndTaxReport(model);

            }
            catch
            {
            }
            return View(model);
        }


        #region to send Lawn Banquet booking mail to units

        protected void SendLawnBanquetMail(string docketNo, string type, string mailTo)
        {
            try
            {
                LawnBanquitBookingDetails model = objBusinessClass.GetLawnBanquetBookingDetails(docketNo);

                StreamReader reader;
                string subject = "";

                if (type == "cust")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/LawnBanquitBookingConfirmationUnit.html"));
                    subject = "UP Tourism Booking Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/LawnBanquitBookingConfirmationUnit.html"));
                    subject = "Online Booking Docket No. " + docketNo;
                }

                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", model.enquiryType);
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[UnitName]", model.UnitName);
                MailBody = MailBody.Replace("[ForDate]", model.ForDate);
                MailBody = MailBody.Replace("[functionName]", model.functionName);
                MailBody = MailBody.Replace("[noOfTourists]", model.noOfTourists);



                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customeremail]", model.email);
                MailBody = MailBody.Replace("[customerphoneno]", model.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", model.mobileNo);

                //MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                //MailBody = MailBody.Replace("[transactionid]", model.transactionID);
                //MailBody = MailBody.Replace("[banrefno]", model.PaymentID);
                //MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                //MailBody = MailBody.Replace("[currency]", model.currency);
                //MailBody = MailBody.Replace("[transactiondate]", model.transactionDate.ToString());


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "cust")
                    {
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);

                    }
                    else
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        //objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = "gaurav@otpl.co.in" };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);

                    }
                }
            }
            catch (Exception)
            {
            }
        }
        #endregion

        #region Sms send Banquet and lawn

        #region to send Lawn Banquet booking sms
        protected void SendLawnBanquetBookSms(string docketNo, string mobileNo, string smsFor, string pickupDate)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["BanquetLawnBookingSMS"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[BookingFor]", smsFor);
                customerSms = customerSms.Replace("[ForDate]", pickupDate);





                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);   // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);


                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        void SendLawnBanquidSMSMail(string docketNo, string BookingFor)
        {


            IEnumerable<OfficerContactDetails> off = objBusinessClass.getMobileNosEmailIdForSMSEmail_BANQ_LAWN_CRS(docketNo);
            //IEnumerable<OfficerContactDetails> IEContactDetails = objBusinessClass.get_Mobile_Nos_For_SMS(docketNo);

            string smsfor = BookingFor.ToUpper() == "BANQUET" ? "Banquet Booking" : "Lawn Booking";

            foreach (var lst in off)
            {
                if (lst.sendTo == "CUSTOMER")
                {

                    SendLawnBanquetBookSms(docketNo, lst.MobileNo, smsfor, lst.checkInDate);
                    SendLawnBanquetMail(docketNo, "cust", lst.Email);
                }
            }

        }

        #endregion

        #region Generate Bill of Lawn Banquit
        public ActionResult GetBanqLawnBill()
        {
            return View();
        }
        [HttpPost]
        public ActionResult GetBanqLawnBill(BanquitLawnBill model)
        {
            if (!string.IsNullOrEmpty(model.docketNo))
            {
                return RedirectToAction("GetBanqLawnBillDetails", "Unit", new { @id = model.docketNo });
            }
            else
            {
                ModelState.AddModelError("docketNo", "Enter Docket No.");
                return View();
            }
        }

        public ActionResult GetBanqLawnBillDetails(string id)
        {
            BanquitLawnBill bill = new BanquitLawnBill();
            bill.docketNo = id;
            LawnBanquetBooking model = new LawnBanquetBooking();

            model.docketNo = bill.docketNo;
            model.UnitId = SessionManager.UnitID;
            model = objBusinessClass.GetLawnBanquetBookingList(model).FirstOrDefault();
            if (model != null && !string.IsNullOrEmpty(model.docketNo))
            {
                if (model.IsBilled)
                {
                    TempData["ErrorMsg"] = "Docket is already Checkout";
                    return RedirectToAction("GetBanqLawnBill");

                }
                if (model.ForDate > DateTime.Now)
                {
                    TempData["ErrorMsg"] = "Can't Checkout booking date is away.";
                    return RedirectToAction("GetBanqLawnBill");
                }
                bill.Tariff = model.Tariff;
                bill.advanceAmount = model.advanceAmount;
                String _luxuryTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["LuxuryTaxBanqLawn"]);
                if (!String.IsNullOrEmpty(_luxuryTax))
                    bill.Luxurytax = Convert.ToDecimal(_luxuryTax);
                else
                    bill.Luxurytax = 0;

                String _serviceTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["ServiceTaxBanqLawn"]);
                if (!String.IsNullOrEmpty(_serviceTax))
                    bill.ServiceTax = Convert.ToDecimal(_serviceTax);
                else
                    bill.ServiceTax = Convert.ToDecimal(15);
                decimal tarif = bill.Tariff ?? 0;
                bill.LuxurytaxAmount = ((tarif * bill.Luxurytax) / 100);
                bill.ServiceTaxAmount = ((tarif * bill.ServiceTax) / 100);
                bill.TotalAmount = tarif + bill.LuxurytaxAmount + bill.ServiceTaxAmount;
                decimal advance = bill.advanceAmount ?? 0;
                bill.NetPayble = bill.TotalAmount - advance;
                bill.ForDate = model.ForDate;

                return View(bill);
            }
            else
            {
                TempData["ErrorMsg"] = "Docket not Found";
                return RedirectToAction("GetBanqLawnBill");
            }
        }

        [HttpPost]
        public ActionResult GetBanqLawnBillDetails(BanquitLawnBill bill)
        {
            try
            {
                LawnBanquetBooking model = new LawnBanquetBooking();
                model.docketNo = bill.docketNo;
                model.UnitId = SessionManager.UnitID;
                model = objBusinessClass.GetLawnBanquetBookingList(model).FirstOrDefault();
                bill.Tariff = model.Tariff;
                bill.advanceAmount = model.advanceAmount;
                String _luxuryTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["LuxuryTaxBanqLawn"]);
                if (!String.IsNullOrEmpty(_luxuryTax))
                    bill.Luxurytax = Convert.ToDecimal(_luxuryTax);
                else
                    bill.Luxurytax = 0;

                String _serviceTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["ServiceTaxBanqLawn"]);
                if (!String.IsNullOrEmpty(_serviceTax))
                    bill.ServiceTax = Convert.ToDecimal(_serviceTax);
                else
                    bill.ServiceTax = Convert.ToDecimal(15);
                decimal tarif = bill.Tariff ?? 0;
                tarif = tarif + bill.OtherAmount;
                bill.DiscountAmount = (tarif * bill.DiscountPer) / 100;
                tarif = tarif - bill.DiscountAmount;
                bill.LuxurytaxAmount = ((tarif * bill.Luxurytax) / 100);
                bill.ServiceTaxAmount = ((tarif * bill.ServiceTax) / 100);
                bill.TotalAmount = tarif + bill.LuxurytaxAmount + bill.ServiceTaxAmount;
                decimal advance = bill.advanceAmount ?? 0;
                bill.NetPayble = bill.TotalAmount - advance;
                bill.ForDate = model.ForDate;
                var a = objBusinessClass.InsertBanqUitLawnBillDEtails(bill);
                if (a != null && !string.IsNullOrEmpty(a.billNo))
                {
                    SessionManager.BillNo = a.billNo;
                    SessionManager.DocketNo = a.docketNo;
                    return RedirectToAction("ConformationBanqLawnCheckout");
                }
                else
                {
                    ViewBag.msg = "Bill details could not insert please try again l";
                }
            }
            catch (Exception ex)
            {
                ViewBag.msg = ex.Message;
            }

            return View(bill);
        }

        public ActionResult ConformationBanqLawnCheckout()
        {
            BanquitLawnBill model = new BanquitLawnBill();
            if (model.billNo == "" || model.docketNo == "")
            {
                TempData["ErrorMsg"] = "Required data could not fetch from server please try again later";
                return RedirectToAction("GetBanqLawnBill");
            }
            model.docketNo = SessionManager.DocketNo;
            model.billNo = SessionManager.BillNo;
            return View(model);
        }

        public ActionResult PrintBanquetLawnBill(string id)
        {
            BanquitLawnBill model = new BanquitLawnBill();

            model = objBusinessClass.GetLawnBanquetBillbyDocket(id);
            if (model.ForDate < new DateTime(2017, 7, 1))
            {
                return View(model);
            }
            else
            {
                return RedirectToAction("PrintBanquetLawnBillGST", new { @id = id });
            }
        }

        public ActionResult PrintBanquetLawnBillGST(string id)
        {
            BanquitLawnBill model = new BanquitLawnBill();

            model = objBusinessClass.GetLawnBanquetBillbyDocket(id);

            return View(model);


        }

        #endregion


        #region To send unit room pre pone postpone mail
        protected void SendUnitPreponePostponeMail(string docketNo, string type, string mailTo)
        {
            try
            {
                UnitTransactionDetail model = objBusinessClass.GetTransactionDetailsUser(docketNo);
                StreamReader reader;
                string subject = "";

                if (type == "CUSTOMER")
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BookingPreponePostponeConfirmation_Customer.html"));
                    subject = "UP Tourism Booking Modification Confirmation";
                }
                else
                {
                    reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Counter/BookingPreponePostponeConfirmation_Other.html"));
                    subject = "Room Booking Docket No. " + docketNo + " Modified by Unit.";
                }
                string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[docketno]", model.docketNo);
                MailBody = MailBody.Replace("[hotelname]", model.unitName);
                MailBody = MailBody.Replace("[hoteladdress]", model.unitAddress);
                MailBody = MailBody.Replace("[hotelphone]", model.unitMobile);
                MailBody = MailBody.Replace("[roomtype]", model.roomType);
                MailBody = MailBody.Replace("[noofrooms]", model.noOfRooms.ToString());
                MailBody = MailBody.Replace("[extrabed]", model.extraBed.ToString());

                MailBody = MailBody.Replace("[checkindate]", model.checkinDate);
                MailBody = MailBody.Replace("[checkoutdate]", model.checkoutDate);
                MailBody = MailBody.Replace("[customername]", model.name);
                MailBody = MailBody.Replace("[customermobileno]", model.customerMobile);
                MailBody = MailBody.Replace("[customeraddress]", model.customerAddress);
                //MailBody = MailBody.Replace("[transactionstatus]", model.transactionStatus);
                if (type != "CUSTOMER")
                {
                    MailBody = MailBody.Replace("[bookedby]", model.bookingBy);
                }
                // MailBody = MailBody.Replace("[transactionid]", model.transactionID); 
                MailBody = MailBody.Replace("[transactionamount]", model.transactionAmount);
                //MailBody = MailBody.Replace("[currency]", model.currency);
                MailBody = MailBody.Replace("[transactiondate]", model.transactionDate);


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    //MailService.Service1 objService = new MailService.Service1();
                    if (type == "CUSTOMER")
                    {
                        //MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "", mailbody = MailBody, subject = subject, toemail = mailTo };
                        //objService.sendMail(objMail);
                        SendMail.SendMailNew(mailTo, subject, MailBody);
                    }
                    //else
                    //{
                    //    MailService.EmailData objMail = new MailService.EmailData() { bccemail = "", ccemail = "anuj@otpl.co.in", mailbody = MailBody, subject = subject, toemail = mailTo };
                    //    objService.sendMail(objMail);
                    //}
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        public ActionResult FillSaleReport()
        {

            return View();
        }

        public ActionResult EditSale(string Date)
        {
            TempData["Date"] = DateTime.ParseExact(Date, "dd/MM/yyyy", null);
            return RedirectToAction("UnitDalySaleReport");
        }

        [HttpPost]
        public ActionResult FillSaleReport(FillSaleReport model)
        {
            if (ModelState.IsValid)
            {
                TempData["Date"] = model.saleDate;
                return RedirectToAction("UnitDalySaleReport", "Unit");
            }
            return View();
        }

        public ActionResult UnitDalySaleReport()
        {
            if (string.IsNullOrEmpty(Convert.ToString(TempData["Date"])))
            {
                return RedirectToAction("FillSaleReport");
            }
            else
            {
                DalySaleReportModel model1 = new DalySaleReportModel();
                try
                {
                    model1.SaleDate = (DateTime)TempData["Date"];

                }
                catch (Exception ex)
                {
                    TempData["msg"] = ex.Message;
                    return RedirectToAction("FillSaleReport");
                }
                DalySaleReportModel model = objBusinessClass.GetDalySaleReportforFillForm(SessionManager.UnitID, model1.SaleDate);
                model.SaleDate = model1.SaleDate;
                model.ViewSaleDate = model1.SaleDate.ToString("dd/MM/yyyy");

                model.TotalRevenuePreviousDate = model1.SaleDate.AddYears(-1).ToString("dd/MM/yyyy");

                return View(model);
            }
        }




        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UnitDalySaleReport(DalySaleReportModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    DalySaleReportModel msterData = objBusinessClass.GetDalySaleReportforFillForm(SessionManager.UnitID, model.SaleDate);
                    ModelState.Clear();
                    model.NameOfStation = msterData.NameOfStation;
                    model.NameofUnit = msterData.NameofUnit;
                    model.UnitId = msterData.UnitId;
                    model.TotalRooms = msterData.TotalRooms == 0 ? model.TotalRooms : msterData.TotalRooms;
                    model.TotalPerRoom = (model.OccupidRooms * 100) / model.TotalRooms;
                    model.Total = model.AccomodationCharges + model.Canteen + model.Bar + model.Miscellaneous + model.BanquitHallLawn;
                    model.Insertedby = SessionManager.UserID;
                    bool valid = true;
                    //if (model.TotalRooms < model.OccupidRooms)
                    //{
                    //    valid = false;
                    //    ModelState.AddModelError("OccupidRooms", "Occupied Rooms must less than Total Rooms !");
                    //    ViewBag.Show = "Occupied Rooms must less than Total Rooms !";
                    //}
                    if (valid && ModelState.IsValid)
                    {
                        int a = objBusinessClass.InsertUpdateDalySaleReport(model);
                        if (a > 0)
                        {
                            TempData["SD"] = model.SaleDate;
                            return RedirectToAction("DalyReportFillConfirmation");
                        }
                        else
                        {
                            ViewBag.Show = "Fail to insert Daly Report please try again !";
                        }
                    }

                }
                catch (Exception ex)
                {
                    ViewBag.Show = ex.Message;
                }
            }

            return View(model);

        }

        public ActionResult DalyReportFillConfirmation()
        {
            FillSaleReport model = new FillSaleReport();
            try
            {
                model.saleDate = (DateTime)TempData["SD"];
            }
            catch
            {

            }
            return View(model);
        }

        public ActionResult ViewDailySaleReport()
        {
            return View();
        }

        public ActionResult getDailySaleReportGrid(string fromdate, string Todate)
        {
            FillSaleReport model = new FillSaleReport();
            try
            {
                model.fromDate = DateTime.ParseExact(fromdate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                //model.dtBookingDateFrom = null;
                model.fromDate = new DateTime(2016, 11, 1);
            }
            try
            {
                model.toDate = DateTime.ParseExact(Todate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
            }
            catch
            {
                //model.dtBookingDateTo = null;
                model.toDate = DateTime.Now;
            }

            model.DalySalelist = objBusinessClass.GetDalySaleReportforView(SessionManager.UnitID, model.fromDate, model.toDate, 1);
            return PartialView("_DalySaleReportGrid", model.DalySalelist);
        }



        #region Check Out Process New
        [HttpGet]
        public ActionResult CheckOutNew(string docketNo = null)
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();

                if (!string.IsNullOrEmpty(docketNo))
                {
                    model.docketNo = docketNo.Trim();
                }
                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        [HttpGet]
        public ActionResult CheckOutDetailNew(string docketNo)
        {
            CustomerRegistration obj_BookingDetail = new CustomerRegistration();
            string _msg = "";
            try
            {
                Int64 _unitId = SessionManager.UnitID;

                obj_BookingDetail = objBusinessClass.GetCustomerBookingDetails(docketNo.Trim(), _unitId);
                if (obj_BookingDetail.isCheckIn == true)
                {
                    IList<CustomerRegistration> lstCheckinDetails = objBusinessClass.GetCustomerBookingList(docketNo.Trim(), _unitId);
                    obj_BookingDetail.checkInDateShow = lstCheckinDetails.Min(c => c.checkInDate);
                    obj_BookingDetail.checkOutDateShow = lstCheckinDetails.Max(c => c.checkOutDateShow);
                    obj_BookingDetail.checkOutDateActual = DateTime.Now.Date;
                    obj_BookingDetail.checkOutTime = DateTime.Now;

                    List<BookedRoomDetails> objRoom = objBusinessClass.GetBookedRoomDetailsOnCheckOut(docketNo.Trim(), _unitId);

                    if (obj_BookingDetail != null)
                    {
                        // obj_BookingDetail.lstBookedRoom = objRoom;

                        obj_BookingDetail.userID = _unitId;
                        return PartialView("_CheckOutDetailsNew", obj_BookingDetail);
                    }
                    else
                    {
                        _msg = "Details Not Available!!";
                        return Content("NA");
                    }
                }
                else
                {
                    _msg = "Not Checked In!!";
                    return Content("NC");
                }
            }
            catch
            {
                _msg = "Details Not Found!!";
                return Content("C");
            }
            ViewBag.Show = _msg;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CheckOutNew(CustomerRegistration model)
        {
            CustomerRegistration obj_BookingDetail = new CustomerRegistration();
            // UnitAmountDetails obj_unitPaymentDetails = new UnitAmountDetails();
            string _msg = "";
            try
            {
                Int64 _unitId = SessionManager.UnitID;
                //DateTime dtCheckin = Convert.ToDateTime(Session["checkInDate"].ToString());
                //DateTime dtCheckout = Convert.ToDateTime(Session["checkOutDate"].ToString());
                //int roomId = Convert.ToInt32(Session["roomID"].ToString());
                //int single = Convert.ToInt32(Session["singleRoom"].ToString());
                //int doubles = Convert.ToInt32(Session["doubleRoom"].ToString());
                //int extraBed = Convert.ToInt32(Session["extraBed"].ToString());
                model.unitID = _unitId;
                model.userIP = this.Request.UserHostAddress;
                #region save CheckOut Details
                int i = objBusinessClass.SaveCheckOutDetails(model);
                #endregion
                if (i > 0)
                {
                    int paybleAmt = 0;
                    double baseSlave1 = 0, baseSlave2 = 0, baseSlave3 = 0, ExtrabaseSlave1 = 0, ExtrabaseSlave2 = 0, ExtrabaseSlave3 = 0, GSTR3Tax, GSTR2Tax, GSTR1Tax, GSTTaxAmount, luxuryTax, serviceTax, luxuryTaxAmt, serviceTaxAmt, totalAmount = 0, totalTaxAmt, discount, discountAmt, amtAfterDiscount, advanceAmount, privilegeDist, privilegeAmt = 0, totalAmountExtra = 0, totalAmountForTax = 0, discountAmtForTax = 0, netAmt = 0, totalAmountForTaxLuxury = 0, totalAmountForTaxService = 0, totalAmountForTaxLuxury_Extra = 0, discountAmtForTaxService = 0, discountAmtForTaxLuxury = 0, discountAmtForTaxLuxury_Extra = 0;
                    GSTTaxAmount = 0;
                    string GSTDisplayTax = "";
                    obj_BookingDetail = objBusinessClass.GetCustomerBookingDetails(model.docketNo, _unitId);
                    //  obj_unitPaymentDetails = objBusinessClass.GetUnitPaymentInfoForTaxSlabsInsert(model.docketNo, _unitId);
                    if (obj_BookingDetail.isCheckIn == true)
                    {
                        IList<CustomerRegistration> lstCheckinDetails = objBusinessClass.GetCustomerBookingList(model.docketNo, _unitId);
                        obj_BookingDetail.checkInDateShow = lstCheckinDetails.Min(c => c.checkInDate);
                        obj_BookingDetail.checkOutDateShow = lstCheckinDetails.Max(c => c.checkOutDateShow);

                        obj_BookingDetail.checkOutDateActual = model.checkOutDateActual;
                        obj_BookingDetail.checkOutTime = model.checkOutTime;


                        List<BookedRoomDetails> objRoom = objBusinessClass.GetBookedRoomDetailsOnCheckOut(model.docketNo, _unitId);
                        List<BillDetails> objBil = null;
                        if (obj_BookingDetail != null && objRoom != null && objRoom.Count > 0)
                        {
                            foreach (var item in objRoom)
                            {
                                if (obj_BookingDetail.lstBill != null && obj_BookingDetail.lstBill.Count > 0)
                                {
                                    objBil = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                                    obj_BookingDetail.lstBill.AddRange(objBil);
                                }
                                else
                                {
                                    obj_BookingDetail.lstBill = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                                }
                            }
                        }


                        if (obj_BookingDetail != null && obj_BookingDetail.lstBill != null && obj_BookingDetail.lstBill.Count > 0)
                        {
                            obj_BookingDetail.lstBookedRoom = objRoom;
                            obj_BookingDetail.isPrivilegeAvail = string.IsNullOrEmpty(obj_BookingDetail.privilegeCardNo) ? false : true;

                            //GST

                            String _GSTR1Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR1"]);
                            if (!String.IsNullOrEmpty(_GSTR1Tax))
                                GSTR1Tax = Convert.ToDouble(_GSTR1Tax);
                            else
                                GSTR1Tax = 12.00;

                            String _GSTR2Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR2"]);
                            if (!String.IsNullOrEmpty(_GSTR2Tax))
                                GSTR2Tax = Convert.ToDouble(_GSTR2Tax);
                            else
                                GSTR2Tax = 18.00;

                            String _GSTR3Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR3"]);
                            if (!String.IsNullOrEmpty(_GSTR3Tax))
                                GSTR3Tax = Convert.ToDouble(_GSTR3Tax);
                            else
                                GSTR3Tax = 28.00;


                            privilegeDist = obj_BookingDetail.discountPercent;


                            String _billXML = "<bill>";
                            foreach (BillDetails item in obj_BookingDetail.lstBill)
                            {
                                _billXML += "<billDetails>";
                                _billXML += "<billDetail>" + item.BillDescription + "</billDetail>";
                                _billXML += "<amount>" + item.Amount + "</amount>";
                                _billXML += "<requestId>" + item.requestId + "</requestId>";
                                _billXML += "</billDetails>";
                                totalAmount += Convert.ToDouble(item.Amount);
                                totalAmountExtra += Convert.ToDouble(item.ExtraBedAmount);

                                // FOR GST

                                if (item.GstApplyed == 1)
                                {
                                    if (item.basetariff < 1000)
                                    {
                                        GSTTaxAmount += 0;

                                    }
                                    //else if (item.basetariff >= 1000 && item.basetariff <= 2499)
                                    //{
                                    //    if (!GSTDisplayTax.Contains(GSTR1Tax.ToString()))
                                    //    {
                                    //        GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, ";
                                    //    }

                                    //    baseSlave1 += Convert.ToDouble(item.Amountbasetariff);
                                    //    ExtrabaseSlave1 += Convert.ToDouble(item.ExtraBedAmount);
                                    //}

                                    //else if (item.basetariff >= 2500 && item.basetariff <= 7499)
                                    //{
                                    //    if (!GSTDisplayTax.Contains(GSTR2Tax.ToString()))
                                    //    {
                                    //        GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, ";
                                    //    }

                                    //    baseSlave2 += Convert.ToDouble(item.Amountbasetariff);
                                    //    ExtrabaseSlave2 += Convert.ToDouble(item.ExtraBedAmount);
                                    //}
                                    //else
                                    //{
                                    //    if (!GSTDisplayTax.Contains(GSTR3Tax.ToString()))
                                    //    {
                                    //        GSTDisplayTax = GSTDisplayTax + GSTR3Tax.ToString() + "%, ";
                                    //    }

                                    //    baseSlave3 += Convert.ToDouble(item.Amountbasetariff);
                                    //    ExtrabaseSlave3 += Convert.ToDouble(item.ExtraBedAmount);
                                    //}
                                    else if (item.basetariff >= 1000 && item.basetariff <= 7500)
                                    {
                                        if (!GSTDisplayTax.Contains(GSTR1Tax.ToString()))
                                        {
                                            GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, ";
                                        }

                                        baseSlave1 += Convert.ToDouble(item.Amountbasetariff);
                                        ExtrabaseSlave1 += Convert.ToDouble(item.ExtraBedAmount);
                                    }

                                    else if (item.basetariff > 7500)
                                    {
                                        if (!GSTDisplayTax.Contains(GSTR2Tax.ToString()))
                                        {
                                            GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, ";
                                        }

                                        baseSlave2 += Convert.ToDouble(item.Amountbasetariff);
                                        ExtrabaseSlave2 += Convert.ToDouble(item.ExtraBedAmount);
                                    }
                                }
                                else
                                {
                                    if (item.basetariff < 1000)
                                    {
                                        GSTTaxAmount += 0;
                                    }
                                    else if (item.basetariff >= 1000 && item.basetariff <= 2499)
                                    {
                                        if (!GSTDisplayTax.Contains(GSTR1Tax.ToString()))
                                        {
                                            GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, ";
                                        }
                                        baseSlave1 += Convert.ToDouble(item.Amountbasetariff);
                                        ExtrabaseSlave1 += Convert.ToDouble(item.ExtraBedAmount);
                                    }

                                    else if (item.basetariff >= 2500 && item.basetariff <= 7499)
                                    {
                                        if (!GSTDisplayTax.Contains(GSTR2Tax.ToString()))
                                        {
                                            GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, ";
                                        }
                                        baseSlave2 += Convert.ToDouble(item.Amountbasetariff);
                                        ExtrabaseSlave2 += Convert.ToDouble(item.ExtraBedAmount);
                                    }
                                    else
                                    {
                                        if (!GSTDisplayTax.Contains(GSTR3Tax.ToString()))
                                        {
                                            GSTDisplayTax = GSTDisplayTax + GSTR3Tax.ToString() + "%, ";
                                        }
                                        baseSlave3 += Convert.ToDouble(item.Amountbasetariff);
                                        ExtrabaseSlave3 += Convert.ToDouble(item.ExtraBedAmount);
                                    }
                                }
                            }
                            _billXML += "</bill>";

                            obj_BookingDetail.totalAmount = totalAmount;
                            obj_BookingDetail.totalAmountActual = totalAmount;
                            obj_BookingDetail.totalAmountExtra = totalAmountExtra;


                            discount = obj_BookingDetail.discount;

                            double discountAmts1 = 0, discountAmts2 = 0, discountAmts3 = 0;

                            discountAmts1 = (baseSlave1 * discount) / 100;
                            discountAmts2 = (baseSlave2 * discount) / 100;
                            discountAmts3 = (baseSlave3 * discount) / 100;

                            discountAmt = discountAmts1 + discountAmts2 + discountAmts3;

                            baseSlave1 = baseSlave1 - discountAmts1;
                            baseSlave2 = baseSlave2 - discountAmts2;
                            baseSlave3 = baseSlave3 - discountAmts3;

                            amtAfterDiscount = (totalAmount - discountAmt) + totalAmountExtra;


                            netAmt = amtAfterDiscount;

                            if (obj_BookingDetail.isPrivilegeAvail == true)
                            {
                                //privilegeAmt = (totalAmount * privilegeDist) / 100;

                                double pdiscountAmts1 = 0, pdiscountAmts2 = 0, pdiscountAmts3 = 0;

                                pdiscountAmts1 = (baseSlave1 * privilegeDist) / 100;
                                pdiscountAmts2 = (baseSlave2 * privilegeDist) / 100;
                                pdiscountAmts3 = (baseSlave3 * privilegeDist) / 100;

                                privilegeAmt = pdiscountAmts1 + pdiscountAmts2 + pdiscountAmts3;

                                baseSlave1 = baseSlave1 - pdiscountAmts1;
                                baseSlave2 = baseSlave2 - pdiscountAmts2;
                                baseSlave3 = baseSlave3 - pdiscountAmts3;

                                netAmt = (obj_BookingDetail.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;
                                amtAfterDiscount = (obj_BookingDetail.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;

                            }

                            GSTTaxAmount += ((baseSlave1 + ExtrabaseSlave1) * GSTR1Tax) / 100;
                            GSTTaxAmount += ((baseSlave2 + ExtrabaseSlave2) * GSTR2Tax) / 100;
                            GSTTaxAmount += ((baseSlave3 + ExtrabaseSlave3) * GSTR3Tax) / 100;

                            obj_BookingDetail.baseSlave1 = baseSlave1;
                            obj_BookingDetail.baseSlave2 = baseSlave2;
                            obj_BookingDetail.baseSlave3 = baseSlave3;

                            obj_BookingDetail.GSTR1per = GSTR1Tax;
                            obj_BookingDetail.GSTR2per = GSTR2Tax;
                            obj_BookingDetail.GSTR3per = GSTR3Tax;

                            obj_BookingDetail.ExtrabaseSlave1 = ExtrabaseSlave1;
                            obj_BookingDetail.ExtrabaseSlave2 = ExtrabaseSlave2;
                            obj_BookingDetail.ExtrabaseSlave3 = ExtrabaseSlave3;

                            serviceTaxAmt = GSTTaxAmount;
                            totalTaxAmt = serviceTaxAmt;
                            netAmt = netAmt + totalTaxAmt;
                            advanceAmount = Convert.ToDouble(obj_BookingDetail.advanceAmount);
                            netAmt = netAmt - advanceAmount;
                            netAmt += (obj_BookingDetail.fAndBAmt + obj_BookingDetail.laundryAmt + obj_BookingDetail.roomServiceAmt + obj_BookingDetail.otherAmt);

                            obj_BookingDetail.serviceTaxAmt = serviceTaxAmt;
                            obj_BookingDetail.totalTaxAmt = totalTaxAmt;
                            obj_BookingDetail.billDetailXML = _billXML;


                            //paybleAmt = (totalAmount + totalTaxAmt) - (discountAmt + advanceAmount);
                            paybleAmt = Convert.ToInt32(Math.Round(netAmt, 2));
                            obj_BookingDetail.discount = discount;
                            obj_BookingDetail.discountAmount = discountAmt;
                            obj_BookingDetail.amountAfterDis = amtAfterDiscount;
                            obj_BookingDetail.netPayable = paybleAmt;
                            obj_BookingDetail.userID = _unitId;
                            obj_BookingDetail.GstApplyed = GSTDisplayTax;
                            obj_BookingDetail.privilegeAmt = privilegeAmt;
                            obj_BookingDetail.privilegeDist = privilegeDist;

                            ViewBag.spclDiscount = objBusinessClass.GetSpecialDiscount().Select(e => new SelectListItem() { Text = e.SpclDiscountName, Value = e.spclDiscountType.ToString() });
                            //return PartialView("_BookingDetails", obj_BookingDetail);
                            obj_BookingDetail.IsSaved = "Y";
                        }
                    }
                }
            }
            catch
            {
                ViewBag.Show = "There is some error in the system. Please try after sometime!";
            }
            //return Content("0");
            return View(obj_BookingDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RoomBookingDetailNew(CustomerRegistration model, FormCollection frmChkIn)
        {
            // List<UnitAmountDetailsSlabWise> obj_unitPaymentDetailsSlabWise = new List<UnitAmountDetailsSlabWise>();
            UnitAmountDetailsSlabWise obj_unitPaymentDetailsSlabWise = new UnitAmountDetailsSlabWise();

            string _msg = "";
            bool _isValid = true;
            try
            {
                //ModelState["checkInTime"].Errors.Clear();
                //if (ModelState.IsValid)
                //{
                string[] checkedRooms = string.IsNullOrEmpty(Convert.ToString(frmChkIn["CheckedRooms"])) ? null : Convert.ToString(frmChkIn["CheckedRooms"]).Split(',');
                _isValid = (checkedRooms != null && checkedRooms.Length > 0) ? true : false;
                if (_isValid == true)
                {
                    String _checkedRooms = "<Room>";
                    foreach (var item in checkedRooms)
                    {
                        _checkedRooms += "<RoomDetails>";
                        _checkedRooms += "<RequestId>" + Convert.ToInt64(item) + "</RequestId>";
                        _checkedRooms += "</RoomDetails>";
                    }
                    _checkedRooms += "</Room>";
                    model.requestXML = _checkedRooms;
                    Int64 _unitId = SessionManager.UnitID;
                    double baseSlave1 = 0, baseSlave2 = 0, baseSlave3 = 0, ExtrabaseSlave1 = 0, ExtrabaseSlave2 = 0, ExtrabaseSlave3 = 0, GSTR3Tax, GSTR2Tax, GSTR1Tax, GSTTaxAmount = 0, luxuryTax, serviceTax, luxuryTaxAmt, serviceTaxAmt, totalAmount = 0, totalTaxAmt, discount, discountAmt, amtAfterDiscount, paybleAmt, advanceAmount, privilegeDist, privilegeAmt = 0, totalOtherAmt = 0, netAmt = 0, totalAmountExtra = 0, totalAmountForTax = 0, discountAmtForTax = 0
                        , totalAmountForTaxLuxury = 0, totalAmountForTaxService = 0, totalAmountForTaxLuxury_Extra = 0, discountAmtForTaxService = 0, discountAmtForTaxLuxury = 0, discountAmtForTaxLuxury_Extra = 0;
                    string GSTDisplayTax = "";
                    List<BookedRoomDetails> objRoom = objBusinessClass.GetBookedRoomDetailsOnCheckOut(model.docketNo, _unitId);
                    List<BillDetails> objBil = null;
                    if (model != null && objRoom != null && objRoom.Count > 0)
                    {
                        foreach (var item in objRoom)
                        {
                            if (model.lstBill != null && model.lstBill.Count > 0)
                            {
                                objBil = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                                model.lstBill.AddRange(objBil);
                            }
                            else
                            {
                                model.lstBill = objBusinessClass.GetBillDetails(item.requestID, _unitId);
                            }
                        }
                    }
                    model.unitID = _unitId;

                    model.isPrivilegeAvail = string.IsNullOrEmpty(model.privilegeCardNo) ? false : true;

                    String _luxuryTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["LuxuryTax"]);
                    if (!String.IsNullOrEmpty(_luxuryTax))
                        luxuryTax = Convert.ToDouble(_luxuryTax);
                    else
                        luxuryTax = 0.0;

                    String _serviceTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["ServiceTax"]);
                    if (!String.IsNullOrEmpty(_serviceTax))
                        serviceTax = Convert.ToDouble(_serviceTax);
                    else
                        serviceTax = 0.0;


                    String _GSTR1Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR1"]);
                    if (!String.IsNullOrEmpty(_GSTR1Tax))
                        GSTR1Tax = Convert.ToDouble(_GSTR1Tax);
                    else
                        GSTR1Tax = 12.00;

                    String _GSTR2Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR2"]);
                    if (!String.IsNullOrEmpty(_GSTR2Tax))
                        GSTR2Tax = Convert.ToDouble(_GSTR2Tax);
                    else
                        GSTR2Tax = 18.00;

                    String _GSTR3Tax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["GSTR3"]);
                    if (!String.IsNullOrEmpty(_GSTR3Tax))
                        GSTR3Tax = Convert.ToDouble(_GSTR3Tax);
                    else
                        GSTR3Tax = 28.00;

                    //String _privilegeDist = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["PrivilegeDiscount"]);
                    //if (!String.IsNullOrEmpty(_privilegeDist))
                    //    privilegeDist = Convert.ToDouble(_privilegeDist);
                    //else
                    //    privilegeDist = 15;
                    privilegeDist = model.discountPercent;

                    String _UnitForTax = Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["UnitForTax"]);
                    bool _isExtraTax = false;

                    model.luxuryTax = luxuryTax;
                    model.luxuryTaxDisplay = luxuryTax.ToString() + " %";
                    model.serviceTax = serviceTax;
                    model.fAndBAmt = model.fAndBAmt > 0 ? model.fAndBAmt : 0;
                    model.laundryAmt = model.laundryAmt > 0 ? model.laundryAmt : 0;
                    model.roomServiceAmt = model.roomServiceAmt > 0 ? model.roomServiceAmt : 0;
                    model.otherAmt = model.otherAmt > 0 ? model.otherAmt : 0;
                    List<UnitAmountDetailsSlabWise> obj_unitPaymentDetailsSlabWise1 = new List<UnitAmountDetailsSlabWise>();
                    String _billXML = "<bill>";
                    foreach (BillDetails item in model.lstBill)
                    {
                        UnitAmountDetailsSlabWise slablist = new UnitAmountDetailsSlabWise();

                        _billXML += "<billDetails>";
                        _billXML += "<BillDate>" + item.RentDate + "</BillDate>";
                        _billXML += "<billDetail>" + item.BillDescription + "</billDetail>";
                        _billXML += "<amount>" + item.Amount + "</amount>";
                        _billXML += "<roomNo>" + item.RoomNo + "</roomNo>";
                        _billXML += "<requestId>" + item.requestId + "</requestId>";
                        _billXML += "<ExtraBedAmount>" + item.ExtraBedAmount + "</ExtraBedAmount>";
                        _billXML += "</billDetails>";
                        totalAmount += Convert.ToDouble(item.Amount);
                        totalAmountExtra += Convert.ToDouble(item.ExtraBedAmount);



                        // FOR GST
                        slablist.DocketNumber = model.docketNo;

                        if (item.basetariff < 1000)
                        {
                            GSTTaxAmount += 0;
                            slablist.taxAmountOnFree = Convert.ToDecimal(item.Amount);
                            slablist.taxrateonFree = 0;
                            slablist.TaxFreeAmount = 0;

                        }
                        //else if (item.basetariff >= 1000 && item.basetariff <= 2499)
                        //{
                        //    if (!GSTDisplayTax.Contains(GSTR1Tax.ToString()))
                        //    {
                        //        GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, "; /*12*/
                        //    }

                        //    baseSlave1 += Convert.ToDouble(item.Amountbasetariff);
                        //    ExtrabaseSlave1 += Convert.ToDouble(item.ExtraBedAmount);

                        //    slablist.SlabOneAmount = Convert.ToDecimal(item.Amount);
                        //    slablist.SlabOneTaxAmount = ((Convert.ToDecimal(item.Amount) + Convert.ToDecimal(item.ExtraBedAmount)) * Convert.ToDecimal(GSTR1Tax)) / 100;
                        //    slablist.taxRateSlabOne = Convert.ToDecimal(GSTR1Tax);

                        //}

                        //else if (item.basetariff >= 2500 && item.basetariff <= 7499)
                        //{
                        //    if (!GSTDisplayTax.Contains(GSTR2Tax.ToString()))
                        //    {
                        //        GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, "; /*18*/
                        //    }

                        //    baseSlave2 += Convert.ToDouble(item.Amountbasetariff);
                        //    ExtrabaseSlave2 += Convert.ToDouble(item.ExtraBedAmount);

                        //    slablist.SlabTwoAmount = Convert.ToDecimal(item.Amount);
                        //    slablist.SlabTwoTaxAmount = ((Convert.ToDecimal(item.Amount) + Convert.ToDecimal(item.ExtraBedAmount)) * Convert.ToDecimal(GSTR2Tax)) / 100;
                        //    slablist.taxRateSlabTwo = Convert.ToDecimal(GSTR2Tax);
                        //}
                        //else
                        //{
                        //    if (!GSTDisplayTax.Contains(GSTR3Tax.ToString()))
                        //    {
                        //        GSTDisplayTax = GSTDisplayTax + GSTR3Tax.ToString() + "%, "; /*28*/
                        //    }

                        //    baseSlave3 += Convert.ToDouble(item.Amountbasetariff);
                        //    ExtrabaseSlave3 += Convert.ToDouble(item.ExtraBedAmount);


                        //    slablist.SlabThreeAmount = Convert.ToDecimal(item.Amount);
                        //    slablist.SlabThreeTaxAmount = ((Convert.ToDecimal(item.Amount) + Convert.ToDecimal(item.ExtraBedAmount)) * Convert.ToDecimal(GSTR3Tax)) / 100;
                        //    slablist.taxRateSlabThree = Convert.ToDecimal(GSTR3Tax);
                        //}
                        else if (item.basetariff >= 1000 && item.basetariff <= 7500)
                        {
                            if (!GSTDisplayTax.Contains(GSTR1Tax.ToString()))
                            {
                                GSTDisplayTax = GSTDisplayTax + GSTR1Tax.ToString() + "%, "; /*12*/
                            }

                            baseSlave1 += Convert.ToDouble(item.Amountbasetariff);
                            ExtrabaseSlave1 += Convert.ToDouble(item.ExtraBedAmount);

                            slablist.SlabOneAmount = Convert.ToDecimal(item.Amount);
                            slablist.SlabOneTaxAmount = ((Convert.ToDecimal(item.Amount) + Convert.ToDecimal(item.ExtraBedAmount)) * Convert.ToDecimal(GSTR1Tax)) / 100;
                            slablist.taxRateSlabOne = Convert.ToDecimal(GSTR1Tax);

                        }

                        else if (item.basetariff > 7500)
                        {
                            if (!GSTDisplayTax.Contains(GSTR2Tax.ToString()))
                            {
                                GSTDisplayTax = GSTDisplayTax + GSTR2Tax.ToString() + "%, "; /*18*/
                            }

                            baseSlave2 += Convert.ToDouble(item.Amountbasetariff);
                            ExtrabaseSlave2 += Convert.ToDouble(item.ExtraBedAmount);

                            slablist.SlabTwoAmount = Convert.ToDecimal(item.Amount);
                            slablist.SlabTwoTaxAmount = ((Convert.ToDecimal(item.Amount) + Convert.ToDecimal(item.ExtraBedAmount)) * Convert.ToDecimal(GSTR2Tax)) / 100;
                            slablist.taxRateSlabTwo = Convert.ToDecimal(GSTR2Tax);
                        }
                        obj_unitPaymentDetailsSlabWise1.Add(slablist);





                    }
                    _billXML += "</bill>";

                    model.totalAmountExtra = totalAmountExtra;
                    model.totalAmount = totalAmount;
                    //model.totalAmountForTax = totalAmountForTax;
                    model.discountAmtForTaxLuxury_Extra = discountAmtForTaxLuxury_Extra;
                    model.discountAmtForTaxLuxury = discountAmtForTaxLuxury;
                    model.discountAmtForTaxService = discountAmtForTaxService;
                    model.totalAmountForTaxLuxury = totalAmountForTaxLuxury;
                    model.totalAmountForTaxService = totalAmountForTaxService;
                    model.totalAmountForTaxLuxury_Extra = totalAmountForTaxLuxury_Extra;
                    if (model.spclDiscount > 80)
                    {
                        model.spclDiscount = 80;
                    }
                    discount = model.discount + model.spclDiscount;

                    double discountAmts1 = 0, discountAmts2 = 0, discountAmts3 = 0;

                    discountAmts1 = (baseSlave1 * discount) / 100;
                    discountAmts2 = (baseSlave2 * discount) / 100;
                    discountAmts3 = (baseSlave3 * discount) / 100;

                    discountAmt = (totalAmount * discount) / 100;

                    baseSlave1 = baseSlave1 - discountAmts1;
                    baseSlave2 = baseSlave2 - discountAmts2;
                    baseSlave3 = baseSlave3 - discountAmts3;

                    amtAfterDiscount = (totalAmount - discountAmt) + totalAmountExtra;
                    //totalAmountForTax = (totalAmountForTax - discountAmtForTax);


                    netAmt = amtAfterDiscount;
                    if (model.isPrivilegeAvail == true)
                    {
                        double pdiscountAmts1 = 0, pdiscountAmts2 = 0, pdiscountAmts3 = 0;

                        pdiscountAmts1 = (baseSlave1 * privilegeDist) / 100;
                        pdiscountAmts2 = (baseSlave2 * privilegeDist) / 100;
                        pdiscountAmts3 = (baseSlave3 * privilegeDist) / 100;

                        //privilegeAmt = pdiscountAmts1 + pdiscountAmts2 + pdiscountAmts3;
                        privilegeAmt = (amtAfterDiscount * discount) / 100;

                        baseSlave1 = baseSlave1 - pdiscountAmts1;
                        baseSlave2 = baseSlave2 - pdiscountAmts2;
                        baseSlave3 = baseSlave3 - pdiscountAmts3;

                        netAmt = (model.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;
                        amtAfterDiscount = (model.isPrivilegeVerified == true) ? (amtAfterDiscount - privilegeAmt) : netAmt;
                    }
                    GSTTaxAmount += ((baseSlave1 + ExtrabaseSlave1) * GSTR1Tax) / 100;
                    GSTTaxAmount += ((baseSlave2 + ExtrabaseSlave2) * GSTR2Tax) / 100;
                    GSTTaxAmount += ((baseSlave3 + ExtrabaseSlave3) * GSTR3Tax) / 100;
                    serviceTaxAmt = GSTTaxAmount;

                    totalTaxAmt = serviceTaxAmt;
                    netAmt = netAmt + totalTaxAmt;
                    advanceAmount = Convert.ToDouble(model.advanceAmount);
                    netAmt = netAmt - advanceAmount;
                    netAmt += (model.fAndBAmt + model.laundryAmt + model.roomServiceAmt + model.otherAmt);
                    model.luxuryTaxAmt = 0;
                    model.serviceTaxAmt = serviceTaxAmt;
                    model.totalTaxAmt = totalTaxAmt;
                    model.billDetailXML = _billXML;


                    //paybleAmt = (totalAmount + totalTaxAmt) - (discountAmt + advanceAmount);
                    paybleAmt = netAmt;
                    //model.discount = discount;
                    model.discountAmount = discountAmt;
                    model.amountAfterDis = amtAfterDiscount;
                    model.totalPayable = Math.Round(paybleAmt, 2);
                    model.netPayable = Convert.ToInt32(Math.Round(paybleAmt, 2));
                    model.userID = model.unitID;

                    model.privilegeAmt = privilegeAmt;
                    model.privilegeDist = privilegeDist;
                    model.roundOffValue = (model.netPayable - model.totalPayable);
                    model.GstApplyed = GSTDisplayTax;



                    string UnitPaymentsSlabXML = generateXMLForSlab(obj_unitPaymentDetailsSlabWise1);

                    var user = objBusinessClass.InsertCheckOutDetails(model, UnitPaymentsSlabXML);
                    if (user != null)
                    {
                        SessionManager.BillNo = user.billNo;
                        SessionManager.DocketNo = model.docketNo;
                        return RedirectToAction("CheckOutConfirmationNew");
                    }
                }
                //else
                //{
                //    _msg = "No Room Selected for Check Out!! ";
                //}

            }
            catch
            { _msg = "Unable to process!"; }
            ViewBag.Show = _msg;
            TempData["msg"] = _msg;
            //return Json(new { result = false, message = "Unable to process!" }, JsonRequestBehavior.AllowGet);
            ViewBag.spclDiscount = objBusinessClass.GetSpecialDiscount().Select(e => new SelectListItem() { Text = e.SpclDiscountName, Value = e.spclDiscountType.ToString() });
            return RedirectToAction("CheckOutNew");
        }

        string generateXMLForSlab(List<UnitAmountDetailsSlabWise> model)
        {
            System.Text.StringBuilder sb = new System.Text.StringBuilder();
            if (model != null)
            {
                sb.Append("<ArrayOfUnitAmountDetails>");
                foreach (var data in model)
                {
                    sb.Append("<UnitAmountDetails>");

                    sb.Append("<TaxFreeAmount>" + data.TaxFreeAmount + "</TaxFreeAmount>");
                    sb.Append("<taxAmountOnFree>" + data.taxAmountOnFree + "</taxAmountOnFree>");
                    sb.Append("<taxrateonFree>" + data.taxrateonFree + "</taxrateonFree>");

                    sb.Append("<SlabOneAmount>" + data.SlabOneAmount + "</SlabOneAmount>");
                    sb.Append("<SlabOneTaxAmount>" + data.SlabOneTaxAmount + "</SlabOneTaxAmount>");
                    sb.Append("<taxRateSlabOne>" + data.taxRateSlabOne + "</taxRateSlabOne>");

                    sb.Append("<SlabTwoAmount>" + data.SlabTwoAmount + "</SlabTwoAmount>");
                    sb.Append("<SlabTwoTaxAmount>" + data.SlabTwoTaxAmount + "</SlabTwoTaxAmount>");
                    sb.Append("<taxRateSlabTwo>" + data.taxRateSlabTwo + "</taxRateSlabTwo>");


                    sb.Append("<SlabThreeAmount>" + data.SlabThreeAmount + "</SlabThreeAmount>");
                    sb.Append("<SlabThreeTaxAmount>" + data.SlabThreeTaxAmount + "</SlabThreeTaxAmount>");
                    sb.Append("<taxRateSlabThree>" + data.taxRateSlabThree + "</taxRateSlabThree>");

                    sb.Append("</UnitAmountDetails>");

                }
                sb.Append("</ArrayOfUnitAmountDetails>");
            }

            return sb.ToString();
        }




        #region check out Confirmation
        [HttpGet]
        public ActionResult CheckOutConfirmationNew()
        {
            try
            {
                CustomerRegistration model = new CustomerRegistration();
                model.billNo = SessionManager.BillNo;
                model.docketNo = SessionManager.DocketNo;

                return View(model);
            }
            catch
            {
                return View("_ErrorPagePartialWebsite");
            }
        }

        #endregion

        #endregion



        #region Get GST Online Unit-Wise

        void GetBookingType()
        {
            ViewBag.BookingType = new List<SelectListItem>() {new SelectListItem { Text="Online", Value = "ONL"},
                                           
                                            new SelectListItem { Text="Other", Value = "Other"}};
        }


        public ActionResult GetUnitReportforGST()
        {
            ViewreportGST model = new ViewreportGST();
            // ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            return View();
        }

        [HttpPost]
        public ActionResult GetUnitReportforGST(ViewreportGST model)
        {
            ModelState.Clear();
            //ViewBag.UnitList = objBusinessClass.GetTotalUnitList().Select(e => new SelectListItem() { Text = e.UnitName, Value = e.UnitID.ToString() });
            GridView gv = new GridView();
            model.unitID = SessionManager.UnitID;
            UnitReportGST mod = new UnitReportGST();
            mod.fromDate = model.fromDate;
            mod.toDate = model.toDate;
            //model.bookingBy = "ONL";
            mod.unitID = SessionManager.UnitID; ;
            var dtresult = objBusinessClass.GetGSTView(mod);
            if (dtresult != null && dtresult.Count() > 0)
            {
                gv.DataSource = dtresult.Select((e, i) => new { S_No = i + 1, Docket_No = e.docketNo, guest_Name = e.guestName, Room_Type = e.roomType, Room_Details = e.RoomDetails, Stay_In_days = e.stayInDays, booking_Date = e.bookingDate.ToString("dd/MM/yyyy"), CGST = e.CGST, SGST = e.SGST, RoomRent = e.RoomRent, Total_Amount = e.amount }).ToList();
                gv.DataBind();

                Response.ClearContent();
                Response.Buffer = true;
                Response.AddHeader("content-disposition", "attachment; filename=Content/writereaddata/GetUnitReport.xls");
                Response.ContentType = "application/ms-excel";
                Response.Charset = "";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                gv.RenderControl(htw);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
            else
            {
                ViewBag.Show = "No Record Found!";
            }



            IEnumerable<UnitReportGST> modellist = dtresult;
            return View(modellist);
        }


        public ActionResult BindGSTDetailsInGrid(string dateFrom, string dateTo)
        {
            UnitReportGST model = new UnitReportGST();
            List<UnitReportGST> modellist = new List<UnitReportGST>();

            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }


                model.unitID = SessionManager.UnitID;
                modellist = objBusinessClass.GetGSTView(model).ToList();
            }
            catch
            {
            }
            return PartialView("_GetUnitReportforGST", modellist);

        }
        public ActionResult PrintGSTReportforUnit(string dateFrom, string dateTo)
        {
            UnitReportGST model = new UnitReportGST();
            List<UnitReportGST> modellist = new List<UnitReportGST>();
            ViewreportGST mdl = new ViewreportGST();

            try
            {
                if (!string.IsNullOrEmpty(dateFrom))
                {
                    ViewBag.fromDate = dateFrom;
                    model.fromDate = DateTime.ParseExact(dateFrom, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(dateTo))
                {
                    ViewBag.todate = dateTo;
                    model.toDate = DateTime.ParseExact(dateTo, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }


                model.unitID = SessionManager.UnitID;
                //ViewBag.unitID = model.unitID;
                modellist = objBusinessClass.GetGSTView(model).ToList();
                mdl.GetGSTView = modellist;
                return View(mdl);
            }

            catch
            {
            }
            return View();
        }
        #endregion


        #region Ankita


        [HttpGet]
        public ActionResult CancelBookingDetail(string docketNo)
        {
            LawnBanquetBookingCancle obj_BookingDetail = new LawnBanquetBookingCancle();
            List<LawnBanquetBookingCancle> obj_BookingList = new List<LawnBanquetBookingCancle>();
            try
            {

                Session["docketNoForCancel"] = docketNo;

                obj_BookingList = objBusinessClass.CancelDetailListforUnit(docketNo);

                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    if (obj_BookingDetail.refaundAmountPer > 0)
                    {
                        obj_BookingDetail.refaundAmount = ((obj_BookingDetail.refaundAmountPer * obj_BookingDetail.amount) / 100);
                    }
                    else
                    {
                        obj_BookingDetail.refaundAmount = 0;
                    }
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                //if (obj_BookingDetail != null)
                //{
                //    obj_BookingDetail.CancelDetail = objBusinessClass.ViewpackagedetailforUnitwise(docketNo);
                //}
                return View("LawnBookingCancellationList", obj_BookingDetail);
            }
            catch
            {

            }
            return View("LawnBookingCancellationList", obj_BookingDetail);
        }
        [HttpGet]
        public ActionResult LawnBookingCancellationList()
        {
            LawnBanquetBookingCancle obj_BookingDetail = new LawnBanquetBookingCancle();
            List<LawnBanquetBookingCancle> obj_BookingList = new List<LawnBanquetBookingCancle>();
            try
            {

                string docketNo = Convert.ToString(Session["docketNoForCancel"]);

                obj_BookingList = objBusinessClass.LawnBanquetCancellationList(docketNo);
                if (obj_BookingList != null && obj_BookingList.Count > 0)
                {
                    obj_BookingDetail = obj_BookingList.FirstOrDefault();
                    obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
                }
                //if (obj_BookingDetail != null)
                //{
                //    obj_BookingDetail.CancelDetail = objBusinessClass.ViewpackagedetailforUnitwise(docketNo);
                //}
                return View("LawnBookingCancellationList", obj_BookingDetail);
            }
            catch
            {

            }

            return RedirectToAction("LawnBookingCancellationList", obj_BookingDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LawnBookingCancellationList(LawnBanquetBookingCancle obj_BookingDetail)
        {
            string id = Convert.ToString(Session["docketNoForCancel"]);
            // obj_BookingDetail.mobileNo = Convert.ToString(SessionManager.CustomerMobile);

            #region Calculate cancilaton amount

            List<LawnBanquetBookingCancle> obj_BookingList = new List<LawnBanquetBookingCancle>();
            obj_BookingList = objBusinessClass.LawnBookingForCancellation(id);

            if (obj_BookingList != null && obj_BookingList.Count > 0)
            {
                obj_BookingDetail = obj_BookingList.FirstOrDefault();
                if (obj_BookingDetail.refaundAmountPer > 0)
                {
                    obj_BookingDetail.refaundAmount = ((obj_BookingDetail.refaundAmountPer * obj_BookingDetail.amount) / 100);
                }
                else
                {
                    obj_BookingDetail.refaundAmount = 0;
                }
                obj_BookingDetail.toDate = obj_BookingList.LastOrDefault().toDate;
            }
            #endregion

            var CancelDetails = objBusinessClass.InsertCancelBookingforUnit(id, obj_BookingDetail.refaundAmountPer, obj_BookingDetail.refaundAmount);
            if (!string.IsNullOrEmpty(CancelDetails.cancelRefNo) && !string.IsNullOrEmpty(CancelDetails.BookingFor))
            {
                //Send Email
                IEnumerable<LawnBanquetBookingCancle> IEContactDetails = objBusinessClass.getMobileNoAndEmailIdforUnit(id);

                // Send SMS to customer
                SendCancelRequestSMS(id, IEContactDetails.FirstOrDefault().mobileNo, IEContactDetails, CancelDetails.BookingFor, CancelDetails.refaundAmount);
                SendCancelRequestEMail(id, IEContactDetails.FirstOrDefault().Email, IEContactDetails, CancelDetails.BookingFor, CancelDetails.refaundPer.ToString(), CancelDetails.refaundAmount.ToString());

                return RedirectToAction("SuccessLawnBanquetBooking", CancelDetails);
            }
            else
            {
                TempData["message"] = "Request Not Cancelled.";
            }
            return View(obj_BookingDetail);
        }

        #endregion

        #region to send sms on booking cancellation
        protected void SendCancelRequestSMS(string docketNo, string mobileNo, IEnumerable<LawnBanquetBookingCancle> contactDetails, string BookingFor, decimal refoundAmt)
        {
            try
            {
                string customerSms = ConfigurationManager.AppSettings["CancelBookingSMSByUser"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                customerSms = customerSms.Replace("[DocketNo]", docketNo);
                customerSms = customerSms.Replace("[Amount]", refoundAmt.ToString());

                string UntAndNodelMsg = ConfigurationManager.AppSettings["CancelBookingSMSByCRSForOthers"].ToString() + Environment.NewLine + ConfigurationManager.AppSettings["Sender"].ToString();
                UntAndNodelMsg = UntAndNodelMsg.Replace("[DocketNo]", docketNo);
                UntAndNodelMsg = UntAndNodelMsg.Replace("[Amount]", refoundAmt.ToString());
                try
                {
                    string SMSStatus = SMS.SMSSend(customerSms, mobileNo);              // Send SMS to customer
                    SMS.SMSLog(customerSms, mobileNo, docketNo, SMSStatus);

                    foreach (var lst in contactDetails)
                    {
                        try
                        {
                            SMSStatus = string.Empty;
                            if (BookingFor == "UNIT")
                            {
                                if (lst.sendTo == "UNIT")
                                {
                                    SMSStatus = SMS.SMSSend(UntAndNodelMsg, lst.mobileNo);
                                    SMS.SMSLog(UntAndNodelMsg, lst.mobileNo, docketNo, SMSStatus);
                                }
                            }

                            if (lst.sendTo == "NODAL")
                            {
                                SMSStatus = SMS.SMSSend(UntAndNodelMsg, lst.mobileNo);     // Send SMS to Nodal Officer
                                SMS.SMSLog(UntAndNodelMsg, lst.mobileNo, docketNo, SMSStatus);
                            }

                        }
                        catch { }
                    }
                }
                catch { }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region to send mail on booking cancellation
        protected void SendCancelRequestEMail(string docketNo, string mailTo, IEnumerable<LawnBanquetBookingCancle> contactDetails, string BookingFor, string refundPer, string refundAmount)
        {
            try
            {
                string MailBody, subject, MailBodyOthers;

                LawnBanquetBookingCancle obj_BookingList = objBusinessClass.getEmailIdBookingForCancellationforUnit(docketNo).FirstOrDefault();
                //LawnBanquitBookingDetails obj_BookingList = objBusinessClass.GetLawnBanquetBookingDetails(docketNo);

                //if (obj_BookingList.BookingFor.ToUpper() == "Lawn")
                //{
                subject = "UP Tourism Lawn/Banquet Booking Cancellation Request";
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/Customer/LawnBanquetCancellationPage.html"));
                MailBody = reader.ReadToEnd();
                //MailBody = MailBody.Replace("[docketno]", docketNo);
                //MailBody = MailBody.Replace("[cancellationreferenceno]", obj_BookingList.cancelRefNo);
                //MailBody = MailBody.Replace("[cancellationdate]", obj_BookingList.CancelDate);
                //MailBody = MailBody.Replace("[hotelname]", obj_BookingList.UnitName);
                //MailBody = MailBody.Replace("[hoteladdress]", obj_BookingList.unitAddress);
                //MailBody = MailBody.Replace("[hotelphone]", obj_BookingList.unitMobile);
                //MailBody = MailBody.Replace("[roomtype]", obj_BookingList.roomType);
                //MailBody = MailBody.Replace("[noofrooms]", obj_BookingList.noOfRooms.ToString());
                //MailBody = MailBody.Replace("[extrabed]", obj_BookingList.extraBed.ToString());
                //MailBody = MailBody.Replace("[checkindate]", obj_BookingList.checkinDate);
                //MailBody = MailBody.Replace("[checkoutdate]", obj_BookingList.checkoutDate);
                //MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                //MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.customerMobile);
                //MailBody = MailBody.Replace("[customeraddress]", obj_BookingList.customerAddress);
                //MailBody = MailBody.Replace("[RefundPercent]", refundPer);
                //MailBody = MailBody.Replace("[refundAmount]", refundAmount);


                // string MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[enquirytype]", obj_BookingList.enquiryType);
                MailBody = MailBody.Replace("[docketno]", obj_BookingList.docketNo);
                MailBody = MailBody.Replace("[UnitName]", obj_BookingList.UnitName);
                MailBody = MailBody.Replace("[ForDate]", obj_BookingList.checkoutDate);
                MailBody = MailBody.Replace("[functionName]", obj_BookingList.functionName);
                MailBody = MailBody.Replace("[noOfTourists]", obj_BookingList.noOfPerson.ToString());
                MailBody = MailBody.Replace("[customername]", obj_BookingList.name);
                MailBody = MailBody.Replace("[customeremail]", obj_BookingList.Email);
                MailBody = MailBody.Replace("[customerphoneno]", obj_BookingList.phoneNo);
                MailBody = MailBody.Replace("[customermobileno]", obj_BookingList.mobileNo);


                if (!(string.IsNullOrEmpty(MailBody) && string.IsNullOrEmpty(mailTo)))
                {
                    SendMail.SendMailNew(mailTo, subject, MailBody);

                }




            }
            catch (Exception)
            {
            }
        }
        #endregion


        public ActionResult SuccessLawnBanquetBooking(LawnBanquetBookingCancle obj_BookingDetail)
        {
            return View(obj_BookingDetail);
        }

        [HttpGet]
        public ActionResult ViewGSTReportSlabWise()
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            return View();
        }
        public ActionResult ViewGSTSlabWiseforUnit(string fromDate, string toDate)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();

            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }
                model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWiseforUnit(model);
            }
            catch
            {
            }
            return PartialView("_ViewGSTReportSlabWiseforUnit", model.SlabWiseDetail);
        }

        public ActionResult GetGSTReportforUnitSlabWise(string fromDate, string toDate)
        {
            UnitAmountDetailsSlabWise model = new UnitAmountDetailsSlabWise();
            // model.DocketNumber = docketNo;
            try
            {

                if (!string.IsNullOrEmpty(fromDate))
                {

                    model.fromDate = DateTime.ParseExact(fromDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                }
                if (!string.IsNullOrEmpty(toDate))
                {
                    model.toDate = DateTime.ParseExact(toDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                }

                model.SlabWiseDetail = objBusinessClass.GetGSTSlabWiseforUnit(model);
            }
            catch
            {
            }
            // model.SlabWiseDetail = objBusinessClass.GetGSTDetailSlabWiseforUnit(model);

            // model.UnitName = model.SlabWiseDetail.FirstOrDefault().UnitName;
            return View(model);
        }
    }

}
