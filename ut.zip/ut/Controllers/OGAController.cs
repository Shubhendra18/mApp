﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models;
using System.IO;
using System.Web.Hosting;

namespace UP_TourismBooking.Controllers
{
    public class OGAController : Controller
    {
        //
        // GET: /OGA/

        BusinessClass objBusinessClass = new BusinessClass();


        [HttpGet]
        public ActionResult Registration()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Registration(OGAModel model)
        {
            int res = objBusinessClass.InsertOGARegistration(model);
            if (res > 0)  //for send message 
            {
                //string msg = "Thank you " + model.Name + " for registration. We will contact you shortly.";
                //SMS.SMSSend(msg, model.ContactNo);

                string OGAAdminEmailId = System.Configuration.ConfigurationManager.AppSettings["OGAAdminEmailId"].ToString();
                string MailBody = "";
                StreamReader reader = new StreamReader(HostingEnvironment.MapPath(@"~/EmailTemplates/OGA/OGARegistration.html"));
                MailBody = reader.ReadToEnd();
                MailBody = MailBody.Replace("[Name]", model.Name);
                MailBody = MailBody.Replace("[Address]", model.Address1 + " " + model.Address2);
                MailBody = MailBody.Replace("[ContactNo]", model.ContactNo);
                MailBody = MailBody.Replace("[EmailId]", model.EmailId);

                //SendMail.SendMailNew(OGAAdminEmailId, "Mr. " + model.Name + "'s Registration Details in OGA", MailBody);

                SendMail.SendMailNew(OGAAdminEmailId, "Details of New Registered User for Bed & Breakfast/ Paying Guest Scheme", MailBody);

            }
            return RedirectToAction("SuccessRegistration");
        }


        [HttpGet]
        public ActionResult SuccessRegistration()
        {
            return View();
        }
    }
}
