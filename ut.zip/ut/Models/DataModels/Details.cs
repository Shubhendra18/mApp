﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.DataModels
{
    public class PackageToursDetails
    {
        public string overview { get; set; }
        public int durationNight { get; set; }
        public int durationDays { get; set; }
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string excDescription { get; set; }
        public string incDescription { get; set; }   
        public string subPackageName { get; set; }
        public string placesCovered { get; set; }
        public string meetingPointAddress { get; set; }
        public string travelMode { get; set; }
        public string mealPlan { get; set; }
        public string packageImage { get; set; }
        public bool Availability { get; set; }
        public int packageCategoryID { get; set; }

        public IEnumerable<PackageToursPolicy> policyList { get; set; }
        public IEnumerable<PackageToursAccomodation> accomodationList { get; set; }
        public IEnumerable<PackageToursItenarary> itenararyList { get; set; }
        public IEnumerable<PackageToursContact> contactList { get; set; }
        public IEnumerable<PackageImages> imageList { get; set; }
      
    }

    public class PackageToursPolicy
    {
        public Int64 cancellationID { get; set; }
        public string policyType { get; set; }
        public string policy { get; set; }
    }

    public class PackageToursAccomodation
    {       
        public string cityname { get; set; }
        public string unitName { get; set; }
        public string roomType { get; set; }
        public string daySequence { get; set; }
        public string unitAddress { get; set; }
    }
    
    public class PackageToursItenarary
    {
        [Display(Name="Day")]
        public string day { get; set; }

        [Display(Name = "Origin")]
        public string origin { get; set; }

        [Display(Name = "Destination")]
        public string destination { get; set; }

        [Display(Name = "Dep/Arr")]
        public string depArr { get; set; }

        [Display(Name = "Time")]
        public string time { get; set; }

        [Display(Name = "Particulars")]
        public string particulars { get; set; }	
    }

    public class PackageToursContact
    {
        public string contactName { get; set; }
        public string contactAddress { get; set; }
        public string contactPhoneNo { get; set; }
        public string contactMobileNo { get; set; }
        public string contactEmail { get; set; }
        public string nodalOfficer { get; set; }
    }

    public class PackageImages
    {
        public string imagePath { get; set; }
        public string imagePathSmall { get; set; }
        public string imageCaption { get; set; }
    }

    public class UnitDetails
    {
        public string overview { get; set; }
        public string duration { get; set; }       
        public Int64 unitID { get; set; }
        public string unitName { get; set; }  
        public string unitImage { get; set; }
        public string completeAddress { get; set; }
        public string address { get; set; }
        public string district { get; set; }
        public string state { get; set; }
        public string pincode { get; set; }
        public string phoneNo { get;set;}
        public int noOfRooms { get; set; }
        public string mobileNo { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string unitDetails { get;set;}

        public IEnumerable<UnitAmenities>  IEAmenities { get;set;}
        public IEnumerable<UnitRooms> IERooms { get; set; }
        public IEnumerable<UnitImages> IEImages { get; set; }
    }

    public class UnitImages
    {
        public string unitImagePath { get; set; }
        public string imageCaption { get; set; }
    }

    public class CityToursDetails
    {
        public string overview { get; set; }
        public int durationNight { get; set; }
        public string durationDays { get; set; }
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string excDescription { get; set; }
        public string incDescription { get; set; }
        public string subPackageName { get; set; }
        public string placesCovered { get; set; }
        public string meetingPointAddress { get; set; }
        public string travelMode { get; set; }
        public string mealPlan { get; set; }
        public string packageImage { get; set; }
        public bool Availability { get; set; }
        public int packageCategoryID { get; set; }
        public DateTime arrivalDate { get; set; }
        public bool isBookable { get; set; }
        public bool isAvailable { get; set; }

        public IEnumerable<CityToursPolicy> policyList { get; set; }       
        public IEnumerable<CityToursItenarary> itenararyList { get; set; }
        public IEnumerable<CityToursContact> contactList { get; set; }

        public IEnumerable<PackageImages> imageList { get; set; }
    }

    public class CityToursPolicy
    {
        public Int64 cancellationID { get; set; }
        public string policyType { get; set; }
        public string policy { get; set; }
    }

    public class CityToursItenarary
    {
        [Display(Name = "Day")]
        public string day { get; set; }

        [Display(Name = "Origin")]
        public string origin { get; set; }

        [Display(Name = "Destination")]
        public string destination { get; set; }

        [Display(Name = "Dep/Arr")]
        public string depArr { get; set; }

        [Display(Name = "Time")]
        public string time { get; set; }

        [Display(Name = "Particulars")]
        public string particulars { get; set; }
    }

    public class CityToursContact
    {
        public string contactName { get; set; }
        public string contactAddress { get; set; }
        public string contactPhoneNo { get; set; }
        public string contactMobileNo { get; set; }
        public string contactEmail { get; set; }
        public string nodalOfficer { get; set; }
    }

    public class ACBusToursDetails
    {
        public string overview { get; set; }        
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string excDescription { get; set; }
        public string incDescription { get; set; }
        public string subPackageName { get; set; }
        public string placesCovered { get; set; }
        public string meetingPointAddress { get; set; }
        public string travelMode { get; set; }
        public string mealPlan { get; set; }
        public string packageImage { get; set; }
        public bool Availability { get; set; }
        public int packageCategoryID { get; set; }
        public DateTime arrivalDate { get; set; }
        public bool isAvailable { get; set; }

        public IEnumerable<ACBusToursPolicy> policyList { get; set; }
        public IEnumerable<ACBusToursItenarary> itenararyList { get; set; }
        public IEnumerable<ACBusToursContact> contactList { get; set; }
        public IEnumerable<PackageImages> imageList { get; set; }
    }

    public class ACBusToursPolicy
    {
        public Int64 cancellationID { get; set; }
        public string policyType { get; set; }
        public string policy { get; set; }
    }

    public class ACBusToursItenarary
    {
        [Display(Name = "Day")]
        public string day { get; set; }

        [Display(Name = "Origin")]
        public string origin { get; set; }

        [Display(Name = "Destination")]
        public string destination { get; set; }

        [Display(Name = "Dep/Arr")]
        public string depArr { get; set; }

        [Display(Name = "Time")]
        public string time { get; set; }

        [Display(Name = "Particulars")]
        public string particulars { get; set; }
    }

    public class ACBusToursContact
    {
        public string contactName { get; set; }
        public string contactAddress { get; set; }
        public string contactPhoneNo { get; set; }
        public string contactMobileNo { get; set; }
        public string contactEmail { get; set; }
        public string nodalOfficer { get; set; }
    }
    public class OnlineBooking
    {
        //public string mobileNo 
        //{
        //    get
        //    {
        //        String mobileNo  = "";
        //        String CCEncoded;
        //        CCEncoded = "XXXX XXXX  " + mobileNo.Substring(mobileNo.Length - 2, 2);
        //        return CCEncoded;
        //    }
        //    set { }
        //}

        public int OTPSend { get; set; }
        public Int64? otp { get; set; }
        public int RandomNo { get; set; }
        public string email { get; set; }
        public int otpRequestCount { get; set; }
        public int flag { get; set; }
        public Int64 userId { get; set; }
        public string name { get; set; }
        public string UnitName { get; set; }
        public string docketNo { get; set; }
        public string packageName { get; set; }
        public string mobileNo { get; set; }
        public string BookingFor { get; set; }
        public string transDate { get; set; }
        public string OTPNo { get; set; }
        public bool isActive { get; set; }
        public bool isDeleted { get; set; }
        public DateTime? modifiedOn { get; set; }
        public IEnumerable<OnlineBooking> ViewBooking { get; set; }
    }


    //public class SpecialUnitDetails
    //{
    //    public string overview { get; set; }
    //    public string duration { get; set; }
    //    public Int64 unitID { get; set; }
    //    public string unitName { get; set; }
    //    public string unitImage { get; set; }
    //    public string completeAddress { get; set; }
    //    public string address { get; set; }
    //    public string district { get; set; }
    //    public string state { get; set; }
    //    public string pincode { get; set; }
    //    public string phoneNo { get; set; }
    //    public int noOfRooms { get; set; }
    //    public string mobileNo { get; set; }
    //    public string latitude { get; set; }
    //    public string longitude { get; set; }
    //    public string unitDetails { get; set; }

    //    public IEnumerable<UnitAmenities> IEAmenities { get; set; }
    //    public IEnumerable<UnitRooms> IERooms { get; set; }
    //    public IEnumerable<UnitImages> IEImages { get; set; }
    //}

}

