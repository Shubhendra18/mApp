﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class Payment
    {
        public string MerchantRefNo { get; set; }
        public string PaymentID { get; set; }
        public string TransactionID { get; set; }
        public string Amount { get; set; }
        public string ResponseMessage { get; set; }
        public string PaymentDate { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string email { get; set; }
        public string mobileNo { get; set; }
        public string BookingFor { get; set; }
        public string BookingStatus { get; set; }
        public int doubleRoom { get; set; }
        public int extraBed { get; set; }
        public string fromDate { get; set; }
        public int noOfRooms { get; set; }
        public int noOfTourists { get; set; }
        public int packageID { get; set; }
        public int roomID { get; set; }
        public int singleRoom { get; set; }
        public string toDate { get; set; }
        public int unitID { get; set; }
        public int unitRoomID { get; set; }
        public string HotelAddree { get; set; }
        public string DistrictName { get; set; }
        public string UnitName { get; set; }
        public string packageName { get; set; }
        public String accomStr { get; set; }
        public string toDateShow { get; set; }
        public string arrivalDate { get; set; }
        public string bookingType { get; set; }
        public DateTime? arrivalTime { get; set; }
        public string fromCityName { get; set; }
        public string toCity { get; set; }
        public string dateOfJourney { get; set; }
        public string dateOfReturn { get; set; }
        public string pickupDate { get; set; }
        public DateTime? pickupTime { get; set; }
        public string pickupAddress { get; set; }
        public string phoneNo { get; set; }


        public IEnumerable<PackageToursAccomodation> IEPackageAccomodation { get; set; }
    }

    public class BookingDetails
    {
        public string MerchantRefNo { get; set; }
        public string PaymentID { get; set; }
        public string TransactionID { get; set; }
        public string Amount { get; set; }
        public string ResponseMessage { get; set; }
        public string PaymentDate { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string email { get; set; }
        public string mobileNo { get; set; }
        public string BookingFor { get; set; }
        public string BookingStatus { get; set; }
        public int doubleRoom { get; set; }
        public int extraBed { get; set; }
        public string fromDate { get; set; }
        public int noOfRooms { get; set; }
        public int noOfTourists { get; set; }
        public int packageID { get; set; }
        public int roomID { get; set; }
        public int singleRoom { get; set; }
        public string toDate { get; set; }
        public int unitID { get; set; }
        public int unitRoomID { get; set; }
        public string HotelAddree { get; set; }
        public string DistrictName { get; set; }
        public string UnitName { get; set; }
        public string packageName { get; set; }
        public String accomStr { get; set; }
        public string toDateShow { get; set; }
        public string CheckoutDate { get; set; }
        public string CheckoutTime { get; set; }
        public string phoneNo { get; set; }
        public string arrivalDate { get; set; }       
        public DateTime? arrivalTime { get; set; }
        public string fromCityName { get; set; }
        public string toCity { get; set; }
        public string dateOfJourney { get; set; }
        public string dateOfReturn { get; set; }
        public string pickupDate { get; set; }
        public DateTime? pickupTime { get; set; }
        public string pickupAddress { get; set; }
       
        public IEnumerable<PackageToursAccomodation> IEPackageAccomodation { get; set; }
       
    }

    public class PayDetails
    {
        public decimal amount { get; set; }
    }

    public class ReconcileApiValues
    {
        public string docketNo { get; set; }
        public string transactionId { get; set; }
        public string paymentId { get; set; }
        public decimal amount { get; set; }
        public DateTime dateTime { get; set; }
        public string mode { get; set; }
        public string referenceNo { get; set; }
        public string transactionType { get; set; }
        public string status { get; set; }

        public string errorCode { get; set; }
        public string error { get; set; }
        public string message { get; set; }
    }

    public class QueryResult
    {
        public int flag { get; set; }
        public string msg { get; set; }
    }
}