﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.DataModels
{
    public class CRSReportModel
    {
        [Required(ErrorMessage="Date Is Required !")]
        public string reportDate { get; set; }
        public string bookingStatus { get; set; }
        public string bookingFor { get; set; }
        public List<BookingCustomerDetailsModel> BookingReport { get; set; }
    }

    public class BookingCustomerDetailsModel
    {
        public string name { get; set; }
        public string email { get; set; }
        public string mobileNo { get; set; }
        public string cityName { get; set; }
        public string stateName { get; set; }
        public string address { get; set; }
        public string pincode { get; set; }
        public string BookingFor { get; set; }
        public string UnitOrPackageName { get; set; }
        public string roomType { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string requestDate { get; set; }
        public string amount { get; set; }
        public string BookingStatus { get; set; }
        public string docketNo { get; set; }
        public long requestID { get; set; }
    }
}