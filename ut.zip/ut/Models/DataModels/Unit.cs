﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class CustomerRegistration : CustomerBooking
    {
        public Int64 userID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }


        [Display(Name = "Email")]
        //[Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        //[Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "From Where")]
        //[Required(ErrorMessage = "From Where!")]
        [StringLength(200, ErrorMessage = "From Where should be upto 200 characters only!")]
        public string fromWhere { get; set; }

        [Display(Name = "To Where")]
        //[Required(ErrorMessage = "To Where!")]
        [StringLength(200, ErrorMessage = "To Where should be upto 200 characters only!")]
        public string toWhere { get; set; }

        [Display(Name = "City")]
        //[Required(ErrorMessage = "Select City!")]
        public int? cityID { get; set; }

        [Display(Name = "City")]
        //[Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        //[Required(ErrorMessage = "Select State!")]
        public int? stateID { get; set; }

        [Display(Name = "State")]
        //[Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        //[Required(ErrorMessage = "Select Country!")]
        public int? countryID { get; set; }

        [Display(Name = "Pincode")]
        //[Required(ErrorMessage = "Enter Pincode!")]
        //[StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        //[RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        //[StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        //[RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [Display(Name = "Phone No.")]
        //[Required(ErrorMessage = "Enter Phone No.!")]
        [StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")]
        public string phone { get; set; }

        [Display(Name = "Personal Identity No.")]
        //[Required(ErrorMessage = "Enter Personal Identity No.!")]
        //[StringLength(10, ErrorMessage = "Personal Identity No. should be upto 10 characters only!")]
        //[RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")] 
        //[RegularExpression(@"^[A-Z0-9]+$", ErrorMessage = "Enter valid Personal Identity No.!")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }
        public string userIP { get; set; }

        public string roleID { get; set; }
        public string docketNo { get; set; }
        [Display(Name = "Identity Type")]
        //[Required(ErrorMessage = "Select Identity Type!")]
        public int? IdentityType { get; set; }

        public int isOtherStateCityRequired
        {
            get
            {
                return countryID != 98 ? 1 : 0;
            }
        }

        [Display(Name = "Is Staff")]
        public Boolean isStaff { get; set; }
        [Display(Name = "Staff Id")]
        public string staffId { get; set; }
        [Display(Name = "Upload Staff Identity")]
        public HttpPostedFileBase staffIdDoc { get; set; }
        public string staffIdDocPath { get; set; }
        [Display(Name = "Staff Grade")]
        public int staffGrade { get; set; }
        [Display(Name = "Staff Tariff")]
        public int staffFacility { get; set; }
        public decimal staffTariff { get; set; }

        public string privilegeCardNo { get; set; }
        public Boolean isPrivilegeAvail { get; set; }
        public Boolean isPrivilegeVerified { get; set; }
        public string bookingFor { get; set; }
        [Display(Name = "Receipt No.")]
        //[Required(ErrorMessage = "Enter Receipt No.!")]
        public string receiptNo { get; set; }

        public Char customerType { get; set; }  // W - Walk In Guest, S - Staff Booking, B - Bulk Booking
        public string bookingXML { get; set; }
        public int tempRoomId { get; set; }
        public int tempRoomId2 { get; set; }
        public string tempRoomIdName { get; set; }

        [Display(Name = "Nationality")]
        public int? applicantType { get; set; }
        public int? nameTitle { get; set; }

        public bool isCheckIn { get; set; }

        public string bookingBy { get; set; }

        [Display(Name = "Date of Birth")]
        public string dateOfBirth { get; set; }

        [Display(Name = "Age")]
        public int age { get; set; }

        public int availableRooms { get; set; }
        public decimal totalAmountPayable { get; set; }

        public string GstApplyed { get; set; }

        public double GSTR1per { get; set; }
        public double GSTR2per { get; set; }
        public double GSTR3per { get; set; }

        public double baseSlave1 { get; set; }
        public double baseSlave2 { get; set; }
        public double baseSlave3 { get; set; }

        public double ExtrabaseSlave1 { get; set; }
        public double ExtrabaseSlave2 { get; set; }
        public double ExtrabaseSlave3 { get; set; }


    }

    public class CustomerBooking
    {
        [Required(ErrorMessage = "Select Check In!")]
        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        public DateTime checkInDate { get; set; }

        [Required(ErrorMessage = "Select Check Out!")]
        [DataType(DataType.Date, ErrorMessage = "Check Out Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Check Out Date")]
        public DateTime checkOutDate { get; set; }

        //[Required(ErrorMessage = "Fill Check In Time!")]
        [DataType(DataType.Time, ErrorMessage = "Check In Time should be valid time!")]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Time")]
        public DateTime checkInTime { get; set; }


        //  [DataType(DataType.Time, ErrorMessage = "Check Out Time should be valid time!")]
        //[DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid time.")]
        [Display(Name = "Check Out Time")]
        [InputMask("99:99")]
        [DataType(DataType.Time, ErrorMessage = "Check Out Time should be valid time!")]
        public DateTime checkOutTime { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        [Display(Name = "No. of Rooms")]
        [Required(ErrorMessage = "Enter No. of Rooms!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfRooms { get; set; }

        [Display(Name = "Single Occupancy")]
        [Required(ErrorMessage = "Enter No. of Rooms (Single)")]
        public int singleRoom { get; set; }

        [Display(Name = "Double Occupancy")]
        [Required(ErrorMessage = "Enter No. of Rooms (Double)")]
        public int doubleRoom { get; set; }

        [Display(Name = "Extra Bed")]
        public int extrabed { get; set; }

        public int unitCount { get; set; }

        [Display(Name = "Unit Name")]
        public Int64 unitID { get; set; }

        [Display(Name = "No. of Rooms")]
        public string unitName { get; set; }
        public string roomName { get; set; }

        public string address { get; set; }

        public string briefDescription { get; set; }

        public string imagePath { get; set; }

        public int noOfDays { get; set; }

        [Display(Name = "Room Type")]
        //[Required(ErrorMessage = "Select Room Type!")]
        public int? roomType { get; set; }

        [Display(Name = "Advance Amount")]
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Advance Amount!")]
        //[Required(ErrorMessage = "Enter Advance Amount!")]
        public decimal? advanceAmount { get; set; }

        public string billNo { get; set; }
        public String billDetailXML { get; set; }

        public double totalAmount { get; set; }
        public double totalAmountExtra { get; set; }
        public double totalAmountForTax { get; set; }
        public double totalAmountActual { get; set; }
        public double discountAmtForTaxService { get; set; }
        public double discountAmtForTaxLuxury { get; set; }
        public double discountAmtForTaxLuxury_Extra { get; set; }
        public double discountAmount { get; set; }
        public double discount { get; set; }
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Special Discount!")]
        [Range(0, 80, ErrorMessage = "Special Discount must be between 0 to 80% !")]
        public double spclDiscount { get; set; }
        public int? spclDiscountType { get; set; }
        public double luxuryTax { get; set; }
        public string luxuryTaxDisplay { get; set; }
        public double luxuryTaxAmt { get; set; }
        public double serviceTax { get; set; }
        public double serviceTaxAmt { get; set; }
        public double totalTaxAmt { get; set; }
        public int netPayable { get; set; }
        public double amountAfterDis { get; set; }
        public double totalPayable { get; set; }
        public double roundOffValue { get; set; }
        public double privilegeAmt { get; set; }
        public double privilegeDist { get; set; }
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid F & B Amount!")]
        public double fAndBAmt { get; set; }
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Laundry Amount!")]
        public double laundryAmt { get; set; }
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Room Service Amount!")]
        public double roomServiceAmt { get; set; }
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Other Amount!")]
        public double otherAmt { get; set; }
        public string cancelRefNo { get; set; }
        public DateTime bookingDate { get; set; }
        public DateTime checkOutDateShow { get; set; }
        public DateTime checkInDateShow { get; set; }
        public Int16 maxCapacity { get; set; }
        public int maxExtraBed { get; set; }
        public bool hasOccupancy { get; set; }
        public string roomTypeDisplay { get; set; }

        public List<BillDetails> lstBill { get; set; }
        public List<BookedRoomDetails> lstBookedRoom { get; set; }
        public IList<RoomDetail> lstBookedRoomDetail { get; set; }
        public String requestXML { get; set; }

        public String roomNo { get; set; }
        public DateTime checkOutDateActual { get; set; }
        public double totalAmountForTaxLuxury { get; set; }
        public double totalAmountForTaxService { get; set; }
        public double totalAmountForTaxLuxury_Extra { get; set; }
        public double discountPercent { get; set; }
        public string IsSaved { get; set; }
        public int dobDate { get; set; }
        public int dobMonth { get; set; }
        public int dobYear { get; set; }
    }

    public class RoomType
    {
        public int roomTypeId { get; set; }
        
        public string roomTypeName { get; set; }
        public int roomID { get; set; } /*--Added By Tabeen*/
    }

    public class RoomAvailabilityDetails
    {
        public DateTime bookingDate { get; set; }
        public Int64 unitId { get; set; }
        public int? roomTypeId { get; set; }
        public int TotalRoom { get; set; }
    }

    public class BillDetails
    {
        public DateTime RentDate { get; set; }
        public String BillDescription { get; set; }
        public String RoomNo { get; set; }
        public decimal Amount { get; set; }
        public Int64 requestId { get; set; }
        public decimal ExtraBedAmount { get; set; }
        public bool isTaxEligible { get; set; }
        public decimal Tariff { get; set; }
        public decimal basetariff { get; set; }
        public decimal Amountbasetariff { get; set; }
        public decimal baseExtraBedAmount { get; set; }
        public int GstApplyed { get; set; }
    }

    public class BookedRoomDetails
    {
        public Int64 requestID { get; set; }
        public string docketNo { get; set; }
        public int roomId { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string roomType { get; set; }
        public int singleRoom { get; set; }
        public int doubleRoom { get; set; }
        public int extrabed { get; set; }
        public bool hasOccupancy { get; set; }
        public int totalRoom { get; set; }
        public string currStatus { get; set; }
    }

    public class InputMaskAttribute : Attribute, IMetadataAware
    {

        private string _mask = string.Empty;

        public InputMaskAttribute(string mask)
        {
            _mask = mask;
        }

        public string Mask
        {
            get { return _mask; }
        }

        private const string ScriptText = "<script type='text/javascript'>" +
                                          "$(document).ready(function () {{" +
                                          "$('#{0}').mask('{1}');}});</script>";

        public const string templateHint = "_mask";

        private int _count;

        public string Id
        {
            get { return "maskedInput_" + _count; }
        }

        internal HttpContextBase Context
        {
            get { return new HttpContextWrapper(HttpContext.Current); }
        }

        public void OnMetadataCreated(ModelMetadata metadata)
        {
            var list = Context.Items["Scripts"]
            as IList<string> ?? new List<string>();
            _count = list.Count;
            metadata.TemplateHint = templateHint;
            metadata.AdditionalValues[templateHint] = Id;
            list.Add(string.Format(ScriptText, Id, Mask));
            Context.Items["Scripts"] = list;
        }
    }

    public class AdvancePayment
    {
        public Int64 unitID { get; set; }

        [Display(Name = "Customer Name")]
        public string customerName { get; set; }

        [Display(Name = "From")]
        public string fromWhere { get; set; }

        [Display(Name = "To")]
        public string toWhere { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Docket No.")]
        public string docketNo { get; set; }

        [Display(Name = "No. of Rooms")]
        public int noOfRooms { get; set; }

        [Display(Name = "Room Type")]
        public string roomType { get; set; }

        [Display(Name = "Advance Paid")]
        public decimal amountPaid { get; set; }

        [Display(Name = "Remaining Charges")]
        public decimal amountUnpaid { get; set; }
        [Display(Name = "Receipt No.")]
        [Required(ErrorMessage = "Enter Receipt No.!")]
        public string receiptNo { get; set; }

        [Display(Name = "Total Amount")]
        public decimal totalAmount { get; set; }

        [Display(Name = "Advance Amount")]
        [Required(ErrorMessage = "Enter Advance Amount!")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "Paid On")]
        [Required(ErrorMessage = "Select Payment Date!")]
        public DateTime paymentDate { get; set; }

        [Display(Name = "Advance Payment Category")]
        [Required(ErrorMessage = "Select Advance Payment Category!")]
        public int CatId { get; set; }

        public string userIP { get; set; }
        public bool isCheckIn { get; set; }
    }

    public class PersonalIdentity
    {
        public int pId { get; set; }
        public string pName { get; set; }
    }

    public class PaymentDetails
    {
        public string docketNo { get; set; }
        public string Amount { get; set; }
        public string Mode { get; set; }
        public string billNo { get; set; }
        public string BillType { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public Int64 unitID { get; set; }
        public string UnitName { get; set; }
        public string AdvancePaymentCategory { get; set; }
        public string IsCreditDebit { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string BookingStatus { get; set; }
        public Nullable<DateTime> paymentDate { get; set; }
    }

    public class CheckinDetails
    {
        public Int64 unitID { get; set; }

        [Display(Name = "Docket No.")]
        public string docketNo { get; set; }

        [Display(Name = "Customer Name")]
        public string name { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfGuests { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        public DateTime checkInDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check Out Date")]
        public DateTime checkOutDate { get; set; }

        [Display(Name = "Single Occupancy")]
        public int singleRoom { get; set; }

        [Display(Name = "Double Occupancy")]
        public int doubleRoom { get; set; }

        [Display(Name = "Room Type")]
        public string roomName { get; set; }

        [Display(Name = "No. of Rooms")]
        public int noOfRooms { get; set; }

        [Display(Name = "Amount Paid")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "Advance Amount")]
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Advance Amount!")]
        //[Required(ErrorMessage = "Enter Advance Amount!")]
        public decimal? advancePayment { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Check In Time!")]
        [Display(Name = "Check In Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Check In Time!")]
        [Required(ErrorMessage = "Enter Check In Time!")]
        public DateTime checkInTime { get; set; }

        [Display(Name = "Upload Privilege Card")]
        public HttpPostedFileBase privilegeCard { get; set; }

        public string privilegeCardPath { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        [Display(Name = "Check if Verified Privilege Card")]
        public Boolean isPrivilegeVerified { get; set; }

        [Display(Name = "From Where")]
        [Required(ErrorMessage = "Enter From Where!")]
        public string fromWhere { get; set; }

        [Display(Name = "To Where")]
        [Required(ErrorMessage = "Enter To Where!")]
        public string toWhere { get; set; }

        [Display(Name = "Paid On")]
        //[Required(ErrorMessage = "Select Payment Date!")]
        public DateTime? paymentDate { get; set; }

        public string userIP { get; set; }

        public Boolean privilegeAvailability { get; set; }

        public int extrabed { get; set; }

        [Display(Name = "Rooms (Single)")]
        public string singleRoomNo { get; set; }

        [Display(Name = "Rooms (Double)")]
        public string doubleRoomNo { get; set; }

        [Display(Name = "Extend Date")]
        [Required(ErrorMessage = "Select Extend Date!")]
        public DateTime extendDate { get; set; }

        public int roomTypeId { get; set; }
        public DateTime checkOutDateShow { get; set; }
        public DateTime checkInDateShow { get; set; }
        public Boolean hasOccupancy { get; set; }

        public String rooms { get; set; }

        public IList<RoomDetail> lstBookedRoomDetail { get; set; }
        public Int64 requestID { get; set; }

        public string roomNos { get; set; }
        [Display(Name = "Receipt No.")]
        //[Required(ErrorMessage = "Enter Receipt No.!")]
        public string receiptNo { get; set; }
        [Required(ErrorMessage = "Select Check In Date!")]
        public DateTime checkInDateActual { get; set; }
        [Display(Name = "Duration Of Stay")]
        public string duration { get; set; }

        public bool isCheckIn { get; set; }

        public DateTime bookingDate { get; set; }
        public string AdvPaidOn { get; set; }
    }

    public class RoomDetails
    {
        public Int64 unitID { get; set; }

        public int noOfBed { get; set; }

        public Int64 RoomNoId { get; set; }

        public string RoomNo { get; set; }

        public Int64 BookedRoomId { get; set; }

        public string roomType { get; set; }

        public String SelectedRooms { get; set; }

        public bool isSelected { get; set; }
    }

    public class StaffGrade
    {
        public int gradeId { get; set; }
        public string grade { get; set; }
        public int facilityId { get; set; }
        public decimal amount { get; set; }
    }

    public class RoomDetail
    {
        public Int64 requestID { get; set; }
        public int Sno { get; set; }
        public int? roomType { get; set; }
        public string roomTypeDisplay { get; set; }
        public int singleRoom { get; set; }
        public int doubleRoom { get; set; }
        public int extrabed { get; set; }
        public DateTime extendedDate { get; set; }
        public bool hasOccupancy { get; set; }
        public int totalRoom { get; set; }
        public Int16 maxCapacity { get; set; }
        public int maxExtraBed { get; set; }
        public int maxExtraBedAllowed { get; set; }
        public String SelectedRooms { get; set; }
        public DateTime checkInDate { get; set; }
        public DateTime checkOutDate { get; set; }
        public DateTime checkOutDateShow { get; set; }
        public int noOfGuests { get; set; }
        public bool isSelected { get; set; }
        public decimal singletariff { get; set; }
        public decimal doubletariff { get; set; }
        public decimal totalTariff { get; set; }
        public string status { get; set; }
        public List<RoomDetails> lstRoomNoDetail { get; set; }
    }

    public class RoomTariffMode
    {
        public int roomID { get; set; }
        public int numofBeds { get; set; }
        public int seasonID { get; set; }
        public decimal tariff { get; set; }

    }

    public class AdvanceAmountCategory
    {
        public int CatId { get; set; }
        public string AdvancePaymentCategory { get; set; }
    }

    public class NameTitle
    {
        public int TitleId { get; set; }
        public string TitleName { get; set; }
    }

    public class VacancyStatusDetail
    {
        public Int64 unitID { get; set; }
        public DateTime BookingDate { get; set; }
        public Int64 RoomTypeId { get; set; }
        public String RoomNoAvail { get; set; }
        public int RoomNoAvailCount { get; set; }
        public String RoomNoBooked { get; set; }
        public int RoomNoBookedCount { get; set; }
        public String RoomNoOutS { get; set; }
        public int RoomNoOutSCount { get; set; }
    }

    public class GuesRoomtDetails
    {
        public Int64 RequestId { get; set; }
        public string RoomNo { get; set; }
        public Int64 RoomNoId { get; set; }
        public string Roomtype { get; set; }
        public string GuestName { get; set; }
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string MobileNo { get; set; }
        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid time.")]
        [Display(Name = "Check Out Time")]
        [InputMask("99:99")]
        [DataType(DataType.Time, ErrorMessage = "Check In Time should be valid time!")]
        public DateTime ChekInTime { get; set; }
        public DateTime ChekInDate { get; set; }
        public List<GuesRoomtDetails> GuestList { get; set; }
    }

    public class SpecialDiscount
    {
        public int spclDiscountType { get; set; }
        public string SpclDiscountName { get; set; }
    }

    public class RoomTariffDetails
    {
        public string bookingMonth { get; set; }
        public decimal singleBedTariff { get; set; }
        public decimal doubleBedTariff { get; set; }
        public bool hasOccupancy { get; set; }
    }

    public class AdvancePaymentRoomWise
    {
        public Int64 unitID { get; set; }

        [Display(Name = "Docket No.")]
        [Required(ErrorMessage = "Enter Docket No.!")]
        public string docketNo { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfPerson { get; set; }

        [Display(Name = "Customer Name")]
        public string name { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Check In Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkInDate { get; set; }

        [Display(Name = "Check Out Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkOutDate { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        public Boolean privilegeAvailability { get; set; }

        [Display(Name = "From")]
        public string fromWhere { get; set; }

        [Display(Name = "To")]
        public string toWhere { get; set; }

        [Display(Name = "No. of Rooms")]
        public int noOfRooms { get; set; }

        [Display(Name = "Room Type")]
        public string roomType { get; set; }

        [Display(Name = "Advance Paid")]
        public decimal amountPaid { get; set; }

        [Display(Name = "Remaining Charges")]
        public decimal amountUnpaid { get; set; }

        [Display(Name = "Receipt No.")]
        [Required(ErrorMessage = "Enter Receipt No.!")]
        public string receiptNo { get; set; }

        [Display(Name = "Total Amount")]
        public decimal totalAmount { get; set; }

        [Display(Name = "Advance Amount")]
        [Required(ErrorMessage = "Enter Advance Amount!")]
        [RegularExpression(@"^[0-9]+$", ErrorMessage = "Enter valid Advance Amount!")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "Paid On")]
        [Required(ErrorMessage = "Select Payment Date!")]
        public DateTime paymentDate { get; set; }

        [Display(Name = "Advance Payment Category")]
        [Required(ErrorMessage = "Select Advance Payment Category!")]
        public int CatId { get; set; }

        public string userIP { get; set; }

        public bool isCheckIn { get; set; }

        [Display(Name = "Current Room No.")]
        public string roomNo { get; set; }

        public Int64 currentRoomNoID { get; set; }

        public Int64 bookedRoomID { get; set; }

        public List<RoomDetails> allotedRoomList { get; set; }

        public List<RoomChangeDetails> roomDetailList { get; set; }

        public List<PaymentDetails> paymentDetailList { get; set; }

        public List<RoomAvailableDetails> availableRoomList { get; set; }

        public Int64 requestID { get; set; }

        public bool isPostBack { get; set; }
    }

    public class ARCCustomerRegistration : CustomerBooking
    {
        public Int64 userID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int? cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int? stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int? countryID { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }

        public string userIP { get; set; }

        public string roleID { get; set; }

        public string docketNo { get; set; }
        [Display(Name = "Identity Type")]
        public int? IdentityType { get; set; }

        public string bookingFor { get; set; }

        [Display(Name = "Receipt No.")]
        [Required(ErrorMessage = "Enter Receipt No.!")]
        public string receiptNo { get; set; }

        public Char customerType { get; set; }  // W - Walk In Guest, S - Staff Booking, B - Bulk Booking

        public string bookingXML { get; set; }

        public int tempRoomId { get; set; }

        public int tempRoomId2 { get; set; }

        public string tempRoomIdName { get; set; }

        [Display(Name = "Nationality")]
        [Required(ErrorMessage = "Select Nationality!")]
        public int? applicantType { get; set; }

        public int? nameTitle { get; set; }

        //public bool isCheckIn { get; set; }

        public string bookingBy { get; set; }

        [Display(Name = "Date of Birth")]
        public string dateOfBirth { get; set; }

        [Display(Name = "Age")]
        public int age { get; set; }

        public int availableRooms { get; set; }

        public decimal totalAmountPayable { get; set; }

        [Display(Name = "Advance Amount")]
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Advance Amount!")]
        [Required(ErrorMessage = "Enter Advance Amount!")]
        new public decimal? advanceAmount { get; set; }

        [Display(Name = "Unit Name")]
        [Required(ErrorMessage = "Select Unit!")]
        new public Int64 unitID { get; set; }

        [Display(Name = "Discount")]
        [Range(0, 20, ErrorMessage = "Discount can't be more than 20%!")]
        public decimal? discountPercentage { get; set; }

    }

    public class UnitSpecialPriceDeals
    {
        public Int64 dealID { get; set; }

        [Required(ErrorMessage = "Enter Deal Title!")]
        [Display(Name = "Deal Title")]
        [StringLength(200, ErrorMessage = "Deal Title should be upto 200 characters only!")]
        public string dealTitle { get; set; }

        [Required(ErrorMessage = "Enter Deal Description!")]
        [Display(Name = "Deal Description")]
        [StringLength(500, ErrorMessage = "Deal Description should be upto 500 characters only!")]
        public string dealDescription { get; set; }

        [Required(ErrorMessage = "Select From Date!")]
        [Display(Name = "From Date")]
        public DateTime? dealFromDate { get; set; }

        [Required(ErrorMessage = "Select To Date!")]
        [Display(Name = "To Date")]
        public DateTime? dealToDate { get; set; }

        [Required(ErrorMessage = "Enter Offer Price!")]
        [Display(Name = "Offer Price")]
        public decimal? dealAmount { get; set; }

        public decimal dealPercent { get; set; }

        [Display(Name = "Offer Type")]
        public bool isDealPercent { get; set; }

        [Required(ErrorMessage = "Select Unit!")]
        [Display(Name = "Unit")]
        public Int64 unitID { get; set; }

        [Required(ErrorMessage = "Select Room Type!")]
        [Display(Name = "Room Type")]
        public int[] roomType { get; set; }

        public IEnumerable<UnitSpecialPriceDealsDetail> lstUnitSpecialDeals { get; set; }
    }

    public class UnitSpecialPriceDealsDetail
    {
        public string dealTitle { get; set; }
        public string unitName { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string roomType { get; set; }
        public decimal dealAmount { get; set; }
        public decimal dealPercent { get; set; }
    }

    public class PackageCheckin
    {
        public Int64 unitID { get; set; }

        [Display(Name = "Docket No.")]
        [Required(ErrorMessage = "Enter Docket No.!")]
        public string docketNo { get; set; }

        public string name { get; set; }

        public string mobileNo { get; set; }

        public string onDate { get; set; }

        public string bookingThrough { get; set; }

        public string packageName { get; set; }

        public int noOfPerson { get; set; }

        public decimal advanceAmount { get; set; }

        public string AdvRecNo { get; set; }

        public string AdvPayDate { get; set; }

        public string userIP { get; set; }

        public bool isCheckIn { get; set; }

        public Nullable<DateTime> checkInTime { get; set; }

        public string roomNo { get; set; }

        public IList<PackageRoomDetail> lstBookedRoomDetail { get; set; }

        public List<RoomOccupancyDetails> lstBookedRoom { get; set; }


    }

    public class PackageCheckinDetails
    {

        public string onDate { get; set; }
        public string toDate { get; set; }
        public int noOfPerson { get; set; }
        public int noOfRoom { get; set; }
        public string docketNo { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string BookingFor { get; set; }
        public decimal amount { get; set; }
        public string bookingThrough { get; set; }
        public string packageName { get; set; }
        public string UnitName { get; set; }
        public int packageID { get; set; }
        public int unitID { get; set; }
        public string cancelRefNo { get; set; }
        public List<PackageDetailUnitWise> PackageDetailList { get; set; }
        public decimal advanceAmount { get; set; }
        public List<RoomOccupancyDetails> BookedRoomList { get; set; }
        public string bookingStatus { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string AdvRecNo { get; set; }
        public string CancelDate { get; set; }
        public string AdvPayDate { get; set; }
        public string arrivalDate { get; set; }
        public DateTime arrivalTime { get; set; }
        public string customerAddress { get; set; }
        public string subPackage { get; set; }
        public string bookingDate { get; set; }


        public string unitAddress { get; set; }
        public string unitMobile { get; set; }
        public string roomType { get; set; }
        public int noOfRooms { get; set; }
        public int extraBed { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string customerMobile { get; set; }
        public string duration { get; set; }
        public string meetingPoint { get; set; }
        public Boolean privilegeAvailability { get; set; }
        public string privilegeCardNo { get; set; }
        public string isPrivilegeVerified { get; set; }
        public string privilegeCardDate { get; set; }
        public decimal discountPercent { get; set; }
        public decimal discountAmt { get; set; }
        public IEnumerable<PackageToursAccomodation> IEPackageAccomodation { get; set; }
    }

    public class PackageRoomDetail
    {
        public Int64 requestID { get; set; }
        public int Sno { get; set; }
        public int? roomType { get; set; }
        public string roomTypeDisplay { get; set; }
        public int totalRoom { get; set; }
        public String SelectedRooms { get; set; }
        public DateTime checkInDate { get; set; }
        public DateTime checkOutDate { get; set; }
        public DateTime checkOutDateShow { get; set; }
        public int noOfGuests { get; set; }
        public bool isSelected { get; set; }
        public bool isCheckIn { get; set; }

        public string docketNo { get; set; }
        public string roomNo { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Check In Time!")]
        [Display(Name = "Check In Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Check In Time!")]
        [Required(ErrorMessage = "Enter Check In Time!")]
        public Nullable<DateTime> checkInTime { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        [Required(ErrorMessage = "Enter Check In Date!")]
        public Nullable<DateTime> actualCheckInDate { get; set; }

        public List<RoomDetails> lstRoomNoDetail { get; set; }
    }

    public class ChkInRooms
    {
        public Int64 RoomNoId { get; set; }
        public DateTime bookingDate { get; set; }
    }

    public class PackageCheckout
    {
        public Int64 unitID { get; set; }

        [Display(Name = "Docket No.")]
        [Required(ErrorMessage = "Enter Docket No.!")]
        public string docketNo { get; set; }

        public string name { get; set; }

        public string mobileNo { get; set; }

        public string onDate { get; set; }

        public string bookingThrough { get; set; }

        public string packageName { get; set; }

        public int noOfPerson { get; set; }

        public decimal advanceAmount { get; set; }

        public string AdvRecNo { get; set; }

        public string AdvPayDate { get; set; }

        public string userIP { get; set; }

        public bool isCheckOut { get; set; }

        public Nullable<DateTime> checkInTime { get; set; }

        public string roomNo { get; set; }

        public IList<PackageCheckOutRoomDetail> lstBookedRoomDetail { get; set; }

        public List<RoomOccupancyDetails> lstBookedRoom { get; set; }


    }

    public class PackageCheckOutRoomDetail
    {
        public Int64 requestID { get; set; }
        public int Sno { get; set; }
        public int? roomType { get; set; }
        public string roomTypeDisplay { get; set; }
        public int totalRoom { get; set; }
        public DateTime checkInDate { get; set; }
        public DateTime checkOutDate { get; set; }
        public DateTime checkOutDateShow { get; set; }
        public int noOfGuests { get; set; }
        public bool isSelected { get; set; }
        public bool isCheckOut { get; set; }
        public string docketNo { get; set; }
        public string roomNo { get; set; }
        public Nullable<DateTime> checkInTime { get; set; }
        public Nullable<DateTime> actualCheckInDate { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Check Out Time!")]
        [Display(Name = "Check Out Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Check Out Time!")]
        [Required(ErrorMessage = "Enter Check Out Time!")]
        public Nullable<DateTime> checkOutTime { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check Out Date")]
        [Required(ErrorMessage = "Enter Check Out Date!")]
        public Nullable<DateTime> actualCheckOutDate { get; set; }

        public List<RoomDetails> lstRoomNoDetail { get; set; }
    }

    public class LawnBanquetBooking
    {
        public string docketNo { get; set; }
        public DateTime ForDate { get; set; }
        public string BookingFor { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public string email { get; set; }
        public string functionName { get; set; }
        public decimal? advanceAmount { get; set; }
        public decimal? Tariff { get; set; }
        public string bookingBy { get; set; }
        public string UnitName { get; set; }
        public string DestinationName { get; set; }
        public bool IsBilled { get; set; }
        public DateTime? dateFrom { get; set; }
        public DateTime? dateTo { get; set; }
        public long? UnitId { get; set; }
    }

    public class UnitLawnBanquetBooking
    {
        public Int64 userID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be up to 150 characters only!")]
        public string name { get; set; }


        [Display(Name = "Email")]
        //[Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be up to 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        //[Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be up to 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "City")]
        //[Required(ErrorMessage = "Select City!")]
        public int? cityID { get; set; }

        [Display(Name = "City")]
        //[Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be up to 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        //[Required(ErrorMessage = "Select State!")]
        public int? stateID { get; set; }

        [Display(Name = "State")]
        //[Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be up to 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        //[Required(ErrorMessage = "Select Country!")]
        public int? countryID { get; set; }

        [Display(Name = "Pincode")]
        //[Required(ErrorMessage = "Enter Pincode!")]
        //[StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        //[RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        [Display(Name = "Phone No.")]
        //[Required(ErrorMessage = "Enter Phone No.!")]
        [StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")]
        public string phone { get; set; }

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }
        public string userIP { get; set; }

        public string roleID { get; set; }
        public string docketNo { get; set; }

        [Display(Name = "Identity Type")]

        //[Required(ErrorMessage = "Select Identity Type!")]
        public int? IdentityType { get; set; }

        public int isOtherStateCityRequired
        {
            get
            {
                return countryID != 98 ? 1 : 0;
            }
        }

        [Display(Name = "Function")]
        [Required(ErrorMessage = "Select Function!")]
        public int functionID { get; set; }
        public int? nameTitle { get; set; }

        [Required(ErrorMessage = "Select Check In!")]
        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Display(Name = "Check In Date")]
        public DateTime checkInDate { get; set; }

        [Required(ErrorMessage = "Tariff Required!")]
        [Display(Name = "Tariff")]
        public decimal Tariff { get; set; }

        [Display(Name = "Advance Amount")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "Receipt No")]
        public string advanceReceptNo { get; set; }

        [Display(Name = "Booking For")]
        [Required(ErrorMessage = "Select Booking For!")]
        public string Bookingfor { get; set; }

        public string bookingBy { get; set; }

        [Display(Name = "Date of Birth")]
        public string dateOfBirth { get; set; }

        [Display(Name = "Age")]
        public int age { get; set; }

    }

    public class BookingChange
    {
        public string DocketNo { get; set; }
        public Int64 requestID { get; set; }
        public int singleRoom { get; set; }
        public int doubleRoom { get; set; }
        public string Roomtype { get; set; }
        public int noOfRooms { get; set; }


        public string onDate { get; set; }
        public string toDate { get; set; }
        public int noOfPerson { get; set; }


        public string name { get; set; }
        public string mobileNo { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string BookingFor { get; set; }
        public decimal amount { get; set; }
        public string bookingThrough { get; set; }
        public string packageName { get; set; }
        public string UnitName { get; set; }
        public int packageID { get; set; }
        public int unitID { get; set; }
        public string cancelRefNo { get; set; }
        public List<PackageDetailUnitWise> PackageDetailList { get; set; }
        public decimal advanceAmount { get; set; }
        public List<RoomOccupancyDetails> BookedRoomList { get; set; }
        public string bookingStatus { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string AdvRecNo { get; set; }
        public string CancelDate { get; set; }
        public string AdvPayDate { get; set; }
        public string arrivalDate { get; set; }
        public DateTime arrivalTime { get; set; }
        public string customerAddress { get; set; }
        public string subPackage { get; set; }
        public string bookingDate { get; set; }

        public string unitAddress { get; set; }
        public string unitMobile { get; set; }


        public int extraBed { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string customerMobile { get; set; }
        public string duration { get; set; }
        public string meetingPoint { get; set; }
        public Boolean privilegeAvailability { get; set; }
        public string privilegeCardNo { get; set; }
        public string isPrivilegeVerified { get; set; }
        public string privilegeCardDate { get; set; }
        public decimal discountPercent { get; set; }
        public decimal discountAmt { get; set; }
        public IEnumerable<PackageToursAccomodation> IEPackageAccomodation { get; set; }
        public List<RoomBookingDetails> roomdetList { get; set; }
        public List<AdvanceAmountDetails> AdvanceAmountdetList { get; set; }
        public List<SpecialBookedDetail> SpecBookingDetls { get; set; }
    }

    public class RoomBookingDetails
    {
        public string docketNo { get; set; }
        public Int64 requestID { get; set; }
        public int singleRoom { get; set; }
        public int doubleRoom { get; set; }
        public string Roomtype { get; set; }
        public int noOfRooms { get; set; }
    }

    public class AdvanceAmountDetails
    {
        public Int64 advancePaymentID { get; set; }
        public string docketNo { get; set; }
        [Required(ErrorMessage = "Advance Amount Required!")]
        public decimal advanceAmount { get; set; }
        [Required(ErrorMessage = "Payment Date Required!")]
        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [RegularExpression(@"^(0?[1-9]|[12][0-9]|3[01])[\/\-](0?[1-9]|1[012])[\/\-]\d{4}$", ErrorMessage = "Enter a Valid Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public string paymentDate { get; set; }
        [Required(ErrorMessage = "Receipt No. Required!")]
        public string receiptNo { get; set; }
    }

    public class BanquitLawnBill
    {
        [Required(ErrorMessage = "Enter Docket No !")]
        public string docketNo { get; set; }
        public string billNo { get; set; }
        public DateTime ForDate { get; set; }
        public string BookingFor { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public string email { get; set; }
        public string functionName { get; set; }
        public decimal? advanceAmount { get; set; }
        public decimal? Tariff { get; set; }
        public string bookingBy { get; set; }
        public string UnitName { get; set; }
        public string DestinationName { get; set; }
        [Required(ErrorMessage = "Bill Date Required!")]
        [DataType(DataType.Date, ErrorMessage = "Bill Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime BillDate { get; set; }

        public string BillDateShow { get; set; }
        public string Address { get; set; }
        public decimal ServiceTax { get; set; }
        public decimal Luxurytax { get; set; }
        public decimal ServiceTaxAmount { get; set; }
        public decimal LuxurytaxAmount { get; set; }
        public decimal DiscountPer { get; set; }
        public decimal DiscountAmount { get; set; }

        public decimal OtherAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public decimal NetPayble { get; set; }
        public decimal GuestAdvanceAmt { get; set; }

        public string UnitAddress { get; set; }
        public string UnitEmail { get; set; }
        public string UnitPhone { get; set; }
        public string serTaxNo { get; set; }
        public string tinNo { get; set; }
        public string tanNo { get; set; }
        public string panNo { get; set; }

        public string CRSEmail { get; set; }
        public string AdvanceDate { get; set; }

    }

    public class UnitBanqlawnBooking
    {
        public DateTime? dtBookingDateFrom { get; set; }
        public DateTime? dtBookingDateTo { get; set; }
        public string docketNo { get; set; }
        public Int64 unitID { get; set; }
        public IEnumerable<LawnBanquetBooking> BanqLawnBookedList { get; set; }
        public DateTime dtCurrent { get; set; }
    }
    public class UnitReportGST
    {
        public Int64 unitID { get; set; }
        public DateTime? toDate { get; set; }
        public DateTime? fromDate { get; set; }
        public string UnitName { get; set; }
        public string RoomDetails { get; set; }
        public string guestName { get; set; }
        public DateTime bookingDate { get; set; }
        public decimal RoomRent { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal taxAmount { get; set; }
        public decimal amount { get; set; }
        public string roomType { get; set; }
        //public List<UnitReportGST> GetGSTView { get; set; }
        public string docketNo { get; set; }
        public string bookingBy { get; set; }
        public int stayInDays { get; set; }

    }
    public class ViewreportGST
    {
        public Int64 unitID { get; set; }
        public DateTime? toDate { get; set; }
        public DateTime? fromDate { get; set; }
        public IEnumerable<UnitReportGST> GetGSTView { get; set; }
        public string bookingBy { get; set; }
    }
    public class GSTBookingDetail
    {
        public int roomID { get; set; }
        public Int64 UnitID { get; set; }
        public string UnitName { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal roomRent { get; set; }
        public decimal taxAmount { get; set; }
        public Int64 userID { get; set; }
        public int BookingCount { get; set; }
        public string bookingBy { get; set; }
        public decimal Amount { get; set; }
        public DateTime bookingDate { get; set; }
        public IEnumerable<GSTBookingDetail> BookingGSTList { get; set; }
    }

    public class LawnBanquetBookingCancle
    {
       // public string MobileNo { get; set; }
        public string Email { get; set; }
        public string sendTo { get; set; }
        public string onDate { get; set; }
        public string toDate { get; set; }
        public int noOfPerson { get; set; }
        public int noOfRoom { get; set; }
        public string docketNo { get; set; }
        public string name { get; set; }
        //public string mobileNo { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string BookingFor { get; set; }
        public decimal amount { get; set; }
        public string bookingThrough { get; set; }
        public string packageName { get; set; }
        public string UnitName { get; set; }
        public int packageID { get; set; }
        public int unitID { get; set; }
        public string cancelRefNo { get; set; }
        public decimal advanceAmount { get; set; }
        public string bookingStatus { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string AdvRecNo { get; set; }
        public string CancelDate { get; set; }
        public string AdvPayDate { get; set; }
        public string arrivalDate { get; set; }
        public DateTime arrivalTime { get; set; }
        public string customerAddress { get; set; }
        public string subPackage { get; set; }
        public string bookingDate { get; set; }
        public string unitAddress { get; set; }
        public string unitMobile { get; set; }
        public string roomType { get; set; }
        public int noOfRooms { get; set; }
        public int extraBed { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string customerMobile { get; set; }
        public string duration { get; set; }
        public string meetingPoint { get; set; }
        public Boolean privilegeAvailability { get; set; }
        public string privilegeCardNo { get; set; }
        public string isPrivilegeVerified { get; set; }
        public string privilegeCardDate { get; set; }
        public decimal discountPercent { get; set; }
        public decimal discountAmt { get; set; }
        public int dayRemaining { get; set; }
        public int refaundAmountPer { get; set; }
        public decimal refaundAmount { get; set; }
        public decimal refaundPer { get; set; }
        public string cityname { get; set; }
        public string daySequence { get; set; }

     
        public string ForDate { get; set; }
        public string enquiryType { get; set; }
        //public string email { get; set; }
        public string mobileNo { get; set; }
       
        public string functionName { get; set; }
        public string noOfTourists { get; set; }
      
        public string phoneNo { get; set; }
        public string transactionStatus { get; set; }
        public string transactionID { get; set; }
        public string PaymentID { get; set; }
        public string transactionAmount { get; set; }
        public string currency { get; set; }
        public DateTime transactionDate { get; set; }

        public IEnumerable<LawnBanquetBookingCancle> CancelDetail { get; set; }





        



    }


}