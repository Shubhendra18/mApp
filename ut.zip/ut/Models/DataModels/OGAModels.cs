﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace UP_TourismBooking.Models.DataModels
{
    public class OGAModel
    {
        [Required(ErrorMessage = "Name is required.")]
        [Display(Name = "Name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Address is required.")]
        [Display(Name = "Address")]
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        [Required(ErrorMessage = "Contact No is required.")]
        [Display(Name = "Contact No")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Please enter correct mobile no.")]
        public string ContactNo { get; set; }
        [Display(Name = "Email-Id")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$", ErrorMessage = "Please enter correct email address")]
        public string EmailId { get; set; }
        public string IpAddress { get; set; }

        [Required(ErrorMessage = "Enter Captcha Text!")]
        public string captcha { get; set; }
    }
}