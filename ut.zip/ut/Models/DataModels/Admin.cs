﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Data;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class PackageCategory
    {
        public int PackageCategoryID { get; set; }

        [Required(ErrorMessage = "Enter Category Name!")]
        [Display(Name = "Category Name")]
        [StringLength(200, ErrorMessage = "Upto 200 Characters Only!")]
        public string PackageCategoryName { get; set; }

        public IEnumerable<PackageCategory> IEPackageCategory { get; set; }
    }

    public class Package
    {
        public int PackageID { get; set; }

        [Required(ErrorMessage = "Select Category!")]
        [Display(Name = "Category")]
        public int PackageCategoryID { get; set; }

        [Required(ErrorMessage = "Enter Package Name!")]
        [Display(Name = "Package Name")]
        [StringLength(200, ErrorMessage = "Upto 200 Characters Only!")]
        public string PackageName { get; set; }

        [Required(ErrorMessage = "Enter Package Code!")]
        [Display(Name = "Package Code")]
        [StringLength(200, ErrorMessage = "Upto 200 Characters Only!")]
        public string PackageCode { get; set; }

        public string PackageCategoryName { get; set; }

        public IEnumerable<Package> IEPackage { get; set; }
    }

    public class PackageDetails
    {
        public int PackageID { get; set; }

        public string PackageName { get; set; }

        public string PackageCode { get; set; }

        public string PackageCategoryName { get; set; }
    }


    public class Contact
    {
        public int PackageID { get; set; }

        public Int64 ContactID { get; set; }

        [Required(ErrorMessage = "Enter Contact Name!")]
        [Display(Name = "Contact Name")]
        [StringLength(200, ErrorMessage = "Upto 200 Characters Only!")]
        public string ContactName { get; set; }

        [Required(ErrorMessage = "Enter Contact Name!")]
        [Display(Name = "Contact Number")]
        [RegularExpression(@"^(\d{10,12})$", ErrorMessage = "Enter a valid Contact No.!")]
        public string ContactNo { get; set; }

        [Required(ErrorMessage = "Select Unit!")]
        [Display(Name = "Unit")]
        public Int64 UnitID { get; set; }

        public string UnitName { get; set; }

        public IEnumerable<Contact> IEContact { get; set; }
    }

    public class Unit
    {
        public Int64 UnitID { get; set; }

        public string UnitName { get; set; }
    }

    public class TermCondition
    {
        public int TermID { get; set; }

        [Required(ErrorMessage = "Enter Terms & Condition!")]
        [Display(Name = "Terms & Condition")]
        [AllowHtml]
        public string TermsCondition { get; set; }

        [Required(ErrorMessage = "Enter Cancellation Policy!")]
        [Display(Name = "Cancellation Policy")]
        [AllowHtml]
        public string CancellationPolicy { get; set; }

        public int PackageID { get; set; }
    }

    public class Overview
    {
        public int OverviewID { get; set; }

        [Required(ErrorMessage = "Enter Description!")]
        [Display(Name = "Description")]
        public string Description { get; set; }


        public string Destination { get; set; }
        public string TravelMode { get; set; }
        public string Frequency { get; set; }
        public string MealPaln { get; set; }
        public string Units { get; set; }

        public int PackageID { get; set; }
    }

    public class Destinations
    {
        public Int64 DestinationID { get; set; }

        [Required(ErrorMessage = "Enter Destination Name!")]
        [Display(Name = "Destination")]
        public String DestinationName { get; set; }

        public Int64 UserID { get; set; }
    }

    public class UnitBookingAtAGlanceHeader
    {
        public string RoomTypeheader { get; set; }
    }

    public class BookingatAglance
    {
        [Required(ErrorMessage="Select Month !")]
        [Display (Name="Month")]
        public int MonthId { get; set; }

        [Display(Name = "Year")]
         [Required(ErrorMessage = "Select Year !")]
        public int YearId { get; set; }
        public List<UnitBookingAtAGlanceHeader> HeaderList { get; set; }
        public DataTable DtReport { get; set; }
    }

    public class AllUnitBookingHQHeader
    {
        public Int64 UnitID { get; set; }
        public string UnitHeader { get; set; }
    }

    public class AllUnitBookingHQ
    {
        [Required(ErrorMessage = "Select Month !")]
        [Display(Name = "Month")]
        public int MonthId { get; set; }

        [Display(Name = "Year")]
        [Required(ErrorMessage = "Select Year !")]
        public int YearId { get; set; }
        public List<AllUnitBookingHQHeader> HeaderList { get; set; }
        public DataTable DtReport { get; set; }
    }


    public class BillRevenueDetails
    {
        public string docketNo { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public decimal discountAmt { get; set; }
        public decimal amountAfterDis { get; set; }
        public decimal TotalAmt { get; set; }
        public decimal roundOff { get; set; }
        public decimal serviceTax { get; set; }
        public decimal serviceTaxAmt { get; set; }
        public decimal luxuryTaxAmt { get; set; }
        public decimal luxuryTax { get; set; }
        public decimal netPayble { get; set; }
        public string billNo { get; set; }
        public string billDate { get; set; }
     

    }

    public class UnitRevenueRepoprt
    {
        public DateTime fromDate { get; set; }
        public DateTime Todate { get; set; }
        public string reportType { get; set; }
        public Int64 UnitId { get; set; }
        public List<BillRevenueDetails> billList { get; set; }

    }
}