﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace UP_TourismBooking.Models.DataModels
{
    public class GuestBasicInfo
    {
        public String docketNo { get; set; }
        public String name { get; set; }
        public String mobileNo { get; set; }
        public String address { get; set; }
        public String cityName { get; set; }
        public String stateName { get; set; }
        public String countryName { get; set; }
        public String pincode { get; set; }
    }

    public class ReleseBusTaxi          
    {
        [Required(ErrorMessage = "Required")]
        public String DocketNo { get; set; }
        public List<BusTaxiBookingDetails> busTaxiBookingList { get; set; }
        public List<BusTaxiDetails> busTaxiDetails { get; set; }
        [Display(Name = "Arival Date")]
        [Required(ErrorMessage = "Required!")]
        [DataType(DataType.Date, ErrorMessage = "Date of Journey should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]        
        public DateTime ReleseDate { get; set; }

        [Required(ErrorMessage = "Required!")]
        public int ExtraKm { get; set; }
        [Required(ErrorMessage = "Required!")]
        public Decimal ExtraKmCharges { get; set; }
        [Required(ErrorMessage = "Required!")]
        public int ExtrHours { get; set; }
        [Required(ErrorMessage = "Required!")]
        public Decimal ExtrHoursCharges { get; set; }
        [Required(ErrorMessage = "Required!")]
        public int ExtraDays { get; set; }
        [Required(ErrorMessage = "Required!")]
        public Decimal ExtraNightHaltCharges { get; set; }
        public Decimal OtherAmount { get; set;}
        public Decimal NetPaybal { get; set; }
        public int BusTaxiId { get; set; }
        public int RequestId { get; set; }
        public string billNo { get; set; }
        public bool HasGuid { get; set; }
        public Decimal GuideTariff { get; set; }
        [Required(ErrorMessage="Vehicle No. Required")]
        public string VehicleNo { get; set; }

        [Required(ErrorMessage = "Driver Name Required")]
        public string DriverName { get; set; }

        [Required(ErrorMessage = "Open Meter Reading Required")]
        public string OpenMeterReading { get; set; }
        [Required(ErrorMessage = "Closing Meter Reading Required")]
        public string ClosingMeterReading { get; set; }

        [Required(ErrorMessage = "Opening Time  Required")]
        //[RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid time.")]      
        [InputMask("99:99")]
        [DataType(DataType.Time, ErrorMessage = "Opening Time should be valid time!")]
        public DateTime? OpeningTime { get; set; }

        [Required(ErrorMessage = "Open Date Required")]
        [DataType(DataType.Date, ErrorMessage = "Open Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? OpenDate { get; set; }

        [Required(ErrorMessage = "Closing Time Required")]
        //[RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid time.")]
        [Display(Name = "Check Out Time")]
        [InputMask("99:99")]
        [DataType(DataType.Time, ErrorMessage = "Closing Time should be valid time!")]
        public DateTime? ClosingTime { get; set; }

        [Required(ErrorMessage = "Closing Date Required")]
        [DataType(DataType.Date, ErrorMessage = "Closing Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? ClosingDate { get; set; }
        public int? uptoursid { get; set; }
        
    }

    public class BusTaxiBillDetails
    {
        public string Name { get; set; }
        public string billNo { get; set; }
        public string Address { get; set; }
        public string mobileNo { get; set; }
        public string noOfTourists { get; set; }
        public string BookedThrough { get; set; }
        public string ArrivalDate { get; set; }
        public string ArrivalTime { get; set; }
        public decimal advanceAmount { get; set; }
        public decimal TotalTariffwithTax { get; set; }
        public decimal BaseTariff { get; set; }
        public decimal serviceTaxPer { get; set; }
        public decimal serviceTaxAmt { get; set; }
        public int AdditionalKm { get; set; }
        public decimal ExtraKmCharges { get; set; }
        public int Extradays { get; set; }
        public decimal ExtraNightHaltCharges { get; set; }
        public decimal ExtraHours { get; set; }
        public decimal ExtraHoursCharges { get; set; }
        public decimal OtherAmount { get; set; }
        public decimal NetPaybal { get; set; }
        public string BookingFor { get; set; }
        public string docketNo { get; set; }
        public string BookedBy { get; set; }
        public string UptoursName { get; set; }
        public int Duration { get; set; }
       
        public string BusTaxiName { get; set; }
        public string BillDate { get; set; }
        public string hasGuid { get; set; }
        public decimal Guidtariff { get; set; }
       
        public string VehicleNo { get; set; }
        public string DriverName { get; set; }
        public string OpenMeterReading { get; set; }
        public string ClosingMeterReading { get; set; }
        public string OpeningTime { get; set; }
        public string OpenDate { get; set; }
        public string ClosingTime { get; set; }
        public string ClosingDate { get; set; }
       
        public string UPTAddress { get; set; }
        public string PhoneNo{ get; set; }
        public string FaxNo{ get; set; }
        public string managerEmail { get; set; }
        public string CRSEmail { get; set; }
        public string AdvanceDate { get; set; }
        public string KM { get; set; }
    }


}