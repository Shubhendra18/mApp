﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Dynamic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class PackageTours
    {
        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int packageCategoryID { get; set; }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfTourists { get; set; }

        [Required(ErrorMessage = "Select Nationality!")]
        [Display(Name = "Nationality")]
        public Int16 isIndian { get; set; }

        public int noOfRooms { get; set; }

        public int packageID { get; set; }

        public string packageName { get; set; }

        public string destinationCovered { get; set; }

        public string overview { get; set; }

        public int durationNight { get; set; }

        public int durationDays { get; set; }

        public string availability { get; set; }

        public string imagePath { get; set; }

        public string imageCaption { get; set; }

        public string packageCategoryName { get; set; }

        public decimal totalAmount { get; set; }

        public string nationality { get; set; }

        public bool isBookable { get; set; }

        public bool isAvailable { get; set; }

        public IEnumerable<PackageTours> IEPackageTours { get; set; }

        public string TourType { get; set; }
    }

    public class PackagePayment : PostPaymentData
    {
        public int packageCategoryID { get; set; }

        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "Arrival Time")]
        public DateTime arrivalTime { get; set; }

        [Display(Name = "No. of Persons")]
        public int noOfTourists { get; set; }

        public Int16 isIndian { get; set; }
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string destinationCovered { get; set; }
        public int durationNight { get; set; }
        public int durationDays { get; set; }
        public string availability { get; set; }
        public string imagePath { get; set; }
        public string imageCaption { get; set; }
        public decimal packageAmount { get; set; }

        [Display(Name = "Total Price")]
        public decimal totalAmount { get; set; }

        [Display(Name = "Nationality")]
        public string nationality { get; set; }

        [Display(Name = "Destination")]
        public string packageCategoryName { get; set; }

        [Display(Name = "Name")]
        public string customerName { get; set; }

        [Display(Name = "Email")]
        public string customerEmail { get; set; }

        [Display(Name = "Mobile No.")]
        public string customerMobile { get; set; }

        [Display(Name = "Rooms")]
        public int noOfRooms { get; set; }

        public string userIP { get; set; }

        [Display(Name = "Applicant Type")]
        public string ApplicantType { get; set; }
        public int maxBookingAllowed { get; set; }

        public int isTaxCalculated { get; set; }
        public decimal taxPercentage { get; set; }
        public decimal packageAmountIncludingGST { get; set; }
    
        public decimal CalculatedGST {get;set;}
        public decimal taxAmount { get; set; }

        
    }

    public class PackageQuery
    {
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [StringLength(200, ErrorMessage = "Name should be upto 200 characters only!")]
        public string name { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string emailID { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(100, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        public string queryFor { get; set; }

        public int packageID { get; set; }

        [Display(Name = "Query")]
        [Required(ErrorMessage = "Enter Query!")]
        [StringLength(500, ErrorMessage = "Query should be upto 500 characters only!")]
        public string query { get; set; }

        public string packageName { get; set; }

        public string queryDate { get; set; }

        [Display(Name = "Captcha")]
        [Required(ErrorMessage = "Enter Captcha Text!")]
        public string Captcha { get; set; }
    }

    public class PostPaymentData
    {
        public string channel { get; set; }
        public string reference_no { get; set; }
        public decimal amount { get; set; }
        public string mode { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string postalCode { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string shipName { get; set; }
        public string shipAddress { get; set; }
        public string shipCountry { get; set; }
        public string shipState { get; set; }
        public string shipCity { get; set; }
        public string shipPostalCode { get; set; }
        public string shipPhone { get; set; }
        public string secure_hash { get; set; }
        public string secrectKey { get; set; }
        public string accountId { get; set; }
        public Int64 RequestID { get; set; }
        public string docketNo { get; set; }
        public string returnUrl { get; set; }
        public string bankCode { get; set; }
        public string nameOnCard { get; set; }
        public string cardNumber { get; set; }
        public string cardExpiry { get; set; }
        public string paymentOption { get; set; }
        public string paymentMode { get; set; }
        public string cardBrand { get; set; }
        public string emi { get; set; }
        public string pageId { get; set; }
        public string cardCVV { get; set; }
        public string secureHash { get; set; }
        public int bookStatus { get; set; }
        public bool isBookable { get; set; }
    }

    public class UnitBooking
    {
        [Required(ErrorMessage = "Select Destination!")]
        [Display(Name = "Choose Your Destination")]
        public Int64 destinationID { get; set; }

        [Required(ErrorMessage = "Select Destination!")]
        [Display(Name = "Choose Your Destination")]
        public Int64 lawnDestinationID { get; set; }

        [Required(ErrorMessage = "Select Destination!")]
        [Display(Name = "Choose Your Destination")]
        public Int64 banquetDestinationID { get; set; }

        [Required(ErrorMessage = "Select Check In!")]
        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        public DateTime checkInDate { get; set; }

        [Required(ErrorMessage = "Select Check Out!")]
        [DataType(DataType.Date, ErrorMessage = "Check Out Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check Out Date")]
        public DateTime checkOutDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        [Display(Name = "No. of Rooms")]
        [Required(ErrorMessage = "Enter No. of Rooms!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfRooms { get; set; }

        public DateTime currentDate { get; set; }

        public int unitCount { get; set; }

        public string destinationName { get; set; }

        public Int64 unitID { get; set; }

        public string unitName { get; set; }

        public string address { get; set; }

        public string briefDescription { get; set; }

        public string imagePath { get; set; }

        public int noOfDays { get; set; }

        public List<UnitBooking> IEunit { get; set; }

        public List<UnitAmenities> IEUnitAmenities { get; set; }

        public List<dynamic> IEUnitRooms { get; set; }

        [Required(ErrorMessage = "Select Booking Date!")]
        [DataType(DataType.Date, ErrorMessage = "Booking Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Booking Date")]
        public DateTime lawnBookingDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfLawnGuest { get; set; }

        [Required(ErrorMessage = "Select Function Type!")]
        [Display(Name = "Function Type")]
        public int functionID { get; set; }

        [Required(ErrorMessage = "Select Booking Date!")]
        [DataType(DataType.Date, ErrorMessage = "Booking Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Booking Date")]
        public DateTime banquetBookingDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfBanquetGuest { get; set; }

        [Required(ErrorMessage = "Select Function Type!")]
        [Display(Name = "Function Type")]
        public int banquetFunctionID { get; set; }


    }

    public class UnitAmenities
    {
        public int packageID { get; set; }

        public string amenities { get; set; }

        public string amenityClass { get; set; }
    }

    public class UnitRooms
    {
        public string roomType { get; set; }

        public int roomTypeID { get; set; }

        public string avalaibility { get; set; }

        public bool isAvailable { get; set; }

        public decimal singleRoomAmount { get; set; }

        public decimal doubleRoomAmount { get; set; }

        public int roomID { get; set; }

        public string roomImage { get; set; }

        public Int16 maxCapacity { get; set; }

        public bool hasOccupancy { get; set; }

        public int maxExtraBed { get; set; }
    }

    public class UnitPayment : PostPaymentData
    {
        [Display(Name = "Check In Date")]
        public DateTime checkInDate { get; set; }

        [Display(Name = "Check Out Date")]
        public DateTime checkOutDate { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfGuests { get; set; }

        [Display(Name = "No. of Rooms")]
        public int noOfRooms { get; set; }

        [Display(Name = "Total Price")]
        public decimal totalAmount { get; set; }

        public bool isPrivilege { get; set; }

        public decimal discountAmount { get; set; }

        public decimal discountPercent { get; set; }

        public decimal amount { get; set; }

        public decimal taxAmount { get; set; }

        [Display(Name = "Name")]
        public string customerName { get; set; }

        [Display(Name = "Email")]
        public string customerEmail { get; set; }

        [Display(Name = "Mobile No.")]
        public string customerMobile { get; set; }

        [Display(Name = "Single")]
        [Required(ErrorMessage = "Enter No. of Rooms (Single)")]
        public int singleRoom { get; set; }

        [Display(Name = "Double")]
        [Required(ErrorMessage = "Enter No. of Rooms (Double)")]
        public int doubleRoom { get; set; }

        [Display(Name = "Room Type")]
        public string roomType { get; set; }

        [Display(Name = "Extra Bed")]
        public int extraBed { get; set; }

        public Int16 maxCapacity { get; set; }
        public bool hasOccupancy { get; set; }
        public Int64 unitID { get; set; }
        public int roomID { get; set; }
        public string unitName { get; set; }
        public string unitAddress { get; set; }
        //public string availability { get; set; }
        public string imagePath { get; set; }
        public string imageCaption { get; set; }
        public string userIP { get; set; }
        [Display(Name = "Destination")]
        public string destination { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        [Display(Name = "Privilege Card Date")]
        [DataType(DataType.Date, ErrorMessage = "Privilege Card Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public Nullable<DateTime> privilegeCardDate { get; set; }

        public List<UnitAmenities> LstUnitAmenities { get; set; }
    }

    public class CityTourCategory
    {
        public int PackageCategoryID { get; set; }

        [Required(ErrorMessage = "Enter Category Name!")]
        [Display(Name = "Category Name")]
        [StringLength(200, ErrorMessage = "Upto 200 Characters Only!")]
        public string PackageCategoryName { get; set; }
    }

    public class CityTours
    {
        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int packageCategoryID { get; set; }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfTourists { get; set; }

        [Required(ErrorMessage = "Select Nationality!")]
        [Display(Name = "Nationality")]
        public Int16 isIndian { get; set; }

        public int packageID { get; set; }

        public string packageName { get; set; }

        public string destinationCovered { get; set; }

        public string briefDescription { get; set; }

        public string overview { get; set; }

        public int durationNight { get; set; }

        public string durationDays { get; set; }

        public string availability { get; set; }

        public string imagePath { get; set; }

        public string packageCategoryName { get; set; }

        public decimal totalAmount { get; set; }

        public string nationality { get; set; }

        public bool isBookable { get; set; }

        public bool isAvailable { get; set; }

        public IEnumerable<CityTours> IECityTours { get; set; }
    }

    public class CityTourQuery
    {
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [StringLength(200, ErrorMessage = "Name should be upto 200 characters only!")]
        public string name { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string emailID { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(100, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        public string queryFor { get; set; }

        public int packageID { get; set; }

        [Display(Name = "Query")]
        [Required(ErrorMessage = "Enter Query!")]
        [StringLength(500, ErrorMessage = "Query should be upto 500 characters only!")]
        public string query { get; set; }

        public string packageName { get; set; }

        public string queryDate { get; set; }

        [Display(Name = "Captcha")]
        [Required(ErrorMessage = "Enter Captcha Text!")]
        public string Captcha { get; set; }
    }

    public class CityTourPayment : PostPaymentData
    {
        public int packageCategoryID { get; set; }

        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        public int noOfTourists { get; set; }

        public Int16 isIndian { get; set; }
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string destinationCovered { get; set; }
        public int durationNight { get; set; }
        public string durationDays { get; set; }
        public string availability { get; set; }
        public string imagePath { get; set; }
        public string imageCaption { get; set; }
        public decimal packageAmount { get; set; }

        [Display(Name = "Total Price")]
        public decimal totalAmount { get; set; }

        [Display(Name = "Nationality")]
        public string nationality { get; set; }

        [Display(Name = "Destination")]
        public string packageCategoryName { get; set; }

        [Display(Name = "Name")]
        public string customerName { get; set; }

        [Display(Name = "Email")]
        public string customerEmail { get; set; }

        [Display(Name = "Mobile No.")]
        public string customerMobile { get; set; }

        public string userIP { get; set; }
        public int isTaxCalculated { get; set; }
        public decimal taxPercentage { get; set; }
        public decimal packageAmountIncludingGST { get; set; }
        public decimal CalculatedGST { get; set; }
        public decimal taxAmount { get; set; }

    }

    public class UnitTransactionDetail
    {

        public string docketNo { get; set; }
        public string unitName { get; set; }
        public string unitAddress { get; set; }
        public string unitMobile { get; set; }
        public string roomType { get; set; }
        public int noOfRooms { get; set; }
        public string name { get; set; }
        public string customerAddress { get; set; }
        public string email { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string transactionStatus { get; set; }
        public string transactionID { get; set; }
        public string bankRefNo { get; set; }
        public string transactionAmount { get; set; }
        public string currency { get; set; }
        public string transactionDate { get; set; }
        public string customerMobile { get; set; }
        public int extraBed { get; set; }
        public string bookingBy { get; set; }
        public string checkinDate_New { get; set; }
        public string checkoutDate_New { get; set; }
        public string Note { get; set; }
    }

    public class PackageTransactionDetail
    {
        public string docketNo { get; set; }
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string subPackage { get; set; }
        public string duration { get; set; }
        public string noOfTourists { get; set; }
        public string arrivalDate { get; set; }
        public string meetingPoint { get; set; }
        public string name { get; set; }
        public string customerAddress { get; set; }
        public string email { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string transactionStatus { get; set; }
        public string transactionID { get; set; }
        public string bankRefNo { get; set; }
        public string transactionAmount { get; set; }
        public string currency { get; set; }
        public string transactionDate { get; set; }
        public string customerMobile { get; set; }
        public decimal amount { get; set; }
        public string bookingDate { get; set; }
        public string bookingBy { get; set; }

        public string UptoursName { get; set; }
        public string UPToursAddress { get; set; }
        public string managerMobileNo { get; set; }
        public string PhoneNo { get; set; }
        public string managerEmail { get; set; }


        public IEnumerable<PackageToursAccomodation> IEPackageAccomodation { get; set; }
    }

    public class SpecialPackageTransactionDetail
    {
        public string docketNo { get; set; }
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string subPackage { get; set; }
        public string duration { get; set; }
        public string noOfTourists { get; set; }
        public string arrivalDate { get; set; }
        public string meetingPoint { get; set; }
        public string name { get; set; }
        public string customerAddress { get; set; }
        public string email { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string transactionStatus { get; set; }
        public string transactionID { get; set; }
        public string bankRefNo { get; set; }
        public string transactionAmount { get; set; }
        public string currency { get; set; }
        public string transactionDate { get; set; }
        public string customerMobile { get; set; }
        public DateTime arrivalTime { get; set; }

        public string UptoursName { get; set; }
        public string UPToursAddress { get; set; }
        public string managerMobileNo { get; set; }
        public string PhoneNo { get; set; }
        public string managerEmail { get; set; }

    }

    public class ACBusTours
    {
        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfTourists { get; set; }

        [Required(ErrorMessage = "Select Nationality!")]
        [Display(Name = "Nationality")]
        public Int16 isIndian { get; set; }

        public int packageID { get; set; }

        public string packageName { get; set; }

        public string destinationCovered { get; set; }

        public string briefDescription { get; set; }

        public int durationNight { get; set; }

        public string availability { get; set; }

        public string imagePath { get; set; }

        public decimal totalAmount { get; set; }

        public string nationality { get; set; }

        public bool isBookable { get; set; }

        public bool isAvailable { get; set; }

        public int packageCategoryID { get; set; }

        public int packageAvailabilityID { get; set; }

        public string OpratesOnDays { get; set; }

        public IEnumerable<ACBusTours> IEACBusTours { get; set; }
    }

    public class ACBusTourPayment : PostPaymentData
    {
        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        public int noOfTourists { get; set; }

        public Int16 isIndian { get; set; }
        public int packageID { get; set; }
        public string packageName { get; set; }
        public string destinationCovered { get; set; }
        public string imagePath { get; set; }
        public string imageCaption { get; set; }
        public decimal packageAmount { get; set; }

        [Display(Name = "Total Price")]
        public decimal totalAmount { get; set; }

        [Display(Name = "Nationality")]
        public string nationality { get; set; }

        [Display(Name = "Name")]
        public string customerName { get; set; }

        [Display(Name = "Email")]
        public string customerEmail { get; set; }

        [Display(Name = "Mobile No.")]
        public string customerMobile { get; set; }

        public string userIP { get; set; }

        public string availability { get; set; }

        public int packageCategoryID { get; set; }
        public int isTaxCalculated { get; set; }
        public decimal taxPercentage { get; set; }
        public decimal packageAmountIncludingGST { get; set; }
        public decimal CalculatedGST { get; set; }
        public decimal taxAmount { get; set; }

       

    }

    public class ACBusTourQuery
    {
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [StringLength(200, ErrorMessage = "Name should be upto 200 characters only!")]
        public string name { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string emailID { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(100, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        public string queryFor { get; set; }

        public int packageID { get; set; }

        [Display(Name = "Query")]
        [Required(ErrorMessage = "Enter Query!")]
        [StringLength(500, ErrorMessage = "Query should be upto 500 characters only!")]
        public string query { get; set; }

        public string packageName { get; set; }

        public string queryDate { get; set; }

        [Display(Name = "Captcha")]
        [Required(ErrorMessage = "Enter Captcha Text!")]
        public string Captcha { get; set; }
    }
    #region Samreen
    public class CycleTours
    {
        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int routeTypeId { get; set; }

        [Required(ErrorMessage = "Select Applicant Type!")]
        [Display(Name = "Applicant Type")]
        public Int16 applicantTypeId { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfTourists { get; set; }

        public string nationality { get; set; }
        public Int16 isIndian { get; set; }
        public string RouteType { get; set; }
        [Required(ErrorMessage = "Select Route Fare!")]
        public decimal RouteFare { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Arrival Time!")]
        [Display(Name = "Arrival Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Arrival Time!")]
        [Required(ErrorMessage = "Enter Arrival Time!")]
        public DateTime arrivalTime { get; set; }

        public Int64 pid { get; set; }
        public string package_Abbr { get; set; }
        public IEnumerable<CycleToursProgram> lstCycleToursProgram { get; set; }
        public IEnumerable<CycleRouteType> lstCycleRoute { get; set; }
        public int isTaxCalculated { get; set; }
        public decimal taxPercentage { get; set; }
        public decimal packageAmountIncludingGST { get; set; }
        public decimal CalculatedGST { get; set; }
        public decimal taxAmount { get; set; }

    }
    public class CycleToursProgram
    {
        public string programStratTimeSummer { get; set; }
        public string programEndTimeSummer { get; set; }
        public string programStratTimeWinter { get; set; }
        public string programEndTimeWinter { get; set; }
        public string RouteType { get; set; }
        public string programName { get; set; }
    }
    public class CheckoutBillHeads
    {
        public string RentDate { get; set; }
        public String BillDescription { get; set; }
        public decimal Amount { get; set; }
    }
    public class CheckOutBillDetails
    {
        public string BillDate { get; set; }
        public string BillDetail { get; set; }
        public decimal Amount { get; set; }
        public decimal ExtraBedAmount { get; set; }
        public decimal AmountForTax { get; set; }
        public string billNo { get; set; }
        public string guestName { get; set; }
        public String address { get; set; }
        public String mobileNo { get; set; }
        public String arrivalDate { get; set; }
        public String arrivalTime { get; set; }
        public String nooftourists { get; set; }
        public string bookedThrough { get; set; }
        public string AdvRecNo { get; set; }
        public decimal advanceAmount { get; set; }
        public String CheckoutDate { get; set; }
        public string CheckoutTime { get; set; }
        public String roomNo { get; set; }
        public string docketNo { get; set; }
        public string nationality { get; set; }
        public decimal luxuryTax { get; set; }
        public string luxuryTaxDisplay { get; set; }
        public decimal luxuryTaxAmt { get; set; }
        public decimal serviceTax { get; set; }
        public decimal serviceTaxAmt { get; set; }
        public decimal netAmount { get; set; }
        public decimal totalAmount { get; set; }
        public decimal discountAmount { get; set; }
        public double spclDiscount { get; set; }
        public string SpclDiscountName { get; set; }
        public decimal discountPer { get; set; }
        public decimal discountedAmount { get; set; }
        public decimal billAmount { get; set; }
        public decimal totalPayable { get; set; }
        public decimal roundOffValue { get; set; }
        public int netpayableAmount { get; set; }
        public string UnitName { get; set; }
        public string unitAddress { get; set; }
        public string unitContact { get; set; }
        public string tinNo { get; set; }
        public string tanNo { get; set; }
        public string panNo { get; set; }
        public string serTaxNo { get; set; }
        public decimal fAndBAmt { get; set; }
        public decimal laundryAmt { get; set; }
        public decimal roomServiceAmt { get; set; }
        public decimal otherAmt { get; set; }
        public string privilegeCardNo { get; set; }
        public string privilegeCardDate { get; set; }
        public bool isPrivilegeVerified { get; set; }
        public decimal privilegeAmt { get; set; }
        public decimal privilegeDist { get; set; }
        public int unitID { get; set; }
        public string advPayment { get; set; }
        public string GSTApplyed { get; set; }
    }

    public class TongaRide
    {
        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfTourists { get; set; }

        public string nationality { get; set; }
        public Int16 isIndian { get; set; }
        public string RouteType { get; set; }
        [Required(ErrorMessage = "Select Ride Fare!")]
        public decimal RouteFare { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int routeTypeId { get; set; }
        [Required(ErrorMessage = "Select Applicant Type!")]
        [Display(Name = "Applicant Type")]
        public Int16 applicantTypeId { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Arrival Time!")]
        [Display(Name = "Arrival Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Arrival Time!")]
        [Required(ErrorMessage = "Enter Arrival Time!")]
        public DateTime arrivalTime { get; set; }

        public IEnumerable<CycleToursProgram> lstCycleToursProgram { get; set; }

        public int isTaxCalculated { get; set; }
        public decimal taxPercentage { get; set; }
        public decimal packageAmountIncludingGST { get; set; }
        public decimal CalculatedGST { get; set; }
        public decimal taxAmount { get; set; }

        
    }
    public class HeritageWalk
    {
        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime arrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfTourists { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Arrival Time!")]
        [Display(Name = "Arrival Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Arrival Time!")]
        [Required(ErrorMessage = "Enter Arrival Time!")]
        public DateTime arrivalTime { get; set; }

        public string nationality { get; set; }
        public Int16 isIndian { get; set; }
        public string RouteType { get; set; }
        [Required(ErrorMessage = "Select Walk Fare!")]
        public decimal RouteFare { get; set; }

        public int isTaxCalculated { get; set; }
        public decimal taxPercentage { get; set; }
        public decimal packageAmountIncludingGST { get; set; }
        public decimal CalculatedGST { get; set; }
        public decimal taxAmount { get; set; }

     
    }
    #endregion

    #region Roop

    public class PackageAndTour
    {
        public DateTime arrivalDate { get; set; }
        public int noOfTourists { get; set; }
        public Int16 isIndian { get; set; }
        public string nationality { get; set; }
        public string tourType { get; set; }
        public string tourId { get; set; }
        public IEnumerable<PackageCategory> lstPackage { get; set; }
        public IEnumerable<CityTourCategory> lstCity { get; set; }
    }

    #endregion

    public class CancelBooking
    {
        public Int64 userid { get; set; }
        public IEnumerable<BookingHistory> lstCancelBookingDetails { get; set; }
    }

    public class BookingHistory
    {
        public string docketNo { get; set; }
        public string packageName { get; set; }
        public string UnitName { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string BookingStatus { get; set; }
        public decimal amount { get; set; }
        public string cancelRefNo { get; set; }
        public string BookingFor { get; set; }
        public decimal refaundAmount { get; set; }
        public decimal refaundPer { get; set; }
        public string isCanAllowed { get; set; }
    }

    public class BusTaxiEnquiry
    {
        public string enquiryNo { get; set; }

        [Required(ErrorMessage = "Select Enquiry Type!")]
        public string enquiryType { get; set; }

        [Display(Name = "From City")]
        [Required(ErrorMessage = "Select From City!")]
        public int fromCity { get; set; }

        [Display(Name = "To City")]
        [Required(ErrorMessage = "Enter To City!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string toCity { get; set; }

        [Display(Name = "Date of Journey")]
        [Required(ErrorMessage = "Select Date of Journey!")]
        [DataType(DataType.Date, ErrorMessage = "Date of Journey should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dateOfJourney { get; set; }

        [Display(Name = "Date of Return")]
        [DataType(DataType.Date, ErrorMessage = "Date of Return should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public Nullable<DateTime> dateOfReturn { get; set; }

        [Display(Name = "Pickup Date")]
        [Required(ErrorMessage = "Select Pickup Date!")]
        [DataType(DataType.Date, ErrorMessage = "Pickup Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime pickupDate { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Pickup Time!")]
        [Display(Name = "Pickup Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Pickup Time!")]
        [Required(ErrorMessage = "Enter Pickup Time!")]
        public DateTime pickupTime { get; set; }

        [Display(Name = "Pickup Address")]
        [Required(ErrorMessage = "Enter Pickup Address!")]
        [StringLength(200, ErrorMessage = "Pickup Address should be upto 200 characters only!")]
        public string pickupAddress { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Enter First Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid First Name!")]
        [StringLength(100, ErrorMessage = "First Name should be upto 100 characters only!")]
        public string firstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Enter Last Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Last Name!")]
        [StringLength(100, ErrorMessage = "Last Name should be upto 100 characters only!")]
        public string lastName { get; set; }


        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(100, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public string phoneNo { get; set; }

        [Display(Name = "Email")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [Required(ErrorMessage = "Enter Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(100, ErrorMessage = "Email should be upto 100 characters only!")]
        public string email { get; set; }

        [Display(Name = "Message")]
        [Required(ErrorMessage = "Enter Message!")]
        [StringLength(500, ErrorMessage = "Message should be upto 500 characters only!")]
        public string message { get; set; }

        public string ipAddress { get; set; }

        public string enquiryDate { get; set; }

        public string name { get; set; }

        public string fromCityName { get; set; }

        public string managerEmail { get; set; }

        public bool isReplied { get; set; }
        [Display(Name = "Enter Captcha Text")]
        [Required(ErrorMessage = "Captcha Text is Requred")]
        public string Captcha { get; set; }

        public string bookingBy { get; set; }

        public string bookingStatus { get; set; }

        public string bookingBySlug { get; set; }

        public string amount { get; set; }

        public string CRSEmailID { get; set; }
    }

    public class BusTaxiSourceCity
    {
        public int cityId { get; set; }
        public String cityName { get; set; }

        public String Latitude { get; set; }

        public String Longitude { get; set; }

    }

    public class Function
    {
        public int functionID { get; set; }
        public String functionName { get; set; }

    }

    public class LawnEnquiry
    {
        public string enquiryNo { get; set; }

        public string enquiryType { get; set; }

        public Int64 destinationID { get; set; }

        public DateTime lawnBookingDate { get; set; }

        public int noOfLawnGuest { get; set; }

        public int functionID { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Enter First Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid First Name!")]
        [StringLength(100, ErrorMessage = "First Name should be upto 100 characters only!")]
        public string firstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Enter Last Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Last Name!")]
        [StringLength(100, ErrorMessage = "Last Name should be upto 100 characters only!")]
        public string lastName { get; set; }


        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(100, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public string phoneNo { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(100, ErrorMessage = "Email should be upto 100 characters only!")]
        public string email { get; set; }

        [Display(Name = "Message")]
        [Required(ErrorMessage = "Enter Message!")]
        [StringLength(500, ErrorMessage = "Message should be upto 500 characters only!")]
        public string message { get; set; }

        public string ipAddress { get; set; }

        public string enquiryDate { get; set; }

        public string name { get; set; }

        public string functionName { get; set; }

        public string unitEmail { get; set; }

        public string unitName { get; set; }

        [Display(Name = "Hotel")]
        [Required(ErrorMessage = "Select Hotel!")]
        public Int64 unitID { get; set; }
        public bool isReplied { get; set; }

        [Display(Name = "Enter Captcha Text")]
        [Required(ErrorMessage = "Captcha Text is Requred")]
        public string Captcha { get; set; }

        [Display(Name = "Amount To Pay")]
        [Required(ErrorMessage = "Enter Amount!")]
        public Nullable<decimal> amount { get; set; }

        [Display(Name = "Remark")]
        [Required(ErrorMessage = "Enter Remark!")]
        public string remark { get; set; }

        [Display(Name = "Document")]
        [Required(ErrorMessage = "Upload Document!")]
        public HttpPostedFileBase document { get; set; }

        public string documentPath { get; set; }

        public string userIP { get; set; }

        public Int64 userID { get; set; }

        public string mode { get; set; }

        public string currency { get; set; }

        public string description { get; set; }

        public string CRSEmailID { get; set; }
    }

    public class AuditoriumEnquiry
    {
        public string enquiryNo { get; set; }

        public string enquiryType { get; set; }

        [Display(Name = "Booking Date")]
        [Required(ErrorMessage = "Select Booking Date!")]
        [DataType(DataType.Date, ErrorMessage = "Booking Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime audibookingDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfAudiGuest { get; set; }

        [Required(ErrorMessage = "Select Function Type!")]
        [Display(Name = "Function Type")]
        public int audiFunctionID { get; set; }

        [Display(Name = "First Name")]
        [Required(ErrorMessage = "Enter First Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid First Name!")]
        [StringLength(100, ErrorMessage = "First Name should be upto 100 characters only!")]
        public string firstName { get; set; }

        [Display(Name = "Last Name")]
        [Required(ErrorMessage = "Enter Last Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Last Name!")]
        [StringLength(100, ErrorMessage = "Last Name should be upto 100 characters only!")]
        public string lastName { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(100, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public string phoneNo { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(100, ErrorMessage = "Email should be upto 100 characters only!")]
        public string email { get; set; }

        [Display(Name = "Message")]
        [Required(ErrorMessage = "Enter Message!")]
        [StringLength(500, ErrorMessage = "Message should be upto 500 characters only!")]
        public string message { get; set; }

        public string ipAddress { get; set; }

        public string enquiryDate { get; set; }

        public string name { get; set; }

        public string functionName { get; set; }

        public string managerEmail { get; set; }

        [Display(Name = "Enter Captcha Text")]
        [Required(ErrorMessage = "Captcha Text is Requred")]
        public string Captcha { get; set; }
    }

    public class BusTaxiEnquiryReply
    {
        [Display(Name = "Enquiry No.")]
        public string enquiryNo { get; set; }

        [Display(Name = "Enquiry Type")]
        public string enquiryType { get; set; }

        [Display(Name = "From City")]
        public string fromCityName { get; set; }

        [Display(Name = "To City")]
        public string toCity { get; set; }

        [Display(Name = "Date of Journey")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dateOfJourney { get; set; }

        [Display(Name = "Date of Return")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public Nullable<DateTime> dateOfReturn { get; set; }

        [Display(Name = "Pickup Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime pickupDate { get; set; }

        [Display(Name = "Pickup Time")]
        public DateTime pickupTime { get; set; }

        [Display(Name = "Pickup Address")]
        public string pickupAddress { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Phone No.")]
        public string phoneNo { get; set; }

        [Display(Name = "Email")]
        public string email { get; set; }

        [Display(Name = "Message")]
        public string message { get; set; }

        [Display(Name = "Name")]
        public string name { get; set; }

        [Display(Name = "Amount To Pay")]
        [Required(ErrorMessage = "Enter Amount!")]
        public Nullable<decimal> amount { get; set; }

        [Display(Name = "Remark")]
        [Required(ErrorMessage = "Enter Remark!")]
        public string remark { get; set; }

        [Display(Name = "Document")]
        [Required(ErrorMessage = "Upload Document!")]
        public HttpPostedFileBase document { get; set; }

        [Display(Name = "Enquiry Date")]
        public string enquiryDate { get; set; }

        public string documentPath { get; set; }

        public bool isReplied { get; set; }

        public string userIP { get; set; }

        public Int64 userID { get; set; }

        public string mode { get; set; }

        public string currency { get; set; }

        public string description { get; set; }

        public int fromCity { get; set; }

    }

    public class BusTaxiBookingDetails
    {
        public int BusTaxiId { get; set; }
        [Display(Name = "Enquiry No.")]
        public string enquiryNo { get; set; }

        [Display(Name = "Enquiry Type")]
        public string enquiryType { get; set; }

        [Display(Name = "From City")]
        public string fromCityName { get; set; }

        [Display(Name = "To City")]
        public string toCity { get; set; }

        [Display(Name = "Date of Journey")]
        public string dateOfJourney { get; set; }

        [Display(Name = "Date of Return")]
        public string dateOfReturn { get; set; }

        [Display(Name = "Pickup Date")]
        public string pickupDate { get; set; }

        [Display(Name = "Pickup Time")]
        public DateTime pickupTime { get; set; }

        [Display(Name = "Drop Date")]
        public string dropDate { get; set; }

        public int Duration { get; set; }

        [Display(Name = "Pickup Address")]
        public string pickupAddress { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Landline No.")]
        public string phoneNo { get; set; }

        [Display(Name = "Email")]
        public string email { get; set; }

        [Display(Name = "Message")]
        public string message { get; set; }

        [Display(Name = "Name")]
        public string name { get; set; }

        public string currency { get; set; }

        public string description { get; set; }

        public int fromCity { get; set; }

        public string docketNo { get; set; }

        public string transactionStatus { get; set; }

        public string transactionID { get; set; }

        public string bankRefNo { get; set; }

        public string transactionAmount { get; set; }

        public string transactionDate { get; set; }

        [Display(Name = "Bill Amount")]
        public string billAmount { get; set; }

        public string bookingDate { get; set; }

        public string bookingType { get; set; }

        public string bookingBy { get; set; }

        public string UPToursName { get; set; }

        public int RequestId { get; set; }

        public decimal BalanceAmount { get; set; }

        public string IsGuideOpted { get; set; }

        public decimal GuideTariff { get; set; }

        public string BusTaxiName { get; set; }
        public int Killometers { get; set; }

        public int? uptoursid { get; set; }

    }

    public class BusTaxiBooking : BusTaxiEnquiry
    {
        [Display(Name = "Amount To Pay")]
        [Required(ErrorMessage = "Enter Amount!")]
        public Nullable<decimal> amount { get; set; }

        public string docketNo { get; set; }

        public HttpPostedFileBase document { get; set; }

        public string documentPath { get; set; }
    }

    public class BusTaxiSearch
    {

        public string docketNo { get; set; }

        public HttpPostedFileBase document { get; set; }

        public string documentPath { get; set; }
    }

    public class BusTaxiBookingReport
    {
        [DataType(DataType.Date, ErrorMessage = "Booking Date From should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateFrom { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Booking Date To should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateTo { get; set; }

        public string docketNo { get; set; }

        //[Required(ErrorMessage = "Select UPTour!")]
        public int? uptourId { get; set; }

        public IEnumerable<BusTaxiBookingDetails> busTaxiBookingList { get; set; }
    }


    #region BusTaxiBoookig

    public class BusTaxiDestinationCity
    {
        public Int64 value { get; set; }
        public String label { get; set; }
        public String Latitude { get; set; }
        public String Longitude { get; set; }

    }
    public class BusTaxi
    {
        [Required(ErrorMessage = "Select Enquiry Type!")]
        public string enquiryType { get; set; }

        [Display(Name = "From City")]
        [Required(ErrorMessage = "Select From City!")]
        public int fromCity { get; set; }

        [Display(Name = "To City")]
        [Required(ErrorMessage = "Enter To City!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string toCity { get; set; }

        public int ToCityCode { get; set; }

        [Display(Name = "Date of Journey")]
        [Required(ErrorMessage = "Select Date of Journey!")]
        [DataType(DataType.Date, ErrorMessage = "Date of Journey should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dateOfJourney { get; set; }

        [Display(Name = "Duration(In Days)")]
        [Required(ErrorMessage = "Select Duration!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string Duration { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfperson { get; set; }

        [Required(ErrorMessage = "Select Avilable Time!")]
        [Display(Name = "at (earliest time available)")]
        public string AvilableTime { get; set; }


        [Required(ErrorMessage = "Select Enquiry Type!")]
        public string enquiryTypeLocal { get; set; }

        [Display(Name = "From City")]
        [Required(ErrorMessage = "Select From City!")]
        public int fromCityLocal { get; set; }

        [Display(Name = "Date of Journey")]
        [Required(ErrorMessage = "Select Date of Journey!")]
        [DataType(DataType.Date, ErrorMessage = "Date of Journey should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dateOfJourneyLocal { get; set; }

        [Display(Name = "Duration(In Days)")]
        [Required(ErrorMessage = "Select Duration!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string DurationLocal { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfpersonLocal { get; set; }

        public bool IsGuid { get; set; }
        public bool IsGuidLocal { get; set; }

        [Required(ErrorMessage = "Select Avilable Time!")]
        [Display(Name = "at (earliest time available)")]
        public string AvilableTimeLocal { get; set; }

        public decimal km { get; set; }

        public string FromcityName { get; set; }
        public string DispAvilableTime { get; set; }
    }

    public class TaxiBusSearch
    {
        [Required(ErrorMessage = "Select Enquiry Type!")]
        public string enquiryType { get; set; }

        [Display(Name = "From City")]
        [Required(ErrorMessage = "Select From City!")]
        public int fromCity { get; set; }
        public string HASGuid { get; set; }

        [Display(Name = "To City")]
        [Required(ErrorMessage = "Enter To City!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string toCity { get; set; }

        public int ToCityCode { get; set; }

        [Display(Name = "Date of Journey")]
        [Required(ErrorMessage = "Select Date of Journey!")]
        [DataType(DataType.Date, ErrorMessage = "Date of Journey should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dateOfJourney { get; set; }

        [Display(Name = "Duration(In Days)")]
        [Required(ErrorMessage = "Select Duration!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string Duration { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfperson { get; set; }

        [Required(ErrorMessage = "Select Avilable Time!")]
        [Display(Name = "at (earliest time available)")]
        public string AvilableTime { get; set; }

        [Required(ErrorMessage = "Select For!")]
        [Display(Name = "For")]
        public String For { get; set; }

        public bool IsGuid { get; set; }
        public decimal km { get; set; }
        public string FromcityName { get; set; }
        public string DispAvilableTime { get; set; }
        public List<BusTaxiList> BusTaxi { get; set; }
    }


    public class BusTaxiList
    {
        public Int64 BusTaxiId { get; set; }
        public string BusTaxiName { get; set; }
        public string BusTaxiDiscription { get; set; }
        public string BusTaxiType { get; set; }
        public string ImageCaption { get; set; }
        public string ImageUrl { get; set; }
        public string Standerd { get; set; }
        public decimal Tariff { get; set; }
        public int AvilCount { get; set; }
        public int MinHours { get; set; }
        public int MinimumKm { get; set; }
        public int MaxCapacity { get; set; }
        public decimal AddKMCharges { get; set; }
        public decimal AdditionalHrsCharges { get; set; }
        public decimal EarliarDeparturCharges { get; set; }
        public int Distance { get; set; }
        public decimal GuidTariff { get; set; }
        public int duration { get; set; }
    }


    public class BusTaxiPayment : PostPaymentData
    {
        [Required(ErrorMessage = "Select Enquiry Type!")]
        public string enquiryType { get; set; }

        [Display(Name = "From City")]
        [Required(ErrorMessage = "Select From City!")]
        public int fromCity { get; set; }

        public string FromCityName { get; set; }

        [Display(Name = "To City")]
        [Required(ErrorMessage = "Enter To City!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string toCity { get; set; }

        public int ToCityCode { get; set; }

        [Display(Name = "Date of Journey")]
        [Required(ErrorMessage = "Select Date of Journey!")]
        [DataType(DataType.Date, ErrorMessage = "Date of Journey should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dateOfJourney { get; set; }

        [Display(Name = "Duration(In Days)")]
        [Required(ErrorMessage = "Select Duration!")]
        [StringLength(100, ErrorMessage = "To City should be upto 100 characters only!")]
        public string Duration { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfperson { get; set; }

        [Required(ErrorMessage = "Select Avilable Time!")]
        [Display(Name = "at (earliest time available)")]
        public string AvilableTime { get; set; }

        public string DispArrivalTime { get; set; }

        [Required(ErrorMessage = "Select For!")]
        [Display(Name = "For")]
        public String For { get; set; }
        public bool IsGuid { get; set; }
        public decimal GuidTariff { get; set; }
        public string customerName { get; set; }
        public string customerEmail { get; set; }
        public string customerMobile { get; set; }
        public Int64 BusTaxiId { get; set; }
        public decimal Tariff { get; set; }
        public decimal km { get; set; }
        public decimal serviceChargePer { get; set; }
        public decimal servicetaxtAmt { get; set; }
        public int BusTaxiCount { get; set; }
        public List<BusTaxiList> BusTaxi { get; set; }

    }

    public class FareBreakup
    {
        public int KMDistance { get; set; }
        public int KmByDuration { get; set; }
        public int Duration { get; set; }
        public decimal Tariff { get; set; }
        public decimal TariffincludingSrTax { get; set; }
        public decimal NightCharges { get; set; }
        public decimal NighthHaltCharges { get; set; }
        public decimal PerKmCharges { get; set; }
        public string fromCityName { get; set; }
        public string ToCityName { get; set; }
        public int MinimumKm { get; set; }
        public decimal BasicTariff { get; set; }
        public decimal ServiceTaxPer { get; set; }
        public decimal ServiceTaxAmt { get; set; }
        public decimal GuidTariff { get; set; }
        public bool IsGuid { get; set; }
        public int busTaxiCount { get; set; }


    }

    #endregion

    public class LawnBanquitBookingDetails
    {
        public string docketNo { get; set; }
        public string ForDate { get; set; }
        public string enquiryType { get; set; }
        public string email { get; set; }
        public string mobileNo { get; set; }
        public string UnitName { get; set; }
        public string functionName { get; set; }
        public string noOfTourists { get; set; }
        public string name { get; set; }
        public string phoneNo { get; set; }
        public string transactionStatus { get; set; }
        public string transactionID { get; set; }
        public string PaymentID { get; set; }
        public string transactionAmount { get; set; }
        public string currency { get; set; }
        public DateTime transactionDate { get; set; }
    }
    public class UnitAmountDetailsSlabWise
    {
        public string name { get; set; }
        public string mobileNo { get; set; }
        public Int64 UnitID { get; set; }
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? fromDate { get; set; }
         [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime? toDate { get; set; }
        public int BookingCount { get; set; }
        public string DocketNumber { get; set; }
        public string UnitName { get; set; }
        public decimal TaxFreeAmount { get; set; }
        public decimal taxAmountOnFree { get; set; }
        public decimal taxrateonFree { get; set; }

        public decimal SlabOneAmount { get; set; }
        public decimal SlabOneTaxAmount { get; set; }
        public decimal taxRateSlabOne { get; set; }

        public decimal SlabTwoAmount { get; set; }
        public decimal SlabTwoTaxAmount { get; set; }
        public decimal taxRateSlabTwo { get; set; }

        public decimal SlabThreeAmount { get; set; }
        public decimal SlabThreeTaxAmount { get; set; }
        public decimal taxRateSlabThree { get; set; }
        public string fromDur { get; set; }
        public string Todur { get; set; }
        public string requestDate { get; set; }
        public string fromDateShow { get; set; }
        public string toDateShow { get; set; }
        public IEnumerable<UnitAmountDetailsSlabWise> SlabWiseDetail { get; set; }
    }
    public class SpecialUnitBooking
    {
        [Required(ErrorMessage = "Select Destination!")]
        [Display(Name = "Choose Your Destination")]
        public Int64 destinationID { get; set; }

        [Required(ErrorMessage = "Select Destination!")]
        [Display(Name = "Choose Your Destination")]
        public Int64 lawnDestinationID { get; set; }

        [Required(ErrorMessage = "Select Destination!")]
        [Display(Name = "Choose Your Destination")]
        public Int64 banquetDestinationID { get; set; }

        [Required(ErrorMessage = "Select Check In!")]
        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        public DateTime checkInDate { get; set; }

        [Required(ErrorMessage = "Select Check Out!")]
        [DataType(DataType.Date, ErrorMessage = "Check Out Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check Out Date")]
        public DateTime checkOutDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        [Display(Name = "No. of Rooms")]
        [Required(ErrorMessage = "Enter No. of Rooms!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfRooms { get; set; }

        public DateTime currentDate { get; set; }

        public int unitCount { get; set; }

        public string destinationName { get; set; }

        public Int64 unitID { get; set; }

        public string unitName { get; set; }

        public string address { get; set; }

        public string briefDescription { get; set; }

        public string imagePath { get; set; }

        public int noOfDays { get; set; }

        public List<UnitBooking> IEunit { get; set; }

        public List<UnitAmenities> IEUnitAmenities { get; set; }

        public List<dynamic> IEUnitRooms { get; set; }

        [Required(ErrorMessage = "Select Booking Date!")]
        [DataType(DataType.Date, ErrorMessage = "Booking Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Booking Date")]
        public DateTime lawnBookingDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfLawnGuest { get; set; }

        [Required(ErrorMessage = "Select Function Type!")]
        [Display(Name = "Function Type")]
        public int functionID { get; set; }

        [Required(ErrorMessage = "Select Booking Date!")]
        [DataType(DataType.Date, ErrorMessage = "Booking Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Booking Date")]
        public DateTime banquetBookingDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfBanquetGuest { get; set; }

        [Required(ErrorMessage = "Select Function Type!")]
        [Display(Name = "Function Type")]
        public int banquetFunctionID { get; set; }


    }
    public class SpecialUnitDetails
    {
        public string overview { get; set; }
        public string duration { get; set; }
       public Int64 unitID { get; set; }
        public string unitName { get; set; }
        public string unitImage { get; set; }
        public string completeAddress { get; set; }
        public string address { get; set; }
        public string district { get; set; }
        public string state { get; set; }
       public string pincode { get; set; }
        public string phoneNo { get; set; }
        public int noOfRooms { get; set; }
        public string mobileNo { get; set; }
        public string latitude { get; set; }
        public string longitude { get; set; }
        public string unitDetails { get; set; }

       public IEnumerable<UnitAmenities> IEAmenities { get; set; }
        public IEnumerable<UnitRooms> IERooms { get; set; }
       public IEnumerable<UnitImages> IEImages { get; set; }
    }

}