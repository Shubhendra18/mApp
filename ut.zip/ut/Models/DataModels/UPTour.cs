﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class UPTour
    {
    }

    public class LkoOnTonga 
    {
        public Int64 userID { get; set; }
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }


        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

      
        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode!")]
        [StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        [RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [Display(Name = "Phone No.")]
        //[Required(ErrorMessage = "Enter Phone No.!")]
        [StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")]
        public string phone { get; set; }

        [Display(Name = "Personal Identity No.")]
      //  [Required(ErrorMessage = "Enter Personal Identity No.!")]
        //[StringLength(10, ErrorMessage = "Personal Identity No. should be upto 10 characters only!")]
        //[RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")] 
        [RegularExpression(@"^[A-Z0-9]+$", ErrorMessage = "Enter valid Personal Identity No.!")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }
        public string userIP { get; set; }

        public string roleID { get; set; }
        public string docketNo { get; set; }
        [Display(Name = "Identity Type")]
        [Required(ErrorMessage = "Select Identity Type!")]
        public int IdentityType { get; set; }

        public int isOtherStateCityRequired
        {
            get
            {
                return countryID != 98 ? 1 : 0;
            }
        }

        [Display(Name = "Is Staff")]
        public Boolean isStaff { get; set; }
        [Display(Name = "Staff Id")]
        public string staffId { get; set; }
        [Display(Name = "Upload Staff Identity")]
        public HttpPostedFileBase staffIdDoc { get; set; }
        public string staffIdDocPath { get; set; }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        [Display(Name = "Route Fare")]
        [Required(ErrorMessage = "Select Ride Fare!")]
        public decimal RouteFare { get; set; }
        public string mode { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
        [Display(Name = "Total Price")]
        public decimal totalAmount { get; set; }
        public string routeType { get; set; }
    }

    public class LkoOnCycle
    {
        public Int64 userID { get; set; }
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }


        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode!")]
        [StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        [RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        //[Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [Display(Name = "Phone No.")]
        //[Required(ErrorMessage = "Enter Phone No.!")]
        [StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")]
        public string phone { get; set; }

        [Display(Name = "Personal Identity No.")]
        //  [Required(ErrorMessage = "Enter Personal Identity No.!")]
        //[StringLength(10, ErrorMessage = "Personal Identity No. should be upto 10 characters only!")]
        //[RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")] 
        [RegularExpression(@"^[A-Z0-9]+$", ErrorMessage = "Enter valid Personal Identity No.!")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }
        public string userIP { get; set; }

        public string roleID { get; set; }
        public string docketNo { get; set; }
        [Display(Name = "Identity Type")]
        [Required(ErrorMessage = "Select Identity Type!")]
        public int IdentityType { get; set; }

        public int isOtherStateCityRequired
        {
            get
            {
                return countryID != 98 ? 1 : 0;
            }
        }

        [Display(Name = "Is Staff")]
        public Boolean isStaff { get; set; }
        [Display(Name = "Staff Id")]
        public string staffId { get; set; }
        [Display(Name = "Upload Staff Identity")]
        public HttpPostedFileBase staffIdDoc { get; set; }
        public string staffIdDocPath { get; set; }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        [Display(Name = "Route Fare")]
        [Required(ErrorMessage = "Select Ride Fare!")]
        public decimal RouteFare { get; set; }
        public string mode { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
        [Display(Name = "Total Price")]
        public decimal totalAmount { get; set; }
          [Required(ErrorMessage = "Select Route!")]
         [Display(Name = "Select Route")]
        public string routeType { get; set; }
          public int? nameTitle { get; set; }
    }

    public class OneDayTourBooking
    {
        public Int64 userID { get; set; }
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        public int? nameTitle { get; set; }

        [Display(Name = "Email")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }

        public string userIP { get; set; }

        public string roleID { get; set; }

        public string docketNo { get; set; }

        [Display(Name = "Identity Type")]
        public int? IdentityType { get; set; }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        public string mode { get; set; }

        public string currency { get; set; }

        public string description { get; set;}

        [Display(Name = "Total Amount")]
        public decimal totalAmount { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int packageCategoryID { get; set; }

        [Required(ErrorMessage = "Select Nationality!")]
        [Display(Name = "Nationality")]
        public Int16 isIndian { get; set; }

        [Required(ErrorMessage = "Select Package Destination!")]
        [Display(Name = "Choose Your Destination")]
        public int packageID { get; set; }

        public string bookingFor { get; set; }

        public string bookingBy{ get; set; }

        public string receiptNo { get; set; }
    }

    public class PackageTour
    {
        public int packageID { get; set; }
        public string packageName { get; set; }
    }

    public class ACBusTourBooking
    {
        public Int64 userID { get; set; }

        [Required(ErrorMessage = "Select Package Destination!")]
        [Display(Name = "Choose Your Destination")]
        public int packageCategoryID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        public int? nameTitle { get; set; }

        [Display(Name = "Email")]     
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }

        public string userIP { get; set; }

        public string roleID { get; set; }

        public string docketNo { get; set; }

        [Display(Name = "Identity Type")]
        public int? IdentityType { get; set; }
   
        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        public string mode { get; set; }

        public string currency { get; set; }

        public string description { get; set; }

        [Display(Name = "Total Amount")]
        public decimal totalAmount { get; set; }

        [Required(ErrorMessage = "Select Nationality!")]
        [Display(Name = "Nationality")]
        public Int16 isIndian { get; set; }

        [Required(ErrorMessage = "Select Package Tour!")]
        [Display(Name = "Choose Your Package Tour")]
        public int packageID { get; set; }

        public string bookingFor { get; set; }

        public string bookingBy { get; set; }

        public string receiptNo { get; set; }
    }

    public class PackageTourBooking
    {
        public Int64 userID { get; set; }
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        public int? nameTitle { get; set; }
        [Display(Name = "Email")]       
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]       
        public string mobileNo { get; set; }       

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }

        public string userIP { get; set; }

        public string roleID { get; set; }
        public string docketNo { get; set; }
        [Display(Name = "Identity Type")]      
        public int? IdentityType { get; set; }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        public string mode { get; set; }
        public string currency { get; set; }
        public string description { get; set; }

        [Display(Name = "Total Amount")]
        [Required(ErrorMessage = "Total Amount is Required!")]
        public decimal totalAmount { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int packageCategoryID { get; set; }
        [Required(ErrorMessage = "Select Nationality!")]
        [Display(Name = "Nationality")]
        public Int16 isIndian { get; set; }
        [Required(ErrorMessage = "Select Package Tour!")]
        [Display(Name = "Choose Your Package Tour")]
        public int packageID { get; set; }
        public string bookingFor { get; set; }
        public string bookingBy { get; set; }
        public string receiptNo { get; set; }

        public List<PackageDetailUnitWise> PackageUnitWiseDetailList { get; set; }
    }

    public class PackageAvailabilityDetails
    {
        public DateTime arrivalDate { get; set; }
        public int packageID { get; set; }
        public int noOfGuests { get; set; }
        public bool isAvailable { get; set; }
    }

    public class LkoOnCycleBooking
    {
        public Int64 userID { get; set; }
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        public int? nameTitle { get; set; }

        [Display(Name = "Email")]    
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]     
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }
        
        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }

        public string userIP { get; set; }

        public string roleID { get; set; }

        public string docketNo { get; set; }
        [Display(Name = "Identity Type")]
        public int? IdentityType { get; set; }

        public int isOtherStateCityRequired
        {
            get
            {
                return countryID != 98 ? 1 : 0;
            }
        }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        public string mode { get; set; }

        public string currency { get; set; }

        public string description { get; set; }

        [Display(Name = "Total Amount")]
        public decimal totalAmount { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int routeTypeId { get; set; }

        [Required(ErrorMessage = "Select Applicant Type!")]
        [Display(Name = "Applicant Type")]
        public Int16 applicantTypeId { get; set; }

        public string bookingFor { get; set; }

        public string bookingBy { get; set; }

        public string receiptNo { get; set; }

        [Required(ErrorMessage = "Select Package Destination!")]
        [Display(Name = "Choose Your Package Destination")]
        public int packageCategoryID { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Arrival Time!")]
        [Display(Name = "Arrival Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Arrival Time!")]
        [Required(ErrorMessage = "Enter Arrival Time!")]
        public DateTime arrivalTime { get; set; }
    }

    public class CycleRouteType
    {
        public Int64 routeTypeId { get; set; }
        public string routeTypeName { get; set; }
    }

    public class CycleApplicantType
    {
        public Int32 applicantTypeId { get; set; }
        public string applicantTypeName { get; set; }
    }

    public class LkoHTWBooking
    {
        public Int64 userID { get; set; }
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        public int? nameTitle { get; set; }

        public int packageCategoryID { get; set; }

        [Display(Name = "Email")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }

        public string userIP { get; set; }

        public string roleID { get; set; }

        public string docketNo { get; set; }

        [Display(Name = "Identity Type")]
        public int? IdentityType { get; set; }

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Enter No. of Persons!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        public string mode { get; set; }

        public string currency { get; set; }

        public string description { get; set; }

        [Display(Name = "Total Amount")]
        public decimal totalAmount { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int routeTypeId { get; set; }

        [Required(ErrorMessage = "Select Applicant Type!")]
        [Display(Name = "Applicant Type")]
        public Int16 applicantTypeId { get; set; }

        public string bookingFor { get; set; }

        public string bookingBy { get; set; }

        public string receiptNo { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Arrival Time!")]
        [Display(Name = "Arrival Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Arrival Time!")]
        [Required(ErrorMessage = "Enter Arrival Time!")]
        public DateTime arrivalTime { get; set; }

    }

    public class LkoTongaRideBooking
    {
        public Int64 userID { get; set; }
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        public int? nameTitle { get; set; }

        [Display(Name = "Email")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }


        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }
        public string userIP { get; set; }

        public string roleID { get; set; }
        public string docketNo { get; set; }

        [Display(Name = "Identity Type")]
        public int? IdentityType { get; set; }       

        [Required(ErrorMessage = "Select Arrival Date!")]
        [DataType(DataType.Date, ErrorMessage = "Arrival Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Arrival Date")]
        public DateTime ArrivalDate { get; set; }

        [Display(Name = "No. of Persons")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        public string mode { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
        [Display(Name = "Total Amount")]
        public decimal totalAmount { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Choose Your Package")]
        public int routeTypeId { get; set; }
        [Required(ErrorMessage = "Select Applicant Type!")]
        [Display(Name = "Applicant Type")]
        public Int16? applicantTypeId { get; set; }
        public IEnumerable<CycleToursProgram> lstCycleToursProgram { get; set; }
        public string bookingFor { get; set; }
        public string bookingBy { get; set; }

        public string receiptNo { get; set; }

        public int packageCategoryID { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Arrival Time!")]
        [Display(Name = "Arrival Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Arrival Time!")]
        [Required(ErrorMessage = "Enter Arrival Time!")]
        public DateTime arrivalTime { get; set; }
    }

    public class UPTPaymentDetails
    {       
        public DateTime? dtBookingDateFrom { get; set; }
        public DateTime? dtBookingDateTo { get; set; }
        public List<PaymentDetails> paymentList { get; set; }
        public string type { get; set; }
        public string docketNo { get; set; }

        //public List<PaymentDetails> paymentList { get; set; }
        //public string docketNo { get; set; }
        //public string Amount { get; set; }
        //public string Mode { get; set; }
        //public string billNo { get; set; }
        //public string BillType { get; set; }
        //public string name { get; set; }
        //public string mobileNo { get; set; }
        //public Int64 unitID { get; set; }
        //public string UnitName { get; set; }
        //public string AdvancePaymentCategory { get; set; }
        //public string IsCreditDebit { get; set; }
        //public string bookingType { get; set; }
        //public Nullable<DateTime> paymentDate { get; set; }
    }

    public class PreponePostponeCRS : PreponePostponeDetailsCRS
    {
        public Int64 unitID { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        [Required(ErrorMessage = "Select Check In Date!")]
        public Nullable<DateTime> newCheckInDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check Out Date")]
        [Required(ErrorMessage = "Select Check Out Date!")]
        public Nullable<DateTime> newCheckOutDate { get; set; }

        public string userIP { get; set; }
    }

    public class PreponePostponeDetailsCRS
    {
        [Display(Name = "Docket No.")]
        [Required(ErrorMessage = "Enter Docket No.!")]
        public string docketNo { get; set; }

        [Display(Name = "Customer Name")]
        public string name { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfGuests { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        public DateTime checkInDate { get; set; }

        public DateTime checkOutDateShow { get; set; }

        [Display(Name = "Single Occupancy")]
        public int singleRoom { get; set; }

        [Display(Name = "Double Occupancy")]
        public int doubleRoom { get; set; }

        [Display(Name = "Room Type")]
        public string roomName { get; set; }

        [Display(Name = "No. of Rooms")]
        public int noOfRooms { get; set; }

        [Display(Name = "Amount Paid")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "Duration Of Stay")]
        public string duration { get; set; }

        public bool isCheckIn { get; set; }

        public Boolean hasOccupancy { get; set; }

        public Boolean privilegeAvailability { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        public List<RoomOccupancyDetails> bookedRoomList { get; set; }



    }

    public class UpdatePayment
    {
        [Display(Name = "Docket No.")]
        public string docketNo { get; set; }

        [Display(Name = "Payment ID")]
        [Required(ErrorMessage = "Enter Payment Id.!")]
        public string PaymentId { get; set; }

        [Display(Name = "Transaction ID")]
        [Required(ErrorMessage = "Enter Transaction Id.!")]
        public string TransactionId { get; set; }

        [Display(Name = "Remark")]
        [Required(ErrorMessage = "Enter Remark.!")]
        public string Remark { get; set; }
    }


    public class UPTBusTaxibooking
    {
        public bool? guiderequired { get; set; }

        public decimal? guidetariff { get; set; }


        [Required(ErrorMessage="Select Package Category!")]
        [Display(Name = "Package Category")]
        public int packagecategory { get; set; }

        [Required(ErrorMessage="Enter Booking Type!")]
        [Display(Name="Booking Type")]
        public string bookingtype { get; set; }
        [Required(ErrorMessage="Select Booking for!")]
        [Display(Name="I need a")]
        public string busortaxi { get; set; }
        public string fromCity { get; set; }
        [Required(ErrorMessage="Select From City!")]
        [Display(Name="From City")]
        public int? fromCityId { get; set; }
        public string toCity { get; set; }
        //[Required(ErrorMessage="Select To City!")]
        [Display(Name="To City")]
        [toCityAttribute("Select To City!")]
        public int? toCityId { get; set; }
        [Required(ErrorMessage="Enter Duration!")]
        [Display(Name="Duration")]
        public int? duration { get; set; }
        [Required(ErrorMessage="Enter Journey Date!")]
        [Display(Name="Journey Date")]
        public DateTime? journeydate { get; set; }
        [Required(ErrorMessage="Enter Distance!")]
        [Display(Name="Distance")]
        public int? distance { get; set; }
        [Required(ErrorMessage="Enter No. of Person!")]
        [Display(Name="No. of Person")]
        public int? noofpersons { get; set; }
        [Required(ErrorMessage="Enter Time of Departure")]
        [Display(Name="Time of Departure")]
        public string timeofdeparture { get; set; }


        [Required(ErrorMessage = "Enter No. of Vehicles!")]
        [Display(Name = "No. of Vehicles")]

        public int? noofvehicles { get; set; }

        [Display(Name = "Advance Amount")]
        public decimal? advanceamount { get; set; }

        [Display(Name="Receipt No")]
        [ReceiptNoRequiredAttribute("Enter Receipt No.!",1)]
        public string receiptno { get; set; }

        [Display(Name = "Payment Date")]
        [ReceiptNoRequiredAttribute("Enter Payment Date!",2)]
        public DateTime? paymentdate { get; set; }

        [Display(Name="Bus")]
        public int? busid { get; set; }
        [Display(Name="Taxi")]
        [Required(ErrorMessage="Select Taxi!")]
        public int? taxiid { get; set; }

        public Int64 userID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }


        [Display(Name = "Email")]
        //[Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "From Where")]
        //[Required(ErrorMessage = "From Where!")]
        [StringLength(200, ErrorMessage = "From Where should be upto 200 characters only!")]
        public string fromWhere { get; set; }

        [Display(Name = "To Where")]
        //[Required(ErrorMessage = "To Where!")]
        [StringLength(200, ErrorMessage = "To Where should be upto 200 characters only!")]
        public string toWhere { get; set; }

        [Display(Name = "City")]
        //[Required(ErrorMessage = "Select City!")]
        [CityIdRequired("Select City!",1)]
        public int? cityID { get; set; }

        [Display(Name = "City")]
        //[Required(ErrorMessage = "Enter City!")]
        [OtherCityRequiredAttribute("Enter City!",1)]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        //[Required(ErrorMessage = "Select State!")]
        [CityIdRequired("Select State!",2)]
        public int? stateID { get; set; }

        [Display(Name = "State")]
        //[Required(ErrorMessage = "Enter State!")]
        [OtherCityRequiredAttribute("Enter State!",2)]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int? countryID { get; set; }

        [Display(Name = "Pincode")]
        //[Required(ErrorMessage = "Enter Pincode!")]
        //[StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        //[RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        //[StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        //[RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        [Display(Name = "Phone No.")]
        //[Required(ErrorMessage = "Enter Phone No.!")]
        [StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")]
        public string phone { get; set; }

        [Display(Name = "Personal Identity No.")]
        //[Required(ErrorMessage = "Enter Personal Identity No.!")]
        //[StringLength(10, ErrorMessage = "Personal Identity No. should be upto 10 characters only!")]
        //[RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")] 
        //[RegularExpression(@"^[A-Z0-9]+$", ErrorMessage = "Enter valid Personal Identity No.!")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }
        public string userIP { get; set; }

        public string roleID { get; set; }
        public string docketNo { get; set; }
        [Display(Name = "Identity Type")]
        //[Required(ErrorMessage = "Select Identity Type!")]
        public int? IdentityType { get; set; }

        public int isOtherStateCityRequired
        {
            get
            {
                return countryID != 98 ? 1 : 0;
            }
        }

        [Display(Name = "Is Staff")]
        public Boolean isStaff { get; set; }
        [Display(Name = "Staff Id")]
        public string staffId { get; set; }
        [Display(Name = "Upload Staff Identity")]
        public HttpPostedFileBase staffIdDoc { get; set; }
        public string staffIdDocPath { get; set; }
        [Display(Name = "Staff Grade")]
        public int staffGrade { get; set; }
        [Display(Name = "Staff Tariff")]
        public int staffFacility { get; set; }
        public decimal staffTariff { get; set; }

        public string privilegeCardNo { get; set; }
        public Boolean isPrivilegeAvail { get; set; }
        public Boolean isPrivilegeVerified { get; set; }
        public string bookingFor { get; set; }
        [Display(Name = "Receipt No.")]
        //[Required(ErrorMessage = "Enter Receipt No.!")]
        //public string receiptNo { get; set; }

        public Char customerType { get; set; }  // W - Walk In Guest, S - Staff Booking, B - Bulk Booking
        public string bookingXML { get; set; }
        public int tempRoomId { get; set; }
        public int tempRoomId2 { get; set; }
        public string tempRoomIdName { get; set; }

        [Display(Name = "Nationality")]
        public int? applicantType { get; set; }
        public int? nameTitle { get; set; }

        public bool isCheckIn { get; set; }

        public string bookingBy { get; set; }

        [Display(Name = "Date of Birth")]
        public string dateOfBirth { get; set; }

        [Display(Name = "Age")]
        public int? age { get; set; }

        public int availableRooms { get; set; }
        public decimal totalAmountPayable { get; set; }


        [Display(Name = "Unit Name")]
        public Int64 unitID { get; set; }
       
    }

    public class busortaxilist
    {
        public long BusTaxiId { get; set; }
        public string BusTaxiName { get; set; }
    }


    public class bustaxibookingconfirm
    {
        public string name { get; set; }
        public string email { get; set; }
        public string address { get; set; }
        public string countryName { get; set; }
        public string cityName { get; set; }
        public string otherCity { get; set; }
        public string stateName { get; set; }
        public string otherState { get; set; }
        public string mobileNo { get; set; }
        public string fromCity { get; set; }
        public string toCity { get; set; }
        public int? Duration { get; set; }
        public int? noOfTourists { get; set; }
        public DateTime? fromTime { get; set; }
        public DateTime? fromDate { get; set; }
        public decimal? serviceTaxPer { get; set; }
        public decimal? serviceTaxAmt { get; set; }
        public decimal? baseTariff { get; set; }
        public decimal? amount { get; set; }
        public string BusTaxiName { get; set; }
        public string docketNo { get; set; }
        public decimal? advanceAmount { get; set; }
        public bool? IsGuide { get; set; }
    }

    public class packagecategory
    {
        public int? packageCategoryID { get; set; }
        public string UptoursName { get; set; }
    }

    public class BusTaxiDetails
    {
        public Int64 BustaxiBusTaxiId { get; set; }
        public string BusTaxiName { get; set; }
        public string BusTaxiDiscription { get; set; }
        public Decimal AddLocalKmCharges { get; set; }
        public Decimal NighthHaltCharges { get; set; }
        public Decimal AdditionalHrsCharges { get; set; }
        public Decimal AddOutofStationKmCharges { get; set; }
        public Decimal MinDayTariff { get; set; }

    }


}