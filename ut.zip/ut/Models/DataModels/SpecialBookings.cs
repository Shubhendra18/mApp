﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.DataModels
{
    public class SpecialGuestDetailModel
    {

        public Int64 guestID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be up to 150 characters only!")]
        public string name { get; set; }

        [Display(Name = "Email Id")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(250, ErrorMessage = "Email should be up to 250 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be up to 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode!")]
        [StringLength(6, ErrorMessage = "Pincode should be up to 6 characters only!")]
        [RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(10, ErrorMessage = "Mobile No. should be up to 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        public string transactionStatus { get; set; }
        public string TransactionID { get; set; }
        public string PaymentID { get; set; }
        public string transactionAmount { get; set; }
        public string currency { get; set; }
        public DateTime transactionDate { get; set; }
        public string enquiryType { get; set; }

    }


    public class ParamotorBookingModel : SpecialGuestDetailModel
    {

        public Int64 requestID { get; set; }
     
        public String docketNo { get; set; }

        [Display(Name = "No. of person for 2 Min Ride")]        
        public Int32 noOfGuestforTwoMinRide { get; set; }
        [Display(Name = "No. of person for 4 Min Ride")]   
        public Int32 noOfGuestforFourMinRide { get; set; }
        public Int32 totalGuest { get; set; }

        [Display(Name = "Ride Date")]    
        [Required(ErrorMessage = "Select Ride Date!")]
        public String rideDate { get; set; }

       
        public String userIP { get; set; }
     
        public Decimal amount { get; set; }

        public Decimal AmountforTwoMinRide { get; set; }

        public Decimal AmountforFourMinRide { get; set; }

        public Decimal unitRateForTwoMinRide { get; set; }

        public Decimal unitRateforFourMinRide { get; set; }     

        [Display(Name = "Enter Captcha Text")]
        [Required(ErrorMessage = "Captcha Text is Required")]
        public string Captcha { get; set; }

        public bool isAmountCalculated { get; set; }

        public string mode { get; set; }
        public string currency { get; set; }
        public string description { get; set; }
    }

    public class PostRequestData
    {
        public int Flag { get; set; }
        public string msg { get; set; }
        public string docketNo { get; set; }
        public long requestId { get; set; }
    }
    public class HotAirBaloonBookingDetailsModel : SpecialGuestDetailModel
    {
        [Display(Name = "No of Persons")]
        [Required(ErrorMessage = "No of Persons!")]
        [Range(1, 240, ErrorMessage = "No of Person Should be between {1} to {2} ")]
        public int NoofPersons { get; set; }


        [Display(Name = "Date of Ride")]
        [Required(ErrorMessage = "Select Date of Ride!")]
        public string RideDate { get; set; }


        [Required(ErrorMessage = "Enter Captcha Code!")]
        public string captchaCode { get; set; }

        public decimal UnitRate { get; set; }

        public decimal RideAmount { get; set; }

        public string AmountForDisplay { get; set; }

        public Boolean isAuthenticated { get; set; }

        public string ipAddress { get; set; }

        public String docketNo { get; set; }

        public string mode { get; set; }

        public string currency { get; set; }

        public string description { get; set; }

       
    }
    public class CheckStatus
    {
        [Display(Name = "Docket No.")]
        [Required(ErrorMessage = "Enter Docket No.!")]      
        public string DocketNo { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(10, ErrorMessage = "Mobile No. should be up to 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string MobileNumber { get; set; }
    }
}