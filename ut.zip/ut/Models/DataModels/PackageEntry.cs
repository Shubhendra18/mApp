﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class PackageEntry
    {
        public int PackageId { get; set; }

        [Required(ErrorMessage = "Enter Package Name !")]
        [Display(Name = "Package Name")]
        [StringLength(200, ErrorMessage = "Upto 200 characters only !")]
        public string PackageName { get; set; }

        public IEnumerable<PackageEntry> IEPackageCategory { get; set; }

        [Required(ErrorMessage = "Enter Package Abbreviation !")]
        [Display(Name ="Package Abbreviation")]
        [StringLength(3, ErrorMessage = "Upto 3 characters only !")]
        public string packageAbbr { get; set; }

        [Required(ErrorMessage = "Enter Sub Package !")]
        [Display(Name = "Sub Package")]
        [StringLength(200, ErrorMessage = "Upto 200 characters only !")]
        public string SubPackage { get; set; }

        [Required(ErrorMessage = "Select Package Category")]
        [Display(Name = "Package Category")]
        public int PackageCategoryID { get; set; }

        [Required(ErrorMessage = "Enter Overview")]
        [Display(Name = "Overview")]
        public string Overview { get; set; }

        //[Required(ErrorMessage = "Enter Brief Description")]
        [Display(Name = "Brief Description")]
        public string BriefDescription { get; set; }


        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Duration!")]
        [Required(ErrorMessage = "Enter Duration of Nights")]
        [Display(Name = "Duration of Night")]
        [StringLength(2, ErrorMessage = "Duration must contain only two digit!", MinimumLength = 1)] 
        public string DurationNight { get; set; }

        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Duration!")]
        [Required(ErrorMessage = "Enter Duration of Days")]
        [Display(Name = "Duration of Days")]
        [StringLength(2, ErrorMessage = "Duration must contain only two digit!", MinimumLength = 1)] 
        public string DurationDays { get; set; }

        [Required(ErrorMessage = "Enter Destination Covered")]
        [Display(Name = "Destination Covered")]
        public string DestinationCovered { get; set; }

        [Required(ErrorMessage = "Enter Departure Time")]      
        [Display(Name = "Departure Time")]
        [RegularExpression(@"^(1[0-2]|0[1-9]):[0-5][0-9]\040(AM|am|PM|pm)$", ErrorMessage = "Invalid Departure Time")]
        public string Departuretime { get; set; }

        [Required(ErrorMessage = "Enter Departure Venue")]
        [Display(Name = "Departure Venue")]
        public string DepartureVenue { get; set; }

        [Required(ErrorMessage = "Enter Traval Mode")]
        [Display(Name = "Travel Mode")]
        public string TravalMode { get; set; }

        //[Required(ErrorMessage = "Enter Meal Plan")]
        [Display(Name = "Meal Plan")]
        public string MealPlan { get; set; }

        [Required(ErrorMessage = "Enter User Id")]
        [Display(Name = "User Id")]
        public int UserId { get; set; }

        [Required(ErrorMessage = "Upload Image")]
        [Display(Name = "Image")]
        public HttpPostedFileBase ImagePath { get; set; }

        [Required(ErrorMessage = "Enter Tour Type")]
        [Display(Name = "TourType")]
        public string TourType { get; set; }

        [Required(ErrorMessage = "Upload Image")]
        [Display(Name = "Small Image")]
        
        public HttpPostedFileBase ImagePathSmall { get; set; }

        public string ImagePathUrl { get; set; }

        public string ImagePathSmallUrl { get; set; }

        public string PackageCategoryName { get; set; }
    }

    public class PackageImageEntry
    {
        public int packageImageId { get; set; }

        [Required(ErrorMessage="Select Package")]
        [Display(Name="Package")]
        public int packageID { get; set; }

        [Required(ErrorMessage="Enter ImageCaption")]
        [Display(Name="ImageCaption")]
        [StringLength(200, ErrorMessage = "Upto 200 characters only !")]
        public string imageCaption { get; set; }

        [Required(ErrorMessage = "Upload Image")]
        [Display(Name = "BannerImage")]
        public HttpPostedFileBase imagePath { get; set; }

        public string imagePathUrl { get; set; }

        [Required(ErrorMessage = "Upload Small Image")]
        [Display(Name = "Small Image")]
        public HttpPostedFileBase imagePathSmall { get; set; }

        public string imagePathSmallUrl { get; set; }

        [Required(ErrorMessage = "Select Primary")]
        [Display(Name = "Primary")]
        public bool isPrimary { get; set; }

        [Required(ErrorMessage = "Enter Large")]
        [Display(Name = "Large")]
        [RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Large!")]
        public int isLarge { get; set; }

        public string TourType { get; set; }

        public string SubPackage { get; set; }

        public string packageName { get; set; }

        public IEnumerable<PackageImageEntry> IPackageImage { get; set; }
    }

    public class Tour
    {
        public string TourType { get; set; }
        public string SubPackage { get; set; }
    }

    public class PackageItinery
    {
        public int ItineryID { get; set; }
              
        [Display(Name="Day")]
        public int? Day { get; set; }

        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Select Package")]
        public int PackageId { get; set; }

        public string packageName { get; set; }
        [Display(Name = "Orgin")]
        public string OriginID { get; set; }
        [Display(Name = "Origin Name")]
        public string OriginName { get; set; }
        [Display(Name = "Destination")]
        public string DestinationID { get; set; }
        [Display(Name = "Destination Name")]
        public string DestinationName { get; set; }
        [Display(Name = "Departure/Arrival")]
        public string Dep_Arr { get; set; }
              
        [Display(Name = "Departure/Arrival Time")]
        [RegularExpression(@"^(1[0-2]|0[1-9]):[0-5][0-9]\040(AM|am|PM|pm)$", ErrorMessage = "Invalid Departure/Arrival Time")]
        public string Dep_Arr_Time { get; set; }

        [Required(ErrorMessage="Enter Particulars")]
        [Display(Name = "Particulars")]  
        public string Particulars { get; set; }
        [Display(Name = "Display Order")]
        [Required(ErrorMessage = "Enter Display Order")]
        public int? DesplayOrder { get; set; }

        public string  cityID { get; set; }

        public string cityName { get; set; }

        public IEnumerable<PackageItinery> IPackageItinery { get; set; }
       
    }

    public class PackageAmount
    {
        public int packageAmountID { get; set; }

        [Required(ErrorMessage = "Select Package")]
        [Display(Name = "Package")]
        public int packageID { get; set; }

        [Required(ErrorMessage = "Select Season")]
        [Display(Name = "Season")]
        public int seasonID { get; set; }

        [Display(Name = "Is Indian")]
        public bool isIndian { get; set; }

        //public bool isAdult { get; set; }

        [Display(Name = "No. of Persons")]
        [Required(ErrorMessage = "Select No. of Persons")]
        public int noOfPersons { get; set; }

        [RegularExpression(@"^0*[1-9][0-9]*(\.[0-9]+)?|0+\.[0-9]*[1-9][0-9]*$",ErrorMessage="Enter a valid Amount!")]
        [Required(ErrorMessage = "Enter Amount")]
        [Display(Name = "Amount")]
        public decimal withoutMealAmount { get; set; }

        public string Packagename { get; set; }

        public string SeasonName { get; set; }
    }

    public class PackageSeason
    {
        public int SeasonID { get; set; }

        public string SeasonName { get; set; }
    }

    public class PackageMappingModel
    {
        [Display(Name = "Select Package")]
        [Required(ErrorMessage = "Select package !")]
        public int packageTypeID { get; set; }

        [Display(Name = "From City")]
        [Required(ErrorMessage = "Select from city !")]
        public int fromCityID { get; set; }

        [Display(Name = "To City")]
        [Required(ErrorMessage = "Select to city !")]
        public int toCityID { get; set; }

        //[Display(Name = "Select Destination")]
        //[Required(ErrorMessage = "Select destination!")]
        //public int destinationID { get; set; }

        [Display(Name = "Select Unit")]
        [Required(ErrorMessage = "Select unit !")]
        public int unitID { get; set; }

        [Display(Name = "Room Type")]
        [RequiredIf("hasStayYes", true, ErrorMessage = "Select room type !")]
        public int RoomTypeID { get; set; }

        [Display(Name = "Day")]
        [Required(ErrorMessage = "Enter Day!")]
        public int sequenceNo { get; set; }

        [Display(Name = "Has Stay")]
        [Required(ErrorMessage = "Please check one !")]
        public bool hasStayYes { get; set; }

        [Display(Name = "Has Stay")]
        
        public bool hasStayNo { get; set; }

        public string Message { get; set; }
        public int Day { get; set; }
        public int userID { get; set; }
        public int packageDestionationID { get; set; }
        public List<FillPackgeMappedDetails> lst_FillPackgeMappedDetails { get; set; }

    }

    public class SelectPackageType
    {
        public int packageID { get; set; }
        public string packageName { get; set; }
    }

    public class SelectFromCity
    {
        public Int64 DestinationID { get; set; }
        public string DestinationName { get; set; }
    }

    public class SelectToCity
    {
        public Int64 DestinationID { get; set; }
        public string DestinationName { get; set; }
    }

    public class SelectDestination
    {
        public Int64 DestinationID { get; set; }
        public string DestinationName { get; set; }
    }

    public class SelectUnit
    {
        public Int64 UnitID { get; set; }
        public string unitName { get; set; }
    }

    public class SelectRoomType
    {
        public int RoomTypeID { get; set; }
        public string roomType { get; set; }
    }

    public class FillPackgeMappedDetails
    {
        public int ID { get; set; }
        public string packageName { get; set; }
        public string FromCity { get; set; }
        public int Day { get; set; }
        public string ToCity { get; set; }
        public string Destination { get; set; }
        public string UnitName { get; set; }
        public string roomType { get; set; }
        public string tranDate { get; set; }



    }

    public class PackageSpecialPriceDeals
    { 
        public Int64 dealID { get;set; }

        [Required(ErrorMessage = "Enter Deal Title!")]
        [Display(Name = "Deal Title")]
        [StringLength(200, ErrorMessage = "Deal Title should be upto 200 characters only!")]
	    public string dealTitle { get;set; }

        [Required(ErrorMessage = "Enter Deal Description!")]
        [Display(Name = "Deal Description")]
        [StringLength(500, ErrorMessage = "Deal Description should be upto 500 characters only!")]
	    public string dealDescription { get;set; }

        //public string dealCode { get;set; }    
    
        [Required(ErrorMessage = "Select Package!")]
        [Display(Name = "Package")]
	    public int packageID { get;set; }

        [Required(ErrorMessage = "Select From Date!")]
        [Display(Name = "From Date")]
	    public DateTime? dealFromDate { get;set; }

        [Required(ErrorMessage = "Select To Date!")]
        [Display(Name = "To Date")]
        public DateTime? dealToDate { get; set; }

        [RequiredIf("dealPercent", "", ErrorMessage = "Enter Offer Price!")]
        [Display(Name = "Offer Price")]
        public decimal? dealAmount { get; set; }

       [RequiredIf("dealAmount", "", ErrorMessage = "Enter Discount Percentage!")]
       [Display(Name = "Discount Percentage (%)")]
       public decimal? dealPercent { get; set; }

       [Display(Name = "No. of Persons")]
       public int noOfPersons { get; set; }

       [Display(Name = "Nationality")]
       public bool isIndian { get; set; }

       public IEnumerable<PackageSpecialPriceDealsDetails> lstPackageSpecialDeals { get; set; }
    }

    public class PackageSpecialPriceDealsDetails
    {
        public string dealTitle { get; set; }
        public string packageName { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public decimal dealAmount { get; set; }
        public decimal dealPercent { get; set; }
    }


}