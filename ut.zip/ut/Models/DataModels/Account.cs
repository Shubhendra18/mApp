﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class Login
    {
        public Int64 UserID { get; set; }

        [Display(Name="User Name")]
        [Required(ErrorMessage="Enter User Name!")]
        public string UserLoginID { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password!")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        public string RoleID { get; set; }
        public string DisplayName { get; set; }
        public IEnumerable<DateTime> LastLogin { get; set; }
        public IEnumerable<DateTime> LastChangePassword { get; set; }
      
        public string pageUrl { get; set; }
        public string pageName { get; set; }
        public string accessIP { get; set; }
        public string seed { get; set; }

    }

    public class Registration 
    {
        public Int64 userID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password!")]
        [DataType(DataType.Password)]        
        public string password { get; set; }    

        [Required(ErrorMessage = "Confirm New Password!")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]       
        [Compare("password", ErrorMessage = "Password and confirmation password do not match!")]
        public string confirmPassword { get; set; }

        [Display(Name = "Username")]
        [System.Web.Mvc.Remote("CheckEmailExistence", "Account", HttpMethod = "POST", ErrorMessage = "Email already exists!")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode!")]
        [StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        [RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")] 
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]        
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        //[Display(Name = "Phone No.")]
        ////[Required(ErrorMessage = "Enter Phone No.!")]
        //[StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        //[RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")] 
        //public string phone { get; set; }    


        public string roleID { get; set; }      
        public IEnumerable<DateTime> LastLogin { get; set; }
        public int isExists { get; set; }
        public IEnumerable<DateTime> LastChangePassword { get; set; }
        public string pageUrl { get; set; }
        public string pageName { get; set; }
        public string accessIP { get; set; }
        public string seed { get; set; }

        public string registerFrom { get; set; }
        [Display(Name = "Enter Captcha Text")]
        [Required(ErrorMessage = "Captcha Text is Requred")]
        public string Captcha { get; set; }
    }

    public class UserLogin
    {
        public Int64 userID { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        public string email { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password!")]
        [DataType(DataType.Password)]
        public string password { get; set; }

        public string roleID { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public IEnumerable<DateTime> lastLogin { get; set; }
        public IEnumerable<DateTime> lastChangePassword { get; set; }

        public string pageUrl { get; set; }
        public string pageName { get; set; }
        public string accessIP { get; set; }
        public string seed { get; set; }
        public string loginFrom { get; set; }
        [Display(Name = "Enter Captcha Text")]
        [Required(ErrorMessage = "Captcha Text is Requred")]
        public string Captcha { get; set; }

        public DateTime attemptTime { get; set; }

        public int wrongAttemptsCount { get; set; }

        public string visitStatus { get; set; }

        public int flag { get; set; }

    }

    public class UserForgetPassword
    {         
        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }
       
        public string mobileNo { get; set; }

        public string name { get; set; }

        public string password { get; set; }
       
    }

    public class UserChangePassword
    {
        public Int64 userId { get; set; }

        public string email { get; set; }

        [Required(ErrorMessage = "Enter Old Password!")]
        [Display(Name = "Old Password")]
        [DataType(DataType.Password)]        
        public string oldPassword { get; set; }

        [Required(ErrorMessage = "Enter New Password!")]
        [Display(Name = "New Password")]
        [DataType(DataType.Password)]
        [StringLength(10, ErrorMessage = "Password should be upto 10 characters only!")]
        [RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$&*]).{5,10})", ErrorMessage = "Enter atleast 1 lower case letter, 1 upper case letter, 1 digit and 1 special character and must not be less than 5 characters and more than 10 characters!")]
        public string newPassword { get; set; }
               
        [Display(Name = "Confirm Password")]
        [Required(ErrorMessage = "Confirm New Password!")]
        [DataType(DataType.Password)]
        [Compare("newPassword", ErrorMessage = "The new password and confirmation password do not match!")]
        public string confirmPassword { get; set; }        
        public string seedChangePassword { get; set; }
        public string passwordChangedOn { get; set; }
        public string roleID { get; set; }
    }

    public class UnitLogin
    {
        public Int64 userID { get; set; }
        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        public string email { get; set; }
        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password!")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        // [Required(ErrorMessage = "Enter User Name !")]
        [Display(Name = "User Name")]
        public string userName { get; set; }
        public string roleID { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public Int64 unitID { get; set; }
        public string seed { get; set; }
      //  [Required(ErrorMessage = "Enter secret answer !")]
        public string secAns { get; set; }
      //  [Required(ErrorMessage = "Select secret question !")]
        public Int32 secQues { get; set; }
        public string tinNo { get; set; }
        public string tanNo { get; set; }
        public string panNo { get; set; }
        public string serTaxNo { get; set; }
        public string msgText { get; set; }
        public string sentotp { get; set; }
        public string recvotp { get; set; }
       
        [Required(ErrorMessage = "Enter Image Text!")]
        public string Captcha { get; set; }
        public int wrongAttemptsCount { get; set; }
    }

    public class ForgetPassword
    {
        public Int64 userID { get; set; }
        public string password { get; set; }
        [Display(Name = "Email")]
        public string email { get; set; }

        [Required(ErrorMessage = "Enter User Name !")]
        [Display(Name = "User Name")]
        public string userName { get; set; }

        public string roleID { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public Int64 unitID { get; set; }
        public string seed { get; set; }
        [Required(ErrorMessage = "Enter secret answer !")]
        public string secAns { get; set; }
        [Required(ErrorMessage = "Select secret question !")]
        public Int32 secQues { get; set; }
        public string tinNo { get; set; }
        public string tanNo { get; set; }
        public string panNo { get; set; }
        public string serTaxNo { get; set; }
        public string msgText { get; set; }
        public string sentotp { get; set; }
        public string recvotp { get; set; }
    }

    public class UPToursLogin
    {
        public Int64 userID { get; set; }

        [Display(Name = "Email")]
        [Required(ErrorMessage = "Enter Email!")]
        public string email { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password!")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        [Display(Name = "User Name")]
        public string userName { get; set; }

        public string roleID { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public int packageCategoryID { get; set; }
        public string seed { get; set; }
        [Display(Name = "Captcha")]
        [Required(ErrorMessage = "Enter Captcha Text!")]
        public string Captcha { get; set; }
        public int wrongAttemptsCount { get; set; }
    }

    public class OnlineCustomer
    {
        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        public string name { get; set; }        

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int? cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int? stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        public string mobileNo { get; set; }

        public string ipAddress { get; set; } 

    }

#region ANurag Forgetpwd by email and otp
    public class ForgotPassword
    {
        [Display(Name = "Login Id")]
        [Required(ErrorMessage = "Enter Login Id")]
        public string userName { get; set; }

        public bool verifyBy { get; set; }

        [Required(ErrorMessage = "Enter Captcha Text!")]
        public string captcha { get; set; }

        public string userEmail { get; set; }

        public string userMobileNo { get; set; }

        public Int64 userID { get; set; }

        public string email { get; set; }

        public string Mobileno { get; set; }
        
        public string msgText { get; set; }

        public string sentotp { get; set; }

        public string otpRequestCount { get; set; }
      
        public string password { get; set; }

        public string name { get; set; }        

        public string roleID { get; set; }

        public Int32 randomNo { get; set; }

        //public string USerMobile { get; set; }

        //public string USeremail { get; set; }

        //ublic bool verifiedBy { get; set; }

       // public List<ForgotPassword> frgUserDetails { get; set; }
    }


    public class changepwdByLink
    {
        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password!")]
        [DataType(DataType.Password)]
        [StringLength(10, ErrorMessage = "Password should be upto 10 characters only")]
        [RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$&*]).{5,10})", ErrorMessage = "Enter atleast 1 lower case letter, 1 upper case letter, 1 digit and 1 special character and password must not be less than 5 characters and not more than 10 characters!")]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "Confirm New Password!")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        [Compare("NewPassword", ErrorMessage = "Password and confirmation password do not match!")]
        public string ConfirmPassword { get; set; }


        public string seedChangePassword { get; set; }
        //public Int32 randomNo { get; set; }
        //public string otpRequestCount { get; set; }
        //public string msgText { get; set; }
        //public Int64 userID { get; set; }

        public string userEmail { get; set; }

        public string userMobileNo { get; set; }

        public Int64 userID { get; set; }

        public string userName { get; set; }

        public string Mobileno { get; set; }

       // public string msgText { get; set; }

       // public string sentotp { get; set; }

        public string otpRequestCount { get; set; }

        public string password { get; set; }

        public string name { get; set; }

        public string roleID { get; set; }

        public Int32 randomNo { get; set; }

        //public List<ForgotPassword> frgUserDetails { get; set; }
    }

    public class OtpVerification
    {
        public Int64 userid { get; set; }
        public string screenNo { get; set; }
        public string orgOtp { get; set; }
        [Required(ErrorMessage="Enter OTP!")]
        public string Otp { get; set; }
        public string InfoText { get; set; }
    }

#endregion

    public class UnlockAccount
    {
        public string roleID { get; set; }
        public string email { get; set; }
        public List<LockAccountDetails> lstLockedAccount { get; set; }
    }

    public class LockAccountDetails
    {      
        public string email { get; set; }
        public string roleID { get; set; }
        public string userType { get; set; }
        public bool unlock { get; set; }
    }


    public class UserRegistration
    {
        public Int64 userID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        [Display(Name = "Password")]
        [Required(ErrorMessage = "Enter Password!")]
        [DataType(DataType.Password)]
        //[StringLength(10, ErrorMessage = "Password should be upto 10 characters only")]
        //[RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$&*]).{5,10})", ErrorMessage = "Enter atleast 1 lower case letter, 1 upper case letter, 1 digit and 1 special character and password must not be less than 5 characters and more than 10 characters!")]
        public string password { get; set; }

        [Required(ErrorMessage = "Confirm New Password!")]
        [DataType(DataType.Password)]
        [Display(Name = "Confirm Password")]
        [Compare("password", ErrorMessage = "Password and confirmation password do not match!")]
        public string confirmPassword { get; set; }

        [Display(Name = "Username")]
        [System.Web.Mvc.Remote("CheckEmailExistenceforUserReg", "Account", HttpMethod = "POST", ErrorMessage = "Email already exists!")]
        [Required(ErrorMessage = "Enter Email!")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]
        [Required(ErrorMessage = "Enter Address!")]
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Select City!")]
        public int cityID { get; set; }

        [Display(Name = "City")]
        [Required(ErrorMessage = "Enter City!")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Select State!")]
        public int stateID { get; set; }

        [Display(Name = "State")]
        [Required(ErrorMessage = "Enter State!")]
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "Country")]
        [Required(ErrorMessage = "Select Country!")]
        public int countryID { get; set; }

        [Display(Name = "Pincode")]
        [Required(ErrorMessage = "Enter Pincode!")]
        //[StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        //[RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")] 
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]
        [System.Web.Mvc.Remote("CheckMobileNoExistenceforUserReg", "Account", HttpMethod = "POST", ErrorMessage = "Mobile No already exists!")]
        [Required(ErrorMessage = "Enter Mobile No.!")]
        // [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]        
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        //[Display(Name = "Phone No.")]
        ////[Required(ErrorMessage = "Enter Phone No.!")]
        //[StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        //[RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")] 
        //public string phone { get; set; }    


        public string roleID { get; set; }
        public IEnumerable<DateTime> LastLogin { get; set; }
        public int isExists { get; set; }
        public IEnumerable<DateTime> LastChangePassword { get; set; }
        public string pageUrl { get; set; }
        public string pageName { get; set; }
        public string accessIP { get; set; }
        public string seed { get; set; }

        public string registerFrom { get; set; }
        [Display(Name = "Enter Captcha Text")]
        [Required(ErrorMessage = "Captcha Text is Requred")]
        [System.Web.Mvc.Remote("Matchcaptcha", "Account", HttpMethod = "POST", ErrorMessage = "Captcha Text did not Match!")]
        public string Captcha { get; set; }
    }
}