﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.DataModels
{
    public class UnitCounterBooking
    {
        [Required(ErrorMessage = "Select Check In!")]
        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        public DateTime checkInDate { get; set; }

        [Required(ErrorMessage = "Select Check Out!")]
        [DataType(DataType.Date, ErrorMessage = "Check Out Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check Out Date")]
        public DateTime checkOutDate { get; set; }

        [Display(Name = "No. of Guests")]
        [Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfGuests { get; set; }

        [Display(Name = "No. of Rooms")]
        [Required(ErrorMessage = "Enter No. of Rooms!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int noOfRooms { get; set; }

        public int unitCount { get; set; }

        public Int64 unitID { get; set; }

        [Display(Name = "No. of Rooms")]
        public string unitName { get; set; }

        public string address { get; set; }

        public string briefDescription { get; set; }

        public string imagePath { get; set; }

        public int noOfDays { get; set; }

        //public List<UnitBooking> IEunit { get; set; }

        //public List<UnitAmenities> IEUnitAmenities { get; set; }

        //public List<UnitRooms> IEUnitRooms { get; set; }
    }

    public class UnitVacancyStatus
    {
        [Required(ErrorMessage = "Select Date!")]
        public DateTime dtBooking { get; set; }
        public Int64 unitID { get; set; }
        public List<VacancyStatus> bookingStatusList { get; set; }

        public List<MasterUnits> UnitDetails { get; set; }


        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Time!")]
        [Display(Name = "Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Time!")]
        [Required(ErrorMessage = "Enter Time!")]
        public DateTime BookingInTime { get; set; }
    }

    public class VacancyStatus
    {
        public string roomType { get; set; }
        public int totalRoom { get; set; }
        public int onlineBooked { get; set; }
        public int counterBooked { get; set; }
        public int upTourBooked { get; set; }
        public int packageBooked { get; set; }
        public int vacant { get; set; }
        public int blocked { get; set; }
        public int OutS { get; set; }
        public int arcBooked { get; set; }
        public int crsBooked { get; set; }
        public int roomtypeid { get; set; }
    }

    public class UnitBlockRelease
    {
        [Required(ErrorMessage = "Select Date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dtBlocking { get; set; }

        public Int64 unitID { get; set; }
        public int blockLimit { get; set; }
        public List<BlockReleaseDetail> blockReleaseList { get; set; }
    }

    public class HQBlockRelease
    {
        [Required(ErrorMessage = "Select Date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dtBlocking { get; set; }

        [Required(ErrorMessage = "Select Date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dtBlockingTo { get; set; }

        [Required(ErrorMessage = "Select Unit!")]
        public Int64 unitID { get; set; }
        public int blockLimit { get; set; }
        public List<BlockReleaseDetail> blockReleaseList { get; set; }
    }

    public class BlockReleaseDetail
    {
        public string roomType { get; set; }
        public int roomTypeID { get; set; }
        public int roomID { get; set; }
        public int totalRoom { get; set; }
        public int booked { get; set; }
        public int blocked { get; set; }
        public int blockAllowed { get; set; }
        public int vacant { get; set; }
        public int blockLimit { get; set; }
        public string unitName { get; set; }
        public string BlockedDate { get; set; }
        public int BlockId { get; set; }

    }


    public class UnitTotalBooking
    {
        public DateTime? dtBookingDateFrom { get; set; }
        public DateTime? dtBookingDateTo { get; set; }
        public string docketNo { get; set; }
        public Int64 unitID { get; set; }
        public List<BookedDetail> bookedList { get; set; }
        public DateTime dtCurrent { get; set; }
    }

    public class BookedDetail
    {
        public string roomType { get; set; }
        [Display(Name = "No. of Rooms")]
        public int totalRoom { get; set; }
        public string docketNo { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public string bookingType { get; set; }
        public string checkInDate { get; set; }
        public string checkOutDate { get; set; }
        public string BookingStatus { get; set; }
        public string BookingFor { get; set; }
        public string noofRooms { get; set; }
        public string bookingBy { get; set; }
        public string GuestSatus { get; set; }
        public string UnitName { get; set; }
        public string packageName { get; set; }
        public string roomNos { get; set; }
        public string bookingDate { get; set; }

        public string email { get; set; }
      
        public string DateofBirth { get; set; }
        public string AnniversaryDate { get; set; }
        public string cityName { get; set; }
        public string countryName { get; set; }
        public string stateName { get; set; }

    }

    public class UPTourVacancyStatus
    {
        [Required(ErrorMessage = "Select Date!")]
        public DateTime dtBooking { get; set; }

        [Required(ErrorMessage = "Select Unit!")]
        public Int64 unitID { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Time!")]
        [Display(Name = "Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Time!")]
        [Required(ErrorMessage = "Enter Time!")]
        public DateTime BookingInTime { get; set; }

        public List<VacancyStatus> bookingStatusList { get; set; }
    }
    public class UPTourTotalBooking
    {
        public DateTime dtBooking { get; set; }
        public DateTime? dtBookingDateFrom { get; set; }
        public DateTime? dtBookingDateTo { get; set; }
        public Int64? unitID { get; set; }
        public List<BookedDetail> bookedList { get; set; }
        public string type { get; set; }
        public string docketNo { get; set; }

        public List<PaymentDetails> paymentList { get; set; }
    }

    public class SpecialBookedDetail
    {
        public string onDate { get; set; }
        public string toDate { get; set; }
        public int noOfPerson { get; set; }
        public int noOfRoom { get; set; }
        public string docketNo { get; set; }
        public string name { get; set; }
        public string mobileNo { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string BookingFor { get; set; }
        public decimal amount { get; set; }
        public string bookingThrough { get; set; }
        public string packageName { get; set; }
        public string UnitName { get; set; }
        public int packageID { get; set; }
        public int unitID { get; set; }
        public string cancelRefNo { get; set; }
        public List<PackageDetailUnitWise> PackageDetailList { get; set; }
        public decimal advanceAmount { get; set; }
        public List<RoomOccupancyDetails> BookedRoomList { get; set; }
        public string bookingStatus { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string AdvRecNo { get; set; }
        public string CancelDate { get; set; }
        public string AdvPayDate { get; set; }
        public string arrivalDate { get; set; }
        public DateTime arrivalTime { get; set; }
        public string customerAddress { get; set; }
        public string subPackage { get; set; }
        public string bookingDate { get; set; }
        public string email { get; set; }         
        public string unitAddress { get; set; }
        public string unitMobile { get; set; }
        public string roomType { get; set; }
        public int noOfRooms { get; set; }
        public int extraBed { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string customerMobile { get; set; }
        public string duration { get; set; }
        public string meetingPoint { get; set; }
        public Boolean privilegeAvailability { get; set; }        
        public string privilegeCardNo { get; set; }        
        public string isPrivilegeVerified { get; set; }
        public string privilegeCardDate { get; set; }
        public decimal discountPercent { get; set; }
        public decimal discountAmt { get; set; }
        public int dayRemaining { get; set; }
        public int refaundAmountPer { get; set; }
        public decimal refaundAmount { get; set; }
        public decimal refaundPer { get; set; }
        public IEnumerable<PackageToursAccomodation> IEPackageAccomodation { get; set; }
    }

    public class PackageDetailUnitWise
    {
        public string UnitName { get; set; }
        public string roomType { get; set; }
        public int noOfPerson { get; set; }
        public int noOfRoom { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
    }

    public class RoomOccupancyDetails
    {
        public string unitName { get; set; }
        public string roomType { get; set; }
        public string noOfRooms { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string roomNos { get; set; }
        public int roomID { get; set; }
        public int totalRooms { get; set; }
        public int singleRoom { get; set; }
        public int doubleRoom { get; set; }
    }

    public class ExtendBookingDetails
    {
        [Display(Name = "Docket No.")]
        public string docketNo { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfPerson { get; set; }

        [Display(Name = "Customer Name")]
        public string name { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Check In Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkInDate { get; set; }

        [Display(Name = "Check Out Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkOutDate { get; set; }

        public DateTime toDate { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        public Boolean privilegeAvailability { get; set; }

        [Display(Name = "Advance Amount")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "From Where")]
        public string fromWhere { get; set; }

        [Display(Name = "To Where")]
        public string toWhere { get; set; }
        public string BookingFor { get; set; }
        public string bookingBy { get; set; }
        public string userIP { get; set; }

        public Int64 unitID { get; set; }

        public Int64 userID { get; set; }

        public List<RoomExtendDetails> roomExtendDetailList { get; set; }

        public string bookingDetails { get; set; }

        public string roomDetailXml { get; set; }

        public Char extendType { get; set; }

        [Display(Name = "Room Type")]
        public int? roomType { get; set; }

        public int tempRoomId { get; set; }

        public string tempRoomIdName { get; set; }

        public Int16 maxCapacity { get; set; }
        public int maxExtraBed { get; set; }
        public bool hasOccupancy { get; set; }

        [Display(Name = "Single Occupancy")]
        [Required(ErrorMessage = "Enter No. of Rooms (Single)")]
        public int singleRoom { get; set; }

        [Display(Name = "Double Occupancy")]
        [Required(ErrorMessage = "Enter No. of Rooms (Double)")]
        public int doubleRoom { get; set; }

        [Display(Name = "Extra Bed")]
        public int extrabed { get; set; }

        public string roomTypeDisplay { get; set; }

        [Display(Name = "No. of Guests")]
        //[Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int? noOfGuests { get; set; }
        [Display(Name = "Extend Date")]
        public DateTime? extendedDate { get; set; }
        public string tmpextendedDate { get; set; }
        public string tmpcheckInDate { get; set; }
        public bool isCheckIn { get; set; }

        public List<BookedRoomDetails> lstBookedRoom { get; set; }

        public IList<RoomDetail> lstBookedRoomDetail { get; set; }
    }

    public class RoomExtendDetails
    {
        public string roomType { get; set; }
        public string noOfRooms { get; set; }
        public int totalRooms { get; set; }
        public DateTime checkinDate { get; set; }
        public DateTime checkoutDate { get; set; }
        public DateTime? extendedDate { get; set; }
        public Int64 requestID { get; set; }
        public int roomID { get; set; }
        public int unitID { get; set; }
        public string roomsAlloted { get; set; }
    }

    public class RoomChange
    {
        [Display(Name = "Docket No.")]
        public string docketNo { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfPerson { get; set; }

        [Display(Name = "Customer Name")]
        public string name { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Check In Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkInDate { get; set; }

        [Display(Name = "Check Out Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkOutDate { get; set; }

        public DateTime toDate { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        public Boolean privilegeAvailability { get; set; }

        [Display(Name = "Advance Amount")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "From Where")]
        public string fromWhere { get; set; }

        [Display(Name = "To Where")]
        public string toWhere { get; set; }

        public Int64 unitID { get; set; }

        public Int64 bookedRoomID { get; set; }

        public List<RoomDetails> allotedRoomList { get; set; }

        public List<RoomChangeDetails> roomDetailList { get; set; }

        public List<RoomAvailableDetails> availableRoomList { get; set; }

        public bool isPostBack { get; set; }

        public string userIP { get; set; }

        public Int64 requestID { get; set; }

        public bool hasOccupancy { get; set; }

        public bool? isSingle { get; set; }

        public int extraBed { get; set; }

        public int? singleRoom { get; set; }

        public int? doubleRoom { get; set; }

        public DateTime oldCheckoutDate { get; set; }

        public int roomID { get; set; }

        public int maxExtraBed { get; set; }

        public int result { get; set; }

        public int roomOccupancy { get; set; }

        public Int64 currentRoomNoID { get; set; }

        [Display(Name = "Current Room No.")]
        public string roomNo { get; set; }

        public string previousRoomNo { get; set; }

        public int currentExtraBed { get; set; }
    }

    public class RoomChangeDetails
    {
        public string roomType { get; set; }
        public string roomsAlloted { get; set; }
        public int singleRoom { get; set; }
        public int doubleRoom { get; set; }
        public int extraBed { get; set; }
        public DateTime checkInDate { get; set; }
        public DateTime checkOutDate { get; set; }
        public Int64 requestID { get; set; }
        public int unitID { get; set; }
        public int roomID { get; set; }
        public int totalRooms { get; set; }

        public string changedRoomsAlloted { get; set; }
        public int changedSingleRoom { get; set; }
        public int changedDoubleRoom { get; set; }
        public int changedExtraBed { get; set; }
        public DateTime changedCheckInDate { get; set; }
        public DateTime changedCheckOutDate { get; set; }
        public int changedRoomID { get; set; }
        //public int totalRooms { get; set; }
        public List<RoomDetails> lstRoomNoDetail { get; set; }
        public List<RoomDetails> lstChangedRoomNoDetail { get; set; }
        //[Display(Name = "Room Type")]
        //[Required(ErrorMessage = "Select Room Type!")]
        //public int roomID { get; set; }

        //public string noOfRooms { get; set; }
        //public int totalRooms { get; set; } 

        //[Display(Name = "Check In Date")]
        //[Required(ErrorMessage = "Select Check In Date!")]
        //public DateTime checkinDate { get; set; }       





    }

    public class RoomAvailableDetails
    {
        public int roomTypeID { get; set; }

        public string roomType { get; set; }

        public int roomID { get; set; }

        public Int64 roomNoId { get; set; }

        public int roomLevel { get; set; }

        public string roomNo { get; set; }

        public bool hasOccupancy { get; set; }
    }

    public class ARCVacancyStatus
    {
        [Required(ErrorMessage = "Select Date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime dtBooking { get; set; }

        [Required(ErrorMessage = "Select Unit!")]
        public Int64 unitID { get; set; }

        [RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Time!")]
        [Display(Name = "Time")]
        [DataType(DataType.Time, ErrorMessage = "Invalid Time!")]
        [Required(ErrorMessage = "Enter Time!")]
        public DateTime BookingInTime { get; set; }

        public List<VacancyStatus> bookingStatusList { get; set; }
    }

    public class PreponePostpone : PreponePostponeDetails
    {
        public Int64 unitID { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check In Date")]
        [Required(ErrorMessage = "Select Check In Date!")]
        public Nullable<DateTime> newCheckInDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        [Display(Name = "Check Out Date")]
        [Required(ErrorMessage = "Select Check Out Date!")]
        public Nullable<DateTime> newCheckOutDate { get; set; }

        public string userIP { get; set; }
    }

    public class PreponePostponeDetails
    {
        [Display(Name = "Docket No.")]
        [Required(ErrorMessage = "Enter Docket No.!")]
        public string docketNo { get; set; }

        [Display(Name = "Customer Name")]
        public string name { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfGuests { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        public DateTime checkInDate { get; set; }

        public DateTime checkOutDateShow { get; set; }

        [Display(Name = "Single Occupancy")]
        public int singleRoom { get; set; }

        [Display(Name = "Double Occupancy")]
        public int doubleRoom { get; set; }

        [Display(Name = "Room Type")]
        public string roomName { get; set; }

        [Display(Name = "No. of Rooms")]
        public int noOfRooms { get; set; }

        [Display(Name = "Amount Paid")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "Duration Of Stay")]
        public string duration { get; set; }

        public bool isCheckIn { get; set; }

        public Boolean hasOccupancy { get; set; }

        public Boolean privilegeAvailability { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        public List<RoomOccupancyDetails> bookedRoomList { get; set; }

        //[Display(Name = "Advance Amount")]
        //[RegularExpression(@"^[0-9 \.]+$", ErrorMessage = "Enter valid Advance Amount!")]
        ////[Required(ErrorMessage = "Enter Advance Amount!")]
        //public decimal advancePayment { get; set; }

        //[RegularExpression(@"^(?:0?[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$", ErrorMessage = "Invalid Check In Time!")]
        //[Display(Name = "Check In Time")]
        //[DataType(DataType.Time, ErrorMessage = "Invalid Check In Time!")]
        //[Required(ErrorMessage = "Enter Check In Time!")]
        //public DateTime checkInTime { get; set; }

        //[Display(Name = "Upload Privilege Card")]
        //public HttpPostedFileBase privilegeCard { get; set; }

        //public string privilegeCardPath { get; set; }



        //[Display(Name = "Verify Privilege Card")]
        //public Boolean isPrivilegeVerified { get; set; }

        //[Display(Name = "From Where")]
        //[Required(ErrorMessage = "Enter From Where!")]
        //public string fromWhere { get; set; }

        //[Display(Name = "To Where")]
        //[Required(ErrorMessage = "Enter To Where!")]
        //public string toWhere { get; set; }

        //[Display(Name = "Paid On")]
        ////[Required(ErrorMessage = "Select Payment Date!")]
        //public DateTime? paymentDate { get; set; }

        //public string userIP { get; set; }

        //

        //public int extrabed { get; set; }

        //[Display(Name = "Rooms (Single)")]
        //public string singleRoomNo { get; set; }

        //[Display(Name = "Rooms (Double)")]
        //public string doubleRoomNo { get; set; }

        //[Display(Name = "Extend Date")]
        //[Required(ErrorMessage = "Select Extend Date!")]
        //public DateTime extendDate { get; set; }

        //public int roomTypeId { get; set; }

        //

        //public String rooms { get; set; }

        //public IList<RoomDetail> lstBookedRoomDetail { get; set; }
        //public Int64 requestID { get; set; }

        //public string roomNos { get; set; }
        //[Display(Name = "Receipt No.")]
        ////[Required(ErrorMessage = "Enter Receipt No.!")]
        //public string receiptNo { get; set; }
        //[Required(ErrorMessage = "Select Check In Date!")]
        //public DateTime checkInDateActual { get; set; }


        //

    }

    public class RoomExtend
    {
        [Display(Name = "Docket No.")]
        public string docketNo { get; set; }

        [Display(Name = "No. of Guests")]
        public int noOfPerson { get; set; }

        [Display(Name = "Customer Name")]
        public string name { get; set; }

        [Display(Name = "Mobile No.")]
        public string mobileNo { get; set; }

        [Display(Name = "Check In Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkInDate { get; set; }

        [Display(Name = "Check Out Date")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime checkOutDate { get; set; }

        public DateTime toDate { get; set; }

        [Display(Name = "Privilege Card No.")]
        public string privilegeCardNo { get; set; }

        public Boolean privilegeAvailability { get; set; }

        [Display(Name = "Advance Amount")]
        public decimal advanceAmount { get; set; }

        [Display(Name = "From Where")]
        public string fromWhere { get; set; }

        [Display(Name = "To Where")]
        public string toWhere { get; set; }
        public string BookingFor { get; set; }
        public string bookingBy { get; set; }
        public string userIP { get; set; }

        public Int64 unitID { get; set; }

        public Int64 userID { get; set; }

        public List<RoomExtendDetails> roomExtendDetailList { get; set; }

        public string bookingDetails { get; set; }

        public string roomDetailXml { get; set; }

        public Char extendType { get; set; }

        [Display(Name = "Room Type")]
        public int? roomType { get; set; }

        public int tempRoomId { get; set; }

        public string tempRoomIdName { get; set; }

        public Int16 maxCapacity { get; set; }
        public int maxExtraBed { get; set; }
        public bool hasOccupancy { get; set; }

        [Display(Name = "Single Occupancy")]
        [Required(ErrorMessage = "Enter No. of Rooms (Single)")]
        public int singleRoom { get; set; }

        [Display(Name = "Double Occupancy")]
        [Required(ErrorMessage = "Enter No. of Rooms (Double)")]
        public int doubleRoom { get; set; }

        [Display(Name = "Extra Bed")]
        public int extrabed { get; set; }

        public string roomTypeDisplay { get; set; }

        [Display(Name = "No. of Guests")]
        //[Required(ErrorMessage = "Enter No. of Guests!")]
        [RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid No.!")]
        public int? noOfGuests { get; set; }
        [Display(Name = "Extend Date")]
        public DateTime? extendedDate { get; set; }
        public string tmpextendedDate { get; set; }
        public string tmpcheckInDate { get; set; }
        public bool isCheckIn { get; set; }

        public List<BookedRoomDetails> lstBookedRoom { get; set; }

        public IList<RoomDetail> lstBookedRoomDetail { get; set; }
    }
}