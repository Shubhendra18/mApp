﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.DataModels
{
    public class DalySaleReportModel
    {

        public string transip { get; set; }

        public Int64 Insertedby { get; set; }

        [Required(ErrorMessage = "Enter Total Income Till Date !")]
        public Decimal TotalIncomeTillDate { get; set; }

       
        public Decimal Total { get; set; }

        [Required(ErrorMessage = "Enter Miscellaneous !")]
        public Decimal Miscellaneous { get; set; }

        [Required(ErrorMessage = "Enter Banquet / Hall / Lawn !")]
        public Decimal BanquitHallLawn { get; set; }

        [Required(ErrorMessage = "Enter Bar!")]
        public Decimal Bar { get; set; }

        [Required(ErrorMessage = "Enter Canteen!")]
        public Decimal Canteen { get; set; }

        [Required(ErrorMessage = "Enter Accommodation Charges!")]
        public Decimal AccomodationCharges { get; set; }
         
        public Decimal TotalPerRoom { get; set; }

        [Required(ErrorMessage = "Enter Occupid Rooms!")]
        public int OccupidRooms { get; set; }


        public int TotalRooms { get; set; }


        public string NameofUnit { get; set; }


        public Int64 UnitId { get; set; }


        public string NameOfStation { get; set; }

        public Int64 Saleid { get; set; }

        public DateTime SaleDate { get; set; }

        public string ViewSaleDate { get; set; }

        public Decimal TotalRevenueTillDate { get; set; }

        public string TotalRevenuePreviousDate { get; set; }

        public string TotalRevenueHQPreviousYear { get; set; }
        public string CurrentMonthYear { get; set; }
    }


    public class FillSaleReport
    {
       
        [Required]
        [DataType(DataType.Date, ErrorMessage = "Sale date is not in correct format")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime saleDate { get; set; }

        public DateTime fromDate { get; set; }

        public DateTime toDate { get; set; }

        public List<DalySaleReportModel> DalySalelist { get; set; }

        public Int64 UnitId { get; set; }

        public string TotalRevenueHQPreviousYear{ get; set; }
        public string CurrentMonthYear { get; set; }

    }



}