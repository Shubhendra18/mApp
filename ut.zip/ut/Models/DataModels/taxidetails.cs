﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.DataModels
{
    public class taxidetails
    {
        public long BusTaxiId { get; set; }
        [Required(ErrorMessage="Select Up Tours!")]
        [Display(Name="UP Tours")]
        public int Uptoursid { get; set; }
        public string UpTours { get; set; }
        [Required(ErrorMessage="Enter Taxi Name!")]
        [Display(Name="Taxi Name")]
        public string taxiname { get; set; }
        [Required(ErrorMessage="Enter Taxi Description!")]
        [Display(Name="Taxi Description")]
        public string taxidescription { get; set; }
        [Required(ErrorMessage="Select Type!")]
        [Display(Name="Vehicle Type")]
        public string taxitype { get; set; }
        [Required(ErrorMessage="Enter Standard!")]
        [Display(Name="Standard")]
        public string standard { get; set; }
        [Required(ErrorMessage="Enter Maximum Capacity!")]
        [Display(Name="Maximum Capacity")]
        public int maxcapacity { get; set; }
        public long userid { get; set; }
    }

    public class tariffdetails
    {
        public long TariffId { get; set; }
        [Required(ErrorMessage="Select UPTours!")]
        [Display(Name="Up Tours")]
        public int Uptoursid { get; set; }
        [Required(ErrorMessage="Select Taxi!")]
        [Display(Name="Taxi")]
        public long BusTaxiId { get; set; }
        public string BusTaxiName { get; set; }
        [Required(ErrorMessage="Enter Min. Hours!")]
        public int? MinHours { get; set; }
        [Required(ErrorMessage="Enter Minimum Km!")]
        [Display(Name="Minimum Km")]
        public int? MinimumKm { get; set; }
        [Required(ErrorMessage="Required!")]
        [Display(Name = "Full Day Min. Tariff")]
        public decimal? FullDayMinTariff { get; set; }
        [Required(ErrorMessage="Required!")]
        [Display(Name = "Add Local Km Charges")]
        public decimal? AddLocalKmCharges { get; set; }
        [Required(ErrorMessage = "Required!")]
        [Display(Name = "Add Out of Station Km Charges")]
        public decimal? AddOutofStationKmCharges { get; set; }
        [Required(ErrorMessage="Required")]
        [Display(Name = "Night Halt Charges")]
        public decimal? NighthHaltCharges { get; set; }
        [Required(ErrorMessage="Required!")]
        [Display(Name = "Additional Hrs Charges")]
        public decimal? AdditionalHrsCharges { get; set; }
        [Required(ErrorMessage="Required!")]

        [Display(Name = "Night Halt Time After Departure(24 hrs)")]
        [DataType(DataType.Time, ErrorMessage = "Should be valid time!")]
        public DateTime? NightHaltTimeAfterDeparture { get; set; }
        [Required(ErrorMessage="Required!")]

        [Display(Name = "Night Halt Time Before Arrival(24 hrs)")]
        [DataType(DataType.Time, ErrorMessage = "Should be valid time!")]
        public DateTime? NightHaltTimeBeforeArri { get; set; }
        public long UserId { get; set; }

    }


    public class taxiimagedetails
    {
        public long BusTaxiImgId { get; set; }
        [Required(ErrorMessage="Select Up Tours!")]
        [Display(Name="UP Tours")]
        public int Uptoursid { get; set; }
        [Required(ErrorMessage="Select Taxi!")]
        [Display(Name="Taxi Name")]
        public long BusTaxiId { get; set; }
        public string BusTaxiName { get; set; }
        [Required(ErrorMessage="Enter Image Caption!")]
        [Display(Name="Image Caption")]
        public string ImageCaption { get; set; }
        [Required(ErrorMessage="Upload Image")]
        [Display(Name="Image Upload")]
        public string ImageUrl { get; set; }
        public long UserId { get; set; }
        public HttpPostedFileBase imagefile { get; set; }
    }
}