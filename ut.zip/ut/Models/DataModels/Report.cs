﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.DataModels
{
    public class UnitWiseRevenue
    {
        public DateTime? dtBookingDateFrom { get; set; }
        public DateTime? dtBookingDateTo { get; set; }
        public IEnumerable<UnitWiseRevenue> revenueList { get; set; }

        public Int64 unitID { get; set; }
        public string unitName { get; set; }
        public decimal revenue { get; set; }
    }

    public class CRSOnlineBookingReport
    {
        [DataType(DataType.Date, ErrorMessage = "Booking Date From should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dtBookingDateFrom { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Booking Date To should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dtBookingDateTo { get; set; }
        public string docketNo { get; set; }
        public string name { get; set; }
        public decimal amount { get; set; }
        public string bookingType { get; set; }
        public string bankReferenceNo { get; set; }
        public string bookingStatus { get; set; }
        public string bookingDate { get; set; }
        public string packageName { get; set; }
        public IEnumerable<CRSOnlineBookingReport> bookingList { get; set; }
    }

    public class CRSOnlineCancellationReport
    {
        [DataType(DataType.Date, ErrorMessage = "Cancellation Date From should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateFrom { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Cancellation Date To should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateTo { get; set; }

        public string docketNo { get; set; }

        public string name { get; set; }

        public decimal amount { get; set; }

        public string amountPaid { get; set; }

        public string bookingType { get; set; }

        public string bankReferenceNo { get; set; }

        public string bookingDate { get; set; }

        public string packageName { get; set; }

        public string cancelRefNo { get; set; }

        public string cancellationDate { get; set; }

        public string cancellationStatus { get; set; }

        public string ResponseStatus { get; set; }

        public string checkinDate { get; set; }

        public string email { get; set; }

        public string mobileNo { get; set; }

        public IEnumerable<CRSOnlineCancellationReport> cancellationList { get; set; }
    }

    public class CRSOnlinePaymentDetails
    {
        public string response { get; set; }

        public string paymentDate { get; set; }

        public string paymentID { get; set; }

        public string docketNo { get; set; }

        public string amount { get; set; }

        public string transactionID { get; set; }
    }

    public class HQBookingStatusReport
    {
        public string unitName { get; set; }

        public Int64 unitID { get; set; }

        public int totalCount { get; set; }

        public DateTime bookingDate { get; set; }

        public IEnumerable<HQBookingStatusReport> bookingList { get; set; }

        public IEnumerable<HQRoomStatusReport> roomList { get; set; }
    }


    public class HQRoomStatusReport
    {
        public string roomType { get; set; }

        public int totalRoom { get; set; }

        public int totalBooked { get; set; }

        public Int64 unitID { get; set; }
    }

    public class BookingRevenue
    {
        [Required(ErrorMessage = "Select Revenue Type!")]
        public int RevenueType { get; set; }

        //[Required(ErrorMessage = "Select Unit!")]
        public Int64? unitID { get; set; }
        public int? PackageCategoryID { get; set; }
        public string packageType { get; set; }
        [Required(ErrorMessage = "Please Enter From Date")]
        public DateTime? fromDate { get; set; }
        [Required(ErrorMessage = "Please Enter To Date")]
        public DateTime? toDate { get; set; }
        public string UnitName { get; set; }
        public string PackageName { get; set; }
        public string mName { get; set; }
        public int reqMonth { get; set; }
        public int reqYear { get; set; }
        public decimal Total { get; set; }
        public string UptoursName { get; set; }
        public int? UptoursId { get; set; }

        public int? paymentMonth { get; set; }
        public int? paymentYear { get; set; }
        public decimal? advanceamount { get; set; }
        public List<BookingRevenue> lstBookingRevenue { get; set; }
        public decimal online { get; set; }
        public decimal Checkout { get; set; }
    }

    public class BookingRevenueForPDF
    {
        public int RevenueType { get; set; }
        public Int64 unitID { get; set; }
        public int PackageCategoryID { get; set; }
        public string packageType { get; set; }

        public DateTime fromDate { get; set; }

        public DateTime toDate { get; set; }
        public string UnitName { get; set; }
        public string PackageName { get; set; }
        public string mName { get; set; }
        public int reqMonth { get; set; }
        public int reqYear { get; set; }
        public decimal Total { get; set; }
        public string UptoursName { get; set; }
        public int UptoursId { get; set; }

        public int paymentMonth { get; set; }
        public int paymentYear { get; set; }
        public decimal advanceamount { get; set; }
        public List<BookingRevenue> lstBookingRevenue { get; set; }
        public decimal online { get; set; }
        public decimal Checkout { get; set; }
        public decimal GTotal { get; set; }
    }

    public class BookingCountReport
    {
        public Int64? unitID { get; set; }

        public DateTime? Fromdate { get; set; }

        public string countFor { get; set; }

        public string UnitName { get; set; }

        public int TotalBooked { get; set; }

        public int TotalCheckIn { get; set; }

        public int TotalCheckOut { get; set; }

        public int bookingYear { get; set; }

        public string bookingMonthName { get; set; }

        public List<BookingCountReport> lstBookingCount { get; set; }
    }

    public class BusTaxiEnquiryReport
    {
        [DataType(DataType.Date, ErrorMessage = "Enquiry Date From should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateFrom { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Enquiry Date To should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateTo { get; set; }

        public string enquiryNo { get; set; }

        public int? uptourId { get; set; }

        public IEnumerable<BusTaxiEnquiry> busTaxiEnquiryList { get; set; }
    }

    public class LawnEnquiryReport
    {
        [DataType(DataType.Date, ErrorMessage = "Enquiry Date From should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateFrom { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Enquiry Date To should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateTo { get; set; }

        public string enquiryNo { get; set; }

        public Int64? unitID { get; set; }

        public string enquiryType { get; set; }

        public IEnumerable<LawnEnquiry> lawnEnquiryList { get; set; }
    }

    public class AuditoriumReport
    {
        [DataType(DataType.Date, ErrorMessage = "Enquiry Date From should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateFrom { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Enquiry Date To should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? dateTo { get; set; }

        public string enquiryNo { get; set; }

        public string enquiryType { get; set; }

        public IEnumerable<AuditoriumEnquiry> auditoriumEnquiryList { get; set; }
    }

    public class OnlineUnitGuestWiseBookingReport
    {
        [Required(ErrorMessage = "Select Month!")]
        public int month { get; set; }

        [Required(ErrorMessage = "Select Year!")]
        public int year { get; set; }

        public Int64? unitID { get; set; }

        public IEnumerable<OnlineBookingRevenueDetails> bookingList { get; set; }
    }

    public class OnlineBookingRevenueDetails
    {
        public string docketNo { get; set; }
        public string name { get; set; }
        public decimal amount { get; set; }
        public string bankReferenceNo { get; set; }
        public string bookingStatus { get; set; }
        public string bookingDate { get; set; }
        public string mobileNo { get; set; }
        public string email { get; set; }
        public string bookingType { get; set; }
        public string packageName { get; set; }
    }

    public class OnlinePackGuestWiseBookingReport
    {
        [Required(ErrorMessage = "Select Month!")]
        public int month { get; set; }

        [Required(ErrorMessage = "Select Year!")]
        public int year { get; set; }

        public IEnumerable<OnlineBookingRevenueDetails> bookingList { get; set; }
    }

    public class TaxiBusBookingReport
    {
        [Required(ErrorMessage = "Select Month!")]
        public int month { get; set; }

        [Required(ErrorMessage = "Select Year!")]
        public int year { get; set; }

        public IEnumerable<BusTaxiBookingDetails> bookingList { get; set; }

    }

    public class TotalBookingDetail
    {
        public int roomID { get; set; }
        public Int64 UnitID { get; set; }
        public string UnitName { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal roomRent { get; set; }
        public decimal taxAmount { get; set; }
        public Int64 userID { get; set; }
        public int BookingCount { get; set; }
        public decimal Amount { get; set; }
        public DateTime bookingDate { get; set; }
        public string docketNo { get; set; }

        public IEnumerable<TotalBookingDetail> BookingList { get; set; }
    }
   
    public class ViewGSTDetailOnline
    {
        public int roomID { get; set; }
        public Int64 UnitID { get; set; }
        public string UnitName { get; set; }
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal roomRent { get; set; }
        public decimal taxAmount { get; set; }
        public Int64 userID { get; set; }
        public int BookingCount { get; set; }
        public decimal Amount { get; set; }
        public DateTime? bookingDate { get; set; }
        public string docketNo { get; set; }
        public string name { get; set; }
        public string checkOutDate { get; set; }
        public string checkInDate { get; set; }
        public IEnumerable<ViewGSTDetailOnline> ViewGSTReportForOnlineBooking { get; set; }
    }

    #region Ankita
    public class ViewBookedDetail
    {
        public string name { get; set; }
        public Int64 UnitID { get; set; }
        public string UnitName { get; set; }
        public string docketNo { get; set; }
        public string BookingFor { get; set; }
        public string BookingStatus { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        //public string fromDate { get; set; }
        //public string toDate { get; set; }
        public string bookingBy { get; set; }
        public string CheckOutDate { get; set; }
        public string CheckInDate { get; set; }
        public decimal amount { get; set; }
        public string cancelRefNo { get; set; }
        public int noOfRooms { get; set; }
        public decimal refaundAmount { get; set; }
        public decimal refaundPer { get; set; }
        public string packageName { get; set; }
        public string CancelRoll { get; set; }
        public DateTime transDate { get; set; }

        public IEnumerable<ViewBookedDetail> ViewBookedDetailList { get; set; }


    }

    public class CancelBookingDetail
    {

        public string fromDate { get; set; }
        public string toDate { get; set; }
        public string MobileNo { get; set; }
        public string Email { get; set; }
        public string sendTo { get; set; }
        public string onDate { get; set; }
       // public string toDate { get; set; }
        public int noOfPerson { get; set; }
        public int noOfRoom { get; set; }
        public string docketNo { get; set; }
        public string name { get; set; }
        //public string mobileNo { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string BookingFor { get; set; }
        public decimal amount { get; set; }
        public string bookingThrough { get; set; }
        public string packageName { get; set; }
        public string UnitName { get; set; }
        public int packageID { get; set; }
        public int unitID { get; set; }
        public string cancelRefNo { get; set; }
       // public List<PackageDetailUnitWise> PackageDetailList { get; set; }
        public decimal advanceAmount { get; set; }
       // public List<RoomOccupancyDetails> BookedRoomList { get; set; }
        public string bookingStatus { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string AdvRecNo { get; set; }
        public string CancelDate { get; set; }
        public string AdvPayDate { get; set; }
        public string arrivalDate { get; set; }
        public DateTime arrivalTime { get; set; }
        public string customerAddress { get; set; }
        public string subPackage { get; set; }
        public string bookingDate { get; set; }
       // public string email { get; set; }
        public string unitAddress { get; set; }
        public string unitMobile { get; set; }
        public string roomType { get; set; }
        public int noOfRooms { get; set; }
        public int extraBed { get; set; }
        public string checkinDate { get; set; }
        public string checkoutDate { get; set; }
        public string customerMobile { get; set; }
        public string duration { get; set; }
        public string meetingPoint { get; set; }
        public Boolean privilegeAvailability { get; set; }
        public string privilegeCardNo { get; set; }
        public string isPrivilegeVerified { get; set; }
        public string privilegeCardDate { get; set; }
        public decimal discountPercent { get; set; }
        public decimal discountAmt { get; set; }
        public int dayRemaining { get; set; }
        public int refaundAmountPer { get; set; }
        public decimal refaundAmount { get; set; }
        public decimal refaundPer { get; set; }
        public string cityname { get; set; }
        public string daySequence { get; set; }
        public IEnumerable<CancelBookingDetail>CancelDetail{ get; set; }
     
        //public string fromDate { get; set; }
      
    }

    #endregion
    #region Riya
    public class TourList
    {
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public int BookingCount { get; set; }
        public decimal Amount { get; set; }
        public string packageName { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal PackageAmountExcludingGST { get; set; }
        public decimal taxAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public string docketNo { get; set; }
        public IEnumerable<TourList> SlabWiseDetail { get; set; }
        public IEnumerable<TourList> BookingList { get; set; }
        public IEnumerable<TourList> ViewGSTReportForOnlineBooking { get; set; }
    }
    public class ViewTourList
    {
        public string fromDate { get; set; }
        public string toDate { get; set; }
        public int BookingCount { get; set; }
        public decimal Amount { get; set; }
        public string packageName { get; set; }
        public decimal CGST { get; set; }
        public decimal SGST { get; set; }
        public decimal PackageAmountExcludingGST { get; set; }
        public decimal taxAmount { get; set; }
        public decimal TotalAmount { get; set; }
        public string docketNo { get; set; }

        public IEnumerable<ViewTourList> ViewGSTReportForOnlineBooking { get; set; }
    }
   #endregion

}