﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    /// <summary>
    /// created by Bramh for Manage Entry of masters
    /// Like Unit details Images and Tariff with block unbloc unit Rooms
    /// </summary>
    public class MasterUnits
    {
        public Int64 UnitId { get; set; }
        [Required(ErrorMessage = "Enter Unit Name")]
        [Display(Name = "Unit Name")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter valid Name!")]
        public string UnitName { get; set; }

        [Required(ErrorMessage = "Enter Unit Address")]
        [Display(Name = "Unit Address")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Enter Pincode")]
        [StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        [RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        [Display(Name = " Pincode")]
        public string PinCode { get; set; }

        [Required(ErrorMessage = "Enter Email")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [Display(Name = " Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Enter  Mobile No")]
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        [Display(Name = " Mobile No")]
        public  string MobileNo { get; set; }

        [Required(ErrorMessage = "Select  Destination")]
        [Display(Name = " Destination")]
        public int Destination { get; set; }

        [Required(ErrorMessage = "Enter  Overview")]
        [RegularExpression(@"^[a-zA-Z\s]+$", ErrorMessage = "Enter Over View!")]
        [Display(Name = " Overview")]
        public string OverView { get; set; }


        [Required(ErrorMessage = "Enter  Phone No")]
        [StringLength(100, ErrorMessage = "Phone No. should be upto 100 characters only!")]
        [RegularExpression(@"^[0-9 \,\-\s,]+$", ErrorMessage = "Enter a valid Phone No.!")]
        [Display(Name = " Phone No")]
        public string PhoneNo { get; set; }

       // [Required(ErrorMessage = "Enter  Tariff")]
        [Display(Name = " Tariff")]
        public int Tariff { get; set; }

        public string UserID { get; set; }

        
        [Display(Name = "Image")]
        public HttpPostedFileBase tileImage { get; set; }

        [Display(Name = "Image")]
        public string titleImagePath { get; set; }

        [Required(ErrorMessage = "Enter  Image Caption")]
        [RegularExpression(@"^[a-zA-Z\s_]+$", ErrorMessage = "Enter valid Name!")]
        [Display(Name = " Image Caption")]
        public string imageCaption { get; set; }

        [Required(ErrorMessage = "Enter  Manager Name")]
        [RegularExpression(@"^[a-zA-Z\s\.]+$", ErrorMessage = "Enter valid Name!")]
        [Display(Name = " Manager Name")]
        public string managerName { get; set; }

        [Required(ErrorMessage = "Enter  Tin No.")]
        [Display(Name = " Tin No")]
        public string tinNo { get; set; }

        [Required(ErrorMessage = "Enter Tan No.")]
        [Display(Name = " Tan No")]
        public string tanNo { get; set; }

        [Required(ErrorMessage = "Enter Pan No.")]
        [Display(Name = " Pan No.")]
        public  string panNo { get; set; }

        [Required(ErrorMessage = "Enter  Service Tax No.")]
        [Display(Name = " Service Tax No.")]
        public string serTaxNo { get; set; }

        [Display(Name = "Unit Mode")]
        public bool IsOnline { get; set; }

        [Display(Name = "Unit Abbreviations")]
        public string UnitAbbr { get; set; }
        public string DestinationName { get; set; }
        public IEnumerable<MasterUnits> AllUnitlis { get; set; }
    
    }

    public class MasterRooms
    {
        public int RoomID { get; set; }

        [Display(Name="Unit")]
        [Required(ErrorMessage = "Select Unit!")]
        public int unitId { get; set; }

        [Display(Name = "Room Type")]
        [Required(ErrorMessage = "Select Room Type!")]
        public int RoomTypeId { get; set; }

        [Required(ErrorMessage = "Enter No of Rooms!")]
        //[StringLength(2, ErrorMessage = "No of Rooms should be upto 2 characters only!")]
        //[RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Enter a valid 2 digit No. of Rooms!")]
        [Display(Name = "No of Rooms")]
        public string NoofRoom { get; set; }

        [Display(Name = "Max Capacity")]
        [Required(ErrorMessage = "Enter Max Capacity")]
        //[StringLength(2, ErrorMessage = "MaxCapacity should be upto 2 characters only!")]
        //[RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Enter a valid 2 digit Max Capacity!")]
        public string MaxCapacity { get; set; }

        [Display(Name = "Occupancy Based")]
        public bool HasOccupancy { get; set; }

        public List<ViewRooms> RoomsList { get; set; }
        
    }

    public class M_RoomType
    {
        [Required(ErrorMessage = "Room Type Requred")]
        [Display(Name = "Room Type")]
        public int RoomTypeId { get; set; }
        public string roomType { get; set; } 
     
    }

    public class M_Unit
    {
        public Int64 UnitID { get; set; }
        public string UnitName { get; set; }
    }

    public class ViewRooms
    {
        public int RoomID { set; get; }
        public int UnitID { set; get; }
        public string UnitName { set; get; }
        public string RoomTypename { set; get; }
        public int NumofRooms { set; get; }
        public Int16 MaxCapacity { set; get; }
        public string InsertDate { set; get; }
        public bool hasOccupancy { set; get; }
        //List<ViewRooms> RoomsList { get; set; }
    }

    public class RoomTariff
    {
       public int roomTariffID { get; set; }
       public int roomID{get;set;}
       [StringLength(1, ErrorMessage = "Occupancy should be upto 1 character 1 or 2 only!")]
       [Display(Name = "Occupancy")]
       [Required(ErrorMessage = "Enter Occupancy")]
       [RegularExpression(@"^[1^2][2]*$", ErrorMessage = "Enter valid Occupancy!")]
       public string numofBeds{get;set;}
       [Display(Name = "Season Name")]
       [Required(ErrorMessage = "Select Season")]
       public int seasonID {get;set;}
       [StringLength(8, ErrorMessage = "Room Tariff should be upto 8 characters only!")]
       [Display(Name = "Room Tariff")]
       [Required(ErrorMessage = "Enter Room Tariff")]
       [RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Enter a valid Room Tariff !")]
       public string tariff { get; set; }
       [Display(Name = "Base Tariff for Tax")]
       [Required(ErrorMessage = "Enter RoomBase Tariff")]
       [RegularExpression(@"^[1-9][0-9]*$", ErrorMessage = "Enter a valid Room Base Tariff !")]
       public string basetariff { get; set; }
       //public List<ViewRoomTariff> GetAllRoomTariff { get; set; }

    }

    public class getSeason
    {
        public int SeasonId { get; set; }
        public string Seasonname { get; set; }
    }

    public class ViewRoomTariff
    {
        public int roomTariffID { set; get; }
        public int RoomID { set; get; }
        public int unitID { set; get; }
        public string UnitName { set; get; }
        public string RoomTypename { set; get; }
        public string SeasonName { set; get; }
        public int numofBeds { set; get; }
        public decimal tariff { set; get; }
        public decimal basetariff { set; get; }
       
    }

    public class UnitImage
    {
       public Int64  UnitImagesID{get;set;}

       [Required(ErrorMessage = "Select Unit!")]
       [Display(Name = "Unit")]
       public Int64 UnitID { get; set; }

       [Display(Name = "Room Type")]
       [RequiredIf("IsRoom", true, ErrorMessage = "Select Room Type!")] 
       public int?  roomTypeID{get; set;}

       [Display(Name = "Unit Image")]       
       public HttpPostedFileBase Image { get; set; }

       public string ImagePath {get;set;}

       [Display(Name = "Unit Image Caption")]
       [Required(ErrorMessage = "Enter Image Caption!")]
       public string ImageCaption {get;set;}

       [Display(Name = "Is Primary Image")]
       public bool IsPrimary {get;set;}

       [Display(Name = "Is Room Image")]
       public bool IsRoom  {get;set;}

        public string roomTypeName{get;set;}
        public List<getroomtype> RoomNoList { get; set; }
     }
    public class getroomtype
    {
         public string roomTypeName{get;set;}
         public int? roomTypeID { get; set; }
    }
    public class Messg
    {
        public string msg { get; set; }
    }

    public class UnitImageDetaisl
    {
       public Int64 UnitImagesID{get;set;}	
        public string UnitName{get;set;}
        public string roomType{get;set;}
        public string ImageCaption{get;set;}
        public string ImagePath { get; set; }
    }

    public class RoomOutOfServiceDetail
    {
        public int outOfServiceID { get; set; }
        [Display(Name="Unit")]
        public int unitID { get; set; }
        public int roomID { get; set; }
        public string roomType { get; set; }
        public int outOfServiceCount { get; set; }
        public int TotalRoom { get; set; }
        public int RemaningCount { get; set; }
        public string UnitName { get; set; }
        public Int32 RoomTypeId { get; set; }
        public List<RoomOutOfServiceDetail> RoomsOutofServiceList { get; set; }
        public List<RoomNumber> RoomNoList { get; set; }
       
    }

    public class RoomNumber
    {
        public Int64 RoomNoId { get; set; }
        public string RoomNo { get; set; }
        public bool isOrderOut { get; set; }
    }

    public class GuestList
    {
      public Int64 userID{get;set;}
	   [Display(Name="Email")]
      public string email { get; set; }
       [Display(Name = "Name")]
       public string name { get; set; }
       public string address { get; set; }
       public string cityName { get; set; }
       public string stateName { get; set; }
       public string countryName { get; set; }
       public string pincode { get; set; }
       [Display(Name = "Mobile")]
       public string mobileNo { get; set; }
       public string phone { get; set; }
       public string docketNo { get; set; }

    }

    public class SpecialPackages
    {
        public Int64? pid { get; set; }
        [Required(ErrorMessage="Enter Package Name!")]
        [StringLength(100, ErrorMessage = "Package name Must less than 100 characters")]
        [Display(Name="Package Name")]
        public string routeType { get; set; }
        [StringLength(20, ErrorMessage = "Start Time or Duration in Summer Must less than 20 characters")]
        [Required(ErrorMessage = "Enter Start Time or Duration in Summer!")]
        [Display(Name = "Start Time/Duration in summer")]
        public string programStratTimeSummer { get; set; }
         [StringLength(20, ErrorMessage = "End Time in Summer Must less than 20 characters")]
        [Display(Name = "End Time")]
        public string programEndTimeSummer { get; set; }
         [StringLength(20, ErrorMessage = "Start Time or Duration in Winter Must less than 20 characters")]
        [Required(ErrorMessage = "Enter Start Time or Duration in Winter!")]
        [Display(Name = "Start Time/Duration in Winter")]
        public string programStratTimeWinter { get; set; }
        [Display(Name = "End Time")]
        [StringLength(20, ErrorMessage = "End Time Winter Must less than 20 characters")]
        public string programEndTimeWinter { get; set; }
        [Required(ErrorMessage = "Enter Abbribatiobn!")]
        [Display(Name = "abbreviation")]
        [StringLength(3, ErrorMessage = "abbreviation must not grater than 3 characters")]
        public string package_Abbr { get; set; }
        public IEnumerable<SpecialPackages> SpecList { get; set; }
        public List<SpecialPackageProgram> PackageProgram { get; set; }
    }

    public class Customer 
    {
        public Int64 userID { get; set; }

        [Display(Name = "Name")]
        [Required(ErrorMessage = "Enter Name!")]
        [StringLength(150, ErrorMessage = "Name should be upto 150 characters only!")]
        public string name { get; set; }

        [Display(Name = "Email")]        
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
        [DataType(DataType.EmailAddress)]
        [StringLength(150, ErrorMessage = "Email should be upto 150 characters only!")]
        public string email { get; set; }

        [Display(Name = "Address")]        
        [StringLength(500, ErrorMessage = "Address should be upto 500 characters only!")]
        public string address { get; set; }      

        [Display(Name = "City")]        
        public int? cityID { get; set; }

        [Display(Name = "State")]       
        public int? stateID { get; set; }

        [Display(Name = "Country")]       
        public int? countryID { get; set; }

        [Display(Name = "Pincode")]        
        [StringLength(6, ErrorMessage = "Pincode should be upto 6 characters only!")]
        [RegularExpression(@"^(\d{6})$", ErrorMessage = "Enter a valid 6 digit Pincode!")]
        public string pincode { get; set; }

        [Display(Name = "Mobile No.")]        
        [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
        [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
        public string mobileNo { get; set; }

        //[Display(Name = "Phone No.")]
        
        //[StringLength(10, ErrorMessage = "Phone No. should be upto 10 characters only!")]
        //[RegularExpression(@"^[0-9 \.\,]+$", ErrorMessage = "Enter a valid Phone No.!")]
        //public string phone { get; set; }

        [Display(Name = "Personal Identity No.")]
        [StringLength(50, ErrorMessage = "Personal Identity No. should be upto 50 characters only!")]
        public string ID { get; set; }

        [Display(Name = "Identity Type")]
        public int? IdentityType { get; set; }

        public string userIP { get; set; }

        

        [Display(Name = "DOB")]
        public int? Dobdate { get; set; }

        public int? DobMonth { get; set; }

        [Display(Name = "Anniversary Date")]
        public int? AnniversaryDate { get; set; }

        public int? AnniversaryMonth { get; set; }

        [Display(Name = "State")]       
        [StringLength(100, ErrorMessage = "State should be upto 100 characters only!")]
        public string otherState { get; set; }

        [Display(Name = "City")]
        [StringLength(100, ErrorMessage = "City should be upto 100 characters only!")]
        public string otherCity { get; set; }

       [Display(Name = "Is Staff")]
        public Boolean isStaff { get; set; }
        [Display(Name = "Staff Id")]
        public string staffId { get; set; }
        [Display(Name = "Upload Staff Identity")]
        public HttpPostedFileBase staffIdDoc { get; set; }
        public string staffIdDocPath { get; set; }
        [Display(Name = "Staff Grade")]
        public int staffGrade { get; set; }
        [Display(Name = "Staff Tariff")]
        public int staffFacility { get; set; }

        //public string privilegeCardNo { get; set; }
        //public Boolean isPrivilegeAvail { get; set; }
        //public Boolean isPrivilegeVerified { get; set; }
        public string bookingFor { get; set; }
       

        [Display(Name = "From Where")]
        [StringLength(200, ErrorMessage = "From Where should be upto 200 characters only!")]
        public string fromWhere { get; set; }
    }
    public class SearchCustomer
    {
        [Display(Name = "Docket No.")]
        [Required(ErrorMessage = "Enter Docket No.!")]
        public string DocketNo { get; set; }
    }

    public class Dates
    {
        public int dateId { get; set; }
        public string dateName { get; set; }
    }

    public class SpecialPackageProgram
    {
        public Int64 pid { get; set; }
        [Display(Name = "Program Name")]
        [Required(ErrorMessage="Enter Program Name !")]
        public string programName { get; set; }
        [Display(Name = "Display Order")]
        [Required(ErrorMessage = "Enter Program Display Order !")]
        public int? DisplayOrder { get;set; }
        [Display(Name = "Start End")]
        public string stratEnd { get; set; }
        
    }

    public class SpecialPackageFare
    {
        public Int64 fid { get; set; }
        public Int64 pid { get; set; }
        [Display(Name = "Package Name")]
        public string PackageName { get; set; }
        [Display(Name = "Package Fare")]
        [Required(ErrorMessage = "Enter Package Fare!")]
        public decimal fare { get; set; }
        public string applicantTypeName { get; set; }
        [Display(Name = "Applicant Type")]
        [Required(ErrorMessage = "Select Applicant Type!")]
        public int? applicantTypeId { get; set; }
        [Display(Name = "No. of Person")]
        public int noofPerson { get; set; }
        public IEnumerable<SpecialPackageFare> PackList { get; set; }
    }

    public class ActivatePackage
    {
        [Display(Name = "Package")]
        [Required(ErrorMessage = "Select Package!")]
        public int Packageid { get; set; }
        public string PackageName { get; set; }
        public bool staus {get;set; }
        public bool Po { get; set; }
        public List<PackageItinery> ItnaryList { get; set; }
        public List<PackageAmount> AmountList { get; set; }
        public List<FillPackgeMappedDetails> MappingDetailslist { get; set; }
        public List<PackageImageEntry> Imagelist { get; set; }
    }

    public class PackageContact
    {
     public int ContactID { get; set; }
    [Display(Name="Package")]
    [Required(ErrorMessage="Package Required !")]
     public int PackageID { get; set; }
    public string PackageName { get; set; }
    [Display(Name = "Contact Name with Mobile No.")]
    [Required(ErrorMessage = "contact Name Required !")]
     public string contactName { get; set; }
    [Display(Name = "Address")]
    [Required(ErrorMessage = "Address Required !")]
     public string address { get; set; }
    [Display(Name = "Phone No.")]
    [Required(ErrorMessage = "Phone No. Required !")]
     public string phoneNo { get; set; }
    [Display(Name = "Nodal Officer Name with Mobile No. ")]
    [Required(ErrorMessage = "Nodal Officer Name Required !")]
    public string nodalOfficer { get; set; }
    [Required(ErrorMessage = "Enter  Mobile No")]
    [StringLength(10, ErrorMessage = "Mobile No. should be upto 10 characters only!")]
    [RegularExpression(@"^(\d{10})$", ErrorMessage = "Enter a valid 10 digit Mobile No.!")]
    public string mobileNo { get; set; }
    [Display(Name = "Email")]
    [Required(ErrorMessage = "Email Required !")]
    [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$", ErrorMessage = "Enter valid Email!")]
     public string email { get; set; }
     public string unitID { get; set; }
     public List<PackageContact> ContactsofPackages { get; set;}
     
    }

    public class IncExc
    {
        [Required(ErrorMessage = "Package Required !")]
        public Int64 PackageID{get;set;}       
        public string PackageName { get; set; }
        [Required(ErrorMessage = "Package Required !")]
        [StringLength(1,ErrorMessage="It Must be I or E, I for Inclusion and E for Exclusion")]
        [Display(Name="Inclusion OR Exclusion")]
        public string Ins_Type{get;set;}
        [Required(ErrorMessage = "Inclusion Exclusion Description Required !")]
        [Display(Name = "Inclusion Exclusion Description")]
        public string Ins_Description{get;set;}
        public List<IncExc> IncExcList { get; set; }
    }
}	
