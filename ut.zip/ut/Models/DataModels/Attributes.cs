﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace UP_TourismBooking.Models.DataModels
{
    public class CityIdRequiredAttribute : ValidationAttribute, IClientValidatable
    {
         string errormessage;
         int i;
         public CityIdRequiredAttribute(string errormessage,int i)
            : base(errormessage)
        {
            this.errormessage = errormessage;
            this.i = i;
        }

         protected override ValidationResult IsValid(object value, ValidationContext validationContext)
         {
             var property = validationContext.ObjectType.GetProperty("countryID");
             int? propertyvalue = (int?)property.GetValue(validationContext.ObjectInstance, null);
             if (propertyvalue == 98 && value == null)
             {
                 if (i == 1)
                 {
                     return new ValidationResult("Select City!");
                 }
                 else
                 {
                     return new ValidationResult("Select State!");
                 }
             }
             else
             {
                 return ValidationResult.Success;
             }
             //return base.IsValid(value, validationContext);
         }



         public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
         {
             ModelClientValidationRule m = new ModelClientValidationRule();
             m.ErrorMessage = errormessage;
             m.ValidationType = "city";
             m.ValidationParameters.Add("coun", "countryID");
             yield return m;
         }
    }


    public class OtherCityRequiredAttribute : ValidationAttribute, IClientValidatable
    {
        string errormessage;
        int i;
        public OtherCityRequiredAttribute(string errormessage, int i)
            : base(errormessage)
        {
            this.errormessage = errormessage;
            this.i = i;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var property = validationContext.ObjectType.GetProperty("countryID");
            int? propertyvalue = (int?)property.GetValue(validationContext.ObjectInstance, null);
            if (propertyvalue !=null && propertyvalue!=98 && value == null)
            {
                if (i == 1)
                {
                    return new ValidationResult("Enter City!");
                }
                else
                {
                    return new ValidationResult("Enter State!");
                }
            }
            else
            {
                return ValidationResult.Success;
            }
            //return base.IsValid(value, validationContext);
        }



        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            ModelClientValidationRule m = new ModelClientValidationRule();
            m.ErrorMessage = errormessage;
            m.ValidationType = "othercity";
            m.ValidationParameters.Add("country", "countryID");
            yield return m;
        }
    }



    public class toCityAttribute : ValidationAttribute, IClientValidatable
    {
        string errormessage;
        public toCityAttribute(string errormessage)
            : base(errormessage)
        {
            this.errormessage = errormessage;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var property = validationContext.ObjectType.GetProperty("bookingtype");
            string propertyvalue = (string)property.GetValue(validationContext.ObjectInstance, null);
            if (propertyvalue=="outstation" && value == null)
            {
                return new ValidationResult("Select City!");
            }
            else
            {
                return ValidationResult.Success;
            }
            //return base.IsValid(value, validationContext);
        }



        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            ModelClientValidationRule m = new ModelClientValidationRule();
            m.ErrorMessage = errormessage;
            m.ValidationType = "tocity";
            m.ValidationParameters.Add("btype", "bookingtype");
            yield return m;
        }
    }




    public class ReceiptNoRequiredAttribute : ValidationAttribute, IClientValidatable
    {
        string errormessage;
        int i;
        public ReceiptNoRequiredAttribute(string errormessage,int i)
            : base(errormessage)
        {
            this.errormessage = errormessage;
            this.i = i;
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var property = validationContext.ObjectType.GetProperty("advanceamount");
            decimal? propertyvalue = (decimal?)property.GetValue(validationContext.ObjectInstance, null);
            if (propertyvalue != null && value == null)
            {
                if (i == 1)
                {
                    return new ValidationResult("Enter Receipt No.!");
                }
                else
                {
                    return new ValidationResult("Enter Payment Date!");
                }
            }
            else
            {
                return ValidationResult.Success;
            }
            //return base.IsValid(value, validationContext);
        }



        public IEnumerable<ModelClientValidationRule> GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        {
            ModelClientValidationRule m = new ModelClientValidationRule();
            m.ErrorMessage = errormessage;
            m.ValidationType = "receipt";
            m.ValidationParameters.Add("rec", "advanceamount");
            yield return m;
        }
    }
}