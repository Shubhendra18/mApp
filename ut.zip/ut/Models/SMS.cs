﻿using System;
using System.Data;
using System.Collections;
using System.Net;
using System.IO;
using UP_TourismBooking.Models;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;

/// <summary>
/// Summary description for SMS
/// </summary>
public class SMS
{
    public SMS()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static String SMSSend(String Message, String Recipient)
    {
        string s = string.Empty;
        try
        {
            WebClient Client = new WebClient();

            string baseurl = "http://103.16.101.52:8080/sendsms/bulksms?username=omnt-UPSTDC&password=GH543E4&type=0&dlr=1&destination=" + Recipient + "&source=UPSTDC&message=" + Message;

            Stream data = Client.OpenRead(baseurl);
            StreamReader reader = new StreamReader(data);
            s = reader.ReadToEnd();
            s = "Success";
            data.Close();
            reader.Close();
        }
        catch (Exception ex)
        {
            return s + " " + ex.Message;
        }
        return s;
    }

    public static void SMSLog(String Message, String MobileNo, String DocketNo, String SMSStatus)
    {
        try
        {
            BusinessClass obj = new BusinessClass();
            obj.SMSLog(Message, MobileNo, DocketNo, SMSStatus);
        }
        catch
        { }
    }

}
