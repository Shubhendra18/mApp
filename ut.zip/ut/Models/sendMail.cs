﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Web.Mail;
using UP_TourismBooking.MailServiceNew;
using UP_TourismBooking.Models;

/// <summary>
/// Summary description for sendMail
/// </summary>

public class SendMail
{


    #region code for mail functionality
    public static void Send(string mailTo, string mailSub, string mailMsg)
    {
        string mailerHost = SendMail.ServerIP;
        string mailFrom = SendMail.AdminMail;

        MailMessage mlMsg = new MailMessage();
        if (mailerHost.Trim() != "")
            SmtpMail.SmtpServer = mailerHost;
        mlMsg.To = mailTo;
        //if (mailCC != "")
        //    mlMsg.Bcc = mailCC;

        mlMsg.From = mailFrom;

        mlMsg.BodyFormat = MailFormat.Html;
        mlMsg.Body = mailMsg;
        mlMsg.Subject = mailSub;

        try
        {
            SmtpMail.Send(mlMsg);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public static string AdminMail
    {
        get
        {
            String _fromEmail = System.Configuration.ConfigurationManager.AppSettings["MailFrom"].ToString();
            if (String.IsNullOrEmpty(_fromEmail))
                return String.Empty;
            else
                return _fromEmail;
        }
    }

    public static string CCMailID
    {
        get
        {
            String _fromEmail = System.Configuration.ConfigurationManager.ConnectionStrings["ccMail"].ConnectionString;
            if (String.IsNullOrEmpty(_fromEmail))
                return String.Empty;
            else
                return _fromEmail;
        }
    }

    public static string ServerIP
    {
        get
        {
            String _serverIP = System.Configuration.ConfigurationManager.AppSettings["serverIP"].ToString();
            if (String.IsNullOrEmpty(_serverIP))
                return String.Empty;
            else
                return _serverIP;
        }
    }
    #endregion


    #region Get IP Address
    public String getIPAddress()
    {
        String ip = "";
        try
        {
            ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
            if (!string.IsNullOrEmpty(ip))
            {
                string[] ipRange = ip.Split(',');
                int le = ipRange.Length - 1;
                string trueIP = ipRange[le];
            }
            else
            {
                ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
            }
        }
        catch
        {
            ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
        }
        return ip;
    }

    #endregion

    public static void SendMailNew(string mailTo, string mailSub, string mailMsg, bool isBCC = true)
    {
        if (!string.IsNullOrEmpty(mailTo))
        {
            MailerClass maileClass = new MailerClass();
            string emailSendService = string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["EmailService"])) ? "S1" : ConfigurationManager.AppSettings["EmailService"].ToString();

            string From = string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["Frommail"])) ? "donotreply@up-tourism.com" : ConfigurationManager.AppSettings["Frommail"].ToString();

            string BCCmail;

            if (isBCC)
            {
                BCCmail = string.IsNullOrEmpty(Convert.ToString(ConfigurationManager.AppSettings["bccmail"])) ? "gaurav@otpl.co.in" : ConfigurationManager.AppSettings["bccmail"].ToString();
            }
            else
            {
                BCCmail = "";
            }

            if (emailSendService == "S2")
            {
                string[] tmp = new string[1];
                string[] mailtol = new string[1];
                mailtol[0] = mailTo;
                Service1 obj = new Service1();
                EmailDataNew msg = new EmailDataNew();

                msg.frommail = "";

                tmp[0] = BCCmail;

                msg.bccemail = tmp;

                //tmp = new string[1];
                //tmp[0] = mailTo;

                msg.toemail = mailtol;

                tmp = new string[1];
                msg.ccemail = tmp;

                msg.subject = mailSub;
                msg.mailbody = mailMsg;
                try
                {
                    obj.sendMailNew(msg);
                }
                catch
                {
                }
            }
            else if (emailSendService == "S1")
            {
                try
                {
                    UP_TourismBooking.MailService.Service1 objService = new UP_TourismBooking.MailService.Service1();
                    UP_TourismBooking.MailService.EmailData objMail = new UP_TourismBooking.MailService.EmailData() { bccemail = BCCmail, ccemail = "", mailbody = mailMsg, subject = mailSub, toemail = mailTo };
                    objService.sendMail(objMail);
                }
                catch
                {
                }
            }
            else if (emailSendService == "S3")
            {
                string[] BccMaill = new string[1];
                string[] mailtol = new string[1];
                string[] ccMaill = new string[1];
                mailtol[0] = mailTo;
                BccMaill[0] = BCCmail;

                string status = maileClass.sendMail(mailtol, BccMaill, ccMaill, From, mailMsg, mailSub);



            }
        }
    }
}

