﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaymentUtility
{
    public class RequestFormat
    {
        public string channel { get; set; }
        public string secrectKey { get; set; }
        public string account_id { get; set; }
        public string reference_no { get; set; }
        public string amount { get; set; }
        public string mode { get; set; }
        public string display_currency { get; set; }
        public string display_currency_rates { get; set; }
        public string description { get; set; }
        public string return_url { get; set; }
        public string name { get; set; }
        public string address { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string country { get; set; }
        public string postal_code { get; set; }
        public string phone { get; set; }
        public string email { get; set; }
        public string ship_address { get; set; }
        public string ship_city { get; set; }
        public string ship_state { get; set; }
        public string ship_postal_code { get; set; }
        public string ship_country { get; set; }
        public string ship_phone { get; set; }
    }
}

