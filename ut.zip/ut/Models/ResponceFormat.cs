﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PaymentUtility
{
    public class ResponceFormat
    {
        public string MerchantRefNo { get; set; }
        public string TransactionID { get; set; }
        public string PaymentID { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentInfoString { get; set; }
        public string ReturnBackToWebsite { get; set; }
    }

}
