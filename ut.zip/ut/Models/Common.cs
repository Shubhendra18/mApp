﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net.Mime;
using System.Data;
using System.Text.RegularExpressions;
using Microsoft.Practices.EnterpriseLibrary.Data;
using System.Data.SqlClient;
//using System.Linq;
using System.Web;
using UP_TourismBooking.Models.DataModels;
using System.Data.Common;
using System.Text;

/// <summary>
/// Summary description for Common
/// </summary>
public class Common
{
    public Common()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public static SortedDictionary<string, string> SortNameValueCollection(NameValueCollection nvc)
    {
        SortedDictionary<string, string> sortedDict = new SortedDictionary<string, string>();
        foreach (String key in nvc.AllKeys)
            sortedDict.Add(key, nvc[key]);
        return sortedDict;
    }

    public static string GetAppConfig(string Key)
    {
        return GetAppConfig(Key, "");
    }

    public static string GetAppConfig(string Key, string defaultValue)
    {
        string appConfigValue = "";
        string AppValue = System.Configuration.ConfigurationManager.AppSettings[Key];
        if (string.IsNullOrEmpty(AppValue))
        {
            if (!string.IsNullOrEmpty(defaultValue))
                appConfigValue = defaultValue;
            else
                appConfigValue = "";
        }
        else
        {
            appConfigValue = AppValue;
        }
        return appConfigValue;
    }

    public static Crypto.Algorithm GetConfigAlgorithm(string key)
    {
        return GetConfigAlgorithm(key, "");
    }

    /// <summary>
    /// Supported Algorithm: SHA1, SHA256, SHA384, MD5 and SHA512
    /// </summary>
    /// <param name="key"></param>
    /// <param name="defaultValue"></param>
    /// <returns></returns>
    public static Crypto.Algorithm GetConfigAlgorithm(string key, string defaultValue)
    {
        string ConfigValue = GetAppConfig(key, defaultValue);
        Crypto.Algorithm algorithm = new Crypto.Algorithm();
        if (!string.IsNullOrEmpty(ConfigValue))
        {
            switch (ConfigValue.ToLower())
            {
                case "sha1":
                    algorithm = Crypto.Algorithm.SHA1;
                    break;
                case "sha256":
                    algorithm = Crypto.Algorithm.SHA256;
                    break;
                case "sha384":
                    algorithm = Crypto.Algorithm.SHA384;
                    break;
                case "sha512":
                    algorithm = Crypto.Algorithm.SHA512;
                    break;
                case "md5":
                    algorithm = Crypto.Algorithm.MD5;
                    break;
                default:
                    throw new ArgumentException("Invalid algorithm configured in configuration", "Algorithm");
            }
        }
        else
            throw new ArgumentException("Invalid algorithm configured in configuration", "Algorithm");
        return algorithm;
    }

    #region Hash-Value-Reverse-Value
    public string HashValue(string value)
    {
        return (Convert.ToInt64(value)).ToString("X");

    }
    public string ReverseHashToValue(string hexValue)
    {
        return (Int64.Parse(hexValue, System.Globalization.NumberStyles.HexNumber)).ToString();
    }
    #endregion

    #region GetIpAddress
    public static String GetIPAddress()
    {
        String ip = "";
        try
        {
            ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
            if (!string.IsNullOrEmpty(ip))
            {
                string[] ipRange = ip.Split(',');
                int le = ipRange.Length - 1;
                string trueIP = ipRange[le];
            }
            else
            {
                ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
            }
        }
        catch
        {
            ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
        }
        return ip;
    }
    #endregion 

    #region Get month date
    public IEnumerable<Dates> getMonthdate()
    {
       
        List<Dates> l = new List<Dates>();
        for (int i = 1; i <= 31; i++)
        {
            l.Add(new Dates() { dateId = i, dateName = i.ToString() });
        }       
        return l;
    }
    #endregion 

    #region ValidateImmageExtension
    public string ValidateImageExt(HttpPostedFileBase image, string UploadImagePath)
    {
        string massage;
        String fn = Path.GetFileNameWithoutExtension(image.FileName);
        String ext = Path.GetExtension(image.FileName);
        char[] SpecialChars = "!@#$%^&*()+=~`\\|/?><,\"".ToCharArray();
        int indexOf = fn.IndexOfAny(SpecialChars);
        String fileName = fn;
        int count = fileName.Split('.').Length - 1;
        if (count > 1)
        {
            massage= "Double extension not allowed in image name";

        }
        else
        {
            if (indexOf != -1)
            {
                massage= "Special character not allowed in image name";

            }
            else
            {
                string mimetype = image.ContentType;
                if ((ext == ".jpg" || ext == ".jpeg") && (mimetype == "image/jpeg" || mimetype == "image/jpg"))
                    
                    {
                        fn = "";

                        string fFullName = image.FileName;
                        int len = fFullName.Length;
                        string ext1 = Path.GetExtension(fFullName);
                        string str = fFullName.Substring(fFullName.LastIndexOf("\\") + 1);
                        len = str.Length;
                        string fileN = str.Substring(0, len - ext1.Length);

                        Regex FilenameRegex = null;
                        FilenameRegex = new Regex("(.*?)\\.(jpeg|jpg|JPEG|JPG)$", RegexOptions.IgnoreCase);
                        int index = fileN.IndexOf(".");

                        if (!FilenameRegex.IsMatch(fFullName) || index != -1)
                        {
                            massage= "Please upload .jpg or .jpeg file only";

                        }
                        else
                        {
                            string Photoname = Path.GetFileNameWithoutExtension(image.FileName);
                            string fileSize = image.ContentLength.ToString();
                            String ImageFileNameMBA = image.FileName;

                            Byte[] stu_imageMBA = new Byte[image.ContentLength];

                            Stream fs = image.InputStream;
                            fs.Read(stu_imageMBA, 0, Convert.ToInt32(fileSize));

                            fs.Seek(0, SeekOrigin.Begin);
                            StreamReader sr = new StreamReader(fs, true);

                            string firstLine = sr.ReadLine().ToString();

                            //string firstLine = "JFIF";

                            if ((firstLine.IndexOf("JFIF") > -1) || (firstLine.IndexOf("Exif") > -1))
                            {

                                if (image.ContentLength <= 1024 * 1024)
                                {
                                    massage= "Valid";

                                }

                                else
                                {
                                    massage= "Image size can not exceed 1 MB ";
                                }
                            }
                            else
                            {
                                massage= "Please upload .jpg or .jpeg file only";
                            }
                        }
                    }
                    else
                    {
                        massage= "Please upload .jpg or .jpeg file only";
                    }
            }
        }
        return massage;
    }

    public string ValidateImageWithCusomSize(HttpPostedFileBase image, int ImageSize)
    {
        string massage;
        String fn = Path.GetFileNameWithoutExtension(image.FileName);
        String ext = Path.GetExtension(image.FileName);
        char[] SpecialChars = "!@#$%^&*()+=~`\\|/?><,\"".ToCharArray();
        int indexOf = fn.IndexOfAny(SpecialChars);
        String fileName = fn;
        int count = fileName.Split('.').Length - 1;
        if (count > 1)
        {
            massage = "Double extension not allowed in file name";

        }
        else
        {
            if (indexOf != -1)
            {
                massage = "Special character not allowed in file name";

            }
            else
            {
                string mimetype = image.ContentType;
                if ((ext == ".jpg" || ext == ".jpeg") && (mimetype == "image/jpeg" || mimetype == "image/jpg"))
                {
                    fn = "";

                    string fFullName = image.FileName;
                    int len = fFullName.Length;
                    string ext1 = Path.GetExtension(fFullName);
                    string str = fFullName.Substring(fFullName.LastIndexOf("\\") + 1);
                    len = str.Length;
                    string fileN = str.Substring(0, len - ext1.Length);

                    Regex FilenameRegex = null;
                    FilenameRegex = new Regex("(.*?)\\.(jpeg|jpg|JPEG|JPG)$", RegexOptions.IgnoreCase);
                    int index = fileN.IndexOf(".");

                    if (!FilenameRegex.IsMatch(fFullName) || index != -1)
                    {
                        massage = "Please upload .jpg or .jpeg file only";

                    }
                    else
                    {
                        string Photoname = Path.GetFileNameWithoutExtension(image.FileName);
                        string fileSize = image.ContentLength.ToString();
                        String ImageFileNameMBA = image.FileName;

                        Byte[] stu_imageMBA = new Byte[image.ContentLength];

                        Stream fs = image.InputStream;
                        fs.Read(stu_imageMBA, 0, Convert.ToInt32(fileSize));

                        fs.Seek(0, SeekOrigin.Begin);
                        StreamReader sr = new StreamReader(fs, true);

                        string firstLine = sr.ReadLine().ToString();

                        //string firstLine = "JFIF";

                        if ((firstLine.IndexOf("JFIF") > -1) || (firstLine.IndexOf("Exif") > -1))
                        {

                            if (image.ContentLength <= 1024 * ImageSize)
                            {
                                massage = "Valid";

                            }

                            else
                            {
                                massage = "File size can not exceed "+ImageSize+" KB ";
                            }
                        }
                        else
                        {
                            massage = "Please upload .jpg or .jpeg file only";
                        }
                    }
                }
                else
                {
                    massage = "Please upload .jpg or .jpeg file only";
                }
            }
        }
        return massage;
    }

    public string ValidateFile(HttpPostedFileBase image)
    {
        string massage;
        String fn = Path.GetFileNameWithoutExtension(image.FileName);
        String ext = Path.GetExtension(image.FileName);
        char[] SpecialChars = "!@#$%^&*()+=~`\\|/?><,\"".ToCharArray();
        int indexOf = fn.IndexOfAny(SpecialChars);
        String fileName = fn;
        int count = fileName.Split('.').Length - 1;
        if (count > 1)
        {
            massage = "Double extension not allowed in file name";

        }
        else
        {
            if (indexOf != -1)
            {
                massage = "Special character not allowed in file name";

            }
            else
            {
                string mimetype = image.ContentType;
                if ((ext == ".jpg" || ext == ".jpeg" || ext == ".pdf" || ext == ".doc" || ext == ".docx") && (mimetype == "image/jpeg" || mimetype == "image/jpg" || mimetype == "application/pdf" || mimetype == "application/msword" || mimetype == "application/vnd.openxmlformats-officedocument.wordprocessingml.document"))
                {
                    fn = "";

                    string fFullName = image.FileName;
                    int len = fFullName.Length;
                    string ext1 = Path.GetExtension(fFullName);
                    string str = fFullName.Substring(fFullName.LastIndexOf("\\") + 1);
                    len = str.Length;
                    string fileN = str.Substring(0, len - ext1.Length);

                    Regex FilenameRegex = null;
                    FilenameRegex = new Regex("(.*?)\\.(jpeg|jpg|JPEG|JPG|pdf|PDF|DOC|doc|docx|DOCX)$", RegexOptions.IgnoreCase);
                    int index = fileN.IndexOf(".");

                    if (!FilenameRegex.IsMatch(fFullName) || index != -1)
                    {
                        massage = "Please upload .jpg or .jpeg file only";

                    }
                    else
                    {
                        massage = "Valid";
                    }
                }
                else
                {
                    massage = "Please upload .jpg or .jpeg file only";
                }
            }
        }
        return massage;
    }
    #endregion

    #region GetUnitRooms
    public static DataTable GetRoomBookingList(int unitid, int month,int Year)
    {
        string _procName = "proc_getUnitBookingAtAGlance";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@month", DbType.Int32, month);
        objDatabase.AddInParameter(objDbCommand, "@unitId", DbType.Int32, unitid);
        objDatabase.AddInParameter(objDbCommand, "@year", DbType.Int32, Year);
       
        try
        {
            using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
            {
                dt1.Load(dr);
            }
        }
        catch { dt1 = null; }
        return dt1;
       
    }
    #endregion

    #region Get all Unit booking count
    public static DataTable GetAllUnitBookingCountReport(int month, int Year)
    {
        string _procName = "getAllUnitBookingCount";
        DataTable dt1 = new DataTable();
        Database objDatabase = DatabaseFactory.CreateDatabase();
        DbCommand objDbCommand = objDatabase.GetStoredProcCommand(_procName);
        objDatabase.AddInParameter(objDbCommand, "@month", DbType.Int32, month);
        objDatabase.AddInParameter(objDbCommand, "@YEAR", DbType.String, Year);

        try
        {
            using (IDataReader dr = objDatabase.ExecuteReader(objDbCommand))
            {
                dt1.Load(dr);
            }
        }
        catch { dt1 = null; }
        return dt1;

    }
    #endregion

    public DataTable ReturnDatatable(string[] arr)
    {
        DataTable dt = new DataTable();
        dt.Columns.Add("item", typeof(string));
        foreach (var item in arr)
        {
            DataRow dr = dt.NewRow();
            dr["item"] = item;
            dt.Rows.Add(dr);
        }
        return dt;
    }

    public string GetCGSTandSGSTSepration(string GSTSlavePer)
    {
        StringBuilder sb = new StringBuilder();
        
        string data=GSTSlavePer.Trim().TrimEnd(',').Replace('%',' ' );
        var Res = data.Split(',');
        if (Res.Length > 0)
        {
            for (int i = 0; i < Res.Length; i++)
            {
                uint a;
                uint.TryParse(Res[i].Trim(), out a);
                sb.Append(Convert.ToString(a / 2));
                sb.Append("%,");
            }
        }
        else
        {
            sb.Append(GSTSlavePer);
        }

        return sb.ToString();
    }

}