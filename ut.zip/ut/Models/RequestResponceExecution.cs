﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;

namespace PaymentUtility
{
    public class RequestResponceExecution
    {
        #region RequestForm
        private string RequestForm(Dictionary<string, string> reqFormat)
        {
            var rForm = @"<form  method='post' action='Post.aspx' name='frmTransaction' id='frmTransaction' runat='server' style='display:none'>  	 
         <table width='600' cellpadding='2' cellspacing='2' border='0'>
            <tr>
                <th colspan='2'>Transaction Details</th>
            </tr>
		    <tr>
                <td class='fieldName'><span class='error'>*</span> Channel</td>
                <td align='left'><select name='channel' >
				    <option value='10'>Standard</option>
			    </select></td>
            </tr>
	       <tr>
                <td class='fieldName' width='50%'><span class='error'>*</span> Account Id</td>
                <td  align='left' width='50%'> <input runat='server' id='account_id' name='account_id' type='text' value='$account_id$'/>
                 <br><span><font color='red'> Please Enter your Account ID provided.</font></span> </td> 
            </tr>
            <tr>
                <td class='fieldName' width='50%'><span class='error'>*</span> Secret Key</td>
                <td  align='left' width='50%'> <input runat='server' id='secretkey' name='secretkey' type='text' value='$secretkey$' size='35'/>
                <br><span><font color='red'> Please Enter your Secret Key provided.</font></span></td>
            </tr>
	       <tr>
                <td class='fieldName' width='50%'><span class='error'>*</span> Reference No</td>
                <td  align='left' width='50%'> <input name='reference_no' type='text' value='$reference_no$' /></td>
            </tr>
            <tr>
                <td class='fieldName' width='50%'><span class='error'>*</span> Sale Amount</td>
                <td  align='left' width='50%'> 
                    <input name='amount' type='text' value='$amount$' /> 
                    <select name='currency' >
				    <option value='INR'>INR</option>
			    </select></td>
            </tr>
		    <tr>
                <td class='fieldName'>Additional Currency</td>
                <td align='left'><select name='display_currency' >
				    <option value='INR' selected>INR</option>
				    <option value='USD'>USD</option>
				    <option value='EUR' selected>EURO</option>
				    <option value='GBP' selected>GBP</option>
			    </select></td>
            </tr>
		    <tr>
                <td class='fieldName' width='50%'>Additional Currency Rate</td>
                <td  align='left' width='50%'> <input name='display_currency_rates' type='text' value='1' /></td>

            </tr>
            <tr>
                <td class='fieldName' width='50%'><span class='error'>*</span> Description</td>
                <td  align='left' width='50%'> <input name='description' type='text' value='UPTU Product' /></td>
            </tr>
		          <tr>
                <td class='fieldName'><span class='error'>*</span> Return Url</td>

                <td align='left'><input name='return_url' type='text' size='60' value='$return_url$' /> </td>
            </tr>
		    <tr>
                <td class='fieldName'><span class='error'>*</span> Mode</td>
                <td align='left'><select name='mode' >
				    <option value='LIVE' selected>LIVE</option>
			    </select> </td>
            </tr>
		    <tr>
                <td class='fieldName'>Payment Mode</td>
                <td align='left'>
                    <select name='payment_mode' >
				    <option value=''>All</option>	
				    <option value='1'>Credit Card</option>
				    <option value='2'>Debit Card</option>
				    <option value='3'>Net Banking</option>
				    <option value='5'>Credit Card - EMI</option>
			    </select>
                </td>
            </tr>
		    <tr>
                <td class='fieldName'>Card Brand</td>
                <td align='left'>
                    <select name='card_brand' >
				    <option value=''>All</option>	
				    <option value='1'>VISA</option>
				    <option value='2'>MasterCard</option>
				    <option value='3'>Maestro</option>
				    <option value='4'>Diners Club</option>

				    <option value='5'>American Express</option>
				    <option value='6'>JCB</option>
			    </select>
                </td>
            </tr>
		    <tr>
                <td class='fieldName'>Payment Option</td>
                <td align='left'>
				    <input name='payment_option' type='text' value='' />
                </td>
            </tr>
		    <tr>
                <td class='fieldName'>Bank Code</td>
                <td align='left'>
                    <input name='bank_code' type='text' value='' />
                </td>
            </tr>
		    <tr>
                <td class='fieldName'>EMI</td>
                <td align='left'>
                    <input name='emi' type='text' value='' />
                </td>
            </tr>
		    <tr>
                <td class='fieldName'>Page ID</td>
                <td align='left'>
                    <input name='page_id' type='text' value='' /> 
                </td>
            </tr>
            <tr>
                <th colspan='2'>Billing Address</th>
            </tr>
	        <tr>
                <td class='fieldName'><span class='error'>*</span> Name</td>
                <td align='left'>
                    <input name='name' type='text' value='$address$' /></td>
            </tr>       
            <tr>

                <td class='fieldName'><span class='error'>*</span>Address</td>
                <td align='left'>
                    <textarea name='address'>$address$</textarea>
                </td>
            </tr>
            <tr>
                <td class='fieldName'><span class='error'>*</span>City</td>

                <td align='left'>
                    <input name='city' type='text' value='$city$' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'>State/Province</td>
                <td align='left'>
                   <input name='state' type='text' value='$name$' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'><span class='error'>*</span>ZIP/Postal Code</td>
                <td align='left'>
                    <input name='postal_code' type='text' value='$postal_code$' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'><span class='error'>*</span>Country</td>
                <td align='left'>
                    <input name='country' type='text' value='IND' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'><span class='error'>*</span>Email</td>
                <td align='left'>
                    <input name='email' type='text' value='$email$' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'><span class='error'>*</span>Telephone</td>
                <td align='left'><input name='phone' type='text' value='$phone$' /></td>
            </tr>		
            <tr>
                <th colspan='2'>Delivery Address</th>
            </tr>
		    <tr>
                <td class='fieldName'>Name</td>
                <td align='left'>
                    <input name='ship_name' type='text' value='Test Name' />
                </td>
            </tr>       
            <tr>
                <td class='fieldName'>Address</td>
                <td align='left'>
                    <input name='ship_address' type='text' value='Test Address' />
                </td>
            </tr>

            <tr>
                <td class='fieldName'>City</td>
                <td align='left'>
                    <input name='ship_city' type='text' value='Test Lko' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'>State/Province</td>
                <td align='left'>
                   <input name='ship_state' type='text' value='UP' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'>ZIP/Postal Code</td>
                <td align='left'>
                    <input name='ship_postal_code' type='text' value='400069' />
                </td>
            </tr>
            <tr>
                <td class='fieldName'>Country</td>
                <td align='left'><input name='ship_country' type='text' value='IND' /></td>
            </tr>
            <tr>
                <td class='fieldName'>Telephone</td>
                <td align='left'><input name='ship_phone' type='text' value='2211112222' /></td>
            </tr>
            <tr>
                <td valign='top' align='center' colspan='2'>
                    <input name='submitted' value='Submit' type='submit' />&nbsp; 
                    <input value='Reset' type='reset' />
                </td>
            </tr>
            <tr>
                <td valign='top' align='center' colspan='2'>
                    <span class='error'>*</span> 
                    <span>denotes required field</span>
                </td>
            </tr>
        </table>
<script type='text/javascript'>
frmTransaction.submit();
        </script>
    </form>";
            foreach (var item in reqFormat)
            {
                rForm = rForm.Replace("$" + item.Key + "$", item.Value);
            }
            return rForm;
        }
        #endregion

        #region RequestPayment
        public string RequestPayment(RequestFormat reqFormat)
        {
            //reqFormat = new Db;// new DataConnectivity().LoadPayeeInfoByRef(reqFormat);
            var reqHashArr = new string[22];
            var reqArr = new Dictionary<string, string>();
            reqArr["channel"] = "10";
            reqArr["secrectKey"] = ConfigurationManager.AppSettings["SECRET_KEY"] != null ? ConfigurationManager.AppSettings["SECRET_KEY"].ToString() : "<SecrectKeyRequire>";
            reqArr["account_id"] = ConfigurationManager.AppSettings["ACCOUNT_ID"] != null ? ConfigurationManager.AppSettings["ACCOUNT_ID"].ToString() : "<AccountID>";
            reqArr["reference_no"] = "12345";//reqFormat.reference_no;
            reqArr["amount"] = "12.34";// reqFormat.amount;
            reqArr["mode"] = "LIVE";
            reqArr["display_currency"] = "INR";
            reqArr["display_currency_rates"] = "1";
            reqArr["description"] = "Ziaul";//string.IsNullOrEmpty(reqFormat.description) ? "UPTU Product" : reqFormat.description;
            reqArr["return_url"] = ConfigurationManager.AppSettings["RETURN_URL"] != null ? ConfigurationManager.AppSettings["RETURN_URL"].ToString() : "<ReturnPageRequrie>";
            reqArr["name"] = "Ziaul";//reqFormat.name;
            reqArr["address"] = "lko";// reqFormat.address;
            reqArr["city"] = "lko";//reqFormat.city;
            reqArr["state"] = "lko";//reqFormat.state;
            reqArr["country"] = "IND";
            reqArr["postal_code"] = "lko";//reqFormat.postal_code;
            reqArr["phone"] = "lko";//reqFormat.phone;
            reqArr["email"] = "lko";//reqFormat.email;
            reqArr["ship_address"] = "Test";
            reqArr["ship_city"] = "Test";
            reqArr["ship_state"] = "Test";
            reqArr["ship_postal_code"] = "400069";
            reqArr["ship_country"] = "IND";
            reqArr["ship_phone"] = "2211112222";
            return RequestForm(reqArr);
        }
        #endregion

        #region ResponceFormat
        public ResponceFormat ResponceFormat(SortedDictionary<string, string> reqFormat)
        {
            //var responceFormat = new DataConnectivity().UpdatePayeeInfoByRef(new ResponceFormat
            //{
            //    MerchantRefNo = reqFormat["MerchantRefNo"],
            //    TransactionID = reqFormat["TransactionID"],
            //    PaymentID = reqFormat["PaymentID"],
            //    PaymentMethod = reqFormat["PaymentMethod"],
            //    PaymentInfoString = ReponceToString(reqFormat),
            //});
            //return responceFormat;
            return null;
        }
        #endregion

        #region ReponceToString
        private string ReponceToString(SortedDictionary<string, string> sortedDict)
        {
            var paymentInfo = new StringBuilder();
            foreach (var item in sortedDict)
            {
                paymentInfo.Append("<" + item.Key + ">" + item.Value + "</" + item.Key + ">");
            }
            return paymentInfo.ToString();
        }
        #endregion
    }
}
