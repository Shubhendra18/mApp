﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;


namespace UP_TourismBooking.Models.ProcessClasses
{
    public static class ExceptionHandler
    {

        //public static int SaveException(string exception, string page, string method, DateTime exceptiondatetime)
        //{
        //    Database dbobj = DatabaseFactory.CreateDatabase("safarnaama");
        //    DbCommand dbcmd = dbobj.GetStoredProcCommand("Proc_SaveException");
        //    dbobj.AddInParameter(dbcmd, "@exception", DbType.String, exception);
        //    dbobj.AddInParameter(dbcmd, "@page", DbType.String, page);
        //    dbobj.AddInParameter(dbcmd, "@method", DbType.String, method);
        //    dbobj.AddInParameter(dbcmd, "@exceptiondatetime", DbType.DateTime, exceptiondatetime);
            
        //    int record = 0;
        //    record = dbobj.ExecuteNonQuery(dbcmd);
        //    return record;
        //}
        //public static string CreateErrorMessage(Exception serviceException)
        //{
        //    StringBuilder messageBuilder = new StringBuilder();

        //    try
        //    {
        //        messageBuilder.Append("The Exception is:-");

        //        messageBuilder.Append("Exception :: " + serviceException.ToString());
        //        if (serviceException.InnerException != null)
        //        {
        //            messageBuilder.Append("InnerException :: " + serviceException.InnerException.ToString());
        //        }
        //        return messageBuilder.ToString();
        //    }
        //    catch
        //    {
        //        messageBuilder.Append("Exception:: Unknown Exception.");
        //        return messageBuilder.ToString();
        //    }

        //} 


        public static void LogException(string controllerName, string methodName, string message)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                string logFilePath = AppDomain.CurrentDomain.BaseDirectory + "ErrorLog\\";

                logFilePath = logFilePath + "ErrorLog_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + "." + "txt";

                if (logFilePath.Equals("")) return;

                //Create the Log file directory if it does not exists

                DirectoryInfo logDirInfo = null;
                FileInfo logFileInfo = new FileInfo(logFilePath);
                logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);

                if (!logDirInfo.Exists) logDirInfo.Create();
             
                if (!logFileInfo.Exists)
                {
                    fileStream = logFileInfo.Create();
                }
                else
                {
                    fileStream = new FileStream(logFilePath, FileMode.Append);
                }
                streamWriter = new StreamWriter(fileStream);
                streamWriter.WriteLine();
                streamWriter.WriteLine(DateTime.Now);
                streamWriter.WriteLine("Controller :: " + controllerName);
                streamWriter.WriteLine("Method :: " + methodName);
                streamWriter.WriteLine("Exception :: " + message);
            }
            finally
            {
                if (streamWriter != null) streamWriter.Close();
                if (fileStream != null) fileStream.Close();
            }
 
        }

        public static void LogExceptionPayment(string controllerName, string methodName, string message)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;
            try
            {
                string logFilePath = AppDomain.CurrentDomain.BaseDirectory + "ErrorLog\\";

                logFilePath = logFilePath + "ErrorLogPayment_" + DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + "." + "txt";

                if (logFilePath.Equals("")) return;

                //Create the Log file directory if it does not exists

                DirectoryInfo logDirInfo = null;
                FileInfo logFileInfo = new FileInfo(logFilePath);
                logDirInfo = new DirectoryInfo(logFileInfo.DirectoryName);

                if (!logDirInfo.Exists) logDirInfo.Create();

                if (!logFileInfo.Exists)
                {
                    fileStream = logFileInfo.Create();
                }
                else
                {
                    fileStream = new FileStream(logFilePath, FileMode.Append);
                }
                streamWriter = new StreamWriter(fileStream);
                streamWriter.WriteLine();
                streamWriter.WriteLine(DateTime.Now);
                streamWriter.WriteLine("Controller :: " + controllerName);
                streamWriter.WriteLine("Method :: " + methodName);
                streamWriter.WriteLine("Exception :: " + message);
            }
            finally
            {
                if (streamWriter != null) streamWriter.Close();
                if (fileStream != null) fileStream.Close();
            }

        }
    }
}

