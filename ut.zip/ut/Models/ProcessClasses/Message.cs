﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.ProcessClasses
{
    public static class Message
    {
        public const string Add = "Record Saved Successfully!";
        public const string Update = "Record Updated Successfully!";
        public const string ErrorAdd = "Record Not Saved!";
        public const string ErrorUpdate = "Record Not Updated!";
        public const string Delete = "Record Deleted Successfully!";
        public const string ErrorDelete = "Record Not Deleted!";
    }
}