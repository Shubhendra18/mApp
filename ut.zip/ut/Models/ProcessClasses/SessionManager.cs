﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UP_TourismBooking.Models.ProcessClasses
{
    public class SessionManager
    {
        public static void RemoveSession()
        {
            try
            {
                HttpContext.Current.Session.Clear();
                HttpContext.Current.Session.Abandon();
                HttpContext.Current.Session.RemoveAll();
            }
            catch
            { }
        }

        public static bool IsAdminSessionActive()
        {
            bool flag = false;
            try
            {
                if (!string.IsNullOrEmpty(SessionManager.Username))
                {
                    flag = true;
                }
            }
            catch
            {
                flag = false;
            }
            return flag;
        }
     
        public static string Username
        {
            get
            {
                if (HttpContext.Current.Session["username"] != null)
                {
                    return HttpContext.Current.Session["username"].ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["username"] = value;
            }
        }
      
        public static string SeedValue
        {
            get
            {
                if (HttpContext.Current.Session["seedValue"] != null)
                {
                    return (HttpContext.Current.Session["seedValue"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["seedValue"] = value;
            }
        }

        public static bool IsGuid
        {
            get
            {
                if (HttpContext.Current.Session["IsGuid"] != null)
                {
                    return Convert.ToBoolean(HttpContext.Current.Session["IsGuid"]);
                }
                else
                {
                    return false;
                }
            }
            set
            {
                HttpContext.Current.Session["IsGuid"] = value;
            }
        }

        public static Int64 UserID
        {
            get
            {
                if (HttpContext.Current.Session["userID"] != null)
                {
                    return Convert.ToInt64(HttpContext.Current.Session["userID"].ToString());
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["userID"] = value;
            }
        }

        public static string RoleID
        {
            get
            {
                if (HttpContext.Current.Session["roleID"] != null)
                {
                    return (HttpContext.Current.Session["roleID"]).ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["roleID"] = value;
            }
        }

        public static bool IsSessionActive(string key)
        {
            bool flag = false;
            try
            {
                if (HttpContext.Current.Session[key] != null && HttpContext.Current.Session[key].ToString() != "")
                {
                    flag = true;
                }
            }
            catch
            {
                flag = false;
            }
            return flag;
        }

        public static string DisplayName
        {
            get
            {
                if (HttpContext.Current.Session["displayName"] != null)
                {
                    return HttpContext.Current.Session["displayName"].ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["displayName"] = value;
            }
        }

        public static string CustomerMobile
        {
            get
            {
                if (HttpContext.Current.Session["customerMobile"] != null)
                {
                    return HttpContext.Current.Session["customerMobile"].ToString();
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["customerMobile"] = value;
            }
        }

        public static Int64 UnitUserID
        {
            get
            {
                if (HttpContext.Current.Session["unitUserID"] != null)
                {
                    return Convert.ToInt64(HttpContext.Current.Session["unitUserID"].ToString());
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["unitUserID"] = value;
            }
        }

        public static Int64 UnitID
        {
            get
            {
                if (HttpContext.Current.Session["unitID"] != null)
                {
                    return Convert.ToInt64(HttpContext.Current.Session["unitID"].ToString());
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["unitID"] = value;
            }
        }

        public static int PackageCategoryID
        {
            get
            {
                if (HttpContext.Current.Session["packageCategoryID"] != null)
                {
                    return Convert.ToInt32(HttpContext.Current.Session["packageCategoryID"].ToString());
                }
                else
                {
                    return 0;
                }
            }
            set
            {
                HttpContext.Current.Session["packageCategoryID"] = value;
            }
        }

        public static string OTP
        {
            get
            {
                if (HttpContext.Current.Session["OTP"] != null)
                {
                    return Convert.ToString(HttpContext.Current.Session["OTP"].ToString());
                }
                else
                {
                    return "";
                }
            }
            set
            {
                HttpContext.Current.Session["OTP"] = value;
            }
        }
        public static bool isMSGSend
        {
            get
            {
                if (HttpContext.Current.Session["isMSGSend"] != null)
                {
                    return Convert.ToBoolean(HttpContext.Current.Session["isMSGSend"]);
                }
                else
                {
                    return false;
                }
            }
            set
            {
                HttpContext.Current.Session["isMSGSend"] = value;
            }
        }

        #region Roop Kanwar On 08-09-2015 

        public static string DocketNo
        {
            get
            {
                if (HttpContext.Current.Session["DocketNo"] != null)
                {
                    return Convert.ToString(HttpContext.Current.Session["DocketNo"].ToString());
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["DocketNo"] = value;
            }
        }

        public static string BillNo
        {
            get
            {
                if (HttpContext.Current.Session["BillNo"] != null)
                {
                    return Convert.ToString(HttpContext.Current.Session["BillNo"].ToString());
                }
                else
                {
                    return null;
                }
            }
            set
            {
                HttpContext.Current.Session["BillNo"] = value;
            }
        }

        #endregion

        #region AddedBy Bramh for Securty
        public static string AuthCookies
        {
            get
            {
                if (HttpContext.Current.Request.Cookies["AuthToken"] != null)
                {
                    return Convert.ToString(HttpContext.Current.Request.Cookies["AuthToken"].Value.ToString());
                }
                else
                {
                    return "";
                }
            }
           
        }

        public static string SesAuthCookies
        {
            get
            {
                if (HttpContext.Current.Session["AuthToken"] != null)
                {
                    return Convert.ToString(HttpContext.Current.Session["AuthToken"].ToString());
                }
                else
                {
                    return "0";
                }
            }
            
        }

        public static string PrevURL
        {
            get
            {
                if (HttpContext.Current.Session["PrevURL"] != null)
                {
                    return (HttpContext.Current.Session["PrevURL"]).ToString();
                }
                else
                {
                    return "UPTourism/Index";
                }
            }
            set
            {
                HttpContext.Current.Session["PrevURL"] = value;
            }
        }
        #endregion
    }
}