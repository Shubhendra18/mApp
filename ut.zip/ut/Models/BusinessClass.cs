﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using UP_TourismBooking.Models.DataModels;
using System.Dynamic;
using System.Collections;
using System.Xml.Linq;

namespace UP_TourismBooking.Models
{
    public class BusinessClass : IDisposable
    {
        public void Dispose()
        {

        }

        UP_TourismConnection db = new UP_TourismConnection();

        #region verify login
        public Login VerifyLogin(string username)
        {
            return db.VerifyLogin(username);
        }
        #endregion

        #region admin section

        #region Package Category

        #region insert/ update package category
        public int InsertUpdatePackageCategory(PackageCategory model)
        {
            return db.InsertUpdatePackageCategory(model);

        }
        #endregion

        #region get package category list
        public IEnumerable<PackageCategory> GetPackageCategoryList()
        {
            return db.GetPackageCategoryList();
        }
        #endregion

        #region get package category details
        public PackageCategory GetPackageCategoryDetails(int packageCategoryID)
        {
            return db.GetPackageCategoryDetails(packageCategoryID);
        }
        #endregion

        #region delete package category
        public int DeletePackageCategory(int packageCategoryID)
        {
            return db.DeletePackageCategory(packageCategoryID);

        }
        #endregion

        #endregion

        #region Package

        #region insert package
        public Package InsertPackage(Package model)
        {
            return db.InsertPackage(model);
        }
        #endregion

        #region update package
        public int UpdatePackage(Package model)
        {
            return db.UpdatePackage(model);
        }
        #endregion

        #region insert/ update package
        public int InsertUpdatePackage(Package model)
        {
            return db.InsertUpdatePackage(model);
        }
        #endregion
        #region get package list
        public IEnumerable<Package> GetPackageList()
        {
            return db.GetPackageList();
        }
        #endregion

        #region get package details
        public Package GetPackageDetails(int packageID)
        {
            return db.GetPackageDetails(packageID);
        }
        #endregion

        #region delete package
        public int DeletePackage(int packageID)
        {
            return db.DeletePackage(packageID);
        }
        #endregion


        #endregion

        #region package details

        #region get package complete details
        public PackageDetails GetPackageCompleteDetails(int packageID)
        {
            return db.GetPackageCompleteDetails(packageID);
        }
        #endregion

        #region get all units
        public IEnumerable<Unit> GetAllUnitList()
        {
            return db.GetAllUnitList();
        }
        #endregion

        #region insert/ update contact
        public int InsertUpdateContact(Contact model)
        {
            return db.InsertUpdateContact(model);
        }
        #endregion

        #region get package contacts
        public IEnumerable<Contact> GetPackageContacts(int packageID)
        {
            return db.GetPackageContacts(packageID);
        }
        #endregion

        #region get package contact details
        public Contact GetPackageContactDetails(int packageID, Int64 contactID)
        {
            return db.GetPackageContactDetails(packageID, contactID);
        }
        #endregion

        #region delete contact
        public int DeleteContact(int packageID, Int64 contactID)
        {
            return db.DeleteContact(packageID, contactID);
        }
        #endregion

        #region get package terms n conditions detail
        public TermCondition GetTermsConditionsDetails(int packageID)
        {
            return db.GetTermsConditionsDetails(packageID);
        }
        #endregion

        #region insert/ update terms condition
        public int InsertUpdateTermsCondition(TermCondition model)
        {
            return db.InsertUpdateTermsCondition(model);
        }
        #endregion

        #endregion



        #endregion

        #region customer section
        #region get destinations
        public IEnumerable<Destinations> GetDestinations()
        {
            return db.GetDestinations();
        }
        #endregion

        #region get category wise package list
        public IEnumerable<PackageTours> GetCategoryWisePackageList(int destinationID, Int16 isIndian, int noOfTourists, int month, DateTime arrivalDate)
        {
            return db.GetCategoryWisePackageList(destinationID, isIndian, noOfTourists, month, arrivalDate);
        }
        #endregion

        #region get country
        public IEnumerable<Country> GetCountryList()
        {
            return db.GetCountryList();
        }
        #endregion

        #region get state
        public IEnumerable<State> GetStateList(int countryID)
        {
            return db.GetStateList(countryID);
        }
        #endregion

        #region get cities
        public IEnumerable<City> GetCityList(int stateID)
        {
            return db.GetCityList(stateID);
        }
        #endregion

        #region get all tour types
        public IEnumerable<TourTypes> GetAllTourTypes()
        {
            return db.GetAllTourTypes();
        }
        #endregion
        #region check email existence
        public Registration CheckEmailExistence(string email)
        {
            return db.CheckEmailExistence(email);
        }
        #endregion

        #region insert user
        public Registration InsertUser(Registration model)
        {
            return db.InsertUser(model);
        }
        #endregion

        #region verify customer login
        public UserLogin VerifyUserLogin(string email)
        {
            return db.VerifyUserLogin(email);
        }
        #endregion

        #region update login attempts
        public int UpdateLoginAttempts(string accessIP, DateTime attemptTime, string email, string pageURL, string visitStatus, int flag)
        {
            return db.UpdateLoginAttempts(accessIP, attemptTime, email, pageURL, visitStatus, flag);
        }
        #endregion

        #region get attempt details
        public UserLogin GetAttemptDetails(string email, string visitStatus)
        {
            return db.GetAttemptDetails(email, visitStatus);
        }
        #endregion

        #region reset login attempts
        public int ResetLoginAttempts(string email)
        {
            return db.ResetLoginAttempts(email);
        }
        #endregion

        #region get locked account list
        public List<LockAccountDetails> GetLockedAccounts(UnlockAccount model)
        {
            return db.GetLockedAccounts(model);
        }
        #endregion

        #region unlock accounts
        public int UnlockAccounts(string unlockXml)
        {
            return db.UnlockAccounts(unlockXml);
        }
        #endregion

        #region get customer details for forgot password
        public UserForgetPassword GetUserDetails(string email)
        {
            return db.GetUserDetails(email);
        }
        #endregion

        #region update customer password
        public int UpdateCustomerPassword(UserForgetPassword model)
        {
            return db.UpdateCustomerPassword(model);
        }
        #endregion

        #region get package payment info
        public PackagePayment GetPackagePayment(int packageID, Int16 isIndian, int noOfPersons, int month)
        {
            return db.GetPackagePayment(packageID, isIndian, noOfPersons, month);
        }
        #endregion

        #region insert booking request for package tours
        public PostPaymentData InsertPackageBookRequest(PackagePayment model)
        {
            return db.InsertPackageBookRequest(model);

        }
        #endregion

        #region get package post data
        public PostPaymentData GetPackagePostData(Int64 requestID, string docketNo)
        {
            return db.GetPackagePostData(requestID, docketNo);
        }
        #endregion

        #region insert package tour query
        public PackageQuery InsertPackageTourQuery(PackageQuery model)
        {
            return db.InsertPackageTourQuery(model);
        }
        #endregion

        #region get package info
        public PackageToursDetails GetPackageDisplayinfo(int packageID, int noOfPerson, DateTime arrivalDate)
        {
            return db.GetPackageDisplayinfo(packageID, noOfPerson, arrivalDate);
        }
        #endregion

        #region get package policies
        public IEnumerable<PackageToursPolicy> GetPackagePolicyList(int packageID)
        {
            return db.GetPackagePolicyList(packageID);
        }
        #endregion

        #region get package accomodation
        public IEnumerable<PackageToursAccomodation> GetPackageAccomodationList(int packageID)
        {
            return db.GetPackageAccomodationList(packageID);
        }
        #endregion

        #region get package accomodation
        public IEnumerable<PackageToursContact> GetPackageContactList(int packageID)
        {
            return db.GetPackageContactList(packageID);
        }
        #endregion

        #region get package itenarary
        public IEnumerable<PackageToursItenarary> GetPackageItenararyList(int packageID)
        {
            return db.GetPackageItenararyList(packageID);
        }
        #endregion

        #region get package images
        public IEnumerable<PackageImages> GetPackageImageList(int packageID)
        {
            return db.GetPackageImageList(packageID);
        }
        #endregion

        #region get unit images
        public IEnumerable<UnitImages> GetUnitImageList(int unitId)
        {
            return db.GetUnitImageList(unitId);
        }
        #endregion

        #endregion

        #region change customer password
        public int ChangeUserPassword(UserChangePassword model)
        {
            return db.ChangeUserPassword(model);
        }
        #endregion

        #region get change password date
        public UserChangePassword GetChangePasswordDate(UserChangePassword model)
        {
            return db.GetChangePasswordDate(model);
        }
        #endregion
        #region unit booking

        #region get unit destinations
        public IEnumerable<Destinations> GetUnitDestinationsList(int type)
        {
            return db.GetUnitDestinationsList(type);
        }
        #endregion

        #region get destination wise unit list
        public List<UnitBooking> GetDestinationWiseUnitList(Int64 destinationID, DateTime checkInDate, DateTime checkOutDate, int noOfGuests, int noOfRooms)
        {
            return db.GetDestinationWiseUnitList(destinationID, checkInDate, checkOutDate, noOfGuests, noOfRooms);
        }
        #endregion

        #region get destination wise unit list
        public List<UnitAmenities> GetUnitWiseAmenitiesList(Int64 unitID)
        {
            return db.GetUnitWiseAmenitiesList(unitID);
        }
        #endregion

        #region get unit wise room availability
        public List<dynamic> GetUnitWiseRoomList(Int64 unitID, DateTime dtCheckIn, DateTime dtCheckOut, int noOfRooms)
        {
            var result = new List<dynamic>();

            DataTable dt = db.GetUnitWiseRoomList(unitID, dtCheckIn, dtCheckOut, noOfRooms);

            foreach (DataRow row in dt.Rows)
            {
                var obj = (IDictionary<string, object>)new ExpandoObject();
                foreach (DataColumn col in dt.Columns)
                {
                    obj.Add(col.ColumnName, row[col.ColumnName]);
                }
                result.Add(obj);
            }

            return result;
        }
        #endregion

        #region get unit info
        public UnitDetails GetUnitDisplayinfo(int unitID)
        {
            return db.GetUnitDisplayinfo(unitID);
        }
        #endregion

        #region get unit wise unit list
        public List<UnitRooms> GetUnitRoomList(Int64 unitID, DateTime checkInDate, DateTime checkOutDate, int noOfRooms)
        {
            return db.GetUnitRoomList(unitID, checkInDate, checkOutDate, noOfRooms);
        }
        #endregion

        #region get unit info
        public UnitRooms GetRoomInfo(int roomID, Int64 unitID)
        {
            return db.GetRoomInfo(roomID, unitID);
        }
        #endregion

        #region get unit payment info
        public UnitPayment GetUnitPaymentInfo(DateTime dtCheckin, DateTime dtCheckout, int roomId, Int64 unitId, int single, int doubles, int extraBedRoom)
        {
            return db.GetUnitPaymentInfo(dtCheckin, dtCheckout, roomId, unitId, single, doubles, extraBedRoom);
        }
        #endregion

        #region insert booking request for unit
        public PostPaymentData InsertUnitBookRequest(UnitPayment model, string UnitPaymentsSlabXML)
        {
            return db.InsertUnitBookRequest(model, UnitPaymentsSlabXML);
        }
        #endregion

        #endregion

        #region Transaction Responce Updation
        public int PROC_UPDATE_PAYMENT_RESPONCE(string MerchantRefNo, string TransactionId, string ResponceString)
        {
            return db.PROC_UPDATE_PAYMENT_RESPONCE(MerchantRefNo, TransactionId, ResponceString);
        }
        #endregion

        #region #region Get Mobile Nos for SMS
        public IEnumerable<OfficerContactDetails> get_Mobile_Nos_For_SMS(string MerchantRefNo)
        {
            return db.get_Mobile_Nos_For_SMS(MerchantRefNo);
        }
        #endregion

        #region get transaction details
        public UnitTransactionDetail GetTransactionDetails(string docketNo)
        {
            return db.GetTransactionDetails(docketNo);
        }
        #endregion

        #region get package transaction details
        public PackageTransactionDetail GetPackageTransactionDetails(string docketNo)
        {
            return db.GetPackageTransactionDetails(docketNo);
        }
        #endregion

        #region get special package transaction details
        public SpecialPackageTransactionDetail GetSplPackageTransactionDetails(string docketNo, string bookingType)
        {
            return db.GetSplPackageTransactionDetails(docketNo, bookingType);
        }
        #endregion

        #region counter booking

        #region verify unit login
        public UnitLogin VerifyUnitLogin(string email)
        {
            return db.VerifyUnitLogin(email);
        }
        #endregion

        #region get unit booking status
        public List<VacancyStatus> GetUnitVacancyStatus(UnitVacancyStatus model)
        {
            return db.GetUnitVacancyStatus(model);
        }
        #endregion

        #region get unit blocked room list
        public List<BlockReleaseDetail> GetUnitBlockedRooms(UnitBlockRelease model)
        {
            return db.GetUnitBlockedRooms(model);
        }
        #endregion

        #region get HQ blocked room list
        public List<BlockReleaseDetail> GetHQBlockedRooms(HQBlockRelease model)
        {
            return db.GetHQBlockedRooms(model);
        }

        public List<BlockReleaseDetail> GetHQBlockedRoomsDetails(HQBlockRelease model)
        {
            return db.GetHQBlockedRoomsDetail(model);
        }
        #endregion

        #region insert package tour query
        public int InsertBlockDetail(Int64 unitID, string blockList, DateTime dtBlocking)
        {
            return db.InsertBlockDetail(unitID, blockList, dtBlocking);
        }
        public int InserthqBlockDetail(Int64 unitID, string blockList, DateTime dtBlocking, DateTime dtBlockingTo)
        {
            return db.InserthqBlockDetail(unitID, blockList, dtBlocking, dtBlockingTo);
        }
        #endregion

        #region get unit booking status
        public List<BookedDetail> GetUnitBookingStatus(UnitTotalBooking model)
        {
            return db.GetUnitBookingStatus(model);
        }
        #endregion



        #region Start and Created by Radhey------------------------------------------------------


        #region get unit booking status
        public List<BookedDetail> GetUnitBookingStatusOldRoomType(UnitTotalBooking model)
        {
            return db.GetUnitBookingStatusOldRoomType(model);
        }
        #endregion



        #region get unit booking Details
        public List<SpecialBookedDetail> GetUnitBookingDetailsOldRoomType(string docketNo, Int64 unitID)
        {
            return db.GetUnitBookingDetailsOldRoomType(docketNo, unitID);
        }
        #endregion


        #region get unit booked room details
        public List<RoomOccupancyDetails> GetBookedRoomDetailsOldRoomType(string docketNo, Int64 unitID)
        {
            return db.GetBookedRoomDetailsOldRoomType(docketNo, unitID);
        }
        #endregion

        #region get details after payment
        public Payment GetDetailsAfterPaymentForPrintOnly(string merchantRefNo,string PaymentID)
        {
            return db.GetDetailsAfterPaymentForPrintOnly(merchantRefNo, PaymentID);
        }
        #endregion


        #endregion



        #region get payment info
        public AdvancePayment GetCounterPaymentInfo(AdvancePayment model)
        {
            return db.GetCounterPaymentInfo(model);
        }
        #endregion

        #region save advance payment
        public int InsertAdvancePayment(AdvancePayment model)
        {
            return db.InsertAdvancePayment(model);
        }
        #endregion

        #endregion

        #region city Tours

        #region get city tours category list
        public IEnumerable<CityTourCategory> GetCityTourCategoryList()
        {
            return db.GetCityTourCategoryList();
        }
        #endregion

        #region get category wise city tour list
        public IEnumerable<CityTours> GetCategoryWiseCityTourList(int destinationID, Int16 isIndian, int noOfTourists, int month, DateTime arrivalDate)
        {
            return db.GetCategoryWiseCityTourList(destinationID, isIndian, noOfTourists, month, arrivalDate);
        }
        #endregion

        #region get city tour info
        public CityToursDetails GetCityTourDisplayinfo(int packageID, int noOfPerson, DateTime arrivalDate)
        {
            return db.GetCityTourDisplayinfo(packageID, noOfPerson, arrivalDate);
        }
        #endregion

        #region get city tours policies
        public IEnumerable<CityToursPolicy> GetCityToursPolicyList(int packageID)
        {
            return db.GetCityToursPolicyList(packageID);
        }
        #endregion

        #region get city tours contact list
        public IEnumerable<CityToursContact> GetCityToursContactList(int packageID)
        {
            return db.GetCityToursContactList(packageID);
        }
        #endregion

        #region get city tours itenarary
        public IEnumerable<CityToursItenarary> GetCityToursItenararyList(int packageID)
        {
            return db.GetCityToursItenararyList(packageID);
        }
        #endregion

        #region insert city tour query
        public CityTourQuery InsertCityTourQuery(CityTourQuery model)
        {
            return db.InsertCityTourQuery(model);
        }
        #endregion

        #region get city tours payment info
        public CityTourPayment GetCityToursPayment(int packageID, Int16 isIndian, int noOfPersons, int month, DateTime arrivalDate)
        {
            return db.GetCityToursPayment(packageID, isIndian, noOfPersons, month, arrivalDate);
        }
        #endregion

        #region insert booking request for city tours
        public PostPaymentData InsertCityToursBookRequest(CityTourPayment model)
        {
            return db.InsertCityToursBookRequest(model);
        }
        #endregion

        #endregion

        #region SMS Log
        public int SMSLog(String Message, String MobileNo, String DocketNo, String SMSStatus)
        {
            return db.SMSLog(Message, MobileNo, DocketNo, SMSStatus);
        }
        #endregion


        #region Yogesh Yadav
        public List<SpecialBookedDetail> GetDetailsOfCancellation(string docketNo)
        {
            return db.GetDetailsOfCancellation(docketNo);
        }

        public BookingCancellation InsertBookingCancellationRequest(string docketNo)
        {
            return db.InsertBookingCancellationRequest(docketNo);

        }

        public List<cancellationRequest> GetCancelRequest(string docketNo, Int64 unitId, DateTime fromDate, DateTime toDate)
        {
            return db.GetCancelRequest(docketNo, unitId, fromDate, toDate);
        }

        public int InsertCancellationConfirmation(string docketNo, string acceptedByIP)
        {
            return db.InsertCancellationConfirmation(docketNo, acceptedByIP);

        }

        public List<cancellationRequest> GetCancelledRequest(string docketNo, Int64 unitId)
        {
            return db.GetCancelledRequest(docketNo, unitId);
        }
        #endregion


        #region Roop Kanwar On 08-09-2015

        #region get room Type
        public List<RoomType> GetRoomType(Int64 unitId)
        {
            return db.GetRoomType(unitId);
        }
        #endregion

        #region insert Customer Booking
        public CustomerRegistration InsertCustomerBooking(CustomerRegistration model)
        {
            return db.InsertCustomerBooking(model);
        }
        #endregion

        #region Chk Room Availability
        public RoomAvailabilityDetails ChkRoomAvailability(RoomAvailabilityDetails model)
        {
            return db.ChkRoomAvailability(model);
        }
        #endregion

        #region get user details on check out
        public CustomerRegistration GetCustomerBookingDetails(string docketNo, Int64 unitId, bool isChekIn = true)
        {
            return db.GetCustomerBookingDetails(docketNo, unitId, isChekIn);
        }

        public List<BillDetails> GetBillDetails(Int64 requestID, Int64 unitId)
        {
            return db.GetBillDetails(requestID, unitId);
        }

        public List<BookedRoomDetails> GetBookedRoomDetailsOnCheckOut(string docketNo, Int64 unitId)
        {
            return db.GetBookedRoomDetailsOnCheckOut(docketNo, unitId);
        }

        public CustomerRegistration InsertCheckOutDetails(CustomerRegistration model, string UnitPaymentsSlabXML)
        {
            return db.InsertCheckOutDetails(model, UnitPaymentsSlabXML);
        }
        #endregion

        #region get personal identity
        public List<PersonalIdentity> GetPersonalIdentityType()
        {
            return db.GetPersonalIdentityType();
        }
        #endregion

        #region payment details
        public List<PaymentDetails> GetPaymentDetails(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 unitId, string docketNo)
        {
            return db.GetPaymentDetails(PaymentDateFrom, PaymentDateTo, unitId, docketNo);
        }
        #endregion
        #endregion
        #region Samreen
        #region get category wise package list
        public IEnumerable<PackageTours> GetCategoryWiseBusPackageList(int destinationID, Int16 isIndian, int noOfTourists, int month)
        {
            return db.GetCategoryWiseBusPackageList(destinationID, isIndian, noOfTourists, month);
        }
        #endregion
        #region insert booking request for package tours
        public PostPaymentData InsertCycleTourBookRequest(PackagePayment model)
        {
            return db.InsertCycleTourBookRequest(model);

        }
        #endregion

        #region Get CheckOut Bill Details
        public IEnumerable<CheckoutBillHeads> GetCheckOutBillHeads(String docketNo, decimal discount)
        {
            return db.GetCheckOutBillHeads(docketNo, discount);
        }
        public IEnumerable<CheckOutBillDetails> GetCheckOutBillDetails(String docketNo, Int64 unitId)
        {
            return db.GetCheckOutBillDetails(docketNo, unitId);
        }


        #region tabeen

        #region get bus package list
        public IEnumerable<ACBusTours> GetBusPackageList(Int16 isIndian, int noOfTourists, int month, DateTime arrivalDate)
        {
            return db.GetBusPackageList(isIndian, noOfTourists, month, arrivalDate);
        }
        #endregion

        #endregion

        #endregion

        #region get ac bus tour info
        public ACBusToursDetails GetACBusDisplayinfo(int packageID, int noOfPerson, DateTime arrivalDate)
        {
            return db.GetACBusDisplayinfo(packageID, noOfPerson, arrivalDate);
        }
        #endregion

        #region get ac bus tours policies
        public IEnumerable<ACBusToursPolicy> GetACBusToursPolicyList(int packageID)
        {
            return db.GetACBusToursPolicyList(packageID);
        }
        #endregion

        #region get ac bus tours contacts
        public IEnumerable<ACBusToursContact> GetACBusToursContactList(int packageID)
        {
            return db.GetACBusToursContactList(packageID);
        }
        #endregion

        #region get ac bus tours itenarary
        public IEnumerable<ACBusToursItenarary> GetACBusToursItenararyList(int packageID)
        {
            return db.GetACBusToursItenararyList(packageID);
        }
        #endregion

        #region get ac bus tours payment info
        public ACBusTourPayment GetACBusToursPayment(int packageID, Int16 isIndian, int noOfPersons, int month, DateTime arrivalDate)
        {
            return db.GetACBusToursPayment(packageID, isIndian, noOfPersons, month, arrivalDate);
        }
        #endregion

        #region insert booking request for city tours
        public PostPaymentData InsertACBusToursBookRequest(ACBusTourPayment model)
        {
            return db.InsertACBusToursBookRequest(model);
        }
        #endregion

        #region insert special tour query
        public ACBusTourQuery InsertSpecialTourQuery(ACBusTourQuery model)
        {
            return db.InsertSpecialTourQuery(model);
        }
        #endregion

        #endregion

        #region   Added By Samreen on 11092015
        #region To Verify User For Forget Password
        public ForgetPassword VerifyUserForForgetPassword(string secQues, Int32 secQuesId, string email)
        {
            return db.VerifyUserForForgetPassword(secQues, secQuesId, email);
        }
        #endregion
        #region Update Password
        public int UpdatePassword(ForgetPassword model)
        {
            return db.UpdatePassword(model);
        }
        #endregion
        #endregion

        #region get booking details for checkin
        public CheckinDetails GetBookingDetailsForCheckin(CheckinDetails model)
        {
            return db.GetBookingDetailsForCheckin(model);
        }
        #endregion

        #region insert checkin details
        public int InsertCheckinDetail(CheckinDetails model, string roomDetailXml)
        {
            return db.InsertCheckinDetail(model, roomDetailXml);
        }
        #endregion

        #region get checkin details
        public CheckinDetails GetCheckinDetails(string docketNo)
        {
            return db.GetCheckinDetails(docketNo);
        }
        #endregion


        #region Added by Samreen on 19092015
        #region Extend Booking
        #region get booking details for Extending booking date
        public ExtendBookingDetails GetBookingDetailsToExtendBooking(ExtendBookingDetails model)
        {
            return db.GetBookingDetailsToExtendBooking(model);
        }
        #endregion

        #region get unit room details to be extended
        public List<RoomExtendDetails> GetExtendedRoomDetails(string docketNo, Int64 unitID)
        {
            return db.GetExtendedRoomDetails(docketNo, unitID);
        }
        #endregion

          #region get alloted rooms
        public List<RoomDetails> GetAllottedRooms(Int64 requestID)
        {
            return db.GetAllottedRooms(requestID);
        }
         #endregion

        #region Update Extend details
        public int UpdateExtendDetail(ExtendBookingDetails model)
        {
            return db.UpdateExtendDetail(model);
        }
        #endregion
        #region get Unit List
        public IEnumerable<Unit> GetUnitList()
        {
            return db.GetUnitList();
        }
        #endregion

        #region get Unit List By Syed
        public IEnumerable<Unit> GetUnitListByOnlineHasLawnHasBanquet()
        {
            return db.GetUnitListByOnlineHasLawnHasBanquet();
        }
        #endregion
        #region get UPTour booking status
        public List<BookedDetail> GetUPTourBookingStatus(UPTourTotalBooking model)
        {
            return db.GetUPTourBookingStatus(model);
        }
        #endregion
        #endregion
        #region #region verify UP Tour login
        public UPToursLogin VerifyUPTourLogin(string email)
        {
            return db.VerifyUPTourLogin(email);
        }
        #endregion
        #endregion
        #region get UPTour booking status
        public List<VacancyStatus> GetUPTourVacancyStatus(UPTourVacancyStatus model)
        {
            return db.GetUPTourVacancyStatus(model);
        }
        #endregion


        #region get all list by Roop Kanwar
        public IEnumerable<PackageTours> GetAllPackageList(Int16 isIndian, int noOfTourists, int month)
        {
            return db.GetAllPackageList(isIndian, noOfTourists, month);
        }
        #endregion

        #region get payable amount
        public PayDetails GetPayableAmountByDocketNo(string docketNo)
        {
            return db.GetPayableAmountByDocketNo(docketNo);
        }
        #endregion

        #region get details after payment
        public Payment GetDetailsAfterPayment(string merchantRefNo, string paymentId)
        {
            return db.GetDetailsAfterPayment(merchantRefNo, paymentId);
        }
        #endregion

        #region cancel room In unit
        public BookingCancellation InsertBookingCancellationRequestInUnit(string docketNo)
        {
            return db.InsertBookingCancellationRequestInUnit(docketNo);

        }
        #endregion
        #region get UPTour booking status
        public List<BookedDetail> GetUPTourSpecialBookingStatus(UPTourTotalBooking model)
        {
            return db.GetUPTourSpecialBookingStatus(model);
        }
        #endregion

        #region get UPTour Special booking Details+
        public List<SpecialBookedDetail> GetUPTourSpecialDetails(string docketNo, Int64 unitID)
        {
            return db.GetUPTourSpecialDetails(docketNo, unitID);
        }
        #endregion

        #region get package detail Unit wise
        public List<PackageDetailUnitWise> GetpackagedetailUnitwise(string docketNo)
        {
            return db.GetpackagedetailUnitwise(docketNo);
        }
        #endregion

        #region get unit booking Details
        public List<SpecialBookedDetail> GetUnitBookingDetails(string docketNo, Int64 unitID)
        {
            return db.GetUnitBookingDetails(docketNo, unitID);
        }
        #endregion

        #region get unit booked room details
        public List<RoomOccupancyDetails> GetBookedRoomDetails(string docketNo, Int64 unitID)
        {
            return db.GetBookedRoomDetails(docketNo, unitID);
        }
        #endregion

        #region insert booking request for Tonga Ride
        public PostPaymentData InsertTongaRideBookRequest(PackagePayment model)
        {
            return db.InsertTongaRideBookRequest(model);
        }
        #endregion
        #region insert booking request for Heritage Walk
        public PostPaymentData InsertHeritageWalkBookRequest(PackagePayment model)
        {
            return db.InsertHeritageWalkBookRequest(model);

        }
        #endregion 

        #region cancellation request process in UP Tours Login by Roop Kanwar

        public List<cancellationRequest> GetCancelRequestForPackages(BookingCancellation obj)
        {
            return db.GetCancelRequestForPackages(obj);
        }
        #endregion

        #region insert Tonga Ride Booking
        public LkoOnTonga saveTongaBookingDetails(LkoOnTonga model)
        {
            return db.saveTongaBookingDetails(model);
        }
        #endregion
        #region insert Cycle Tour Booking
        public LkoOnCycle saveCycleTourBookingDetails(LkoOnCycle model)
        {
            return db.saveCycleTourBookingDetails(model);
        }
        #endregion

        #region Cycle Tour Booking Anonymous
        #region Get Cycle Routes Details
        public IEnumerable<CycleToursProgram> GetCycleRouteDetails(Int64 packageId)
        {
            return db.GetCycleRouteDetails(packageId);
        }
        #endregion
        #region Get Booking History
        public IEnumerable<BookingHistory> GetBookingHistory(Int64 userId)
        {
            return db.GetBookingHistory(userId);
        }
        #endregion
        public BookingHistory CancelBooking(string docketNo, decimal refaundPer, decimal refaundAmount)
        {
            return db.CancelBooking(docketNo, refaundPer, refaundAmount);
        }
        #endregion 

        #region staff related process
        #region get staff grade
        public List<StaffGrade> GetStaffGrade()
        {
            return db.GetStaffGrade();
        }
        #endregion

        public List<RoomType> GetStaffRoom(Int64 unitId, int facilityId)
        {
            return db.GetStaffRoom(unitId, facilityId);
        }
        #endregion

        #region get Rooms On Check In
        public List<RoomDetails> GetRoomsOnCheckIn(Int64 unitId, Int64 requestId, int roomId)
        {
            return db.GetRoomsOnCheckIn(unitId, requestId, roomId);
        }
        #endregion
        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> getMobileNosEmailIdForSMSEmail(string docketNo)
        {
            return db.getMobileNosEmailIdForSMSEmail(docketNo);
        }
        #endregion

        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> GetOfficerMobileNoForUnit(string docketNo)
        {
            return db.getMobileNosEmailIdForSMSEmail(docketNo);
        }
        #endregion
        #region Get All Accepted Cancelled Request
        public List<cancellationRequest> getAcceptedCancelledRequestDetails(string docketNo)
        {
            return db.getAcceptedCancelledRequestDetails(docketNo);
        }
        #endregion
        #region Cancelation Confirmation By CRS
        public BookingHistory InsertCancellationConfirmationByCRS(string docketNo)
        {
            return db.InsertCancellationConfirmationByCRS(docketNo);
        }
        #endregion
        #region Get Counter Booking History
        public IEnumerable<BookingHistory> GetCounterBookingHistory(Int64 userId)
        {
            return db.GetCounterBookingHistory(userId);
        }
        #endregion
        #region Get Cancellation Confirmation Details For Packages and spcial packages
        public List<SpecialBookedDetail> getDetailsOfCancellationConfirmation(string docketNo)
        {
            return db.getDetailsOfCancellationConfirmation(docketNo);
        }
        #endregion

        #region Get Counter Booking History
        public IEnumerable<cancellationRequest> GetCounterBookingAndUnitBookingInfo(Int64 unitID, string docketNo, DateTime fromDate, DateTime toDate)
        {
            return db.GetCounterBookingAndUnitBookingInfo(unitID, docketNo, fromDate, toDate);
        }
        #endregion

        #region advance payment details
        public List<PaymentDetails> GetAdvancePaymentDetails(string docketNo, Int64 unitId)
        {
            return db.GetAdvancePaymentDetails(docketNo, unitId);
        }
        #endregion

        #region One Day Tour booking
        #region City Tour List
        public IEnumerable<PackageTour> getCityTourList(int packageCategoryID)
        {
            return db.getCityTourList(packageCategoryID);
        }
        #endregion
        #region insert booking request for city tours
        public OneDayTourBooking saveOneDayTourBookingDetails(OneDayTourBooking model)
        {
            return db.saveOneDayTourBookingDetails(model);
        }
        #endregion
        public OneDayTourBooking GetTourTotalAmount(Int32 packageID, Int32 isIndian, Int32 noOfGuests)
        {
            return db.GetTourTotalAmount(packageID, isIndian, noOfGuests);
        }
        #endregion

        #region AC BUS Tour Booking
        #region City Tour List
        public IEnumerable<PackageTour> getACBusTourList()
        {
            return db.getACBusTourList();
        }
        #endregion
        #region insert booking request for AC Bus Booking
        public ACBusTourBooking saveACBusTourBookingDetails(ACBusTourBooking model)
        {
            return db.saveACBusTourBookingDetails(model);
        }
        #endregion
        public ACBusTourBooking GetACBusTourTotalAmount(Int32 packageID, Int32 isIndian)
        {
            return db.GetACBusTourTotalAmount(packageID, isIndian);
        }
        #endregion

        #region Package Tour Booking By UPTour
        #region get city tours category list
        public IEnumerable<PackageCategory> GetPackageTourCategoryList()
        {
            return db.GetPackageTourCategoryList();
        }
        #endregion
        #region get package Tour list fpr up tours and crs
        public IEnumerable<PackageTour> getPackageTourList(Int32 packageCategoryID)
        {
            return db.getPackageTourList(packageCategoryID);
        }
        #endregion
        #region Save Package Tour Booking Details
        public PackageTourBooking savePackageTourBookingDetails(PackageTourBooking model)
        {
            return db.savePackageTourBookingDetails(model);
        }
        #endregion
        #region Chk Package Tour Availability
        public PackageAvailabilityDetails ChkPackageTourAvailability(PackageAvailabilityDetails model)
        {
            return db.ChkPackageTourAvailability(model);
        }
        #endregion
        #endregion

        #region Lko on Cycle Booking
        public IEnumerable<CycleRouteType> GetCycleToureRouteType(string package_Abbr, int packageCategoryID)
        {
            return db.GetCycleToureRouteType(package_Abbr, packageCategoryID);
        }
        public IEnumerable<CycleApplicantType> GetCycleApplicantType(string package_Abbr)
        {
            return db.GetCycleApplicantType(package_Abbr);
        }

        #region Cycle Tour Booking By UPTour
        public LkoOnCycle saveCycleTourBookingByUPTour(LkoOnCycleBooking model)
        {
            return db.saveCycleTourBookingByUPTour(model);
        }
        #endregion
        #endregion

        #region insert Customer Booking By UP Tour
        public CustomerRegistration InsertCustomerBookingByUPTour(CustomerRegistration model)
        {
            return db.InsertCustomerBookingByUPTour(model);
        }
        #endregion

        #region Get Special Packages Fare
        public LkoOnCycleBooking GetSpecialPackegeFare(Int32 packageID, Int32 applicantTypeId)
        {
            return db.GetSpecialPackegeFare(packageID, applicantTypeId);
        }

        #endregion

        #region HTW Booking By UPTour
        public LkoHTWBooking saveHTWBookingByUPTour(LkoHTWBooking model)
        {
            return db.saveHTWBookingByUPTour(model);
        }
        #endregion
        #region HTW Booking By UPTour
        public LkoTongaRideBooking saveLkoTongaRideBookingByUPTour(LkoTongaRideBooking model)
        {
            return db.saveLkoTongaRideBookingByUPTour(model);
        }
        #endregion

        #region Get Tonga Ride Packages Fare
        public LkoOnCycleBooking GetTongaRideFare(Int32 packageID, Int32 applicantTypeId)
        {
            return db.GetTongaRideFare(packageID, applicantTypeId);
        }
        #endregion

        #region get ARC booking status
        public List<BookedDetail> GetARCBookingList(UPTourTotalBooking model)
        {
            return db.GetARCBookingList(model);
        }
        #endregion

        #region get UPT booking status
        public List<BookedDetail> GetUPTBookingStatus( UPTourTotalBooking model)
        {
            return db.GetUPTBookingStatus(model);
        }
        #endregion


        #region insert Master Details  -----By Bramh
        #region Insert Unit
        public Messg InsertUnitDetails(MasterUnits model)
        {
            return db.InsertUnitDetails(model);

        }
        #endregion
        #region GetAllDestinations
        public IEnumerable<Destinations> GetallDestination()
        {
            return db.GetAllDestinations();
        }
        #endregion
        #region GetAllUnitDetails
        public IEnumerable<M_Unit> GetAllunitdetails(int unitId)
        {
            return db.GetallUnits(unitId);
        }
        #endregion
        #region Get roomType
        public IEnumerable<M_RoomType> getAllRoomType()
        {
            return db.getallRoomtype();
        }
        #endregion
        #region GetRoomDetails
        public IEnumerable<ViewRooms> GetallRooms(int UnitId, int RoomId)
        {
            return db.getallRoomDetails(UnitId, RoomId);
        }
        #endregion
        #region get room Type for unit
        public List<RoomType> GetUnitRoomType(Int64 unitId)
        {
            return db.GetUnitRoomType(unitId);
        }
        #endregion
        #region GetRoomDetailForEdit
        public IEnumerable<MasterRooms> GetRoomForEdit(int UnitId, int RoomId)
        {
            return db.GetRoomForEdit(UnitId, RoomId);
        }
        #endregion
        #region InsertRooms
        public int insertInRooms(MasterRooms m)
        {
            return db.insertRooms(m);

        }
        #endregion
        #region Delete Rooms
        public int DeleteRooms(int roomId)
        {
            return db.DeleteRooms(roomId);

        }
        #endregion
        #region Insert Room Tariff
        public Messg InsertRoomTariffDetails(RoomTariff Mtarif)
        {
            return db.InsertTariff(Mtarif);
        }

        #endregion
        #region GetSession
        public IEnumerable<getSeason> GetSeason()
        {
            return db.GetSeason();
        }
        #endregion
        #region Get all RoomTariff
        public IEnumerable<ViewRoomTariff> GetRoomTariff(int RoomId)
        {
            return db.GetRoomTariff(RoomId);
        }
        #endregion
        #region GetallUnitFor Edit
        public IEnumerable<MasterUnits> GetallUnit(int unitId)
        {
            return db.GetallUnit(unitId);
        }
        #endregion
        #region Get RoomTariff By  roomTariffID
        public IEnumerable<RoomTariff> GetRoomTariffByroomTariffID(int roomTariffID)
        {
            return db.GetRoomTariffByroomTariffID(roomTariffID);
        }
        #endregion
        #region Insert Unit Image
        public int InsertUpdateUnitImage(UnitImage m)
        {
            return db.InsertUpdateUnitImage(m);

        }
        #endregion

        #region getall UnitImage for Display
        public IEnumerable<UnitImageDetaisl> getUnitImage(int unitid, int RoomId)
        {
            return db.getUnitImage(unitid, RoomId);
        }
        #endregion

        #region Get UnitImageForEdit By UnitImageId
        public UnitImage getUnitImageForEditByUnitImageId(Int64 unitImageId)
        {
            return db.getUnitImageForEditByUnitImageId(unitImageId);
        }
        #endregion
        #endregion



        #region payment details for UPT
        public List<PaymentDetails> GetPaymentDetailsForUPT(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 unitId, string docketNo)
        {
            return db.GetPaymentDetailsForUPT(PaymentDateFrom, PaymentDateTo, unitId, docketNo);
        }
        #endregion

        #region advance payment details for UPT
        public List<PaymentDetails> GetAdvancePaymentDetailsForUPT(string docketNo, Int64 unitId)
        {
            return db.GetAdvancePaymentDetailsForUPT(docketNo, unitId);
        }
        #endregion

        #region get booked room details
        public IList<RoomDetail> GetBookedRoomDetails(CheckinDetails model)
        {
            return db.GetBookedRoomDetails(model);
        }
        #endregion

        #region Get Special PackageName
        public SpecialPackageName GetSpecialPackageName(string docketNo)
        {
            return db.GetSpecialPackageName(docketNo);
        }
        #endregion

        #region Get Cancellation Confirmation Details For Packages and spcial packages and Unit Booking Cancellation
        public List<SpecialBookedDetail> DetailsOfBookingForCancellation(string docketNo)
        {
            return db.DetailsOfBookingForCancellation(docketNo);
        }
        #endregion

        /*------------Room Change---------------*/

        #region get all allotted rooms
        public List<RoomDetails> GetAllAllottedRooms(Int64 unitID)
        {
            return db.GetAllAllottedRooms(unitID);
        }
        #endregion

        #region get booking details for room change
        public RoomChange GetBookingDetailsToChangeRoom(RoomChange model)
        {
            return db.GetBookingDetailsToChangeRoom(model);
        }
        #endregion

        #region get unit room details to be changed
        public List<RoomChangeDetails> GetRoomDetailsForChange(string docketNo, Int64 unitID)
        {
            return db.GetRoomDetailsForChange(docketNo, unitID);
        }
        #endregion

        #region get all available Rooms 
        public List<RoomAvailableDetails> GetAllAvailableRoom(Int64 unitId, Int64 bookedRoomId)
        {
            return db.GetAllAvailableRoom(unitId, bookedRoomId);
        }
        #endregion

        #region insert room change details
        public RoomChange InsertRoomChangeDetails(RoomChange model, string roomChangeXml)
        {
            return db.InsertRoomChangeDetails(model, roomChangeXml);
        }
        #endregion

        #region get change details 
        public RoomChange GetChangeDetails(RoomChange model)
        {
            return db.GetChangeDetails(model);
        }
        #endregion
   
        /*------------End Room Change---------------*/

        #region  Insert Update OUT of Order room
        public List<RoomOutOfServiceDetail> getRoomOutOfOrder(int unit)
        {
            return db.getRoomOutOfOrder(unit);
        }
        #endregion

        #region  Insert Update OUT of Order room
        public int InsertUpdateRoomOutOfOrder(RoomOutOfServiceDetail Rt,string outoforderList)
        {
            return db.InsertUpdateRoomOutOfOrder(Rt, outoforderList);
        }
        #endregion

        #region  get out of order room details
        public RoomOutOfServiceDetail GetOutofServiceRoomDetails(int unitID, int roomID)
        {
            return db.GetOutofServiceRoomDetails(unitID, roomID);
        }
        #endregion

        #region  get unit wise and room type wise room no.
        public List<RoomNumber> GetRoomTypeWiseRoomNo(int unitID, int roomID)
        {
            return db.GetRoomTypeWiseRoomNo(unitID, roomID);
        }
        #endregion

         #region  Modify room status
        public int UpdateRoomStatus(RoomOutOfServiceDetail model, string roomNoXml)
        {
            return db.UpdateRoomStatus(model, roomNoXml);
        }
         #endregion

        #region Get Customer List-----------------------------By Bramh
        public IEnumerable<GuestList> getGuestList(int UserId, string name, string mobileno, string Email, DateTime fromDate, DateTime todate)
        {
            return db.getGuestList(UserId, name, mobileno, Email,fromDate,todate);
        }
        #endregion
        

        #region get unit and Package Booking Details for CRS
        public List<SpecialBookedDetail> GetUnitPackageBookingDetailsForCRS(string docketNo, int unitID)
        {
            return db.GetUnitPackageBookingDetailsForCRS(docketNo,unitID);
        }
        #endregion
          #region get unit and Package  booked room Details for CRS
        public List<RoomOccupancyDetails> GetBookedRoomDetailsForCRS(string docketNo, Int64 unitID)
        {
            return db.GetBookedRoomDetailsForCRS(docketNo,unitID);
        }
          #endregion



        #region get list of booking details for checkin
        public IList<CheckinDetails> GetBookingDetailsList(CheckinDetails model)
        {
            return db.GetBookingDetailsList(model);
        }
        #endregion

        #region check out list By Roop Kanwar On 18-10-2015
        public IList<CustomerRegistration> GetCustomerBookingList(string docketNo, Int64 unitId, bool isChekIn = true)
        {
            return db.GetCustomerBookingList(docketNo, unitId, isChekIn);
        }
        #endregion


        #region Added by Pooja
        #region Admin Manipulation
        #region Check Package Exist or not
        public IEnumerable<PackageEntry> CheckPackageExist(PackageEntry model)
        {
            return db.CheckPackageExist(model);
        }
        #endregion

        #region Insert Package
        public int InsertPackage(PackageEntry model)
        {
            return db.InsertPackageAdmin(model);
        }
        #endregion

        #region GetAll Package
        public IEnumerable<PackageEntry> GetPackageAdmin()
        {
            return db.GetAllPackageAdmin();
        }
        #endregion

        #region Get Package Detail By Id
        public PackageEntry GetPackageDetailById(int id)
        {
            return db.GetPackageDetailById(id);
        }
        #endregion

        #region Get PackageTour By Id
        public IEnumerable<Tour> GetPackageAdminById(int Id)
        {
            return db.GetPackageAdminById(Id);
        }
        #endregion

        #region Delete Package
        public int DeletePackageAdmin(int packageId)
        {
            return db.DeletePackageAdmin(packageId);
        }
        #endregion

        #region Insert Package Image
        public int InsertPackageImage(PackageImageEntry model)
        {
            return db.InsertPackageImageAdmin(model);
        }
        #endregion

        #region Get Package Image
        public IEnumerable<PackageImageEntry> GetPackageImageAdmin( int id)
        {
            return db.GetAllPackageImageAdmin(id);
        }
        #endregion

        #region Delete Package Image Detail
        public int DeletePackageImageDetail(int packageImageId)
        {
            return db.DeletePackageImageDetail(packageImageId);
        }
        #endregion

        #region Insert Update Package Itinery
        public int InsertUpdatePackageItinery(PackageItinery model)
        {
            return db.InsertUpdatePackageInTinery(model);
        }
        #endregion

        #region Get City List
        public IEnumerable<City> GetCityList()
        {
            return db.GetCityList();
        }
        #endregion

        #region Count Display of Package Itinery
        public PackageItinery CountPackageItinery(PackageItinery model)
        {
            return db.CountPackageItinery(model);
        }
        #endregion

        #region Get Package Itinery
        public IEnumerable<PackageItinery> GetPackageItinery(int PackageId)
        {
            return db.GetPackageItinery(PackageId);
        }
        #endregion

        #region Delete Package Itinery
        public int DeletePackageItinery(int ItineryId)
        {
            return db.DeletePackageItinery(ItineryId);
        }
        #endregion

        #region Get Package Itinery By Id
        public PackageItinery GetPackageItineryById(int ItineryId)
        {
            return db.GetPackageItinerybyId(ItineryId);
        }
        #endregion

        #region Check Package Itinerary Exist
        public IEnumerable<PackageItinery> CheckPackageItineryExist(PackageItinery model)
        {
            return db.checkPackageItineraryExist(model);
        }
        #endregion

        #region Check Display order of Package Itinerary
        public IEnumerable<PackageItinery> checkDisplayOrder(PackageItinery model)
        {
            return db.checkDisplayOrder(model);
        }

        #endregion

        #region Get Package Image By Id
        public PackageImageEntry GetPackageImageById(int PackageImageId)
        {
            return db.GetPackageImagebyId(PackageImageId);
        }
        #endregion

        #region Add Package Amount
        public int AddPackageAmount(PackageAmount model)
        {
            return db.InsertUpdatePackageAmount(model);
        }
        #endregion

        #region Get Season
        public IEnumerable<PackageSeason> GetSeasonBy()
        {
            return db.GetSeasonBy();
        }
        #endregion
        #endregion
        #endregion
        #region Get Package Amount By Package amountid and PackageId------------------------------By bramh
        public IEnumerable<PackageAmount> GetPackageAmount(int PackageId, int PackageAmountId)
        {
            return db.GetPackageAmount(PackageId, PackageAmountId);
        }
        #endregion

        #region Delete Package Amount By Package amountid ------------------------------By bramh
        public int DeletePackageAmount(int PackageAmountId)
        {
            return db.DeletePackageAmount(PackageAmountId);
        }
        #endregion
        #region Insert into Audit Trail ------------------------------By bramh
        public int InsertAuditTrail(string PageUrl, string VisitStatus)
        {
            return db.InsertAuditTrail(PageUrl, VisitStatus);
        }
        #endregion

        #region Get Package Amount By Package amountid and PackageId------------------------------By bramh
        public Messg InsertUpdateSpecialPackage(SpecialPackages specPack)
        {
            return db.InsertUpdateSpecialPackage(specPack);
        }
        #endregion

        #region Get Customer DetailsForEdit by DocketNo.
        public IEnumerable<Customer> GetCustomerDetailsForEdit(string DocketNo)
        {
            return db.GetCustomerDetailsForEdit(DocketNo);            
        }
        #endregion

        #region Insert into Audit Trail ------------------------------By bramh
        public int UpdateCustomerDetails(Customer cust)
        {
            return db.UpdateCustomerDetails(cust);
        }
        #endregion


        #region get details after payment--------------------by bramh
        public BookingDetails GetbookedCheckoutDetailsForPrint(string merchantRefNo)
        {
            return db.GetbookedCheckoutDetailsForPrint(merchantRefNo);
        }
        #endregion


        #region get Advance Amount Category
        public List<AdvanceAmountCategory> GetAdvanceAmountCategory()
        {
            return db.GetAdvanceAmountCategory();
        }
        #endregion
        
        /*------------------Vacancy Status ARC Login----------------------------*/

        #region get ARC booking status
        public List<VacancyStatus> GetARCVacancyStatus(ARCVacancyStatus model)
        {
            return db.GetARCVacancyStatus(model);
        }
        #endregion
        /*------------------End Vacancy Status ARC Login----------------------------*/

       #region Get SpecialPackageDetails.-----------------------------------by Bramh
        public IEnumerable<SpecialPackages> GetSpecialpackageDetails(Int64 SpId)
        {
            return db.GetSpecialpackageDetails(SpId);

        }
        #endregion

        #region payment details for UPT
        public List<PaymentDetails> GetPaymentDetailsForARC(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 unitId, string docketNo)
        {
            return db.GetPaymentDetailsForARC(PaymentDateFrom, PaymentDateTo, unitId, docketNo);
        }
        #endregion


        #region get Unit List by packagecatgryid--------------bramh
        public IEnumerable<Unit> GetUnitListPackageWiseByPackagecatId()
        {
            return db.GetUnitListPackageWiseByPackagecatId();
        }
        #endregion



        /*-------------------ARC Booking Cancellation-----------------*/

        #region Get ARC booking for cancellation
        public IEnumerable<ARCCancellationRequest> GetARCBookingForCancellation(Int64? unitID, int bookingType, string docketNo, DateTime fromDate, DateTime toDate)
        {
            return db.GetARCBookingForCancellation(unitID, bookingType, docketNo, fromDate, toDate);
        }
        #endregion

        #region cancel booking for arc
        public BookingCancellation CancelARCBooking(string docketNo)
        {
            return db.CancelARCBooking(docketNo);
        }
        #endregion
        /*-------------------End ARC Booking Cancellation-----------------*/


        #region GetPackageCancilationDetails by out Anonymous User at UP Tours------------ by Bramh
        public List<cancellationRequest> GetPackageCancilationRequestatUPT(string docketNo, DateTime dateFrom, DateTime dateTo)
        {
            return db.GetPackageCancilationRequestatUPT(docketNo, dateFrom, dateTo);
        }
        #endregion

        /*-------------------UP Tour Booking Cancellation-----------------*/       

        #region Get UP Tour booking for cancellation
        public IEnumerable<cancellationRequest> GetUPTBookingForCancellation(string docketNo)
        {
            return db.GetUPTBookingForCancellation(docketNo);
        }
        #endregion

        #region cancel booking for UP Tour
        public BookingCancellation CancelUPTBooking(string docketNo, string ipAddress)
        {
            return db.CancelUPTBooking(docketNo, ipAddress);
        }
        #endregion
        /*-------------------End UP Tour Booking Cancellation-----------------*/

        #region get name title
        public List<NameTitle> GetTitle()
        {
            return db.GetTitle();
        }
        #endregion

        public List<SpecialBookedDetail> GetCancilledBookingDetailsatUPT(string docketNo, Int64 unitID)
        {
            return db.GetCancilledBookingDetailsatUPT(docketNo, unitID);
        }


        #region Package payment details for UPT------------------BY BRAMH
        public List<PaymentDetails> GetPackagePaymentDetailsForUPT(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 PackageId, string docketNo)
        {
            return db.GetPackagePaymentDetailsForUPT(PaymentDateFrom, PaymentDateTo, PackageId, docketNo);
        }
        #endregion

        #region get UPTour Special booking Payment
        public List<PaymentDetails> GetUPTourSpecialBookingPayment(UPTourTotalBooking model)
        {
            return db.GetUPTourSpecialBookingPayment(model);
        }
        #endregion


         /*-------------------UP Tour Booking Cancellation-----------------*/

        #region Get UP Tour booking for cancellation
        public IEnumerable<CRSCancellationRequest> GetCRSBookingForCancellation(string docketNo, int bookingType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            return db.GetCRSBookingForCancellation(docketNo, bookingType, unitID, fromDate, toDate);
        }
        #endregion

         #region cancel booking for crs
        public CRSBookingCancellation CancelCRSBooking(string docketNo, string ipAddress)
        {
            return db.CancelCRSBooking(docketNo, ipAddress);
        }
         #endregion
        /*-------------------End UP Tour Booking Cancellation-----------------*/

        /*-------------------CRS Cancellation List-----------------*/
        #region Get UP Tour cancelled booking
        public IEnumerable<CRSCancellationRequest> GetCRSCancelledBooking(string docketNo, int bookingType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            return db.GetCRSCancelledBooking(docketNo, bookingType, unitID, fromDate, toDate);
        }
        #endregion
        /*-------------------End CRS Cancellation List-----------------*/

        #region GetGuestStatus date wise By Bramh
        public List<BookedDetail> GetGuestStatus(UnitTotalBooking model)
        {
            return db.GetGuestStatus(model);
        }
        #endregion

        #region get total amount
        public decimal GetTotalUnitRoomPrice(DateTime fromDate, DateTime toDate, RoomDetail obj)
        {
            return db.GetTotalUnitRoomPrice(fromDate, toDate, obj);
        }
        #endregion


        #region get room tariff details
        public List<RoomTariffDetails> GetRoomTariffDetails(int roomID, DateTime fromDate, DateTime toDate)
        {
            return db.GetRoomTariffDetails(roomID, fromDate, toDate);
        }
         #endregion

        #region get set Special Package Program By Id -----------------------by bramh
        public List<SpecialPackageProgram> GetSetspecialPackageProgram(Int64 PID)
        {
            return db.GetSetspecialPackageProgram(PID);
        }
        #endregion

        #region Insert into Special Package Program ------------------------------By bramh
        public int AddSpecialPackageProgram(SpecialPackageProgram spp)
        {
            return db.AddSpecialPackageProgram(spp);
        }
        #endregion

        #region get unit Current Guest status
        public VacancyStatusDetail GetVacancyStatusDetail(VacancyStatusDetail model)
        {
            return db.GetVacancyStatusDetail(model);
        }
        #endregion


         /*----------------Prepone-postpone booking----------------------*/

        #region get booking details for prepone-postpone
        public PreponePostpone GetBookingDetailsForPrePostpone(string docketNo, Int64 unitID)
        {
            return db.GetBookingDetailsForPrePostpone(docketNo, unitID);
        }
        #endregion

        #region save prepone-postpone booking
        public int SavePreponePostponeBooking(PreponePostpone model)
        {
            return db.SavePreponePostponeBooking(model);
        }
        #endregion

        public IEnumerable<CheckOutBillDetails> GetCheckOutBillDetailsUPT(String docketNo)
        {
            return db.GetCheckOutBillDetailsUPT(docketNo);
        }

        #region   Update Special Program -------------------------By Bramh
        public int UpdateSpecialProgram(string xml, Int64? pid)
        {
           return db.UpdateSpecialProgram(xml,pid);
        }
        #endregion

        #region get Rooms On Check In
        public List<RoomDetails> GetRoomsOnCheckInByDate(Int64 unitId, DateTime fromDate, DateTime toDate, int roomId)
        {
            return db.GetRoomsOnCheckInByDate(unitId, fromDate, toDate, roomId);
        }
        #endregion

        #region Get Checked in room Guest details
        public IEnumerable<GuesRoomtDetails> GetCheckinRoomDetails(String docketNo, DateTime bookingdate)
        {
            return db.GetCheckinRoomDetails(docketNo,bookingdate);
        }
        #endregion

        public int InsertUpdateGuestRoomDetails(string xml, GuesRoomtDetails rl)
        {
            return db.InsertUpdateGuestRoomDetails(xml, rl);
        }

        #region View SpecialFair
        public List<SpecialPackageFare> GetSetspecialPackageFare(Int64 PID)
        {
            return db.GetSetspecialPackageFare(PID);
        }
        #endregion



        #region get special discount
        public List<SpecialDiscount> GetSpecialDiscount()
        {
            return db.GetSpecialDiscount();
        }
        #endregion
        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> getMobileNosEmailIdForSMSEmailCRS(string docketNo)
        {
            return db.getMobileNosEmailIdForSMSEmailCRS(docketNo);
        }
        #endregion

        #region   Insert Update SpecialPackage Fare -------------------------By Bramh
        public Messg InsertUpdateSpecialPackFare(SpecialPackageFare spf)
        {
            return db.InsertUpdateSpecialPackFare(spf);
        }
        #endregion


        #region Package Destination----------------------
        #region insert Package Mapping
        public int InsertPackageMapDetails(PackageMappingModel model)
        {
            int i = 0;
            i = db.InsertPackageMap(model);
            return i;
        }
        #endregion

        #region Delete Package Destination (package mapping) record

        public int DeletePackageMapDetails(PackageMappingModel model, int packageDestionationID)
        {
            int i = 0;
            i = db.DeletePackageMap(model, packageDestionationID);
            return i;
        }
        #endregion

        #region get PackageType

        public IEnumerable<SelectPackageType> GetPackageType()
        {
            return db.GetPackageType();
        }

        #endregion

        #region get From City Details

        public IEnumerable<SelectFromCity> GetFromCity()
        {
            return db.GetFromCity();
        }

        #endregion

        #region get To City Details

        public IEnumerable<SelectToCity> GetToCity()
        {
            // return PMI.GetToCity(DestinationID);
            return db.GetToCity();
        }

        #endregion

        #region get Unit Details

        public IEnumerable<SelectUnit> GetUnitDetail(int destinationID)
        {
            return db.GetUnitDetail(destinationID);
        }

        #endregion

        #region get Room Type Details

        public IEnumerable<SelectRoomType> GetRoomTypeDetails(int unitID)
        {
            return db.GetRoomTypeDetail(unitID);
        }

        #endregion

        #region get Mapped Package Details

        public List<FillPackgeMappedDetails> GetMappedPackageDetails(int packageID)
        {
            return db.GetMappedPackageDetails(packageID);
        }


        #endregion
        #endregion 

        #region get unit booking details for ARC
        public SpecialBookedDetail GetUnitBookingDetailsForARC(string docketNo)
        {
            return db.GetUnitBookingDetailsForARC(docketNo);
        }
        #endregion

        #region Get ARC cancelled booking
        public IEnumerable<ARCCancellationRequest> GetARCCancelledBooking(string docketNo, int bookingType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            return db.GetARCCancelledBooking(docketNo, bookingType, unitID, fromDate, toDate);
        }
        #endregion

        #region get unit transaction details For Mail
        public UnitTransactionDetail GetTransactionDetailsUser(string docketNo)
        {
            return db.GetTransactionDetailsUser(docketNo);
        }
        #endregion

        #region Get Unit cancelled booking
        public IEnumerable<CRSCancellationRequest> GetCancelledBooking(string docketNo, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            return db.GetCancelledBooking(docketNo, unitID, fromDate, toDate);
        }
        #endregion

        #region Get contact list for up tours
        public IEnumerable<OfficerContactDetails> GetContactForUPTours(string docketNo)
        {
            return db.GetContactForUPTours(docketNo);
        }
        #endregion


         /*---------------UPT Booking List---------------*/

        #region get UPT booking Details
        public SpecialBookedDetail GetUPTBookingDetails(string docketNo)
        {
            return db.GetUPTBookingDetails(docketNo);
        }
        #endregion


        /*---------------UPT Package Booking--------------*/
        #region get city tours category list
        public IEnumerable<PackageCategory> GetPackageTourCategoryForUPT()
        {
            return db.GetPackageTourCategoryForUPT();
        }
        #endregion
        /*---------------End UPT Package Booking--------------*/

        /*---------------UPT One day Tours && ac bus Booking--------------*/
        #region get city tours category list
        public IEnumerable<CityTourCategory> GetCityTourCategoryList(int packageCategoryID, string tourType)
        {
            return db.GetCityTourCategoryList(packageCategoryID, tourType);
        }
        #endregion

        #region get AC Bus package list
        public IEnumerable<PackageTour> GetACBusTourForUPT(int packageCategoryID)
        {
            return db.GetACBusTourForUPT(packageCategoryID);
        }
        #endregion
        /*---------------End UPT One day Tours Booking--------------*/


        #region Activate package
        public Messg ActivateDeactivatePackage(int PID)
        {
            return db.ActivateDeactivatePackage(PID);
        }
        #endregion

        #region Get  All deactive Package
        public IEnumerable<PackageEntry> GetAllDeactivatedPackage()
        {
            return db.GetAllDeactivatedPackagedb();
        }
        #endregion



        /*---------------UPT Payment Details--------------*/
        #region payment details
        public List<PaymentDetails> GetPaymentDetailsForUPT(UPTPaymentDetails model)
        {
           return db.GetPaymentDetailsForUPT(model);
        }
        #endregion

        #region advance payment details
        public List<PaymentDetails> GetAdvancePaymentForUPT(string docketNo)
        {
            return db.GetAdvancePaymentForUPT(docketNo);
        }
        #endregion
        /*---------------End UPT Payment Details--------------*/


         /*-------------------UPT Booking Cancellation-----------------*/

        #region Get UP Tour booking for cancellation
        public IEnumerable<CRSCancellationRequest> GetUPToursBookingForCancellation(string docketNo, int bookingType, DateTime fromDate, DateTime toDate)
        {
            return db.GetUPToursBookingForCancellation(docketNo, bookingType, fromDate, toDate);
        }
        #endregion
        
        /*-------------------End UPT Booking Cancellation-----------------*/
        #region verify All user for PasswordChange
        public UserLogin verifyuserforPasswordChange(string email, string roleId)
        {
            return db.verifyuserforPasswordChange(email, roleId);
        }
        #endregion


        #region change Password
        public int ChangeAllUserPassword(UserChangePassword m)
        {
            return db.ChangeAllUserPassword(m);
        }
        #endregion

        #region get ARC Special booking status
        public List<BookedDetail> GetSpecialBookingForARC(UPTourTotalBooking model)
        {
            return db.GetSpecialBookingForARC(model);
        }
        #endregion

        #region get UPTour Special booking Details
        public List<SpecialBookedDetail> GetSpecialDetailsForARC(string docketNo)
        {
            return db.GetSpecialDetailsForARC(docketNo);
        }
        #endregion

        #region get ARC Special booking Payment
        public List<PaymentDetails> GetPaymentDetailsDateWiseForSpclForARC(UPTourTotalBooking model)
        {
            return db.GetPaymentDetailsDateWiseForSpclForARC(model);
        }
        #endregion


        /*---------------CRS Online booking report---------------------*/

        #region Get UP Tour Online booking list
        public IEnumerable<CRSOnlineBookingReport> GetCRSOnlineBookingList(CRSOnlineBookingReport model)
        {
            return db.GetCRSOnlineBookingList(model);
        }
        #endregion

        #region Get CRS Online cancellation list
        public IEnumerable<CRSOnlineCancellationReport> GetCRSOnlineCancellationList(CRSOnlineCancellationReport model)
        {
            return db.GetCRSOnlineCancellationList(model);
        }
        #endregion

        #region Get Online Failed Booking list
        public IEnumerable<CRSOnlineCancellationReport> GetOnlineFailedBookingList(CRSOnlineCancellationReport model)
        {
            return db.GetOnlineFailedBookingList(model);
        }
        #endregion

        #region Get CRS online payment details
        public CRSOnlinePaymentDetails GetCRSOnlinePaymentDetails(CRSOnlinePaymentDetails model)
        {
            return db.GetCRSOnlinePaymentDetails(model);
        }
        #endregion

        #region Get CRS/HQ Online bookings guest wise
        public IEnumerable<OnlineBookingRevenueDetails> GetOnlineUnitBookingGuestWiseList(OnlineUnitGuestWiseBookingReport model)
        {
            return db.GetOnlineUnitBookingGuestWiseList(model);
        }
        #endregion


        #region Get CRS/HQ Online package bookings guest wise
        public IEnumerable<OnlineBookingRevenueDetails> GetOnlinePackBookingGuestWiseList(OnlinePackGuestWiseBookingReport model)
        {
            return db.GetOnlinePackBookingGuestWiseList(model);
        }
        #endregion

        #region Get CRS/HQ Online taxi/ bus bookings guest wise
        public IEnumerable<OnlineBookingRevenueDetails> GetTaxiBusBookingGuestWiseList(OnlinePackGuestWiseBookingReport model)
        {
            return db.GetTaxiBusBookingGuestWiseList(model);
        }
        #endregion
        /*---------------End UP Tours Online booking report-------------------*/

        #region Get UP Tour cancelled booking
        public IEnumerable<CRSCancellationRequest> GetCancelledBookingUPT(string docketNo, int bookingType, DateTime fromDate, DateTime toDate)
        {
            return db.GetCancelledBookingUPT(docketNo, bookingType, fromDate, toDate);
        }
        #endregion

        /*------------HQ Report-----------------*/

        #region get unit booking status
        public List<HQBookingStatusReport> GetUnitWiseBookingStatus(HQBookingStatusReport model)
        {
            return db.GetUnitWiseBookingStatus(model);
        }
        #endregion

        #region Get HQ room type wise status
        public IEnumerable<HQRoomStatusReport> GetRoomTypeWiseBookingStatus(HQBookingStatusReport model)
        {
            return db.GetRoomTypeWiseBookingStatus(model);
        }
        #endregion
        /*------------End HQ Report-----------------*/

        /*-------------------Booking Revenue-----------------*/
        #region Get UP Tour cancelled booking
        public IEnumerable<BookingRevenue> GetBookingRevenue(int ReportType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            return db.GetBookingRevenueReport(ReportType, unitID, fromDate, toDate);
        }
        #endregion

        #region Get UP Tour cancelled booking
        public IEnumerable<BookingRevenueForPDF> GetBookingRevenueReportForPDF(int ReportType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            return db.GetBookingRevenueReportForPDF(ReportType, unitID, fromDate, toDate);
        }
        #endregion

        #region Lawn Banquet Booking List by Syed
        public IEnumerable<BookingRevenue> GetBanquetLawnBookingRevenue(Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            return db.GetBanquetLawnBookingRevenue(unitID, fromDate, toDate);
        }
        #endregion

        #region Get Package Revenue
        public IEnumerable<BookingRevenue> GetPackageRevenueReport(int ReportType, int? PackageCategoryID, DateTime fromDate, DateTime toDate)
        {
            return db.GetPackageRevenueReport(ReportType, PackageCategoryID, fromDate, toDate);
        }
        #endregion

        #region Get Special Package Revenue
        public IEnumerable<BookingRevenue> GetSpecialPackageRevenueReport(int ReportType, string packageType, DateTime fromDate, DateTime toDate)
        {
            return db.GetSpecialPackageRevenueReport(ReportType, packageType, fromDate, toDate);
        }
        #endregion
        /*-------------------End Booking Revenue-----------------*/

        #region get package list
        public IEnumerable<PackageDetails> GetPackagesList()
        {
            return db.GetPackagesList();
        }
        #endregion

        #region Get Mobile Nos for SMS
        public CustomerDetails GetCustomerDetails(string MerchantRefNo)
        {
            return db.GetCustomerDetails(MerchantRefNo);
        }
        #endregion

        #region get unit blocked room list on date
        public List<BlockReleaseDetail> GetUnitBlockedRoomsOnDate(UnitBlockRelease model)
        {
            return db.GetUnitBlockedRoomsOnDate(model);
        }
        #endregion

        #region insert package tour query
        public int InsertBlockDetailOnDate(Int64 unitID, string blockList, DateTime blockedDate)
        {
            return db.InsertBlockDetailOnDate(unitID, blockList, blockedDate);
        }
        #endregion

        #region save checkout detail
        public int SaveCheckOutDetails(CustomerRegistration model)
        {
            return db.SaveCheckOutDetails(model);
        }
        #endregion

        #region Get contact details to send customer query mail
        public IEnumerable<OfficerContactDetails> GetContactForCustomerQuery(int packageID)
        {
            return db.GetContactForCustomerQuery(packageID);
        }
        #endregion

        /*---------------Anonymous user profile updation---------------*/

        #region Get Anonymous Customer Details
        public OnlineCustomer GetAnonymousCustomerDetails(string email)
        {
            return db.GetAnonymousCustomerDetails(email);
        }
        #endregion

        #region Update Anonymous Customer Profile
        public int UpdateAnonymousCustomerProfile(OnlineCustomer model)
        {
            return db.UpdateAnonymousCustomerProfile(model);
        }
        #endregion

        /*---------------End anonymous user profile updation---------------*/

        #region insert Customer Booking
        public CustomerRegistration InsertCustomerBookingBulk(CustomerRegistration model)
        {
            return db.InsertCustomerBookingBulk(model);
        }
        #endregion

        #region Get Booking Revenue
        public IEnumerable<BookingCountReport> GetUnitWiseCount(Int64? unitID, string countFor,DateTime fromdate)
        {
            return db.GetUnitWiseCount(unitID, countFor, fromdate);
        }
        #endregion


        #region PackageContact
        public int InsertUpdatePackageContact(PackageContact modl)
        {
            return db.InsertUpdatePackageContact(modl);
        }
        #endregion

        #region get package Contact
        public IEnumerable<PackageContact> GetPackageContact(int packageID)
        {
            return db.GetPackageContact(packageID);
        }
        #endregion

        #region insert update Package Inclusion Exclusion
        public int InsertUpdatePackageINCEXC(IncExc model)
        {
            return db.InsertUpdatePackageINCEXC(model);
        }
        #endregion

        #region get Inclusion Exclusion
        public IEnumerable<IncExc> GetPackageIncExc(int packageID)
        {
            return db.GetPackageIncExc(packageID);
        }
        #endregion


        #region get counter package booking details
        public PackageTransactionDetail GetPackageBookingDetails(string docketNo)
        {
            return db.GetPackageBookingDetails(docketNo);
        }
        #endregion

         #region get CRS booking Details
        public SpecialBookedDetail GetCRSBookingDetails(string docketNo)
        {
            return db.GetCRSBookingDetails(docketNo);
        }
        #endregion

        #region Get Special PackageName for mail
        public SpecialPackageName GetCounterSpecialPackageName(string docketNo)
        {
            return db.GetCounterSpecialPackageName(docketNo);
        }
         #endregion

        /*--------------------Taxi/ Bus  Enquiry-------------------*/

        #region get taxi/ bus from city
        public IEnumerable<BusTaxiSourceCity> GetFromCityList()
        {
            return db.GetFromCityList(); ;
        }
        #endregion

        #region insert bus taxi enquiry
        public BusTaxiEnquiry InsertBusTaxiEnquiry(BusTaxiEnquiry model)
        {
            return db.InsertBusTaxiEnquiry(model);
        }
        #endregion

        #region Get contact details to send customer query mail
        public BusTaxiEnquiry GetTaxiBusEnquiry(string enquiryNo)
        {
           return db.GetTaxiBusEnquiry(enquiryNo);
        }
         #endregion

        #region get bus taxi enquiry list
        public IEnumerable<BusTaxiEnquiry> GetBusTaxiEnquiryList(BusTaxiEnquiryReport model)
        {
            return db.GetBusTaxiEnquiryList(model);
        }
        #endregion

        #region Get contact details to send customer query mail
        public BusTaxiEnquiryReply GetTaxiBusEnquiryDetails(string enquiryNo)
        {
            return db.GetTaxiBusEnquiryDetails(enquiryNo);
        }
        #endregion

        #region Get booking details to send mail
        public BusTaxiBookingDetails GetTaxiBusBookingDetails(string docketNo)
        {
            return db.GetTaxiBusBookingDetails(docketNo);
        }
        #endregion

        #region save bus taxi enquiry reply
        public int SaveBusTaxiEnquiryReply(BusTaxiEnquiryReply model)
        {
            return db.SaveBusTaxiEnquiryReply(model);
        }
        #endregion

        #region insert booking request for taxi/bus 
        public PostPaymentData InsertBusTaxiBookRequest(BusTaxiEnquiryReply model)
        {
            return db.InsertBusTaxiBookRequest(model);
        }
        #endregion

        #region insert bus taxi booking by UPT
        public BusTaxiBooking InsertBusTaxiBooking(BusTaxiBooking model)
        {
            return db.InsertBusTaxiBooking(model);
        }
        #endregion


        #region Get booking details to send mail for counter booking
        public BusTaxiBookingDetails GetTaxiBusCounterBookingDetails(string docketNo)
        {
            return db.GetTaxiBusCounterBookingDetails(docketNo);
        }
        #endregion
        /*--------------------End Taxi/ Bus  Enquiry-------------------*/

        /*--------------------Lawn/ Banquet  Enquiry-------------------*/

        #region get destination wise unit list
        public List<Unit> GetUnitsByDestination(Int64 destinationID)
        {
            return db.GetUnitsByDestination(destinationID);
        }
        #endregion

        #region get all functions
        public IEnumerable<Function> GetFunctionList()
        {
            return db.GetFunctionList();
        }
        #endregion

        #region insert lawn enquiry
        public LawnEnquiry InsertLawnEnquiry(LawnEnquiry model)
        {
            return db.InsertLawnEnquiry(model);
        }
        #endregion

        #region Get contact details to send customer query mail
        public LawnEnquiry GetLawnBanquetEnquiry(string enquiryNo)
        {
            return db.GetLawnBanquetEnquiry(enquiryNo);
        }
        #endregion

        #region get lawn/ banquet enquiry list
        public IEnumerable<LawnEnquiry> GetLawnBanquetEnquiryList(LawnEnquiryReport model)
        {
            return db.GetLawnBanquetEnquiryList(model);
        }
        #endregion
        /*--------------------End Lawn/ Banquet  Enquiry-------------------*/

        /*--------------------Auditorium  Enquiry-------------------*/

        #region get all auditorium functions
        public IEnumerable<Function> GetAuditoriumFunctionList()
        {
            return db.GetAuditoriumFunctionList();
        }
        #endregion

        #region insert auditorium enquiry
        public AuditoriumEnquiry InsertAuditoriumEnquiry(AuditoriumEnquiry model)
        {
            return db.InsertAuditoriumEnquiry(model);
        }
        #endregion

        #region Get contact details to send customer query mail
        public AuditoriumEnquiry GetAuditoriumEnquiry(string enquiryNo)
        {
            return db.GetAuditoriumEnquiry(enquiryNo);
        }
        #endregion

        #region get auditorium enquiry list
        public IEnumerable<AuditoriumEnquiry> GetAuditoriumEnquiryList(AuditoriumReport model)
        {
            return db.GetAuditoriumEnquiryList(model);
        }
        #endregion

        /*--------------------Auditorium  Enquiry-------------------*/

        /*--------------------Advance Payment Room Wise----------------*/

        #region get booking details based on room no. id
        public AdvancePaymentRoomWise GetBookingDetailsByRoom(AdvancePaymentRoomWise model)
        {
            return db.GetBookingDetailsByRoom(model);
        }
        #endregion

        #region save advance payment based on room no. id
        public int InsertAdvancePaymentByRoom(AdvancePaymentRoomWise model)
        {
            return db.InsertAdvancePaymentByRoom(model);
        }
        #endregion
        /*-------------------End Advance Payment Room Wise----------------*/

        #region GetPackageBy filterlist

        public IEnumerable<PackageEntry> GetPackageByCatIdAndname(int PackagecatId, string pName)
        {
            return db.GetPackageByCatIdAndname(PackagecatId, pName);
        }
       
        #endregion

        #region get lawn/ banquet enquiry list for Admin
        public IEnumerable<LawnEnquiry> GetLawnBanquetEnquiryListforUnit(LawnEnquiryReport model)
        {
            return db.GetLawnBanquetEnquiryListForUNIT(model);
        }
        #endregion



        //By Tabeen
        #region get user details for resetting password
        public ForgotPassword GetUserDetailsForPasswordReset(ForgotPassword model)
        {
            return db.GetUserDetailsForPasswordReset(model);
        }
        #endregion

        //End By Tabeen



        #region Anurag Forget Password through Emil and otp
        public IEnumerable<ForgotPassword> VerifyUserForForgetPasswordEO(string LoginEmail, String Email, string Mobile, string Randomno)
        {
            return db.getAuthoUserDataForForgotPasswordEO(LoginEmail, Email, Mobile, Randomno);
        }

        public changepwdByLink GetUserDetailsforChangingPwd(string userId)
        {
            return db.GetUserDetailsforChangingPwd(userId);
        }


        public int UpdateUserPassword(Int64 useid ,  string EncPwd)
        {
            return db.UpdateUserPassword(useid, EncPwd);
        }

        #endregion



        /*---------------Package Special Price-------------------*/
        #region get special deal list
        public IEnumerable<PackageSpecialPriceDealsDetails> GetSpecialDeals(int dealType)
        {
            return db.GetSpecialDeals(dealType);
        }
        #endregion


        #region insert special deals
        public int InsertSpecialDeals(PackageSpecialPriceDeals model)
        {
            return db.InsertSpecialDeals(model);
        }
        #endregion

         /*--------------------Unit Special Deals-------------------*/
        
        #region insert unit special deals
        public int InsertUnitSpecialDeals(UnitSpecialPriceDeals model, string dealxml)
        {
            return db.InsertUnitSpecialDeals(model, dealxml);
        }
        #endregion
        /*--------------------End Unit Special Deals-------------------*/



        /*---------------------Packages Checkin------------------------*/

        #region get unit booking Details
        public PackageCheckin GetPackageBookingDetailsForCheckin(string docketNo, Int64 unitID)
        {
            return db.GetPackageBookingDetailsForCheckin(docketNo, unitID);
        }
        #endregion

        #region get booked room details for package
        public IList<PackageRoomDetail> GetPackageBookedRoomDetails(PackageCheckin model)
        {
            return db.GetPackageBookedRoomDetails(model);
        }
        #endregion

        #region insert package checkin details
        public int InsertPackageCheckinDetail(PackageCheckin model, string roomDetailXml)
        {
            return db.InsertPackageCheckinDetail(model, roomDetailXml);
        }
        #endregion

        #region get package checkin details
        public List<PackageRoomDetail> GetPackCheckinDetails(string docketNo)
        {
            return db.GetPackCheckinDetails(docketNo);
        }
        #endregion
        /*---------------------End Packages Checkin------------------------*/

        #region get taxi/bus booking list
        public IEnumerable<BusTaxiBookingDetails> GetTaxiBusBookingList(BusTaxiBookingReport model)
        {
            return db.GetTaxiBusBookingList(model);
        }
        #endregion


        /*--------------End Taxi/Bus Booking List--------------------------*/


         /*---------------------Packages Checkout------------------------*/

        #region get package booking Details
        public PackageCheckout GetPackageBookingDetailsForCheckout(string docketNo, Int64 unitID)
        {
            return db.GetPackageBookingDetailsForCheckout(docketNo, unitID);
        }
        #endregion

        #region get booked room details for package
        public IList<PackageCheckOutRoomDetail> GetPackageCheckoutRoomDetails(PackageCheckout model)
        {
            return db.GetPackageCheckoutRoomDetails(model);
        }
        #endregion

        #region insert package checkin details
        public int InsertPackageCheckoutDetail(PackageCheckout model, string roomDetailXml)
        {
            return db.InsertPackageCheckoutDetail(model, roomDetailXml);
        }
        #endregion

        #region get package checkin details
        public List<PackageCheckOutRoomDetail> GetPackCheckoutDetails(string docketNo)
        {
            return db.GetPackCheckoutDetails(docketNo);
        }
        #endregion


        /*----------------Prepone-postpone booking----------------------*/

        #region get booking details for prepone-postpone
        public PreponePostponeCRS GetBookingDetailsForPrePostpone(string docketNo)
        {
            return db.GetBookingDetailsForPrePostpone(docketNo);
        }
        #endregion

        #region save prepone-postpone booking
        public int SavePreponePostponeBookingByCrs(PreponePostponeCRS model)
        {
            return db.SavePreponePostponeBookingByCrs(model);
        }
        #endregion
        /*--------------------End Preponepostponeby CRS------------------*/

        /* --------------------Update Fail Payment and Change Status to Booked using DocketNo-----------------------*/
        #region Update Fail Payment and Change Status to Booked
        public int UpdateFailPaymentResponceCRS(UpdatePayment model)
        {
            return db.UpdateFailPaymentResponceCRS(model);
        }
        #endregion
        /* --------------------End Update Fail Payment and Change Status to Booked using DocketNo-----------------------*/

        /*------------------Real Time Booking for Taxi----------------------------------------*/
        #region lawn Banquet by Syed
        public IEnumerable<LawnBanquetBooking> GetLawnBanquetBookingList(LawnBanquetBooking model)
        {
            return db.GetLawnBanquetBookingList(model);
        }
        #endregion

        #region by Syed

        public int DeleteTaxiImageDetails(long? BusTaxiImgId)
        {
            return db.DeleteTaxiImageDetails(BusTaxiImgId);
        }

        public int UpdateTaxiImageDetails(taxiimagedetails tid, string ipaddress)
        {
            return db.UpdateTaxiImageDetails(tid, ipaddress);
        }

        public taxiimagedetails GetTaxiImageDetailsByBusTaxiImgId(long? BusTaxiImgId)
        {
            return db.GetTaxiImageDetailsByBusTaxiImgId(BusTaxiImgId);
        }

        public List<taxiimagedetails> GetTaxiImageDetails()
        {
            return db.GetTaxiImageDetails();
        }

        public int InsertTaxiImageDetails(taxiimagedetails tid, string ipaddress)
        {
            return db.InsertTaxiImageDetails(tid, ipaddress);
        }
        #endregion

        #region by Syed

        public int DeleteTariffDetails(long? TariffId)
        {
            return db.DeleteTariffDetails(TariffId);
        }

        public int UpdateTariffDetails(tariffdetails td, string ipaddress)
        {
            return db.UpdateTariffDetails(td, ipaddress);
        }

        public List<tariffdetails> GetTariffDetails()
        {
            return db.GetTariffDetails();
        }

        public tariffdetails GetTariffDetailsByTariffId(long? TariffId)
        {
            return db.GetTariffDetailsByTariffId(TariffId);
        }

        public int InsertTariffDetails(tariffdetails td, string ipaddress)
        {
            return db.InsertTariffDetails(td, ipaddress);
        }
        #endregion

        public int DeleteTaxiDetails(long? bustaxiid)
        {
            return db.DeleteTaxiDetails(bustaxiid);
        }

        public int UpdateTaxiDetails(taxidetails td, string ipaddress)
        {
            return db.UpdateTaxiDetails(td, ipaddress);
        }

        public taxidetails GetTaxiDetailsByBusTaxiId(long? bustaxiid)
        {
            return db.GetTaxiDetailsByBusTaxiId(bustaxiid);
        }


        public List<taxidetails> GetTaxiDetails()
        {
            return db.GetTaxiDetails();
        }

        public int InsertTaxiDetails(taxidetails td, string ipaddress)
        {
            return db.InsertTaxiDetails(td, ipaddress);
        }

        public int CheckMoblieNoExistenceforUserReg(string mobileno)
        {
            return db.CheckMoblieNoExistenceforUserReg(mobileno);
        }

        public int CheckEmailExistenceforUserReg(string email)
        {
            return db.CheckEmailExistenceforUserReg(email);
        }


        public int InsertUserRegistration(UserRegistration ur, string ipaddress)
        {
            return db.InsertUserRegistration(ur, ipaddress);
        }

        public string insertbustaxibookingdetails(UPTBusTaxibooking bustaxibooking, string ipaddress)
        {
            return db.insertbustaxibookingdetails(bustaxibooking, ipaddress);
        }

        public IEnumerable<BusTaxiBookingDetails> GetReleasedListTaxi(BusTaxiBookingReport model)
        {
            return db.GetReleasedListTaxi(model);
        }

        public decimal? getguidetariffbynoofperson(int? noofperson)
        {
            return db.getguidetariffbynoofperson(noofperson);
        }

        public IEnumerable<packagecategory> getpackagecategoryuptoursname()
        {
            return db.getpackagecategoryuptoursname();
        }

        public IEnumerable<bustaxibookingconfirm> getbustaxibookingconfirmation(string docketno)
        {
            return db.getbustaxibookingconfirmation(docketno);
        }


        public IEnumerable<decimal> getBusTaxitariff(Int64? bustaxiid, int? duration, int? km, string bookingtype, string departuretime)
        {
            return db.getBusTaxitariff(bustaxiid, duration, km, bookingtype, departuretime);
        }


        public IEnumerable<busortaxilist> GetBusTaxiNameList(string bustaxi, int? UptoursId)
        {
            return db.GetBusTaxiNameList(bustaxi, UptoursId);
        }
        public IEnumerable<busortaxilist> GetBusTaxiNameList(string bustaxi, int uptoursid)
        {
            return db.GetBusTaxiNameList(bustaxi, uptoursid);
        }


        public IEnumerable<BusTaxiSourceCity> GetFromCityBusTaxiList()
        {
            return db.GetFromCityBusTaxiList(); 
        }

        public IEnumerable<BusTaxiSourceCity> GetFromCityBusTaxiListByUpToursId(int? UpToursId)
        {
            return db.GetFromCityBusTaxiListByUpToursId(UpToursId);
        }

        public List<BusTaxiDestinationCity> GetDestinationCityBusTaxiList()
        {
            return db.GetDestinationCityBusTaxiList(); 
        }

        public FareBreakup GetFareBreakup(string Duration, string Type, decimal KM, Int64 BustaxiId, DateTime DepartureTime, int noOfPerson)
        {
            return db.GetFareBreakup(Duration, Type, KM, BustaxiId, DepartureTime, noOfPerson);
        }

        #region Insert Payment Details for Bus Taxi Booking
        public PostPaymentData InsertBusTaxiBookRequest(BusTaxiPayment model)
        {
            return db.InsertBusTaxiBookRequest(model);
        }
        #endregion

        #region Update Fail Payment and Change Status to Booked
        public List<BusTaxiList> GetBusTaxilist(int fromCityId, string Duration, string Type, string BusTaxitype, decimal km, Int64 BustaxiId, DateTime DepartureTime, DateTime departuredate, int noOfPerson)
        {
            return db.GetBusTaxilist(fromCityId, Duration, Type, BusTaxitype, km, BustaxiId, DepartureTime, departuredate,noOfPerson);
        }
        #endregion

        public List<BusTaxiSourceCity> GetFromCityDetails(int cityId)
        {
            return db.GetFromCityDetails(cityId);
        }

        public IEnumerable<BusTaxiBookingDetails> GetBookingListBusTaxi(BusTaxiBookingReport model)
        {
            return db.GetBookingListBusTaxi(model);
        }

        #region Get Booking Revenue
        public IEnumerable<BookingRevenue> GetBuxTaxiBookingRevenueReport(int ReportType, Int64? UptoursId, DateTime fromDate, DateTime toDate)
        {
            return db.GetBuxTaxiBookingRevenueReport(ReportType, UptoursId, fromDate, toDate);
        }
        #endregion

        #region get Uptours list
        public IEnumerable<PackageCategory> GetUptoursList()
        {
            return db.GetUptoursList();
        }
        #endregion

        #region get Bus Taxi details
        public IEnumerable<BusTaxiDetails> GetBusTaxiDetail(int UptoursId, int taxiId)
        {
          return  db.GetBusTaxiDetail(UptoursId, taxiId);
        }
        #endregion
        /*------------------End Real Time Booking for Taxi----------------------------------------*/

        #region insert billDetails
        public ReleseBusTaxi InsertBillDetails(ReleseBusTaxi model)
        {
            return db.InsertBillDetails(model);
        }
        #endregion 

        #region get Bus Taxi bill details
        public BusTaxiBillDetails GetBusTaxiBillDetail(string DocketNo)
        {
            return db.GetBusTaxiBillDetail(DocketNo);
        }
        #endregion

        public int ReleseBlockedRoom(int blockId)
        {
            return db.ReleseBlockedRoom(blockId);
        }

        public int SaveBanqLawnEnquiryReply(LawnEnquiry model)
        {
            return db.SaveBanqLawnEnquiryReply(model);
        }

        public PostPaymentData InsertLawnBanquitBookRequest(LawnEnquiry model)
        {
            return db.InsertLawnBanquitBookRequest(model);
        }

        #region Get Lawn Banquet booking details to send mail
        public LawnBanquitBookingDetails GetLawnBanquetBookingDetails(string docketNo)
        {
            return db.GetLawnBanquetBookingDetails(docketNo);
        }
        #endregion

         #region Save Lawn banquiet Booking Details
        public UnitLawnBanquetBooking insertLawnBanquietbookingdetails(UnitLawnBanquetBooking model, string ipaddress)
        {
            return db.insertLawnBanquietbookingdetails(model, ipaddress);
        }
        #endregion

        public IEnumerable<GuestList> getGuestListUNIT(int UserId, string name, string mobileno, string Email, int unitid)
        {
            return db.getGuestListUNIT(UserId, name, mobileno, Email, unitid);
        }

        public CustomerRegistration getCustomerDetailsAutoFill(Int64 UserId)
        {
            return db.getCustomerDetailsAutoFill(UserId);
        }

        public List<AdvanceAmountDetails> GetAdvanceAmountList(string DocketNo, Int64 AdvancePaymentId, Int64 UnitID)
        {
            return db.GetAdvanceAmountList(DocketNo, AdvancePaymentId,UnitID);
        }

        public List<RoomBookingDetails> getRoomBookingList(string DocketNo, int RequestId, Int64 UnitID)
        {
            return db.getRoomBookingList(DocketNo, RequestId, UnitID);
        }

        public List<BookingChange> GetUnitBookingDetailseEDIT(string docketNo, Int64 unitID)
        {
            return db.GetUnitBookingDetailseEDIT(docketNo, unitID);
        }
        public int UpdateRoomOccupancyByReqId(RoomBookingDetails model)
        {
            return db.UpdateRoomOccupancyByReqId(model);
        }

        public int UpdateAdvanceAmountByAdvanceAmtId(AdvanceAmountDetails model)
        {
            return db.UpdateAdvanceAmountByAdvanceAmtId(model);
        }

        public List<UnitBookingAtAGlanceHeader> getUnitBookingAtAGlanceHeaders(int unitId)
        {
            return db.getUnitBookingAtAGlanceHeaders(unitId);
        }

        #region Unit Revenue and Tax Report
        public List<BillRevenueDetails> getUnitRevenueAndTaxReport(UnitRevenueRepoprt model)
        {
            return db.getUnitRevenueAndTaxReport(model);
        }
        #endregion

        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> getMobileNosEmailIdForSMSEmail_BANQ_LAWN_CRS(string docketNo)
        {
            return db.getMobileNosEmailIdForSMSEmail_BANQ_LAWN_CRS(docketNo);
        }
        #endregion

         #region Get Ac Bus Package List
        public IEnumerable<PackageEntry> getACBUSPackageList()
        {
            return db.getACBUSPackageList();
        }

        public List<PackageBlockModel> getACBUSPackageBlockedList(int Packageid, DateTime fromdate, DateTime todate)
        {
            return db.getACBUSPackageBlockedList(Packageid, fromdate, todate);
        }
        #endregion
        public int Insert_AcBus_Blocked(PackageBlockModel model)
        {
            return db.Insert_AcBus_Blocked(model);
        }

        public int ReleseBlockedACBUSTOUR(Int64 BlockId)
        {
            return db.ReleseBlockedACBUSTOUR(BlockId);
        }

        #region all unit Booking Report header
        public List<AllUnitBookingHQHeader> AllUnitBookingCountReportHeaders()
        {
            return db.AllUnitBookingCountReportHeaders();
        }
        #endregion

         #region Insert Bill Details Banquet Lawan
        public BanquitLawnBill InsertBanqUitLawnBillDEtails(BanquitLawnBill bill)
        {
            return db.InsertBanqUitLawnBillDEtails(bill);
        }
         #endregion

         #region GET BANQUET LAWN BILL BY DOCKET
        public BanquitLawnBill GetLawnBanquetBillbyDocket(string docketNo)
        {
            return db.GetLawnBanquetBillbyDocket(docketNo);
        }
        #endregion

        #region get Daly Sale Report
        public DalySaleReportModel GetDalySaleReportforFillForm(Int64 unitId, DateTime saleDate)
        {
            return db.GetDalySaleReportforFillForm(unitId, saleDate);
        }
        #endregion

        #region Insert Daily Sale Report
        public int InsertUpdateDalySaleReport(DalySaleReportModel model)
        {
            return db.InsertUpdateDalySaleReport(model);
        }
        #endregion

         #region get Daly Sale Report for View
            public List< DalySaleReportModel> GetDalySaleReportforView(Int64 unitId, DateTime fromDate, DateTime date,int Procid)
            {
                return db.GetDalySaleReportforView(unitId, fromDate, date, Procid);
            }
        #endregion

            #region get room Tariff details
            public RoomTariffMode getRoomTariffDetails(int roomId, int sesionId, int noOfBeds)
            {
                return db.getRoomTariffDetails(roomId, sesionId, noOfBeds);
            }
            #endregion

            public List<BookingChange> GetUnitBookingDetailseEDITAtCRS(string docketNo)
            {
                return db.GetUnitBookingDetailseEDITAtCRS(docketNo);
            }

            #region Get Day Closing Report
            public List<BookingCustomerDetailsModel> GetDayClosingReport(CRSReportModel model)
            {
                return db.GetDayClosingReport(model);
            }
            #endregion



            #region Update Fail Payment by reconcile the payment status by API
            public QueryResult UpdateFailPaymentByAPI(ReconcileApiValues model)
            {
                return db.UpdateFailPaymentByAPI(model);
            }
            #endregion

            //public List<UnitReportGST> GetGSTView(string fromDate, string toDate)
            //{
            //    return db.GetGSTView(fromDate,toDate);
            //}

            public IEnumerable<UnitReportGST> GetGSTView(UnitReportGST model)
            {
                return db.GetGSTView(model);
            }



            public IEnumerable<TotalBookingDetail> GetTotalUnitList()
            {
                return db.GetTotalUnitList();
            }

            public IEnumerable<TotalBookingDetail> BindTotalBookingList(TotalBookingDetail model)
            {
                return db.BindTotalBookingList(model);
            }
            public IEnumerable<TourList> BindTourBookingList(TourList model)
            {
                return db.BindTourBookingList(model);
            }
            public IEnumerable<GSTBookingDetail> GetGSTandTarrifView(GSTBookingDetail model)
            {
                return db.GetGSTandTarrifView(model);
            }

            public PostRequestData InsertParamotorBookRequest(ParamotorBookingModel model)
            {
               return db.InsertParamotorBookRequest(model);
            }
            public PostRequestData InsertHotAirBaloonRideBookRequest(HotAirBaloonBookingDetailsModel model)
            {
                return db.InsertHotAirBaloonRideBookRequest(model);
            }
            public ParamotorBookingModel GetParaMotorView(string DocketNo)
            {
                return db.GetParaMotorBookingView(DocketNo);
            }
            public HotAirBaloonBookingDetailsModel GetHotAirBaloonRideView(string DocketNo)
            {
                return db.GetHotAirBaloonRideBookingView(DocketNo);
            }
            public ParamotorBookingModel GetParaMotorByMobileNoView(CheckStatus model)
            {
                return db.GetParaMotorBookingViewByMobile(model);
            }
            public HotAirBaloonBookingDetailsModel GetHotAirBaloonRideByMobileNoView(CheckStatus model)
            {
                return db.GetHotAirBaloonRideBookingViewByMobile(model);
            }

            public List<UnitAmountDetailsSlabWise> GetUnitPaymentInfoForTaxSlabsInsert(DateTime dtCheckin, DateTime dtCheckout, int roomId, int single, int doubles, int extraBedRoom)
            {
                return db.GetUnitPaymentInfoForTaxSlabs(dtCheckin, dtCheckout, roomId, single, doubles, extraBedRoom);
            }

            #region Ankita Tripathi

            public List<ViewBookedDetail> ViewBookedDetail(ViewBookedDetail model)
            {
                return db.ViewBookedDetail(model);
            }

            public List<CancelBookingDetail> CancelDetailList(string docketNo)
            {
                return db.CancelDetailList(docketNo);
            }

            public List<CancelBookingDetail> DetailsOfCancellationConfirmation(string docketNo)
            {
                return db.DetailsOfCancellationConfirmation(docketNo);
            }
            public List<CancelBookingDetail> ViewpackagedetailUnitwise(string docketNo)
            {
                return db.ViewpackagedetailUnitwise(docketNo);
            }
            public List<CancelBookingDetail> BookingForCancellation(string docketNo)
            {
                return db.BookingForCancellation(docketNo);
            }


            public IEnumerable<CancelBookingDetail> getMobileNoAndEmailId(string docketNo)
            {
                return db.getMobileNoAndEmailId(docketNo);
            }

            public ViewBookedDetail InsertCancelBooking(string docketNo, decimal refaundPer, decimal refaundAmount)
            {
                return db.InsertCancelBooking(docketNo, refaundPer, refaundAmount);
            }

            public IEnumerable<CancelBookingDetail> PackageAccomodationList(int packageID)
            {
                return db.PackageAccomodationList(packageID);
            }

            public List<ViewBookedDetail> ViewCancelDetail(ViewBookedDetail model)
            {
                return db.ViewCancelDetail(model);
            }

            #endregion



            #region  UNIT Detail Ankita
            public List<LawnBanquetBookingCancle> CancelDetailListforUnit(string docketNo)
            {
                return db.CancelDetailListforUnit(docketNo);
            }

            public List<LawnBanquetBookingCancle> ViewpackagedetailforUnitwise(string docketNo)
            {
                return db.ViewpackagedetailforUnitwise(docketNo);
            }
            public List<LawnBanquetBookingCancle> LawnBanquetCancellationList(string docketNo)
            {
                return db.LawnBanquetCancellationList(docketNo);
            }
            public List<LawnBanquetBookingCancle> LawnBookingForCancellation(string docketNo)
            {
                return db.LawnBookingForCancellation(docketNo);
            }
            public IEnumerable<LawnBanquetBookingCancle> getMobileNoAndEmailIdforUnit(string docketNo)
            {
                return db.getMobileNoAndEmailIdforUnit(docketNo);
            }
            public List<LawnBanquetBookingCancle> getEmailIdBookingForCancellationforUnit(string docketNo)
            {
                return db.getEmailIdBookingForCancellationforUnit(docketNo);
            }
            public IEnumerable<LawnBanquetBookingCancle> PackageAccomodationListforUnit(int packageID)
            {
                return db.PackageAccomodationListforUnit(packageID);
            }
            public LawnBanquetBookingCancle InsertCancelBookingforUnit(string docketNo, decimal refaundPer, decimal refaundAmount)
            {
                return db.InsertCancelBookingforUnit(docketNo, refaundPer, refaundAmount);
            }

            public List<ViewGSTDetailOnline> ViewGSTReportForOnlineBooking(string docketNo)
            {
                return db.ViewGSTReportForOnlineBooking(docketNo);
            }
            public List<ViewTourList> ViewGSTReportForPackageOnlineBooking(string docketNo)
            {
                return db.ViewGSTReportForPackageOnlineBooking(docketNo);
            }
            #endregion


            #region  Online Booking For UPTourism Created By Ankita
            public List<OnlineBooking> OnlineBooking(string docketNo)
            {
                return db.OnlineBooking(docketNo);
            }
            public IEnumerable<OnlineBooking> SendOTPForMobile(OnlineBooking model)
            {
                return db.SendOTPForMobile(model);
            }
            public OnlineBooking GetUserDetailsByEmailAndMobileNo(int flag, Int64 userid, string mobileno, string emailid, string UserName)
            {
                return db.GetUserDetailsByEmailAndMobileNo(flag, userid, mobileno, emailid, UserName);
            }
            #endregion 


            public IEnumerable<UnitAmountDetailsSlabWise> GetGSTDetailSlabWise(UnitAmountDetailsSlabWise model)
            {
                return db.GetGSTDetailSlabWise(model);
            }


            public IEnumerable<UnitAmountDetailsSlabWise> GetGSTDetailSlabWiseCurrent(UnitAmountDetailsSlabWise model)
            {
                return db.GetGSTDetailSlabWiseCurrent(model);
            }

            public IEnumerable<UnitAmountDetailsSlabWise> GetGSTDetailSlabWiseforUnit(UnitAmountDetailsSlabWise model)
            {
                return db.GetGSTDetailSlabWiseforUnit(model);
            }

            public List<UnitAmountDetailsSlabWise> GetOnlineDocketSlabWise(UnitAmountDetailsSlabWise model)
            {
                return db.GetOnlineDocketSlabWise(model);
            }

            public List<UnitAmountDetailsSlabWise> GetOnlineDocketSlabWiseCurrent(UnitAmountDetailsSlabWise model)
            {
                return db.GetOnlineDocketSlabWiseCurrent(model);
            }
            public IEnumerable<UnitAmountDetailsSlabWise> GetGSTSlabWiseforUnit(UnitAmountDetailsSlabWise model)
            {
                return db.GetGSTSlabWiseforUnit(model);
            }


            #region get special unit info
            public SpecialUnitDetails GetSpecialUnitDisplayinfo(int unitID)
            {
                return db.GetSpecialUnitDisplayinfo(unitID);
            }
            #endregion
            #region get special destination wise unit list
            public List<UnitAmenities> GetSpecialUnitWiseAmenitiesList(Int64 unitID)
            {
                return db.GetSpecialUnitWiseAmenitiesList(unitID);
            }
            #endregion
            #region get unit wise unit list
            public List<UnitRooms> GetSpecialUnitRoomList(Int64 unitID, DateTime checkInDate, DateTime checkOutDate, int noOfRooms)
            {
                return db.GetSpecialUnitRoomList(unitID, checkInDate, checkOutDate, noOfRooms);
            }
            #endregion
            #region GetallSpecialUnits
            public IEnumerable<M_Unit> GetallSpecialUnits(int unitId)
            {
                return db.GetallSpecialUnits(unitId);
            }
            #endregion
            public SpecialUnitBooking getDestination(SpecialUnitBooking model)
            {
                return db.getDestination(model);
            }

            #region insert OGA Registration
            public int InsertOGARegistration(OGAModel model)
            {
                return db.InsertOGARegistration(model);
            }
            #endregion
    }
    
}
