﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using UP_TourismBooking.Models.DataModels;
using UP_TourismBooking.Models.ProcessClasses;
using System.Data;
using System.Xml.Linq;
using System.Globalization;
using System.Configuration;

namespace UP_TourismBooking.Models
{
    public class UP_TourismConnection : DbContext
    {
        public UP_TourismConnection()
        {

        }
        Common objcommon = new Common();
        public void Disposing()
        {
            this.Database.Connection.Close();
            base.Dispose();
        }
        Common comp = new Common();

        #region verify login
        public Login VerifyLogin(string username)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@UserLoginID", Value = username }           
                };
            var sqlQuery = @"PROC_CheckLogin @UserLoginID";
            var sDetail = this.Database.SqlQuery<Login>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region admin section

        #region Package Category

        #region insert/ update package category
        public int InsertUpdatePackageCategory(PackageCategory model)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_InsertUpdatePackageCategory  @PackageCategoryID, @PackageCategoryName, @UserID",
               new SqlParameter("PackageCategoryID", model.PackageCategoryID),
               new SqlParameter("PackageCategoryName", model.PackageCategoryName),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion

        #region get package category list
        public IEnumerable<PackageCategory> GetPackageCategoryList()
        {
            var sqlQuery = @"PROC_GetPackageCategory";
            var sList = this.Database.SqlQuery<PackageCategory>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get package category details
        public PackageCategory GetPackageCategoryDetails(int packageCategoryID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageCategoryID", Value = packageCategoryID }           
                };

            var sqlQuery = @"PROC_GetPackageCategory @PackageCategoryID";
            var sList = this.Database.SqlQuery<PackageCategory>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion

        #region delete package category
        public int DeletePackageCategory(int packageCategoryID)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_DeletePackageCategory @packageCategoryID, @UserID",
               new SqlParameter("packageCategoryID", packageCategoryID),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion

        #endregion

        #region package

        #region insert package
        public Package InsertPackage(Package model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageID", Value = model.PackageID },
                    new SqlParameter { ParameterName = "@PackageName", Value = model.PackageName },
                    new SqlParameter { ParameterName = "@PackageCategoryID", Value = model.PackageCategoryID },   
                    new SqlParameter { ParameterName = "@PackageCode", Value = model.PackageCode },   
                    new SqlParameter { ParameterName = "@UserID", Value = SessionManager.UserID }   
                };

            var sqlQuery = @"PROC_InsertUpdatePackage @PackageID, @PackageName, @PackageCategoryID, @PackageCode, @UserID";
            var sDetail = this.Database.SqlQuery<Package>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;

        }
        #endregion

        #region update package
        public int UpdatePackage(Package model)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_InsertUpdatePackage  @PackageID, @PackageName, @PackageCategoryID, @PackageCode, @UserID",
               new SqlParameter("PackageID", model.PackageID),
               new SqlParameter("PackageName", model.PackageName),
               new SqlParameter("PackageCategoryID", model.PackageCategoryID),
               new SqlParameter("PackageCode", model.PackageCode),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion

        #region insert/ update package
        public int InsertUpdatePackage(Package model)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_InsertUpdatePackage  @PackageID, @PackageName, @PackageCategoryID, @PackageCode, @UserID",
               new SqlParameter("PackageID", model.PackageID),
               new SqlParameter("PackageName", model.PackageName),
               new SqlParameter("PackageCategoryID", model.PackageCategoryID),
               new SqlParameter("PackageCode", model.PackageCode),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion

        #region get package list
        public IEnumerable<Package> GetPackageList()
        {
            var sqlQuery = @"PROC_GetPackage";
            var sList = this.Database.SqlQuery<Package>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get package details
        public Package GetPackageDetails(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageID", Value = packageID }           
                };

            var sqlQuery = @"PROC_GetPackage @PackageID";
            var sList = this.Database.SqlQuery<Package>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion

        #region delete package
        public int DeletePackage(int packageID)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_DeletePackage @PackageID, @UserID",
               new SqlParameter("PackageID", packageID),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion

        #endregion

        #region package details

        #region get package complete details
        public PackageDetails GetPackageCompleteDetails(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageID", Value = packageID }           
                };

            var sqlQuery = @"PROC_GetPackageDetails @PackageID";
            var sList = this.Database.SqlQuery<PackageDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion

        #region get all units
        public IEnumerable<Unit> GetAllUnitList()
        {
            var sqlQuery = @"PROC_GetUnits";
            var sList = this.Database.SqlQuery<Unit>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region insert/ update contact
        public int InsertUpdateContact(Contact model)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_InsertUpdateContact  @ContactID, @ContactName, @ContactNumber, @PackageID, @UnitID, @UserID",
               new SqlParameter("ContactID", model.ContactID),
               new SqlParameter("ContactName", model.ContactName),
               new SqlParameter("ContactNumber", model.ContactNo),
               new SqlParameter("PackageID", model.PackageID),
               new SqlParameter("UnitID", model.UnitID),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion

        #region get package contacts
        public IEnumerable<Contact> GetPackageContacts(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageID", Value = packageID }
                };

            var sqlQuery = @"PROC_GetPackageContact @PackageID";
            var sList = this.Database.SqlQuery<Contact>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get package contact details
        public Contact GetPackageContactDetails(int packageID, Int64 contactID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageID", Value = packageID },
                    new SqlParameter { ParameterName = "@ContactID", Value = contactID }
                };

            var sqlQuery = @"PROC_GetPackageContact @PackageID, @ContactID";
            var sDetails = this.Database.SqlQuery<Contact>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region delete contact
        public int DeleteContact(int packageID, Int64 contactID)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_DeleteContact @PackageID, @ContactID, @UserID",
               new SqlParameter("PackageID", packageID),
               new SqlParameter("ContactID", contactID),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion

        #region get package terms n conditions detail
        public TermCondition GetTermsConditionsDetails(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageID", Value = packageID }
                };

            var sqlQuery = @"PROC_GetPackageTerms @PackageID";
            var sDetails = this.Database.SqlQuery<TermCondition>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert/ update terms condition
        public int InsertUpdateTermsCondition(TermCondition model)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_InsertPackageTerms  @TermID, @TermsCondition, @CancellationPolicy, @PackageID, @UserID",
               new SqlParameter("TermID", model.TermID),
               new SqlParameter("TermsCondition", model.TermsCondition),
               new SqlParameter("CancellationPolicy", model.CancellationPolicy),
               new SqlParameter("PackageID", model.PackageID),
               new SqlParameter("UserID", SessionManager.UserID));
            return count;

        }
        #endregion



        #endregion
        /* website */

        #region get destinations
        public IEnumerable<Destinations> GetDestinations()
        {
            var sqlQuery = @"PROC_GetDestinations";
            var sList = this.Database.SqlQuery<Destinations>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get category wise package list
        public IEnumerable<PackageTours> GetCategoryWisePackageList(int destinationID, Int16 isIndian, int noOfTourists, int month, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageCategoryID", Value = destinationID },
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfTourists },
                    new SqlParameter { ParameterName = "@seasonID", Value = month },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                    
                };

            var sqlQuery = @"proc_getPackageInfo @packageCategoryID, @isIndian, @noOfPersons, @seasonID, @arrivalDate";
            var sList = this.Database.SqlQuery<PackageTours>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get country
        public IEnumerable<Country> GetCountryList()
        {
            var sqlQuery = @"proc_getMasterData @masterID=1";
            var sList = this.Database.SqlQuery<Country>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get state
        public IEnumerable<State> GetStateList(int countryID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@masterID", Value = 2 },
                    new SqlParameter { ParameterName = "@countryID", Value = countryID }
                };

            var sqlQuery = @"proc_getMasterData @masterID, @countryID";
            var sList = this.Database.SqlQuery<State>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get cities
        public IEnumerable<City> GetCityList(int stateID)
        {
            var sqlQuery = @"proc_getMasterData @masterID = 3, @stateID= " + stateID;
            var sList = this.Database.SqlQuery<City>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get all tour types
        public IEnumerable<TourTypes> GetAllTourTypes()
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@masterID", Value = 7 }
                };

            var sqlQuery = @"proc_getMasterData @masterID";
            var sList = this.Database.SqlQuery<TourTypes>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion


        #region check email existence
        public Registration CheckEmailExistence(string email)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = email }
                };

            var sqlQuery = @"proc_checkEmailExistence @email";
            var sDetails = this.Database.SqlQuery<Registration>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert user
        public Registration InsertUser(Registration model)
        {
            var sDetails = this.Database.SqlQuery<Registration>("proc_InsertUser  @password, @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo",
               new SqlParameter("password", model.password),
               new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode),
               new SqlParameter("email", model.email),
               new SqlParameter("mobileNo", model.mobileNo)).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #region verify customer login
        public UserLogin VerifyUserLogin(string email)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = email }           
                };
            var sqlQuery = @"proc_VerifyUserLogin @email";
            var sDetail = this.Database.SqlQuery<UserLogin>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region update login attempts
        public int UpdateLoginAttempts(string accessIP, DateTime attemptTime, string email, string pageURL, string visitStatus, int flag)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("UserIPAddress", accessIP),
               new SqlParameter("UserDateTime", attemptTime),
               new SqlParameter("Email", email),
               new SqlParameter("PageURL", pageURL),
               new SqlParameter("VisitStatus", visitStatus),
               new SqlParameter("Flag", flag)
            };
            var sqlQuery = @"proc_Insert_T_AuditTrailStatus @UserIPAddress, @UserDateTime, @Email, @PageURL, @VisitStatus, @Flag";
            int sDetails = this.Database.ExecuteSqlCommand(sqlQuery, sqlParam);
            return sDetails;

        }
        #endregion

        #region get attempt details
        public UserLogin GetAttemptDetails(string email, string visitStatus)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@Email", Value = email },
                    new SqlParameter { ParameterName = "@VisitStatus", Value = visitStatus } 
                };
            var sqlQuery = @"proc_getWrongPasswordAttemptsOfToday @Email, @VisitStatus";
            var sDetail = this.Database.SqlQuery<UserLogin>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region reset login attempts
        public int ResetLoginAttempts(string email)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("Email", email)
            };
            var sqlQuery = @"proc_ResetWrongAttemptsFlag @Email";
            int sDetails = this.Database.ExecuteSqlCommand(sqlQuery, sqlParam);
            return sDetails;

        }
        #endregion


        #region get customer details for forgot password
        public UserForgetPassword GetUserDetails(string email)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = email }           
                };
            var sqlQuery = @"proc_GetUserDetails @email";
            var sDetail = this.Database.SqlQuery<UserForgetPassword>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region update customer password
        public int UpdateCustomerPassword(UserForgetPassword model)
        {
            int count = this.Database.ExecuteSqlCommand("proc_UpdateUserPassword  @email, @password",
               new SqlParameter("email", model.email),
               new SqlParameter("password", model.password));
            return count;
        }
        #endregion

        #region change customer password
        public int ChangeUserPassword(UserChangePassword model)
        {
            int count = 0;
            try
            {
                count = this.Database.ExecuteSqlCommand("proc_changeUserPassword  @email, @password, @userID, @entryby, @IpAddress",
                   new SqlParameter("email", model.email),
                   new SqlParameter("password", model.newPassword),
                   new SqlParameter("userID", model.userId),
                   new SqlParameter("entryby", SessionManager.UserID),
                   new SqlParameter("IpAddress", Common.GetIPAddress()));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return count;
        }
        #endregion

        #region get change password date
        public UserChangePassword GetChangePasswordDate(UserChangePassword model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = model.email },  
                    new SqlParameter { ParameterName = "@userID", Value = model.userId },  
                };
            var sqlQuery = @"proc_changePasswordDate @email, @userID";
            var sDetail = this.Database.SqlQuery<UserChangePassword>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region get package payment info
        public PackagePayment GetPackagePayment(int packageID, Int16 isIndian, int noOfPersons, int month)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID },
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfPersons },
                    new SqlParameter { ParameterName = "@seasonID", Value = month }
                };

            var sqlQuery = @"proc_getPackagePaymentInfo @packageID, @isIndian, @noOfPersons, @seasonID";
            var sDetails = this.Database.SqlQuery<PackagePayment>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert booking request for package tours
        public PostPaymentData InsertPackageBookRequest(PackagePayment model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("packageID", model.packageID),
                   new SqlParameter("arrivalDate", Convert.ToDateTime(model.arrivalDate)),
                   new SqlParameter("noOfTourists", model.noOfTourists),
                   new SqlParameter("noOfRooms", model.noOfRooms),
                   new SqlParameter("amount", Math.Ceiling(model.packageAmountIncludingGST)),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("applicantType", model.isIndian),                  
                   new SqlParameter("description", model.description) ,
                   new SqlParameter("taxAmount", model.taxAmount) ,
                   new SqlParameter("taxPercentage", model.taxPercentage) 
                };

                var sqlQuery = @"proc_InsertPackageBookRequest @userID, @packageID, @arrivalDate, @noOfTourists, @noOfRooms, @amount, @userIP, @mode, @currency, @applicantType, @description,@taxAmount,@taxPercentage";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #region get package post data
        public PostPaymentData GetPackagePostData(Int64 requestID, string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@RequestID", Value = requestID },                    
                    new SqlParameter { ParameterName = "@DocketNo", Value = docketNo }
                };

            var sqlQuery = @"PROC_getPackagePostDate @RequestID, @DocketNo";
            var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert package tour query
        public PackageQuery InsertPackageTourQuery(PackageQuery model)
        {

            //int count = this.Database.ExecuteSqlCommand("proc_InsertPackageTourQuery  @name, @email, @mobileNo, @queryFor, @packageID, @query",
            //   new SqlParameter("name", model.name),
            //   new SqlParameter("email", model.emailID),
            //   new SqlParameter("mobileNo", model.mobileNo),
            //   new SqlParameter("queryFor", model.queryFor),
            //   new SqlParameter("packageID", model.packageID),
            //   new SqlParameter("query", model.query));
            //return count;

            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@name", Value = model.name },
                    new SqlParameter { ParameterName = "@email", Value = model.emailID },
                    new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
                    new SqlParameter { ParameterName = "@queryFor", Value = model.queryFor },
                    new SqlParameter { ParameterName = "@packageID", Value = model.packageID },
                    new SqlParameter { ParameterName = "@query", Value = model.query }
                 };
            var sqlQuery = @"proc_InsertPackageTourQuery @name, @email, @mobileNo, @queryFor, @packageID, @query";
            var sDetails = this.Database.SqlQuery<PackageQuery>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #region get package info
        public PackageToursDetails GetPackageDisplayinfo(int packageID, int noOfPerson, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfPerson },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                 };
            var sqlQuery = @"PROC_getPackageOverview @packageID, @noOfPersons, @arrivalDate";
            var sDetails = this.Database.SqlQuery<PackageToursDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get package policies
        public IEnumerable<PackageToursPolicy> GetPackagePolicyList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = 0 }
                 };

            var sqlQuery = @"PROC_getPackageToursPolicy @packageID";
            var sList = this.Database.SqlQuery<PackageToursPolicy>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get package accomodation
        public IEnumerable<PackageToursAccomodation> GetPackageAccomodationList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursAccomodation @packageID";
            var sList = this.Database.SqlQuery<PackageToursAccomodation>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get package contacts
        public IEnumerable<PackageToursContact> GetPackageContactList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursContact @packageID";
            var sList = this.Database.SqlQuery<PackageToursContact>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get package itenarary
        public IEnumerable<PackageToursItenarary> GetPackageItenararyList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursItinerary @packageID";
            var sList = this.Database.SqlQuery<PackageToursItenarary>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get package images
        public IEnumerable<PackageImages> GetPackageImageList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"proc_getPackageImages @packageID";
            var sList = this.Database.SqlQuery<PackageImages>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get Unit images
        public IEnumerable<UnitImages> GetUnitImageList(int unitID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                 };

            var sqlQuery = @"proc_getUnitImages @unitID";
            var sList = this.Database.SqlQuery<UnitImages>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #endregion


        #region unit booking

        #region get unit destinations
        public IEnumerable<Destinations> GetUnitDestinationsList(int type)
        {

            var sqlQuery = @"PROC_GetDestinations @type=" + type;
            var sList = this.Database.SqlQuery<Destinations>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get destination wise unit list
        public List<UnitBooking> GetDestinationWiseUnitList(Int64 destinationID, DateTime checkInDate, DateTime checkOutDate, int noOfGuests, int noOfRooms)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@destinationID", Value = destinationID },
                    new SqlParameter { ParameterName = "@checkInDate", Value = checkInDate },
                    new SqlParameter { ParameterName = "@checkOutDate", Value = checkOutDate },
                    new SqlParameter { ParameterName = "@noOfGuests", Value = noOfGuests },
                    new SqlParameter { ParameterName = "@noOfRooms", Value = noOfRooms }
                };

            var sqlQuery = @"PROC_getAvailableUnitList @destinationID, @checkInDate, @checkOutDate, @noOfGuests, @noOfRooms";
            var sList = this.Database.SqlQuery<UnitBooking>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get unit wise amenity list
        public List<UnitAmenities> GetUnitWiseAmenitiesList(Int64 unitID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                };

            var sqlQuery = @"PROC_getUnitAmenities @unitID";
            var sList = this.Database.SqlQuery<UnitAmenities>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get unit wise unit list
        public List<UnitRooms> GetUnitWiseRoomList(Int64 unitID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                };

            var sqlQuery = @"PROC_getUnitRooms @unitID";
            var sList = this.Database.SqlQuery<UnitRooms>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get unit wise room availability
        public DataTable GetUnitWiseRoomList(Int64 unitID, DateTime dtCheckIn, DateTime dtCheckOut, int noOfRooms)
        {
            DataTable dt = new DataTable();
            using (var dataContext = new UP_TourismConnection())
            {
                var conn = dataContext.Database.Connection;
                var connectionState = conn.State;
                try
                {

                    if (connectionState != ConnectionState.Open)
                        conn.Open();
                    using (var cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = "PROC_getDateWiseAvailableRooms";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.Add(new SqlParameter("fromDate", dtCheckIn));
                        cmd.Parameters.Add(new SqlParameter("toDate", dtCheckOut));
                        cmd.Parameters.Add(new SqlParameter("unitID", unitID));
                        cmd.Parameters.Add(new SqlParameter("noOfRooms", noOfRooms));

                        using (var reader = cmd.ExecuteReader())
                        {
                            dt.Load(reader);
                        }
                    }

                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    if (connectionState != ConnectionState.Open)
                        conn.Close();
                }
            }
            return dt;
        }


        #endregion

        #region get unit info
        public UnitDetails GetUnitDisplayinfo(int unitID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                 };
            var sqlQuery = @"PROC_getUnitDetails @unitID";
            var sDetails = this.Database.SqlQuery<UnitDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get unit wise unit list
        public List<UnitRooms> GetUnitRoomList(Int64 unitID, DateTime checkInDate, DateTime checkOutDate, int noOfRooms)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID },
                    new SqlParameter { ParameterName = "@checkInDate", Value = checkInDate },
                    new SqlParameter { ParameterName = "@checkOutDate", Value = checkOutDate },
                    new SqlParameter { ParameterName = "@noOfRooms", Value = noOfRooms }
                };

            var sqlQuery = @"PROC_getUnitRoomsList @unitID, @checkInDate, @checkOutDate, @noOfRooms";
            var sList = this.Database.SqlQuery<UnitRooms>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get unit info
        public UnitRooms GetRoomInfo(int roomID, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@roomID", Value = roomID },
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                 };
            var sqlQuery = @"proc_getRoomBasicDetails @roomID, @unitID";
            var sDetails = this.Database.SqlQuery<UnitRooms>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get unit payment info
        public UnitPayment GetUnitPaymentInfo(DateTime dtCheckin, DateTime dtCheckout, int roomId, Int64 unitId, int single, int doubles, int extraBedRoom)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitId },
                    new SqlParameter { ParameterName = "@roomID", Value = roomId },
                    new SqlParameter { ParameterName = "@singleBedRoom", Value = single},
                    new SqlParameter { ParameterName = "@doubleBedRoom", Value = doubles },
                    new SqlParameter { ParameterName = "@checkInDate", Value = dtCheckin },
                    new SqlParameter { ParameterName = "@checkOutDate", Value = dtCheckout },
                    new SqlParameter { ParameterName = "@extraBedRoom", Value = extraBedRoom }
                 };
            var sqlQuery = @"PROC_getUnitPaymentInfo @unitID, @roomID, @singleBedRoom, @doubleBedRoom, @checkInDate, @checkOutDate, @extraBedRoom";
            var sDetails = this.Database.SqlQuery<UnitPayment>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert booking request for unit
        public PostPaymentData InsertUnitBookRequest(UnitPayment model, string UnitPaymentsSlabXML)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("unitID", model.unitID),
                   new SqlParameter("roomID", model.roomID),
                   new SqlParameter("singleRoom", model.singleRoom),
                   new SqlParameter("doubleRoom", model.doubleRoom),
                   new SqlParameter("checkinDate", model.checkInDate),
                   new SqlParameter("checkoutDate", model.checkOutDate),
                   new SqlParameter("noOfGuests", model.noOfGuests),
                   new SqlParameter("noOfRooms", model.noOfRooms),                   
                   new SqlParameter("amount", model.totalAmount),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("description", model.description),
                   new SqlParameter("extraBed", model.extraBed),
                   new SqlParameter("discountAmt", model.discountAmount),
                   new SqlParameter("privilegeCardNo", model.privilegeCardNo),  
                   new SqlParameter("privilegeCardDate", model.privilegeCardDate ?? (object)DBNull.Value),
                   new SqlParameter("discountPercent", model.discountPercent),
                   new SqlParameter("taxAmount", model.taxAmount),
                   new SqlParameter("UnitPaymentsSlabXML",string.IsNullOrEmpty(UnitPaymentsSlabXML)?(object)DBNull.Value:UnitPaymentsSlabXML)
                };

                var sqlQuery = @"proc_InsertUnitBookRequest @userID, @unitID, @roomID, @singleRoom, @doubleRoom, @checkinDate, @checkoutDate, @noOfGuests, @noOfRooms, @amount, @userIP, @mode, @currency, @description, @extraBed, @discountAmt, @privilegeCardNo, @privilegeCardDate, @discountPercent,@taxAmount,@UnitPaymentsSlabXML";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #endregion

        #region Transaction Responce Updation
        public int PROC_UPDATE_PAYMENT_RESPONCE(string MerchantRefNo, string TransactionId, string ResponceString)
        {

            var sqlParam = new SqlParameter[] { 
                new SqlParameter{ParameterName="@MerchantRefNo",Value=MerchantRefNo},
                new SqlParameter{ParameterName="@TransactionId",Value=TransactionId},
                new SqlParameter{ParameterName="@ResponceString",Value=ResponceString}
            };
            var sqlQuery = @"PROC_UPDATE_PAYMENT_RESPONCE @MerchantRefNo,@TransactionId,@ResponceString";
            var sList = this.Database.SqlQuery<int>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion


        #region get unit transaction details
        public UnitTransactionDetail GetTransactionDetails(string docketNo)
        {
            var sqlParams = new SqlParameter[] {                    
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };
            var sqlQuery = @"proc_getTransactionDetails @docketNo";
            var sDetails = this.Database.SqlQuery<UnitTransactionDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get package transaction details
        public PackageTransactionDetail GetPackageTransactionDetails(string docketNo)
        {
            var sqlParams = new SqlParameter[] {                    
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };
            var sqlQuery = @"proc_getPackageTransactionDetails @docketNo";
            var sDetails = this.Database.SqlQuery<PackageTransactionDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get special package transaction details
        public SpecialPackageTransactionDetail GetSplPackageTransactionDetails(string docketNo, string bookingType)
        {
            var sqlParams = new SqlParameter[] {                    
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                    new SqlParameter { ParameterName = "@bookingType", Value = bookingType }
                 };
            var sqlQuery = @"proc_getSplPackageTransDetails @docketNo, @bookingType";
            var sDetails = this.Database.SqlQuery<SpecialPackageTransactionDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region Get Mobile Nos for SMS
        public IEnumerable<OfficerContactDetails> get_Mobile_Nos_For_SMS(string MerchantRefNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=MerchantRefNo}
            };
            var sqlQuery = @"PROC_getOfficerMobileNo @docketNo";
            var sList = this.Database.SqlQuery<OfficerContactDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion

        #region counter booking

        #region verify unit login
        public UnitLogin VerifyUnitLogin(string email)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = email }           
                };
            var sqlQuery = @"proc_VerifyUnitLogin @email";
            var sDetail = this.Database.SqlQuery<UnitLogin>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region get unit booking status
        public List<VacancyStatus> GetUnitVacancyStatus(UnitVacancyStatus model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },                    
                    new SqlParameter { ParameterName = "@dtBooking", Value = model.dtBooking }
                 };
            var sqlQuery = @"proc_getUnitBookingStatus @unitID, @dtBooking";
            var sDetails = this.Database.SqlQuery<VacancyStatus>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get unit blocked room list
        public List<BlockReleaseDetail> GetUnitBlockedRooms(UnitBlockRelease model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },
                    new SqlParameter { ParameterName = "@dtBlocking", Value = model.dtBlocking }
                 };
            var sqlQuery = @"proc_getUnitBlockDetails @unitID, @dtBlocking";
            var sDetails = this.Database.SqlQuery<BlockReleaseDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get HQ blocked room Detailed list
        public List<BlockReleaseDetail> GetHQBlockedRoomsDetail(HQBlockRelease model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },
                    new SqlParameter { ParameterName = "@dtBlocking", Value = model.dtBlocking },
                    new SqlParameter { ParameterName = "@dtBlockingTo", Value = model.dtBlockingTo }
                 };
            var sqlQuery = @"proc_getHQBlockedRoomDetails @unitID, @dtBlocking,@dtBlockingTo";
            var sDetails = this.Database.SqlQuery<BlockReleaseDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get HQ blocked room list
        public List<BlockReleaseDetail> GetHQBlockedRooms(HQBlockRelease model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },
                    new SqlParameter { ParameterName = "@dtBlocking", Value = model.dtBlocking }
                 };
            var sqlQuery = @"proc_gethqBlockDetails @unitID, @dtBlocking";
            var sDetails = this.Database.SqlQuery<BlockReleaseDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region insert unit block room list
        public int InsertBlockDetail(Int64 unitID, string blockList, DateTime dtBlocking)
        {
            int count = this.Database.ExecuteSqlCommand("proc_insertUnitBlockDetails @unitID, @userID, @blockList, @dtBlocking",
               new SqlParameter("unitID", unitID),
               new SqlParameter("userID", SessionManager.UserID),
               new SqlParameter("blockList", blockList),
               new SqlParameter("dtBlocking", dtBlocking));
            return count;
        }
        #endregion


        #region insert HQ block room list
        public int InserthqBlockDetail(Int64 unitID, string blockList, DateTime dtBlocking, DateTime dtBlockingTo)
        {
            int count = this.Database.ExecuteSqlCommand("proc_insertHQBlockDetails @unitID, @userID, @blockList, @dtBlocking,@dtBlockingTo",
               new SqlParameter("unitID", unitID),
               new SqlParameter("userID", SessionManager.UserID),
               new SqlParameter("blockList", blockList),
               new SqlParameter("dtBlocking", dtBlocking),
               new SqlParameter("dtBlockingTo", dtBlockingTo));
            return count;
        }
        #endregion

        #region get unit booking status
        public List<BookedDetail> GetUnitBookingStatus(UnitTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                    new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID},
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? "" }
                 };
            var sqlQuery = @"proc_getUnitBooking @BookingDateFrom, @BookingDateTo, @unitId, @docketNo";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Start and Created By Radhey---------------------------------------------------------------------


        #region get unit booking status
        public List<BookedDetail> GetUnitBookingStatusOldRoomType(UnitTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                    new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? "" }
                 };
            var sqlQuery = @"proc_getUnitBooking_oldRoomType @BookingDateFrom, @BookingDateTo, @unitId, @docketNo";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion




        #region get unit booking Details
        public List<SpecialBookedDetail> GetUnitBookingDetailsOldRoomType(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_getUnitBookingDetails_oldRoomType @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion




        #region get unit booked room details

        public List<RoomOccupancyDetails> GetBookedRoomDetailsOldRoomType(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_GetBookedRoomDetails_oldRoomType @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<RoomOccupancyDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #endregion

        #region get payment info
        public AdvancePayment GetCounterPaymentInfo(AdvancePayment model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID }
                 };
            var sqlQuery = @"proc_getUnitPaymentDetail @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<AdvancePayment>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region save advance payment
        public int InsertAdvancePayment(AdvancePayment model)
        {
            int count = this.Database.ExecuteSqlCommand("proc_insertAdvancePayment @unitID, @docketNo, @advanceAmount, @paymentDate, @userIP, @receiptNo, @CatId, @EntryBy",
               new SqlParameter("unitID", model.unitID),
               new SqlParameter("docketNo", model.docketNo),
               new SqlParameter("advanceAmount", model.advanceAmount),
               new SqlParameter("paymentDate", model.paymentDate),
               new SqlParameter("userIP", model.userIP),
               new SqlParameter("receiptNo", model.receiptNo ?? string.Empty),
               new SqlParameter("CatId", model.CatId),
               new SqlParameter("EntryBy", SessionManager.UserID));
            return count;
        }
        #endregion

        #endregion

        #region city Tours

        #region get city tours category list
        public IEnumerable<CityTourCategory> GetCityTourCategoryList()
        {
            var sqlQuery = @"proc_getCityTourCategory";
            var sList = this.Database.SqlQuery<CityTourCategory>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get category wise city tour list
        public IEnumerable<CityTours> GetCategoryWiseCityTourList(int destinationID, Int16 isIndian, int noOfTourists, int month, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageCategoryID", Value = destinationID },
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfTourists },
                    new SqlParameter { ParameterName = "@seasonID", Value = month },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                    
                };

            var sqlQuery = @"proc_getCityTourInfo @packageCategoryID, @isIndian, @noOfPersons, @seasonID, @arrivalDate";
            var sList = this.Database.SqlQuery<CityTours>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get city tour info
        public CityToursDetails GetCityTourDisplayinfo(int packageID, int noOfPerson, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfPerson },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                 };
            var sqlQuery = @"proc_getCityTourDetails @packageID, @noOfPersons, @arrivalDate";
            var sDetails = this.Database.SqlQuery<CityToursDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get city tours policies
        public IEnumerable<CityToursPolicy> GetCityToursPolicyList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = 0 }
                 };

            var sqlQuery = @"PROC_getPackageToursPolicy @packageID";
            var sList = this.Database.SqlQuery<CityToursPolicy>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get city tours contacts
        public IEnumerable<CityToursContact> GetCityToursContactList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursContact @packageID";
            var sList = this.Database.SqlQuery<CityToursContact>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get city tours itenarary
        public IEnumerable<CityToursItenarary> GetCityToursItenararyList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursItinerary @packageID";
            var sList = this.Database.SqlQuery<CityToursItenarary>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion


        #region insert city tour query
        public CityTourQuery InsertCityTourQuery(CityTourQuery model)
        {
            //int count = this.Database.ExecuteSqlCommand("proc_InsertPackageTourQuery  @name, @email, @mobileNo, @queryFor, @packageID, @query",
            //   new SqlParameter("name", model.name),
            //   new SqlParameter("email", model.emailID),
            //   new SqlParameter("mobileNo", model.mobileNo),
            //   new SqlParameter("queryFor", model.queryFor),
            //   new SqlParameter("packageID", model.packageID),
            //   new SqlParameter("query", model.query));
            //return count;
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@name", Value = model.name },
                    new SqlParameter { ParameterName = "@email", Value = model.emailID },
                    new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
                    new SqlParameter { ParameterName = "@queryFor", Value = model.queryFor },
                    new SqlParameter { ParameterName = "@packageID", Value = model.packageID },
                    new SqlParameter { ParameterName = "@query", Value = model.query }
                 };
            var sqlQuery = @"proc_InsertPackageTourQuery @name, @email, @mobileNo, @queryFor, @packageID, @query";
            var sDetails = this.Database.SqlQuery<CityTourQuery>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #region get city tours payment info
        public CityTourPayment GetCityToursPayment(int packageID, Int16 isIndian, int noOfPersons, int month, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID },
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfPersons },
                    new SqlParameter { ParameterName = "@seasonID", Value = month },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                };

            var sqlQuery = @"proc_getCityTourPaymentInfo @packageID, @isIndian, @noOfPersons, @seasonID, @arrivalDate";
            var sDetails = this.Database.SqlQuery<CityTourPayment>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert booking request for city tours
        public PostPaymentData InsertCityToursBookRequest(CityTourPayment model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("packageID", model.packageID),
                   new SqlParameter("arrivalDate", model.arrivalDate),
                   new SqlParameter("noOfTourists", model.noOfTourists),
                   new SqlParameter("noOfRooms", "0"),
                   new SqlParameter("amount", Math.Ceiling(model.packageAmountIncludingGST)),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("applicantType", model.isIndian),
                   new SqlParameter("description", model.description)  ,
                    new SqlParameter("taxAmount", model.taxAmount) ,
                   new SqlParameter("taxPercentage", model.taxPercentage) 
                };

                var sqlQuery = @"proc_InsertCitytourBookRequest @userID, @packageID, @arrivalDate, @noOfTourists, @noOfRooms, @amount, @userIP, @mode, @currency, @applicantType, @description,@taxAmount,@taxPercentage";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #endregion

        #region Create SMS Log
        public int SMSLog(String Message, String MobileNo, String DocketNo, String SMSStatus)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("PROC_SMSLog @MobileNo, @DocketNo, @SMSText, @SMSStatus",
                    new SqlParameter("MobileNo", MobileNo),
                    new SqlParameter("DocketNo", DocketNo),
                    new SqlParameter("SMSText", Message),
                    new SqlParameter("SMSStatus", SMSStatus));
                return count;
            }
            catch
            { return 0; }

        }
        #endregion

        #region Yogesh Yadav
        public List<SpecialBookedDetail> GetDetailsOfCancellation(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"proc_DetailsOfCancellationRequest @docketNo";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }


        public BookingCancellation InsertBookingCancellationRequest(string docketNo)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("docketNo", docketNo),
                             
          
                };

                var sqlQuery = @"proc_InsertBookingCancellationRequest @docketNo";
                var sDetails = this.Database.SqlQuery<BookingCancellation>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }


        public List<cancellationRequest> GetCancelRequest(string docketNo, Int64 unitId, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo ?? string.Empty },
                    new SqlParameter { ParameterName = "@unitId", Value =unitId },
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate },
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate}
                 };
            var sqlQuery = @"proc_getCancelRequest @docketNo, @unitId, @dateFrom, @dateTo";
            var sDetails = this.Database.SqlQuery<cancellationRequest>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public int InsertCancellationConfirmation(string docketNo, string acceptedByIP)
        {
            int count = this.Database.ExecuteSqlCommand("proc_InsertCancellationConfirmation  @docketNo, @acceptedByIP, @acceptedBy",
               new SqlParameter("docketNo", docketNo),
               new SqlParameter("acceptedByIP", acceptedByIP),
               new SqlParameter("acceptedBy", SessionManager.UserID)
              );
            return count;

        }

        public List<cancellationRequest> GetCancelledRequest(string docketNo, Int64 unitId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value ="" },
                    new SqlParameter { ParameterName = "@unitId", Value =unitId }
                 };
            var sqlQuery = @"proc_GetCancelledRequest @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<cancellationRequest>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        #endregion

        #region Roop Kanwar On 08-09-2015

        #region get room type
        public List<RoomType> GetRoomType(Int64 unitId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitId } 
                 };
            var sqlQuery = @"Proc_getRoomTypeByUnitId @unitID";
            var sDetails = this.Database.SqlQuery<RoomType>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region insert Customer Booking
        public CustomerRegistration InsertCustomerBooking(CustomerRegistration model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address ?? string.Empty),
               new SqlParameter("cityID", model.cityID ?? 0),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID ?? 0),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID ?? 0),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo ?? string.Empty),
               new SqlParameter("phone", model.phone ?? string.Empty),
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("unitID", model.unitID),
               //new SqlParameter("roomID", model.roomType),
               //new SqlParameter("singleRoom", model.singleRoom),
               //new SqlParameter("doubleRoom", model.doubleRoom),
               new SqlParameter("checkinDate", model.checkInDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               //new SqlParameter("noOfRooms", model.noOfRooms),
               new SqlParameter("userIP", model.userIP), 
               new SqlParameter("advancedAmount", model.advanceAmount?? (object)DBNull.Value),
               new SqlParameter("checkOutDate", model.checkOutDate),
               new SqlParameter("IdType", model.IdentityType),
               //new SqlParameter("extrabed", model.extrabed),
               new SqlParameter("isStaff", model.isStaff),
               new SqlParameter("staffId", model.staffId),
               new SqlParameter("staffIdDocPath", model.staffIdDocPath),
               new SqlParameter("staffGrade", model.staffGrade),
               new SqlParameter("staffFacility", model.staffFacility),
               new SqlParameter("strXML", model.bookingXML),
               new SqlParameter("BookingFor", model.bookingFor),
               new SqlParameter("receiptNo", model.receiptNo?? string.Empty),
               new SqlParameter("applicantType", model.applicantType?? 1),
               new SqlParameter("nameTitle", model.nameTitle?? 1),
               new SqlParameter("EntryBy", SessionManager.UserID),
               new SqlParameter("bookingBy", model.bookingBy),
               new SqlParameter("dobDate", model.dobDate),
               new SqlParameter("dobMonth", model.dobMonth),
               new SqlParameter("dobYear", model.dobYear),               
               new SqlParameter("age", model.age),
               new SqlParameter("discountPercent", model.discountPercent),
               new SqlParameter("discountAmount", model.discountAmount),
               new SqlParameter("OldUserId", model.userID)

            };
            var sqlQuery = @"Proc_saveCustomerBookingDetails_new  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @phone, @id, @unitID, @checkinDate, @noOfGuests, @userIP, @advancedAmount, @checkOutDate, @IdType, @isStaff, @staffId, @staffIdDocPath, @staffGrade, @staffFacility, @strXML, @BookingFor, @receiptNo, @applicantType, @nameTitle, @EntryBy, @bookingBy, @dobDate, @dobMonth, @dobYear, @age, @discountPercent, @discountAmount,@OldUserId";
            var sDetails = this.Database.SqlQuery<CustomerRegistration>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        #region Chk Room Availability
        public RoomAvailabilityDetails ChkRoomAvailability(RoomAvailabilityDetails model)
        {
            var _roomAvl = this.Database.SqlQuery<RoomAvailabilityDetails>("Proc_chkRoomAvailability @date, @UnitID, @roomTypeID",
                new SqlParameter("date", model.bookingDate),
                new SqlParameter("UnitID", model.unitId),
                new SqlParameter("roomTypeID", model.roomTypeId)).ToList();
            return _roomAvl.FirstOrDefault();

        }
        #endregion

        #region check out By Roop Kanwar On 09-09-2015
        public CustomerRegistration GetCustomerBookingDetails(string docketNo, Int64 unitId, bool isChekIn = true)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("unitId", unitId),
                new SqlParameter("isChekIn", isChekIn)
            };
            var sqlQuery = @"PROC_getCheckOutGuestContactInfo  @docketNo, @unitId, @isChekIn";
            var sDetails = this.Database.SqlQuery<CustomerRegistration>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();
        }

        public List<BillDetails> GetBillDetails(Int64 requestID, Int64 unitId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("requestID", requestID),
                new SqlParameter("discount", "0.00"),
                new SqlParameter("unitId", unitId)
            };
            //var sqlQuery = @"PROC_getCheckOutBillDetails  @requestID, @discount, @unitId";
            var sqlQuery = @"PROC_getCheckOutBillDetails_New  @requestID, @discount, @unitId";
            var sDetails = this.Database.SqlQuery<BillDetails>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }

        public List<BookedRoomDetails> GetBookedRoomDetailsOnCheckOut(string docketNo, Int64 unitId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("unitId", unitId) 
            };
            var sqlQuery = @"Proc_getBookedRoomOnCheckout  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<BookedRoomDetails>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }

        public CustomerRegistration InsertCheckOutDetails(CustomerRegistration model, string UnitPaymentsSlabXML)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
               new SqlParameter("discountPer", model.discount),
               new SqlParameter("discountAmt", model.discountAmount),
               new SqlParameter("amountAfterDis", model.amountAfterDis),
               new SqlParameter("disThroughID", "0"),
               new SqlParameter("disDetails", ""),
               new SqlParameter("roundOff", "0"),
               new SqlParameter("netPayble", model.netPayable),
               new SqlParameter("totalTaxAmount", model.totalTaxAmt),
               new SqlParameter("luxuryTax", model.luxuryTax),
               new SqlParameter("luxuryTaxAmt", model.luxuryTaxAmt),
               new SqlParameter("serviceTax", model.serviceTax),
               new SqlParameter("serviceTaxAmt", model.serviceTaxAmt),
               new SqlParameter("notes", ""),
               new SqlParameter("billDetailXML", model.billDetailXML),
               new SqlParameter("userID", model.userID),
               new SqlParameter("checkOutDate", model.checkOutDateActual),
               new SqlParameter("checkOutTime",model.checkOutTime),
               new SqlParameter("fAndBAmt", model.fAndBAmt),
               new SqlParameter("laundryAmt", model.laundryAmt),
               new SqlParameter("roomServiceAmt", model.roomServiceAmt) ,
               new SqlParameter("otherAmt",model.otherAmt),
               new SqlParameter("unitId",model.unitID) ,
               new SqlParameter("requestXML",model.requestXML),
               new SqlParameter("totalAmountExtra",model.totalAmountExtra),
               new SqlParameter("privilegeAmt",model.privilegeAmt),
               new SqlParameter("privilegeDist",model.privilegeDist),
               new SqlParameter("totalAmountForTax",model.totalAmountForTax),
               new SqlParameter("roundOffValue",model.roundOffValue),
               new SqlParameter("totalPayable",model.totalPayable),
               new SqlParameter("spclDiscountType",model.spclDiscountType?? (object)DBNull.Value),
               new SqlParameter("spclDiscount",model.spclDiscount),
               new SqlParameter("GSTApplyed",model.GstApplyed),
                new SqlParameter("UnitPaymentsSlabXML",string.IsNullOrEmpty(UnitPaymentsSlabXML)?(object)DBNull.Value:UnitPaymentsSlabXML)
            };
            var sqlQuery = @"PROC_SubmitCheckOutDetails @docketNo, @discountPer, @discountAmt, @amountAfterDis, @disThroughID, @disDetails, @roundOff
                            , @netPayble, @totalTaxAmount, @luxuryTax, @luxuryTaxAmt
                            , @serviceTax, @serviceTaxAmt, @notes, @billDetailXML, @userID, @checkOutDate, @checkOutTime, @fAndBAmt, @laundryAmt, @roomServiceAmt, @otherAmt, @unitId, @requestXML, @totalAmountExtra, @privilegeAmt, @privilegeDist, @totalAmountForTax, @roundOffValue, @totalPayable, @spclDiscountType, @spclDiscount,@GSTApplyed,@UnitPaymentsSlabXML";
            var sDetails = this.Database.SqlQuery<CustomerRegistration>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }

        #region get personal identity
        public List<PersonalIdentity> GetPersonalIdentityType()
        {
            var sqlQuery = @"Proc_getTypesOfIdentity";
            var sDetails = this.Database.SqlQuery<PersonalIdentity>(sqlQuery).ToList();
            return sDetails;
        }
        #endregion
        #endregion

        #region payment details
        public List<PaymentDetails> GetPaymentDetails(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 unitId, string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PaymentDateFrom", Value = PaymentDateFrom },
                    new SqlParameter { ParameterName = "@PaymentDateTo", Value = PaymentDateTo }, 
                    new SqlParameter { ParameterName = "@unitId", Value = unitId } , 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo } 
                 };
            var sqlQuery = @"Proc_getPaymentDetailsDateWise @PaymentDateFrom, @PaymentDateTo, @unitId, @docketNo";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #endregion
        #region samreen
        #region get category wise package list
        public IEnumerable<PackageTours> GetCategoryWiseBusPackageList(int destinationID, Int16 isIndian, int noOfTourists, int month)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageCategoryID", Value = destinationID },
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfTourists },
                    new SqlParameter { ParameterName = "@seasonID", Value = month }
                    
                };

            var sqlQuery = @"PROC_getBusPackageInfo @packageCategoryID, @isIndian, @noOfPersons, @seasonID";
            var sList = this.Database.SqlQuery<PackageTours>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion


        #region Get CheckOut Bill Details
        public List<CheckoutBillHeads> GetCheckOutBillHeads(String docketNo, decimal discount)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                    new SqlParameter { ParameterName = "@discount", Value = discount }                    
                };
            //var sqlQuery = @"PROC_getCheckOutBillDetails @docketNo, @discount";
            var sqlQuery = @"PROC_getCheckOutBillDetails_New @docketNo, @discount";
            var sList = this.Database.SqlQuery<CheckoutBillHeads>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        public IEnumerable<CheckOutBillDetails> GetCheckOutBillDetails(String docketNo, Int64 unitId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                    new SqlParameter { ParameterName = "@unitId", Value = unitId }                       
                };
            var sqlQuery = @"PROC_PrintBillDetails @docketNo, @unitId";
            var sList = this.Database.SqlQuery<CheckOutBillDetails>(sqlQuery, sqlParams).ToList();
            return sList;
        }

        #endregion

        #region get bus package list
        public IEnumerable<ACBusTours> GetBusPackageList(Int16 isIndian, int noOfTourists, int month, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] {                    
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfTourists },
                    new SqlParameter { ParameterName = "@seasonID", Value = month },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                    
                };

            var sqlQuery = @"proc_getBusPackageInfo @isIndian, @noOfPersons, @seasonID, @arrivalDate";
            var sList = this.Database.SqlQuery<ACBusTours>(sqlQuery, sqlParams).ToList();
            return sList;
        }

        #endregion

        #region get ac bus tour info
        public ACBusToursDetails GetACBusDisplayinfo(int packageID, int noOfPerson, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfPerson },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                 };
            var sqlQuery = @"proc_getBusTourDetails @packageID, @noOfPersons, @arrivalDate";
            var sDetails = this.Database.SqlQuery<ACBusToursDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get ac bus tours policies
        public IEnumerable<ACBusToursPolicy> GetACBusToursPolicyList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = 0 }
                 };

            var sqlQuery = @"PROC_getPackageToursPolicy @packageID";
            var sList = this.Database.SqlQuery<ACBusToursPolicy>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get ac bus tours contacts
        public IEnumerable<ACBusToursContact> GetACBusToursContactList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursContact @packageID";
            var sList = this.Database.SqlQuery<ACBusToursContact>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get ac bus tours itenarary
        public IEnumerable<ACBusToursItenarary> GetACBusToursItenararyList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursItinerary @packageID";
            var sList = this.Database.SqlQuery<ACBusToursItenarary>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get ac bus tours payment info
        public ACBusTourPayment GetACBusToursPayment(int packageID, Int16 isIndian, int noOfPersons, int month, DateTime arrivalDate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID },
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfPersons },
                    new SqlParameter { ParameterName = "@seasonID", Value = month },
                    new SqlParameter { ParameterName = "@arrivalDate", Value = arrivalDate }
                };

            var sqlQuery = @"proc_getBusTourPaymentInfo @packageID, @isIndian, @noOfPersons, @seasonID, @arrivalDate";
            var sDetails = this.Database.SqlQuery<ACBusTourPayment>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert booking request for ac bus tours
        public PostPaymentData InsertACBusToursBookRequest(ACBusTourPayment model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("packageID", model.packageID),
                   new SqlParameter("arrivalDate", model.arrivalDate),
                   new SqlParameter("noOfTourists", model.noOfTourists),
                   //new SqlParameter("noOfRooms", "0"),
                   new SqlParameter("amount", Math.Ceiling(model.packageAmountIncludingGST)),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("applicantType", model.isIndian),
                   new SqlParameter("description", model.description),
                   new SqlParameter("taxAmount", model.taxAmount) ,
                   new SqlParameter("taxPercentage", model.taxPercentage) 
                };

                var sqlQuery = @"proc_InsertBustourBookRequest @userID, @packageID, @arrivalDate, @noOfTourists, @amount, @userIP, @mode, @currency, @applicantType, @description,@taxAmount,@taxPercentage";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #region insert special tour query
        public ACBusTourQuery InsertSpecialTourQuery(ACBusTourQuery model)
        {
            //int count = this.Database.ExecuteSqlCommand("proc_InsertPackageTourQuery  @name, @email, @mobileNo, @queryFor, @packageID, @query",
            //   new SqlParameter("name", model.name),
            //   new SqlParameter("email", model.emailID),
            //   new SqlParameter("mobileNo", model.mobileNo),
            //   new SqlParameter("queryFor", model.queryFor),
            //   new SqlParameter("packageID", model.packageID),
            //   new SqlParameter("query", model.query));
            //return count;
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@name", Value = model.name },
                    new SqlParameter { ParameterName = "@email", Value = model.emailID },
                    new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
                    new SqlParameter { ParameterName = "@queryFor", Value = model.queryFor },
                    new SqlParameter { ParameterName = "@packageID", Value = model.packageID },
                    new SqlParameter { ParameterName = "@query", Value = model.query }
                 };
            var sqlQuery = @"proc_InsertPackageTourQuery @name, @email, @mobileNo, @queryFor, @packageID, @query";
            var sDetails = this.Database.SqlQuery<ACBusTourQuery>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #endregion

        #region   Added By Samreen on 11092015
        #region To Verify User For Forget Password

        public ForgetPassword VerifyUserForForgetPassword(string secQues, Int32 secQuesId, string email)
        {
            var sqlParams = new SqlParameter[] { 
                   new SqlParameter { ParameterName = "@secQues", Value = secQues },
                     new SqlParameter { ParameterName = "@secQuesId", Value = secQuesId },
                    // new SqlParameter { ParameterName = "@tanNo", Value = tanNo },
                    //  new SqlParameter { ParameterName = "@tinNo", Value = tinNo },
                    //   new SqlParameter { ParameterName = "@serTaxNo", Value = serTaxNo },
                        new SqlParameter { ParameterName = "@email", Value = email }
                };

            var sqlQuery = @"PROC_VerifyUserForForgetPassword @secQues,@secQuesId,@email";
            var sDetails = this.Database.SqlQuery<ForgetPassword>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion Update password

        #region Update Password

        public int UpdatePassword(ForgetPassword model)
        {
            int count = this.Database.ExecuteSqlCommand("PROC_UpdatePassword  @userId, @password",
                new SqlParameter("userId", model.userID),
                new SqlParameter("password", model.password));
            return count;
        }
        #endregion
        #endregion

        #region get booking details for checkin
        public CheckinDetails GetBookingDetailsForCheckin(CheckinDetails model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
                new SqlParameter("unitId", model.unitID),
                new SqlParameter("isChekIn", false)                
            };
            var sqlQuery = @"PROC_getCheckOutGuestContactInfo  @docketNo, @unitId, @isChekIn";
            var sDetails = this.Database.SqlQuery<CheckinDetails>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();
        }
        #endregion

        #region insert checkin details
        public int InsertCheckinDetail(CheckinDetails model, string roomDetailXml)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("proc_InsertCheckinDetails @docketNo, @advanceAmt, @chekinTime, @privilegeCardPath, @isPrivilegeVerified, @fromWhere, @toWhere, @userID, @unitID, @paymentDate, @userIP, @roomDetailXml, @receiptNo, @checkInDate",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("advanceAmt", model.advancePayment ?? (object)DBNull.Value),
                   new SqlParameter("chekinTime", model.checkInTime),
                   new SqlParameter("privilegeCardPath", model.privilegeCardPath ?? string.Empty),
                   new SqlParameter("isPrivilegeVerified", model.isPrivilegeVerified),
                   new SqlParameter("fromWhere", model.fromWhere),
                   new SqlParameter("toWhere", model.toWhere),
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("unitID", SessionManager.UnitID),
                   new SqlParameter("paymentDate", model.paymentDate ?? (object)DBNull.Value),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("roomDetailXml", roomDetailXml),
                   new SqlParameter("receiptNo", model.receiptNo ?? string.Empty),
                   new SqlParameter("checkInDate", model.checkInDateActual));
                return count;
            }
            catch
            { }
            return 0;
        }
        #endregion

        #region get checkin details
        public CheckinDetails GetCheckinDetails(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("unitID", SessionManager.UnitID)
            };
            var sqlQuery = @"proc_GetCheckinDetails  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<CheckinDetails>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();
        }
        #endregion

        #region Added by Samreen on 19092015
        #region Extend Booking
        #region get booking details for Extending booking date
        public ExtendBookingDetails GetBookingDetailsToExtendBooking(ExtendBookingDetails model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
                new SqlParameter("unitId", model.unitID)                             
            };
            var sqlQuery = @"proc_getBookingDetailsByDocketNo  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<ExtendBookingDetails>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();
        }
        #endregion

        #region get unit room details to be extended
        public List<RoomExtendDetails> GetExtendedRoomDetails(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                 };
            var sqlQuery = @"proc_getExtendedRoomDetails @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<RoomExtendDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get alloted rooms
        public List<RoomDetails> GetAllottedRooms(Int64 requestID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@requestID", Value = requestID }
                 };
            var sqlQuery = @"proc_getCurrentAllotedRooms @requestID";
            var sDetails = this.Database.SqlQuery<RoomDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Update Extend details
        public int UpdateExtendDetail(ExtendBookingDetails model)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("Proc_ExtendBooking @docketNo, @unitId, @BookingFor, @userIP, @EntryBy, @bookingDetails, @roomDetailXml, @bookingBy",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("unitId", model.unitID),
                   new SqlParameter("BookingFor", model.BookingFor),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("EntryBy", SessionManager.UserID),
                   new SqlParameter("bookingDetails", model.bookingDetails),
                   new SqlParameter("roomDetailXml", model.roomDetailXml),
               new SqlParameter("bookingBy", model.bookingBy));
                return count;
            }
            catch
            { }
            return 0;
        }
        #endregion
        #endregion

        #region verify UP Tour login
        public UPToursLogin VerifyUPTourLogin(string email)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = email }           
                };
            var sqlQuery = @"proc_VerifyUpTourLogin @email";
            var sDetail = this.Database.SqlQuery<UPToursLogin>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region get UPTour booking status
        public List<VacancyStatus> GetUPTourVacancyStatus(UPTourVacancyStatus model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },                    
                    new SqlParameter { ParameterName = "@dtBooking", Value = model.dtBooking }
                 };
            var sqlQuery = @"proc_getUnitBookingStatus @unitID, @dtBooking";
            var sDetails = this.Database.SqlQuery<VacancyStatus>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get Unit List
        public IEnumerable<Unit> GetUnitList()
        {
            var sqlQuery = @"proc_getUnitList";
            var sList = this.Database.SqlQuery<Unit>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get Unit List by Syed
        public IEnumerable<Unit> GetUnitListByOnlineHasLawnHasBanquet()
        {
            var sqlQuery = @"proc_getUnitListbyisonlinehaslawnhasbanquet";
            var sList = this.Database.SqlQuery<Unit>(sqlQuery).ToList();
            return sList;
        }
        #endregion
        #region get UPTour booking status
        public List<BookedDetail> GetUPTourBookingStatus(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                    new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID ?? 0 },
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty }
                 };

            var sqlQuery = @"proc_getBookingListForUPTour @BookingDateFrom, @BookingDateTo, @unitId, @docketNo";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;


        }
        #endregion
        #endregion


        #region get all list by Roop Kanwar
        public IEnumerable<PackageTours> GetAllPackageList(Int16 isIndian, int noOfTourists, int month)
        {
            var sqlParams = new SqlParameter[] {  
                    new SqlParameter { ParameterName = "@isIndian", Value = isIndian },
                    new SqlParameter { ParameterName = "@noOfPersons", Value = noOfTourists },
                    new SqlParameter { ParameterName = "@seasonID", Value = month }
                    
                };

            var sqlQuery = @"PROC_getPackageList @isIndian, @noOfPersons, @seasonID";
            var sList = this.Database.SqlQuery<PackageTours>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get payable amount
        public PayDetails GetPayableAmountByDocketNo(string docketNo)
        {
            var sqlParams = new SqlParameter[] {                    
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };
            var sqlQuery = @"proc_getPayableAmountByDocketNo @docketNo";
            var sDetails = this.Database.SqlQuery<PayDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get details after payment
        public Payment GetDetailsAfterPayment(string merchantRefNo, string paymentId)
        {
            var sqlParams = new SqlParameter[] {
                new SqlParameter {ParameterName="MerchantRefNo", Value=merchantRefNo},
                new SqlParameter {ParameterName="PaymentID", Value=paymentId}
            };
            var sqlQuery = @"proc_getDetailsAfterPayment @MerchantRefNo, @PaymentID";
            var pDetails = this.Database.SqlQuery<Payment>(sqlQuery, sqlParams).FirstOrDefault();
            return pDetails;
        }
        #endregion


        #region get details after payment For Print Only By Radhey On Date 17/10/2015

        public Payment GetDetailsAfterPaymentForPrintOnly(string merchantRefNo, string paymentId)
        {
            var sqlParams = new SqlParameter[] {
                new SqlParameter {ParameterName="MerchantRefNo", Value=merchantRefNo},
                new SqlParameter {ParameterName="PaymentID", Value=paymentId}
            };
            var sqlQuery = @"proc_getDetailsAfterPaymentForPrint @MerchantRefNo, @PaymentID";
            var pDetails = this.Database.SqlQuery<Payment>(sqlQuery, sqlParams).FirstOrDefault();
            return pDetails;
        }
        #endregion




        #region cancel room In unit
        public BookingCancellation InsertBookingCancellationRequestInUnit(string docketNo)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("docketNo", docketNo),
                             
          
                };

                var sqlQuery = @"Proc_cancelRoomInUnit @docketNo";
                var sDetails = this.Database.SqlQuery<BookingCancellation>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #region get UPTour Special booking status
        public List<BookedDetail> GetUPTourSpecialBookingStatus(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {              
                  new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                  new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },   
                  new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty },
                  new SqlParameter { ParameterName = "@BookingFor", Value = model.type }
                 };
            var sqlQuery = @"proc_getUPTourSpecialBooking @BookingDateFrom,@BookingDateTo,@docketNo, @BookingFor";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get UPTour Special booking Details
        public List<SpecialBookedDetail> GetUPTourSpecialDetails(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                 };
            var sqlQuery = @"proc_getUPTourSpecialDetails @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get package detail Unit wise
        public List<PackageDetailUnitWise> GetpackagedetailUnitwise(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo }
                 };
            var sqlQuery = @"proc_getpackagedetailUnitwise @docketNo";
            var sDetails = this.Database.SqlQuery<PackageDetailUnitWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get unit booking Details
        public List<SpecialBookedDetail> GetUnitBookingDetails(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_getUnitBookingDetails @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get unit booked room details
        public List<RoomOccupancyDetails> GetBookedRoomDetails(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_GetBookedRoomDetails @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<RoomOccupancyDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #region Insert Tonga Ride Payment Request
        #region insert booking request for package tours
        public PostPaymentData InsertTongaRideBookRequest(PackagePayment model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("arrivalDate", model.arrivalDate),
                   new SqlParameter("noOfTourists", model.noOfTourists),
                   new SqlParameter("amount", Math.Ceiling(model.totalAmount)),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("description", model.description),              
                   new SqlParameter("routeType", model.packageName),
                   new SqlParameter("arrivalTime", model.arrivalTime),
                   new SqlParameter("taxAmount", model.taxAmount) ,
                   new SqlParameter("taxPercentage", model.taxPercentage) 
                };

                var sqlQuery = @"proc_InsertTongaRideBookRequest @userID, @arrivalDate, @noOfTourists, @amount, @userIP, @mode, @currency, @description,@routeType,@arrivalTime,@taxAmount,@taxPercentage";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion
        #endregion

        #region insert booking request for Heritage Walk
        public PostPaymentData InsertHeritageWalkBookRequest(PackagePayment model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("arrivalDate", model.arrivalDate),
                   new SqlParameter("noOfTourists", model.noOfTourists),
                   new SqlParameter("amount", Math.Ceiling(model.totalAmount)),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("description", model.description)   ,
                   new SqlParameter("applicantType", model.isIndian)  , 
                   new SqlParameter("routeType", model.packageName),
                   new SqlParameter("arrivalTime", model.arrivalTime),
                   new SqlParameter("taxAmount", model.taxAmount) ,
                   new SqlParameter("taxPercentage", model.taxPercentage) 
                };

                var sqlQuery = @"proc_InsertHeritageWalkBookRequest @userID, @arrivalDate, @noOfTourists, @amount, @userIP, @mode, @currency, @description,@applicantType,@routeType, @arrivalTime,@taxAmount,@taxPercentage";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #region cancellation request process in UP Tours Login by Roop Kanwar

        public List<cancellationRequest> GetCancelRequestForPackages(BookingCancellation obj)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@dateFrom", Value = obj.FromDate ?? (object)DBNull.Value},
                    new SqlParameter { ParameterName = "@dateTo", Value = obj.ToDate ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@docketNo", Value = obj.docketNo ?? string.Empty }
                    //, new SqlParameter { ParameterName = "@fromDate", Value = obj.FromDate } ,
                    //new SqlParameter { ParameterName = "@toDate", Value = obj.ToDate } 
                 };
            //var sqlQuery = @"proc_getCancelRequestForPackages @docketNo";
            var sqlQuery = @"proc_getOnlineCancellationRequests @dateFrom, @dateTo, @docketNo";

            var sDetails = this.Database.SqlQuery<cancellationRequest>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion



        #region Tonga Booking By UPTour
        public LkoOnTonga saveTongaBookingDetails(LkoOnTonga model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode),
               new SqlParameter("email", model.email),
               new SqlParameter("mobileNo", model.mobileNo),
               new SqlParameter("phone", model.phone),
               new SqlParameter("id", model.ID),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),
            //   new SqlParameter("advancedAmount", model.advanceAmount),
               new SqlParameter("IdType", model.IdentityType),
               new SqlParameter("isStaff", model.isStaff),
               new SqlParameter("staffId", model.staffId),
               new SqlParameter("staffIdDocPath", model.staffIdDocPath) ,
                new SqlParameter("amount", model.RouteFare),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("routeType", model.routeType)
            };
            var sqlQuery = @"Proc_saveTongaBookingDetails  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @phone, @id, @arrivalDate, @noOfGuests,@userIP, @IdType, @isStaff, @staffId, @staffIdDocPath,@amount,@mode,@currency,@description,@routeType";
            var sDetails = this.Database.SqlQuery<LkoOnTonga>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion
        #region Cycle Tour Booking By UPTour
        public LkoOnCycle saveCycleTourBookingDetails(LkoOnCycle model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode),
               new SqlParameter("email", model.email),
               new SqlParameter("mobileNo", model.mobileNo),
               new SqlParameter("phone", model.phone),
               new SqlParameter("id", model.ID),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),
            //   new SqlParameter("advancedAmount", model.advanceAmount),
               new SqlParameter("IdType", model.IdentityType),
               new SqlParameter("isStaff", model.isStaff),
               new SqlParameter("staffId", model.staffId),
               new SqlParameter("staffIdDocPath", model.staffIdDocPath) ,
                new SqlParameter("amount", model.totalAmount),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("routeType", model.routeType),
               new SqlParameter("nameTitle", model.nameTitle)
            };
            var sqlQuery = @"Proc_saveCycleTourBookingDetails  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @phone, @id, @arrivalDate, @noOfGuests,@userIP, @IdType, @isStaff, @staffId, @staffIdDocPath,@amount,@mode,@currency,@description,@routeType, @nameTitle";
            var sDetails = this.Database.SqlQuery<LkoOnCycle>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        #region Cycle Tour Booking Anonymous
        #region Get Cycle Routes Details
        public IEnumerable<CycleToursProgram> GetCycleRouteDetails(Int64 packageId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageId", Value = packageId }
                 };
            var sqlQuery = @"proc_GetCycleRouteDetails @packageId";
            var sList = this.Database.SqlQuery<CycleToursProgram>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion
        #region insert booking request for Cycle tours
        public PostPaymentData InsertCycleTourBookRequest(PackagePayment model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("arrivalDate", model.arrivalDate),
                   new SqlParameter("noOfTourists", model.noOfTourists),
                   new SqlParameter("amount", Math.Ceiling(model.totalAmount)),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("description", model.description)   ,
                   new SqlParameter("applicantType", model.isIndian)   ,
                   new SqlParameter("routeType", model.packageName),
                   new SqlParameter("arrivalTime", model.arrivalTime),
                   new SqlParameter("maxAllowedBooking", model.maxBookingAllowed),
                     new SqlParameter("taxAmount", model.taxAmount) ,
                   new SqlParameter("taxPercentage", model.taxPercentage) 
                };

                var sqlQuery = @"proc_InsertCycletourBookRequest @userID, @arrivalDate, @noOfTourists, @amount, @userIP, @mode, @currency, @description,@applicantType,@routeType, @arrivalTime,@maxAllowedBooking,@taxAmount,@taxPercentage";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion
        #endregion

        #region Get Booking History
        public IEnumerable<BookingHistory> GetBookingHistory(Int64 userId)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@userID", Value =userId }
                 };
            var sqlQuery = @"proc_GetBookingHistory @userID";
            var sList = this.Database.SqlQuery<BookingHistory>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion




        #region Cancel Booking
        public BookingHistory CancelBooking(string docketNo, decimal refaundPer, decimal refaundAmount)
        {
            //int count = this.Database.ExecuteSqlCommand("proc_CancelBooking @docketNo",
            //   new SqlParameter("docketNo", docketNo));
            //return count;
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                     new SqlParameter { ParameterName = "@refaundPer", Value =refaundPer },
                      new SqlParameter { ParameterName = "@refaundAmount", Value =refaundAmount }
                 };
            var sqlQuery = @"proc_InsertBookingCancellationRequestByUser @docketNo,@refaundPer,@refaundAmount";
            var sList = this.Database.SqlQuery<BookingHistory>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;


        }
        #endregion


        #region staff related process
        #region get staff grade
        public List<StaffGrade> GetStaffGrade()
        {
            var sqlQuery = @"proc_getstaffGrade";
            var sDetails = this.Database.SqlQuery<StaffGrade>(sqlQuery).ToList();
            return sDetails;
        }
        public List<RoomType> GetStaffRoom(Int64 unitId, int facilityId)
        {
            var sqlParams = new SqlParameter[] {  
                    new SqlParameter { ParameterName = "@unitID", Value = unitId } ,
                    new SqlParameter { ParameterName = "@roomTypeId", Value = facilityId } 
                 };
            var sqlQuery = @"Proc_getRoomTypeByroomTypeId @unitID, @roomTypeId";
            var sDetails = this.Database.SqlQuery<RoomType>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion
        #endregion


        #region get Rooms On Check In
        public List<RoomDetails> GetRoomsOnCheckIn(Int64 unitId, Int64 requestId, int roomId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@requestId", Value = requestId },
                    new SqlParameter { ParameterName = "@unitID", Value = unitId },
                    new SqlParameter { ParameterName = "@roomId", Value = roomId }  
                 };
            var sqlQuery = @"Proc_getAvailableRoomsOnCheckIn @requestId, @unitId, @roomId";
            var sDetails = this.Database.SqlQuery<RoomDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> getMobileNosEmailIdForSMSEmail(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_GetUnitListToSendSMS @docketNo";
            var sList = this.Database.SqlQuery<OfficerContactDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion
        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> GetOfficerMobileNoForUnit(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"PROC_getOfficerMobileNoForUnit @docketNo";
            var sList = this.Database.SqlQuery<OfficerContactDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion

        #region Get All Accepted Cancelled Request
        public List<cancellationRequest> getAcceptedCancelledRequestDetails(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo }
                 };
            var sqlQuery = @"proc_GetBookingCancel @docketNo";
            var sDetails = this.Database.SqlQuery<cancellationRequest>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion
        #region Cancelation Confirmation By CRS
        public BookingHistory InsertCancellationConfirmationByCRS(string docketNo)
        {
            //int count = this.Database.ExecuteSqlCommand("proc_InsertCancellationConfirmationByCRS  @docketNo",
            //   new SqlParameter("docketNo", docketNo)
            //  );
            //return count;
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo }
                 };
            var sqlQuery = @"proc_InsertBookingCancellationRequestByUser @docketNo";
            var sList = this.Database.SqlQuery<BookingHistory>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;

        }
        #endregion
        #region Get Booking History
        public IEnumerable<BookingHistory> GetCounterBookingHistory(Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_GetBookingHistoryOfCounterBooking @unitID";
            var sList = this.Database.SqlQuery<BookingHistory>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get Cancellation Confirmation Details For Packages and spcial packages
        public List<SpecialBookedDetail> getDetailsOfCancellationConfirmation(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"proc_DetailsOfCancellationConfirmation @docketNo";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #region Get Booking History for Counter Booking
        public IEnumerable<cancellationRequest> GetCounterBookingAndUnitBookingInfo(Int64 unitID, string docketNo, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@unitID", Value =unitID },
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo ?? string.Empty },
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate },
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate}
                 };
            var sqlQuery = @"PROC_getCounterBookingAndUnitBookingInfo @docketNo, @unitID, @dateFrom, @dateTo";
            var sList = this.Database.SqlQuery<cancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion


        #region advance payment details
        public List<PaymentDetails> GetAdvancePaymentDetails(string docketNo, Int64 unitId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }, 
                    new SqlParameter { ParameterName = "@unitId", Value = unitId } 
                 };
            var sqlQuery = @"Proc_getAdvancePaymentDetail @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region On Day Tour Booking
        #region get category wise city tour list
        public IEnumerable<PackageTour> getCityTourList(int packageCategoryID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageCategoryID", Value =packageCategoryID }
                 };
            var sqlQuery = @"proc_getCityTourList @packageCategoryID";
            var sList = this.Database.SqlQuery<PackageTour>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion
        #region One Day Booking By UPTour
        public OneDayTourBooking saveOneDayTourBookingDetails(OneDayTourBooking model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo?? string.Empty),              
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),
               new SqlParameter("IdType", model.IdentityType??0),
               new SqlParameter("amount", model.totalAmount),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("packageID", model.packageID),
               new SqlParameter("bookingFor", model.bookingFor),
               new SqlParameter("enteredBy", SessionManager.UserID),
               new SqlParameter("applicantType", model.isIndian),
               new SqlParameter("bookingBy", model.bookingBy),               
               new SqlParameter("receiptNo", model.receiptNo),
               new SqlParameter("nameTitle", model.nameTitle)
            };
            var sqlQuery = @"Proc_saveOneDayTourBookingDetails  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @id, @arrivalDate, @noOfGuests,@userIP, @IdType,@amount,@mode,@currency,@description,@packageID,@bookingFor, @enteredBy, @applicantType, @bookingBy, @receiptNo, @nameTitle";
            var sDetails = this.Database.SqlQuery<OneDayTourBooking>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        public OneDayTourBooking GetTourTotalAmount(Int32 packageID, Int32 isIndian, Int32 noOfGuests)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageID", Value =packageID },
                    new SqlParameter { ParameterName = "@isIndian", Value =isIndian },
                    new SqlParameter { ParameterName = "@noOfGuests", Value =noOfGuests }
                 };
            var sqlQuery = @"proc_getTourAmount @packageID,@isIndian,@noOfGuests";
            var sList = this.Database.SqlQuery<OneDayTourBooking>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion


        #region AC Bus package Booking
        #region get AC Bus package list
        public IEnumerable<PackageTour> getACBusTourList()
        {
            //var sqlParams = new SqlParameter[] {              
            //        new SqlParameter { ParameterName = "@packageCategoryID", Value =packageCategoryID }
            //     };
            var sqlQuery = @"proc_getBusPackageList";
            var sList = this.Database.SqlQuery<PackageTour>(sqlQuery).ToList();
            return sList;
        }
        #endregion
        #region AC Bus package Booking By UPTour
        public ACBusTourBooking saveACBusTourBookingDetails(ACBusTourBooking model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode  ?? string.Empty),
               new SqlParameter("email", model.email  ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo ?? string.Empty),              
               new SqlParameter("id", model.ID  ?? string.Empty),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),
               new SqlParameter("IdType", model.IdentityType ?? 0),
               new SqlParameter("amount", model.totalAmount),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("packageID", model.packageID),
               new SqlParameter("bookingFor", model.bookingFor),
               new SqlParameter("enteredBy", SessionManager.UserID),
               new SqlParameter("applicantType", model.isIndian),
               new SqlParameter("bookingBy", model.bookingBy),
               new SqlParameter("receiptNo", model.receiptNo),
               new SqlParameter("nameTitle", model.nameTitle)
            };
            var sqlQuery = @"Proc_saveACBusTourBookingDetails  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @id, @arrivalDate, @noOfGuests,@userIP, @IdType,@amount,@mode,@currency,@description,@packageID,@bookingFor,@enteredBy, @applicantType, @bookingBy, @receiptNo, @nameTitle";
            var sDetails = this.Database.SqlQuery<ACBusTourBooking>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        public ACBusTourBooking GetACBusTourTotalAmount(Int32 packageID, Int32 isIndian)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageID", Value =packageID },
                    new SqlParameter { ParameterName = "@isIndian", Value =isIndian }
                 };
            var sqlQuery = @"proc_getBusTourAmount @packageID,@isIndian";
            var sList = this.Database.SqlQuery<ACBusTourBooking>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion


        #region Package Tour Booking By UPTour
        #region get city tours category list
        public IEnumerable<PackageCategory> GetPackageTourCategoryList()
        {
            var sqlQuery = @"PROC_GetPackageCategoryList";
            var sList = this.Database.SqlQuery<PackageCategory>(sqlQuery).ToList();
            return sList;
        }
        #endregion
        #region get package Tour list for up tours and crs
        public IEnumerable<PackageTour> getPackageTourList(Int32 packageCategoryID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageCategoryID", Value =packageCategoryID }
                 };
            var sqlQuery = @"PROC_getPackageInfoList @packageCategoryID";
            var sList = this.Database.SqlQuery<PackageTour>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Save Package Tour Booking Details
        public PackageTourBooking savePackageTourBookingDetails(PackageTourBooking model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo ?? string.Empty),               
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),
               new SqlParameter("IdType", model.IdentityType?? 0),
               new SqlParameter("amount", model.totalAmount),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("packageID", model.packageID),
               new SqlParameter("BookingFor", model.bookingFor),
               new SqlParameter("enteredBY", SessionManager.UserID),
               new SqlParameter("applicantType", model.isIndian),
               new SqlParameter("bookingBy", model.bookingBy),
               new SqlParameter("receiptNo", model.receiptNo),
               new SqlParameter("nameTitle", model.nameTitle) 
            };
            var sqlQuery = @"Proc_savePackageTourBookingDetails  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @id, @arrivalDate, @noOfGuests,@userIP, @IdType,@amount,@mode,@currency,@description,@packageID,@BookingFor, @enteredBY, @applicantType, @bookingBy, @receiptNo, @nameTitle";
            var sDetails = this.Database.SqlQuery<PackageTourBooking>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        #region Chk Package Tour Availability
        public PackageAvailabilityDetails ChkPackageTourAvailability(PackageAvailabilityDetails model)
        {
            var _packageAvl = this.Database.SqlQuery<PackageAvailabilityDetails>("PROC_getPackageTourAvailibility @packageID, @noOfPersons, @arrivalDate",
                new SqlParameter("arrivalDate", model.arrivalDate),
                new SqlParameter("noOfPersons", model.noOfGuests),
                new SqlParameter("packageID", model.packageID)).ToList();
            return _packageAvl.FirstOrDefault();

        }
        #endregion
        #endregion

        #region Lko on Cycle Booking
        public IEnumerable<CycleRouteType> GetCycleToureRouteType(string package_Abbr, int packageCategoryID)
        {
            var sqlParam = new SqlParameter[] { 
             new SqlParameter{ParameterName="@package_Abbr",Value = package_Abbr},
             new SqlParameter{ParameterName="@packageCategoryID",Value= packageCategoryID}
                                              };
            var sqlQuery = @"Proc_GetCycleToureRouteType @package_Abbr, @packageCategoryID";
            var sList = this.Database.SqlQuery<CycleRouteType>(sqlQuery, sqlParam).ToList();
            return sList;
        }

        public IEnumerable<CycleApplicantType> GetCycleApplicantType(string package_Abbr)
        {
            var sqlParam = new SqlParameter[] { 
             new SqlParameter{ParameterName="@package_Abbr",Value=package_Abbr}
                                              };
            var sqlQuery = @"Proc_GetCycleApplicantType @package_Abbr";
            var sList = this.Database.SqlQuery<CycleApplicantType>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion

        #region insert Customer Booking By UP Tour
        public CustomerRegistration InsertCustomerBookingByUPTour(CustomerRegistration model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo),
               new SqlParameter("phone", model.phone ?? string.Empty),
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("unitID", model.unitID),
               new SqlParameter("roomID", model.roomType),
               new SqlParameter("singleRoom", model.singleRoom),
               new SqlParameter("doubleRoom", model.doubleRoom),
               new SqlParameter("checkinDate", model.checkInDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("noOfRooms", model.noOfRooms),
               new SqlParameter("userIP", model.userIP),
               //new SqlParameter("fromWhere", model.fromWhere),
               //new SqlParameter("toWhere", model.toWhere),
               new SqlParameter("advancedAmount", model.advanceAmount),
               new SqlParameter("checkOutDate", model.checkOutDate),
               new SqlParameter("IdType", model.IdentityType),
               new SqlParameter("extrabed", model.extrabed),
               new SqlParameter("isStaff", model.isStaff),
               new SqlParameter("staffId", model.staffId),
               new SqlParameter("staffIdDocPath", model.staffIdDocPath),
               new SqlParameter("staffGrade", model.staffGrade),
               new SqlParameter("staffFacility", model.staffFacility) ,
               new SqlParameter("BookingFor", model.bookingFor) 
            };
            var sqlQuery = @"Proc_saveCustomerBookingDetailsByUPTour  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @phone, @id, @unitID, @roomID, @singleRoom, @doubleRoom, @checkinDate, @noOfGuests, @noOfRooms, @userIP, @advancedAmount, @checkOutDate, @IdType, @extrabed, @isStaff, @staffId, @staffIdDocPath, @staffGrade, @staffFacility,@bookingFor";
            var sDetails = this.Database.SqlQuery<CustomerRegistration>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        #region Get Special Packages Fare
        public LkoOnCycleBooking GetSpecialPackegeFare(Int32 packageID, Int32 applicantTypeId)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageID", Value =packageID },
                    new SqlParameter { ParameterName = "@applicantTypeId", Value =applicantTypeId }
                 };
            var sqlQuery = @"Proc_getSpecialPackegeFare @packageID,@applicantTypeId";
            var sList = this.Database.SqlQuery<LkoOnCycleBooking>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion

        #region Cycle Tour Booking By UPTour
        public LkoOnCycle saveCycleTourBookingByUPTour(LkoOnCycleBooking model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo ?? string.Empty),               
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),           
               new SqlParameter("IdType", model.IdentityType ?? 0),
               new SqlParameter("amount", model.totalAmount),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("routeTypeId", model.routeTypeId),
               new SqlParameter("applicantTypeId", model.applicantTypeId),
               new SqlParameter("bookingFor", model.bookingFor),
               new SqlParameter("enteredBY", SessionManager.UserID),
               new SqlParameter("bookingBy", model.bookingBy),
               new SqlParameter("receiptNo", model.receiptNo),
               new SqlParameter("nameTitle", model.nameTitle),
               new SqlParameter("arrivalTime", model.arrivalTime) 
            };
            var sqlQuery = @"Proc_saveCycleTourBookingByUPTour  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @id, @arrivalDate, @noOfGuests,@userIP, @IdType, @amount,@mode,@currency,@description,@routeTypeId,@applicantTypeId,@bookingFor, @enteredBY, @bookingBy, @receiptNo, @nameTitle, @arrivalTime";
            var sDetails = this.Database.SqlQuery<LkoOnCycle>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion


        #region HTW Booking By UPTour
        public LkoHTWBooking saveHTWBookingByUPTour(LkoHTWBooking model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo ?? string.Empty),
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),
               new SqlParameter("IdType", model.IdentityType ?? 0),
               new SqlParameter("amount", model.totalAmount),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("routeTypeId", model.routeTypeId),
               new SqlParameter("applicantTypeId", model.applicantTypeId),
               new SqlParameter("bookingFor", model.bookingFor),
               new SqlParameter("enteredBy", SessionManager.UserID),
               new SqlParameter("bookingBy", model.bookingBy),
               new SqlParameter("receiptNo", model.receiptNo),
               new SqlParameter("nameTitle", model.nameTitle),
               new SqlParameter("arrivalTime", model.arrivalTime) 
            };
            var sqlQuery = @"Proc_saveHTWBookingByUPTour  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @id, @arrivalDate, @noOfGuests,@userIP, @IdType, @amount,@mode, @currency, @description, @routeTypeId, @applicantTypeId, @bookingFor, @enteredBy, @bookingBy, @receiptNo, @nameTitle, @arrivalTime";
            var sDetails = this.Database.SqlQuery<LkoHTWBooking>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        #region HTW Booking By UPTour
        public LkoTongaRideBooking saveLkoTongaRideBookingByUPTour(LkoTongaRideBooking model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address),
               new SqlParameter("cityID", model.cityID),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo ?? string.Empty),               
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("arrivalDate", model.ArrivalDate), 
               new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP),
               new SqlParameter("IdType", model.IdentityType ?? 0),
               new SqlParameter("amount", model.totalAmount),
               new SqlParameter("mode", model.mode),
               new SqlParameter("currency", model.currency),
               new SqlParameter("description", model.description) ,
               new SqlParameter("routeTypeId", model.routeTypeId),
               new SqlParameter("applicantTypeId", model.applicantTypeId),
               new SqlParameter("bookingFor", model.bookingFor),
               new SqlParameter("enteredBY", SessionManager.UserID),
               new SqlParameter("bookingBy", model.bookingBy),
               new SqlParameter("receiptNo", model.receiptNo),
               new SqlParameter("nameTitle", model.nameTitle),
               new SqlParameter("arrivalTime", model.arrivalTime) 
            };
            var sqlQuery = @"Proc_saveTongaRideBookingByUPTour  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @id, @arrivalDate, @noOfGuests,@userIP, @IdType, @amount,@mode,@currency,@description,@routeTypeId,@applicantTypeId,@bookingFor, @enteredBY, @bookingBy, @receiptNo, @nameTitle, @arrivalTime";
            var sDetails = this.Database.SqlQuery<LkoTongaRideBooking>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }

        #region Get Tonga Ride Packages Fare
        public LkoOnCycleBooking GetTongaRideFare(Int32 packageID, Int32 applicantTypeId)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageID", Value =packageID },
                    new SqlParameter { ParameterName = "@applicantTypeId", Value =applicantTypeId }
                 };
            var sqlQuery = @"Proc_GetTongaRideFare @packageID,@applicantTypeId";
            var sList = this.Database.SqlQuery<LkoOnCycleBooking>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion
        #endregion

        #region get UPTour booking status
        public List<BookedDetail> GetARCBookingList(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                    new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID ?? 0},
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty },
                    new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID },
                    
                 };

            var sqlQuery = @"proc_getBookingListForARC @BookingDateFrom, @BookingDateTo, @unitId, @docketNo, @entryBy";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;


        }
        #endregion

        #region get UPT booking status
        public List<BookedDetail> GetUPTBookingStatus(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {              
                  new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                  new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },                   
                  new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty },
                  new SqlParameter { ParameterName = "@packageCategoryID", Value = SessionManager.PackageCategoryID }
              };
            var sqlQuery = @"proc_getBookingListForUPT @BookingDateFrom, @BookingDateTo, @docketNo, @packageCategoryID";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Insert MasterData in Masters................ by bramh
        #region Insert Unit Master
        public Messg InsertUnitDetails(MasterUnits m)
        {
            Common com = new Common();

            var count = this.Database.SqlQuery<Messg>("Proc_InsertUnitDetails @unitId,@UnitName  ,@Address ,@PinCode ,@Email ,@MobileNo,@DestinationID,@OverView ,@PhoneNo ,@UserID ,@tileImagePath ,@imageCaption ,@managerName ,@tinNo ,@tanNo ,@panNo , @serTaxNo ,@isOnline,@UnitAbbr,@IpAddres",
                    new SqlParameter[] { 
                            new SqlParameter("unitId",m.UnitId),
                            new SqlParameter("UnitName",m.UnitName),
                            new SqlParameter("Address",m.Address),
                            new SqlParameter("PinCode",m.PinCode),
                            new SqlParameter("Email",m.Email),
                            new SqlParameter("MobileNo",m.MobileNo),             
                            new SqlParameter("DestinationID",m.Destination),
                            new SqlParameter("OverView",m.OverView),
                            new SqlParameter("PhoneNo",m.PhoneNo),
                            //new SqlParameter("Tariff",m.Tariff),
                            new SqlParameter("userID", SessionManager.UserID.ToString()),
                            new SqlParameter("tileImagePath",m.titleImagePath),
                            new SqlParameter("imageCaption",m.imageCaption),
                            new SqlParameter("managerName",m.managerName),
                            new SqlParameter("tinNo",m.tinNo),
                            new SqlParameter("tanNo",m.tanNo),
                            new SqlParameter("panNo",m.panNo),
                            new SqlParameter("serTaxNo",m.serTaxNo),
                            new SqlParameter("isOnline",m.IsOnline),
                            new SqlParameter("UnitAbbr",m.UnitAbbr),
                            new SqlParameter("IpAddres",Common.GetIPAddress())}).FirstOrDefault();


            return count;
        }
        #endregion
        #region getAll Destination
        public IEnumerable<Destinations> GetAllDestinations()
        {
            var sqlQuery = @"proc_getMasterData 4";
            var list = this.Database.SqlQuery<Destinations>(sqlQuery).ToList();
            return list;
        }
        #endregion
        #region get all Units
        public IEnumerable<M_Unit> GetallUnits(int unitid)
        {
            var sqlQuery = "proc_getMasterData @masterID,@UnitId";
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@masterID", Value = 6 },
                    new SqlParameter { ParameterName = "@UnitId", Value = unitid }};

            var Unitlist = this.Database.SqlQuery<M_Unit>(sqlQuery, sqlParams).ToList();
            return Unitlist;

        }
        #endregion
        #region Get AllRoomType
        public IEnumerable<M_RoomType> getallRoomtype()
        {
            var sqlQuery = "Proc_getRoomDetails @Id";
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@Id", Value = 1 }};

            var RoomTypelist = this.Database.SqlQuery<M_RoomType>(sqlQuery, sqlParams).ToList();
            return RoomTypelist;
        }
        #endregion
        #region Get AllRoomDetailsByUnitId
        public IEnumerable<ViewRooms> getallRoomDetails(int unitid, int RoomId)
        {
            //id=2 for unit room details
            var sqlQuery = "Proc_getRoomDetails @Id,@RoomId,@unitId";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@Id", Value = 2 },
                     new SqlParameter { ParameterName = "@RoomId", Value = RoomId },
                     new SqlParameter { ParameterName = "@unitId", Value = unitid }};

            var RoomTypelist = this.Database.SqlQuery<ViewRooms>(sqlQuery, sqlParams).ToList();
            return RoomTypelist;
        }
        #endregion
        #region Get RoomDetailsForEdit by RoomId
        public IEnumerable<MasterRooms> GetRoomForEdit(int unitid, int RoomId)
        {
            //id=2 for unit room details
            var sqlQuery = "Proc_getRoomDetails @Id,@RoomId,@unitId";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@Id", Value = 6 },
                     new SqlParameter { ParameterName = "@RoomId", Value = RoomId },
                     new SqlParameter { ParameterName = "@unitId", Value = unitid }};

            var RoomTypelist = this.Database.SqlQuery<MasterRooms>(sqlQuery, sqlParams).ToList();
            return RoomTypelist;
        }
        #endregion
        #region InsertRooms
        public int insertRooms(MasterRooms Rooms)
        {
            Common com = new Common();
            int count = 0;
            try
            {
                var sql = @"Proc_InsertRooms  @RoomId,@UnitID,@RoomTypeID,@NumofRooms,@MaxCapacity,@UserID,@hasOccupancy,@IPAddress";
                var sqlParams = new SqlParameter[] { 
                         new SqlParameter { ParameterName = "@RoomId", Value = Rooms.RoomID },
                         new SqlParameter { ParameterName = "@UnitID", Value = Rooms.unitId },
                         new SqlParameter { ParameterName = "@RoomTypeID", Value = Rooms.RoomTypeId },
                         new SqlParameter { ParameterName = "@NumofRooms", Value = Rooms.NoofRoom },
                         new SqlParameter { ParameterName = "@MaxCapacity", Value = Rooms.MaxCapacity },
                         new SqlParameter { ParameterName = "@UserID", Value = SessionManager.UserID },
                         new SqlParameter { ParameterName = "@hasOccupancy", Value = Rooms.HasOccupancy},
                         new SqlParameter { ParameterName = "@IPAddress", Value = Common.GetIPAddress() }};
                count = this.Database.ExecuteSqlCommand(sql, sqlParams);
            }
            catch
            {
                count = 0;
            }
            return count;
        }
        #endregion
        #region InsertRoomTariff
        public Messg InsertTariff(RoomTariff Rt)
        {
            Common com = new Common();


            var sql = @"PROC_InsertRoomTariff @roomTariffID,@roomID ,@numofBeds, @seasonID ,@tariff ,@basetariff , @userID,@IPAddress";
            var sqlParm = new SqlParameter[] { new SqlParameter { ParameterName="@roomTariffID",Value=Rt.roomTariffID },
                                                        new SqlParameter { ParameterName="@roomID",Value=Rt.roomID },
                                                        new SqlParameter{ParameterName="@numofBeds",Value=Rt.numofBeds},
                                                        new SqlParameter{ParameterName="@seasonID",Value=Rt.seasonID},
                                                        new SqlParameter{ParameterName="@tariff",Value=Rt.tariff},
                                                        new SqlParameter{ParameterName="@basetariff",Value=Rt.basetariff},
                                                        new SqlParameter{ParameterName="@userID",Value=SessionManager.UserID},
                                                         new SqlParameter{ParameterName="@IPAddress",Value=Common.GetIPAddress()}};
            var count = this.Database.SqlQuery<Messg>(sql, sqlParm).FirstOrDefault();


            return count;
        }
        #endregion
        #region Get all RoomTariff
        public IEnumerable<ViewRoomTariff> GetRoomTariff(int RoomId)
        {

            var sqlQuery = "Proc_getRoomDetails @Id,@RoomId";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@Id", Value = 4 },
                     new SqlParameter { ParameterName = "@RoomId", Value = RoomId }};

            var RoomTypelist = this.Database.SqlQuery<ViewRoomTariff>(sqlQuery, sqlParams).ToList();
            return RoomTypelist;
        }
        #endregion
        #region GetSeason
        public IEnumerable<getSeason> GetSeason()
        {
            //@id 3 for Get all Session
            var sqlQuery = "Proc_getRoomDetails @Id";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@Id", Value = 3 }};

            var SeasonList = this.Database.SqlQuery<getSeason>(sqlQuery, sqlParams).ToList();
            return SeasonList;

        }
        #endregion
        #region GetRoomTariffForEdit
        public IEnumerable<RoomTariff> GetRoomTariffByroomTariffID(int roomTariffID)
        {

            var sqlQuery = "Proc_getRoomDetails @Id,@unitId,@RoomId,@roomTariffID";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@Id", Value = 5 },
                     new SqlParameter { ParameterName = "@unitId", Value = 0 },
                     new SqlParameter { ParameterName = "@RoomId", Value = 0},
                     new SqlParameter { ParameterName = "@roomTariffID", Value = roomTariffID }};

            var RoomTypelist = this.Database.SqlQuery<RoomTariff>(sqlQuery, sqlParams).ToList();
            return RoomTypelist;
        }
        #endregion

        #region DeleteRoom
        public int DeleteRooms(int Rt)
        {
            Common com = new Common();
            int count = 0;
            try
            {
                var sql = @"Proc_DeleteRoom @roomID,@IPAddress";
                var sqlParm = new SqlParameter[] {new SqlParameter { ParameterName="@roomID",Value=Rt },
                                                        new SqlParameter{ParameterName="@IPAddress",Value=Common.GetIPAddress()}};
                count = this.Database.ExecuteSqlCommand(sql, sqlParm);

            }
            catch
            {
                count = 0;
            }
            return count;
        }
        #endregion
        #region get room type for image insert
        public List<RoomType> GetUnitRoomType(Int64 unitId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitId } 
                 };
            var sqlQuery = @"Proc_GetUnitRoomType @unitID";
            var sDetails = this.Database.SqlQuery<RoomType>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion
        #region Insert Update Unit image
        public int InsertUpdateUnitImage(UnitImage UM)
        {
            Common com = new Common();
            int count = 0;
            try
            {
                int? rtId = UM.roomTypeID == null ? 0 : UM.roomTypeID;
                var sql = @"Proc_InsertUpdateUnitImage @UnitImagesID,@UnitId,@roomTypeID,@ImagePath,@ImageCaption,@IsRoom,@UserID,@IPAddress ";
                var sqlParm = new SqlParameter[] { new SqlParameter { ParameterName="@UnitImagesID",Value=UM.UnitImagesID },
                                                        new SqlParameter { ParameterName="@UnitId",Value=UM.UnitID },
                                                        new SqlParameter{ParameterName="@roomTypeID",Value=rtId},
                                                        new SqlParameter{ParameterName="@ImagePath",Value=UM.ImagePath},
                                                        new SqlParameter{ParameterName="@ImageCaption",Value=UM.ImageCaption},
                                                        //new SqlParameter{ParameterName="@IsPrimary",Value=UM.IsPrimary},
                                                        new SqlParameter{ParameterName="@IsRoom",Value=UM.IsRoom},
                                                        new SqlParameter{ParameterName="@UserID",Value=SessionManager.UserID},
                                                        new SqlParameter{ParameterName="@IPAddress",Value=Common.GetIPAddress()}};
                count = this.Database.ExecuteSqlCommand(sql, sqlParm);

            }
            catch
            {
                count = 0;
            }
            return count;
        }
        #endregion
        #region GetallUnitFor Edit
        public IEnumerable<MasterUnits> GetallUnit(int unitId)
        {
            var sqlQuery = "Proc_GetallUnitForEdit @unitId";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@unitId", Value = unitId }};
            var UniTList = this.Database.SqlQuery<MasterUnits>(sqlQuery, sqlParams).ToList();
            return UniTList;
        }
        #endregion
        #region Get UnitImageForDesplay
        public IEnumerable<UnitImageDetaisl> getUnitImage(int unitid, int RoomId)
        {
            var sqlQuery = "Proc_getRoomDetails @Id,@RoomId,@unitId";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@Id", Value = 7 },
                     new SqlParameter { ParameterName = "@RoomId", Value = RoomId },
                     new SqlParameter { ParameterName = "@unitId", Value = unitid }};

            var RoomImageist = this.Database.SqlQuery<UnitImageDetaisl>(sqlQuery, sqlParams).ToList();
            return RoomImageist;
        }
        #endregion
        #region Get UnitImageForEdit By UnitImageId
        public UnitImage getUnitImageForEditByUnitImageId(Int64 unitImageId)
        {
            var sqlQuery = @"Proc_GetUnitImageForEditByUnitImageId @UnitImageId";
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@UnitImageId", Value = unitImageId }};

            var RoomImageist = this.Database.SqlQuery<UnitImage>(sqlQuery, sqlParams).FirstOrDefault();
            return RoomImageist;
        }
        #endregion
        #endregion

        #region payment details for UPT
        public List<PaymentDetails> GetPaymentDetailsForUPT(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 unitId, string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PaymentDateFrom", Value = PaymentDateFrom },
                    new SqlParameter { ParameterName = "@PaymentDateTo", Value = PaymentDateTo }, 
                    new SqlParameter { ParameterName = "@unitId", Value = unitId } , 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo.Trim() } 
                 };
            var sqlQuery = @"Proc_getPaymentDetailsDateWiseForUPT @PaymentDateFrom, @PaymentDateTo, @unitId, @docketNo";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion
        #region advance payment details for UPT
        public List<PaymentDetails> GetAdvancePaymentDetailsForUPT(string docketNo, Int64 unitId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }, 
                    new SqlParameter { ParameterName = "@unitId", Value = unitId } 
                 };
            var sqlQuery = @"Proc_getAdvancePaymentDetailForUPT @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get booked room details
        public IList<RoomDetail> GetBookedRoomDetails(CheckinDetails model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
                new SqlParameter("unitId", model.unitID)            
            };
            var sqlQuery = @"Proc_getBookedRoomDetail  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<RoomDetail>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }
        #endregion


        #region Get Special PackageName
        public SpecialPackageName GetSpecialPackageName(string docketNo)
        {
            var sqlParams = new SqlParameter[] {
                new SqlParameter {ParameterName="docketNo", Value=docketNo}
            };
            var sqlQuery = @"Proc_getSpecialPackageName @docketNo";
            var pDetails = this.Database.SqlQuery<SpecialPackageName>(sqlQuery, sqlParams).FirstOrDefault();
            return pDetails;
        }
        #endregion


        #region Get Cancellation Confirmation Details For Packages and spcial packages and Unit Booking Cancellation
        public List<SpecialBookedDetail> DetailsOfBookingForCancellation(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"proc_DetailsOfBookingForCancellation @docketNo";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        /*------------Room Change---------------*/
        #region get all allotted rooms
        public List<RoomDetails> GetAllAllottedRooms(Int64 unitID)
        {
            var sqlParam = new SqlParameter[] {              
                new SqlParameter("unitID", unitID)                             
            };
            var sqlQuery = @"proc_getAllotedRoomByDate @unitID";
            var sList = this.Database.SqlQuery<RoomDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion

        #region get booking details to room change
        public RoomChange GetBookingDetailsToChangeRoom(RoomChange model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("bookedRoomID", model.bookedRoomID),
                new SqlParameter("unitId", model.unitID)                             
            };
            var sqlQuery = @"proc_getBookingDetailsForChange  @bookedRoomID, @unitId";
            var sDetails = this.Database.SqlQuery<RoomChange>(sqlQuery, sqlParam).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get unit room details to be changed
        public List<RoomChangeDetails> GetRoomDetailsForChange(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                 };
            var sqlQuery = @"proc_getRoomDetailsForChange @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<RoomChangeDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get all available Rooms
        public List<RoomAvailableDetails> GetAllAvailableRoom(Int64 unitId, Int64 bookedRoomId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@bookedRoomID", Value = bookedRoomId },
                    new SqlParameter { ParameterName = "@unitID", Value = unitId } 
                 };
            var sqlQuery = @"proc_getAllAvailableRooms @bookedRoomID, @unitID";
            var sList = this.Database.SqlQuery<RoomAvailableDetails>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region insert room change details
        public RoomChange InsertRoomChangeDetails(RoomChange model, string roomChangeXml)
        {
            try
            {
                var sqlParams = new SqlParameter[] {                     
                   new SqlParameter("requestID", model.requestID),
                  new SqlParameter("unitId", model.unitID),
                   new SqlParameter("singleBed", model.singleRoom ?? 0),
                   new SqlParameter("doubleBed", model.doubleRoom ?? 0),
                   new SqlParameter("extraBed", model.extraBed),
                   new SqlParameter("roomID", model.roomID),
                   new SqlParameter("currentRoomNoID", model.currentRoomNoID),
                   new SqlParameter("checkInDate", model.checkInDate),
                   //new SqlParameter("checkOutDate", model.checkOutDate),
                   new SqlParameter("oldCheckOutDate", model.oldCheckoutDate),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("enteredBy", SessionManager.UserID),
                   new SqlParameter("changeDetails", roomChangeXml)
                 };
                var sqlQuery = @"proc_ChangeRoom @requestID, @unitID, @singleBed, @doubleBed, @extraBed, @roomID, @currentRoomNoID, @checkInDate, @oldCheckOutDate,  @userIP, @enteredBy, @changeDetails";
                //var sqlQuery = @"proc_ChangeRoom @requestID, @unitID, @singleBed, @doubleBed, @extraBed, @roomID, @checkInDate, @checkOutDate, @oldCheckOutDate, @userIP, @enteredBy, @changeDetails";
                var sDetails = this.Database.SqlQuery<RoomChange>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            {
                return null;
            }
        }
        #endregion

        #region get change details
        public RoomChange GetChangeDetails(RoomChange model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("requestID", model.requestID),
                new SqlParameter("unitID", model.unitID)                             
            };
            var sqlQuery = @"proc_getChangeDetails  @requestID, @unitID";
            var sDetails = this.Database.SqlQuery<RoomChange>(sqlQuery, sqlParam).FirstOrDefault();
            return sDetails;
        }
        #endregion

        /*------------End Room Change---------------*/



        #region  Insert Update OUT of Order room-------------------------By Bramh
        public int InsertUpdateRoomOutOfOrder(RoomOutOfServiceDetail Rt, string outoforderList)
        {
            Common com = new Common();


            var sql = @"Proc_InsertUpdateOutOfServiceRooms @UnitID,@IPAddress, @userId,@outoforderList";
            var sqlParm = new SqlParameter[] {new SqlParameter { ParameterName="@UnitID",Value=Rt.unitID },
                                                        new SqlParameter{ParameterName="@IPAddress",Value=Common.GetIPAddress()},
                                                        new SqlParameter{ParameterName="@userID",Value=SessionManager.UserID},
                                                        new SqlParameter{ParameterName="@outoforderList",Value=outoforderList}};
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);

            return count;
        }
        #endregion

        #region  get out of Order room list -------------------------By Bramh
        public List<RoomOutOfServiceDetail> getRoomOutOfOrder(int UnityId)
        {
            var sql = @"Proc_getOutOfServiceRoomsListbyUnitId @UnitID";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@UnitID", Value = UnityId }};
            var count = this.Database.SqlQuery<RoomOutOfServiceDetail>(sql, sqlParm).ToList();
            return count;
        }
        #endregion

        #region  get out of order room details
        public RoomOutOfServiceDetail GetOutofServiceRoomDetails(int unitID, int roomID)
        {
            var sql = @"proc_getOutofServiceRoomDtls @unitID, @roomID";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@unitID", Value = unitID },
                new SqlParameter { ParameterName = "@roomID", Value = roomID }};
            var count = this.Database.SqlQuery<RoomOutOfServiceDetail>(sql, sqlParm).FirstOrDefault();
            return count;
        }
        #endregion

        #region  get unit wise and room type wise room no.
        public List<RoomNumber> GetRoomTypeWiseRoomNo(int unitID, int roomID)
        {
            var sql = @"proc_getUnitWiseRoomNo  @unitID, @roomID";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@unitID", Value = unitID },
                new SqlParameter { ParameterName = "@roomID", Value = roomID }};
            var count = this.Database.SqlQuery<RoomNumber>(sql, sqlParm).ToList();
            return count;
        }
        #endregion

        #region  Modify room status
        public int UpdateRoomStatus(RoomOutOfServiceDetail model, string roomNoXml)
        {
            int count = this.Database.ExecuteSqlCommand("proc_saveOutOfServiceRoomNo  @unitID, @roomTypeID, @roomNoXml",
                  new SqlParameter("unitID", model.unitID),
                  new SqlParameter("roomTypeID", model.RoomTypeId),
                  new SqlParameter("roomNoXml", roomNoXml));
            return count;
        }
        #endregion

        #region Get Customer List-----------------------------By Bramh
        public IEnumerable<GuestList> getGuestList(int UserId, string name, string mobileno, string Email, DateTime fromDate, DateTime todate)
        {
            var sql = @"Proc_GetGuestDetails @fromDate,@todate,@userID,@Name,@mobile,@email";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@fromDate", Value = fromDate },
                new SqlParameter { ParameterName = "@todate", Value = todate },
                new SqlParameter { ParameterName = "@userID", Value = UserId },
                new SqlParameter { ParameterName = "@Name", Value =name?? string.Empty },
                new SqlParameter { ParameterName = "@mobile", Value = mobileno ?? string.Empty},
                new SqlParameter { ParameterName = "@email", Value =Email?? string.Empty}};
            var count = this.Database.SqlQuery<GuestList>(sql, sqlParm).ToList();
            return count;
        }
        #endregion


        #region get unit and Package Booking Details for CRS
        public List<SpecialBookedDetail> GetUnitPackageBookingDetailsForCRS(string docketNo, int unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo},
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_getBookingDetailsForCRS @docketNo,@unitID";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get unit and Package  booked room Details for CRS
        public List<RoomOccupancyDetails> GetBookedRoomDetailsForCRS(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_GetBookedRoomDetailsForCRS @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<RoomOccupancyDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get list of booking details for checkin
        public IList<CheckinDetails> GetBookingDetailsList(CheckinDetails model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
                new SqlParameter("unitId", model.unitID),
                new SqlParameter("isChekIn", false)                
            };
            var sqlQuery = @"PROC_getCheckOutGuestContactInfo  @docketNo, @unitId, @isChekIn";
            var sDetails = this.Database.SqlQuery<CheckinDetails>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }
        #endregion

        #region check out list By Roop Kanwar On 18-10-2015
        public IList<CustomerRegistration> GetCustomerBookingList(string docketNo, Int64 unitId, bool isChekIn = true)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("unitId", unitId),
                new SqlParameter("isChekIn", isChekIn)
            };
            var sqlQuery = @"PROC_getCheckOutGuestContactInfo  @docketNo, @unitId, @isChekIn";
            var sDetails = this.Database.SqlQuery<CustomerRegistration>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }
        #endregion

        #region Added by Pooja

        #region Select PackageTour and PackageName
        public IEnumerable<PackageEntry> CheckPackageExist(PackageEntry model)
        {
            var Sql = @"Proc_CheckPackageExist @TourType,@PackageName";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("TourType",model.TourType),
                new SqlParameter("PackageName",model.PackageName)
            };
            var SDetails = this.Database.SqlQuery<PackageEntry>(Sql, SqlParam).ToList();
            return SDetails;
        }
        #endregion

        #region Insert Package

        public int InsertPackageAdmin(PackageEntry model)
        {
            var sql = new SqlParameter[]{
          new SqlParameter("packageId",model.PackageId),
                new SqlParameter("packageAbbr", model.packageAbbr),
                new SqlParameter("packageName", model.PackageName),
                new SqlParameter("subPackage", model.SubPackage),
                new SqlParameter("packageCategoryId", model.PackageCategoryID),
                new SqlParameter("overview", model.Overview),
               // new SqlParameter("briefDescription", model.BriefDescription),
                new SqlParameter("durationNight",model.DurationNight==null?"0":model.DurationNight),
                new SqlParameter("durationDays", model.DurationDays==null?"0":model.DurationDays),
                new SqlParameter("destinationCovered", model.DestinationCovered),
                new SqlParameter("meetingOrDepartureTime",model.Departuretime),
                new SqlParameter("meetingOrDepartureVenue", model.DepartureVenue),
                new SqlParameter("travelMode", model.TravalMode),
                //new SqlParameter("mealPlan", model.MealPlan),
                new SqlParameter("UserID", SessionManager.UserID),
                new SqlParameter("imagePath", model.ImagePathUrl),
                new SqlParameter("TourType", model.TourType),
                new SqlParameter("imagePathSmall", model.ImagePathSmallUrl),
                new SqlParameter("IPAddress",Common.GetIPAddress())
        };
            var sqlquery = @"Proc_InsertUpdatePackageDetail @packageId,@packageAbbr,@packageName,@subPackage,@packageCategoryId,@overview,@durationNight,@durationDays,@destinationCovered,@meetingOrDepartureTime,@meetingOrDepartureVenue,@travelMode,@userId,@imagePath,@TourType,@imagePathSmall,@IPAddress";
            int sDetails = this.Database.ExecuteSqlCommand(sqlquery, sql);
            return sDetails;


        }
        #endregion

        #region Get All Package
        public IEnumerable<PackageEntry> GetAllPackageAdmin()
        {
            var Sqlquery = @"Proc_GetPackageDetail";
            var SDetails = this.Database.SqlQuery<PackageEntry>(Sqlquery).ToList();
            return SDetails;
        }

        #endregion

        #region Get Package Detail By Id
        public PackageEntry GetPackageDetailById(int id)
        {
            var Sql = @"Proc_GetPackageDetail @packageId";
            var Sqlparam = new SqlParameter[]{
                new SqlParameter("PackageId",id)
            };
            var Sdetails = this.Database.SqlQuery<PackageEntry>(Sql, Sqlparam).FirstOrDefault();
            return Sdetails;
        }
        #endregion

        #region Get PackageTour By Id
        public IEnumerable<Tour> GetPackageAdminById(int id)
        {
            var Sql = @"Proc_GetPackageTour @PackageId";
            var Sqlparam = new SqlParameter[]{
                new SqlParameter("PackageId",id)
 };

            var SDetails = this.Database.SqlQuery<Tour>(Sql, Sqlparam).ToList();
            return SDetails;
        }
        #endregion

        #region DeletePackage

        public int DeletePackageAdmin(int packageId)
        {
            int Count = this.Database.ExecuteSqlCommand("Proc_DeletePackageDetail @PackageId,@UserId",
                new SqlParameter("PackageId", packageId),
                new SqlParameter("UserId", SessionManager.UserID)
                );
            return Count;

        }
        #endregion

        #region Insert Package Image
        public int InsertPackageImageAdmin(PackageImageEntry model)
        {
            var sql = new SqlParameter[]{
                new SqlParameter("packageImageId",model.packageImageId),
                new SqlParameter("packageID",model.packageID),
                new SqlParameter("imageCaption",model.imageCaption),
                new SqlParameter("imagePathUrl",model.imagePathUrl),
                new SqlParameter("imagePathSmallUrl",model.imagePathSmallUrl),
                new SqlParameter("userID",SessionManager.UserID),
                new SqlParameter("isPrimary",model.isPrimary),
                new SqlParameter("isLarge",model.isLarge),
                new SqlParameter("IPAddress",Common.GetIPAddress())
            };
            var sqlquery = @"Proc_InsertUpdatePackageIMage @packageImageId, @packageID,@imageCaption,@imagePathUrl,@imagePathSmallUrl,@userID,@isPrimary,@isLarge,@IPAddress";
            int sDetails = this.Database.ExecuteSqlCommand(sqlquery, sql);
            return sDetails;
        }
        #endregion

        #region Get Package Image
        public IEnumerable<PackageImageEntry> GetAllPackageImageAdmin(int packageId)
        {
            var Sql = @"proc_GetPackageImageDetail @packageId, @fl";
            var Sqlparam = new SqlParameter[]{
                new SqlParameter{ParameterName = "@packageId", Value = packageId},
                new SqlParameter{ParameterName = "@fl", Value = 1}};
            var SDetails = this.Database.SqlQuery<PackageImageEntry>(Sql, Sqlparam).ToList();
            return SDetails;
        }
        #endregion

        #region Delete Package Image Detail
        public int DeletePackageImageDetail(int packageImageId)
        {
            int Count = this.Database.ExecuteSqlCommand("Proc_DeletePackageImageDetail @packageImageId,@UserId",
                new SqlParameter("PackageimageId", packageImageId),
                new SqlParameter("UserId", SessionManager.UserID)
                );
            return Count;
        }
        #endregion

        #region Insert Update Package Intinery
        public int InsertUpdatePackageInTinery(PackageItinery model)
        {

            var SqlParam = new SqlParameter[]{
                new SqlParameter("ItineryID",model.ItineryID),
                new SqlParameter("Day",model.Day ?? 0),
                new SqlParameter("PackageID",model.PackageId),
                new SqlParameter("OriginID",model.OriginID??string.Empty),
                new SqlParameter("OriginName",model.OriginName??string.Empty),
                new SqlParameter("DestinationID",model.DestinationID??string.Empty),
                new SqlParameter("DestinationName",model.DestinationName??string.Empty),
                new SqlParameter("Dep_Arr",model.Dep_Arr??string.Empty),
                new SqlParameter("Dep_Arr_Time",model.Dep_Arr_Time??string.Empty),
                new SqlParameter("Particulars",model.Particulars),
                new SqlParameter("DesplayOrder",model.DesplayOrder),
                new SqlParameter("UserId",SessionManager.UserID),
                new SqlParameter("IPAddress",Common.GetIPAddress())
            };
            var Sql = @"proc_InsertUpdatePackageItinery  @ItineryID,@Day,@PackageID,@OriginID,@OriginName,@DestinationID,@DestinationName,@Dep_Arr,@Dep_Arr_Time,@Particulars,@DesplayOrder,@UserId,@IPAddress";
            int SDetails = this.Database.ExecuteSqlCommand(Sql, SqlParam);
            return SDetails;

        }
        #endregion



        #region City List
        public IEnumerable<City> GetCityList()
        {
            var Sql = @"proc_GetCity @StateId";
            var Sqlparam = new SqlParameter[]{
                new SqlParameter("StateId",34)
            };
            var SDetails = this.Database.SqlQuery<City>(Sql, Sqlparam);
            return SDetails;
        }
        #endregion

        #region Count Display of Package Itinery
        public PackageItinery CountPackageItinery(PackageItinery model)
        {
            var Sql = @"proc_CountPackageItineryDisplay @PackageId";
            var Sqlparam = new SqlParameter[]{
                new SqlParameter("PackageId",model.PackageId)
            };
            var SDetails = this.Database.SqlQuery<PackageItinery>(Sql, Sqlparam).FirstOrDefault();
            return SDetails;
        }
        #endregion

        #region Get Package Itinery Detail
        public IEnumerable<PackageItinery> GetPackageItinery(int PackageId)
        {

            var Sql = @"proc_GetPackageItineryDetail @ItineryID, @packageId";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("ItineryId",'0'),
                new SqlParameter("PackageId",PackageId)
            };
            var SDetails = this.Database.SqlQuery<PackageItinery>(Sql, SqlParam).ToList();
            return SDetails;
        }
        #endregion

        #region Delete Package Itinery
        public int DeletePackageItinery(int ItineryId)
        {
            int Count = this.Database.ExecuteSqlCommand("proc_DeletePackageItinery @itineryId",
                new SqlParameter("ItineryId", ItineryId)
                );
            return Count;
        }
        #endregion

        #region Get Package Itinery By Id
        public PackageItinery GetPackageItinerybyId(int ItineryId)
        {
            var Sql = @"proc_GetPackageItineryDetail @ItineryID";
            var Sqlparam = new SqlParameter[]{
                new SqlParameter("ItineryId",ItineryId)
            };
            var SDetails = this.Database.SqlQuery<PackageItinery>(Sql, Sqlparam).FirstOrDefault();
            return SDetails;
        }
        #endregion

        #region Check Package Itinerary Exist
        public IEnumerable<PackageItinery> checkPackageItineraryExist(PackageItinery model)
        {
            var Sql = @"Proc_CheckItineraryExist @PackageID,@DisplayOrder,@Particulars";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("PackageId",model.PackageId),
                new SqlParameter("DisplayOrder",model.DesplayOrder),
                //new SqlParameter("Dep_Arr_Time",model.Dep_Arr_Time),
                new SqlParameter("Particulars",model.Particulars)
            };
            var SDetails = this.Database.SqlQuery<PackageItinery>(Sql, SqlParam).ToList();
            return SDetails;

        }
        #endregion

        #region Check Display Order of Itinerary
        public IEnumerable<PackageItinery> checkDisplayOrder(PackageItinery model)
        {
            var Sql = @"Proc_CheckItineraryDisplay @PackageId,@DisplayOrder";
            var SqlParam = new SqlParameter[]{
                 new SqlParameter("PackageId",model.PackageId),
                new SqlParameter("DisplayOrder",model.DesplayOrder),
            };
            var SDetails = this.Database.SqlQuery<PackageItinery>(Sql, SqlParam).ToList();
            return SDetails;
        }
        #endregion

        #region Get Package Image By Id
        public PackageImageEntry GetPackageImagebyId(int PackageImageId)
        {
            var Sql = @"proc_GetPackageImageDetail @packageImageId";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("packageImageId",PackageImageId)
            };
            var SDeatils = this.Database.SqlQuery<PackageImageEntry>(Sql, SqlParam).FirstOrDefault();
            return SDeatils;
        }
        #endregion

        #region Add Package Amount
        public int InsertUpdatePackageAmount(PackageAmount model)
        {
            var SqlParam = new SqlParameter[]{
                new SqlParameter("packageAmountID",model.packageAmountID),
                new SqlParameter("packageID",model.packageID),
                new SqlParameter("seasonID",model.seasonID),
                new SqlParameter("isIndian",model.isIndian),
                //new SqlParameter("isAdult",model.isAdult),
                new SqlParameter("noOfPersons",model.noOfPersons),
                new SqlParameter("withoutMealAmount",model.withoutMealAmount),
                new SqlParameter("userID",SessionManager.UserID),
                new SqlParameter("IPAddress",Common.GetIPAddress())
            };
            var Sql = @"Proc_InsertUpdatePackageAmount @packageAmountID,@packageID,@seasonID,@isIndian,@noOfPersons,@withoutMealAmount,@UserID,@IPAddress";
            int SDetails = this.Database.ExecuteSqlCommand(Sql, SqlParam);
            return SDetails;
        }
        #endregion

        #region Get Season
        public IEnumerable<PackageSeason> GetSeasonBy()
        {
            var Sql = "Proc_GetSeason";
            var SDetails = this.Database.SqlQuery<PackageSeason>(Sql).ToList();
            return SDetails;
        }
        #endregion
        #endregion

        #region Get Package Amount By Package amountid and PackageId------------------------------By bramh
        public IEnumerable<PackageAmount> GetPackageAmount(int PackageId, int PackageAmountId)
        {
            var sql = "Proc_GetPackageAmount @packageAmountID,@PackageId";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("packageAmountID",PackageAmountId),
                new SqlParameter("PackageId",PackageId)};
            var PackageAmountList = this.Database.SqlQuery<PackageAmount>(sql, SqlParam).ToList();
            return PackageAmountList;
        }
        #endregion
        #region Delete Package Amount By Package amountid ------------------------------By bramh
        public int DeletePackageAmount(int PackageAmountId)
        {
            var sql = "Proc_deletePackageAmount @packageAmountID";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("packageAmountID",PackageAmountId)};
            var result = this.Database.ExecuteSqlCommand(sql, SqlParam);
            return result;
        }
        #endregion

        #region Insert into Audit Trail ------------------------------By bramh
        public int InsertAuditTrail(string PageUrl, string VisitStatus)
        {
            Common com = new Common();
            var sql = "Proc_InsertAuditTrail @IPaddress,@UserId,@pageUrl,@VisitStatus";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("IPaddress",Common.GetIPAddress()),
                new SqlParameter("UserId",SessionManager.UserID),
                new SqlParameter("pageUrl",PageUrl),
                new SqlParameter("VisitStatus",VisitStatus)};
            var result = this.Database.ExecuteSqlCommand(sql, SqlParam);
            return result;
        }
        #endregion

        #region Get Package Amount By Package amountid and PackageId------------------------------By bramh
        public Messg InsertUpdateSpecialPackage(SpecialPackages specPack)
        {
            Int64? PID = specPack.pid == null ? 0 : specPack.pid;
            Common com = new Common();
            var sql = "Proc_InsertUpdateSpecialPackages  @Pid ,@routeType ,@programStratTimeSummer ,@programEndTimeSummer ,@programStratTimeWinter ,@programEndTimeWinter ,@package_Abbr ,@IpAddress ,@userId";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("Pid",PID),
                new SqlParameter("routeType",specPack.routeType),
                new SqlParameter("programStratTimeSummer",specPack.programStratTimeSummer),
                new SqlParameter("programEndTimeSummer",(specPack.programEndTimeSummer!=null?specPack.programEndTimeSummer:"")),
                new SqlParameter("programStratTimeWinter",specPack.programStratTimeWinter),
                new SqlParameter("programEndTimeWinter",specPack.programEndTimeWinter!=null?specPack.programEndTimeWinter:""),
                new SqlParameter("package_Abbr",specPack.package_Abbr),
                new SqlParameter("IpAddress",Common.GetIPAddress()),
                new SqlParameter("userId",SessionManager.UserID)};
            var msg = this.Database.SqlQuery<Messg>(sql, SqlParam).FirstOrDefault();
            return msg;
        }
        #endregion

        #region Get Customer DetailsForEdit by DocketNo.-----------------------------------by Bramh
        public IEnumerable<Customer> GetCustomerDetailsForEdit(string DocketNo)
        {

            var sqlQuery = "GetCustomerDetails @docketNo";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@docketNo", Value = DocketNo }};

            var RoomTypelist = this.Database.SqlQuery<Customer>(sqlQuery, sqlParams).ToList();
            return RoomTypelist;
        }
        #endregion

        #region UpdateCustomerDetails ------------------------------By bramh
        public int UpdateCustomerDetails(Customer cust)
        {
            Common com = new Common();
            var sql = @"Proc_UpdateCustomerDetails @userID,@email,@name,@address,@cityID,@stateID,@otherCity,@otherState,@countryID,@pincode,@mobileNo,@IdentityType,@ID,@Dobdate,@DobMonth,@AnniversaryDate,@AnniversaryMonth,@IPAdress, @EntryBy";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("userID",cust.userID),
                new SqlParameter("email",cust.email ?? string.Empty),
                new SqlParameter("name",cust.name),
                new SqlParameter("address",cust.address ?? string.Empty),
                new SqlParameter("cityID",cust.cityID ?? (object)DBNull.Value),
                new SqlParameter("stateID",cust.stateID ?? (object)DBNull.Value),
                new SqlParameter("otherCity", cust.otherCity ?? string.Empty),            
               new SqlParameter("otherState", cust.otherState ?? string.Empty),
                new SqlParameter("countryID",cust.countryID?? (object)DBNull.Value),
                new SqlParameter("pincode",cust.pincode ?? string.Empty),
                new SqlParameter("mobileNo",cust.mobileNo ?? string.Empty),               
                new SqlParameter("IdentityType",cust.IdentityType ?? (object)DBNull.Value),
                new SqlParameter("ID",cust.ID ?? (object)DBNull.Value),
                new SqlParameter("Dobdate",cust.Dobdate ?? (object)DBNull.Value),
                new SqlParameter("DobMonth",cust.DobMonth ?? (object)DBNull.Value),
                new SqlParameter("AnniversaryDate",cust.AnniversaryDate ?? (object)DBNull.Value),
                new SqlParameter("AnniversaryMonth",cust.AnniversaryMonth ?? (object)DBNull.Value),
                new SqlParameter("IPAdress",Common.GetIPAddress()),
                new SqlParameter("EntryBy",SessionManager.UserID)};
            var result = this.Database.ExecuteSqlCommand(sql, SqlParam);
            return result;
        }
        #endregion



        #region get details  For Print-----------------------  By bramh

        public BookingDetails GetbookedCheckoutDetailsForPrint(string merchantRefNo)
        {
            var sqlParams = new SqlParameter[] {
                new SqlParameter {ParameterName="MerchantRefNo", Value=merchantRefNo},
               };
            var sqlQuery = @"proc_getBookedCheckoutDetailsforPrint @MerchantRefNo";
            var pDetails = this.Database.SqlQuery<BookingDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return pDetails;
        }
        #endregion


        #region get Advance Amount Category
        public List<AdvanceAmountCategory> GetAdvanceAmountCategory()
        {
            var sqlQuery = @"proc_getAdvanceAmountCategory";
            var sDetails = this.Database.SqlQuery<AdvanceAmountCategory>(sqlQuery).ToList();
            return sDetails;
        }
        #endregion


        /*------------------Vacancy Status ARC Login----------------------------*/

        #region get UPTour booking status
        public List<VacancyStatus> GetARCVacancyStatus(ARCVacancyStatus model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },                    
                    new SqlParameter { ParameterName = "@dtBooking", Value = model.dtBooking }
                 };
            var sqlQuery = @"proc_getUnitBookingStatus @unitID, @dtBooking";
            var sDetails = this.Database.SqlQuery<VacancyStatus>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion
        /*------------------End Vacancy Status ARC Login----------------------------*/

        #region Get SpecialPackageDetails.-----------------------------------by Bramh
        public IEnumerable<SpecialPackages> GetSpecialpackageDetails(Int64 SpId)
        {

            var sqlQuery = "Proc_GetSpecialPackagelist @SpId";
            var sqlParams = new SqlParameter[] { 
                     new SqlParameter { ParameterName = "@SpId", Value = SpId }};

            var RoomTypelist = this.Database.SqlQuery<SpecialPackages>(sqlQuery, sqlParams);
            return RoomTypelist;
        }
        #endregion

        #region payment details for ARC-----------------by Bramh
        public List<PaymentDetails> GetPaymentDetailsForARC(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 unitId, string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PaymentDateFrom", Value = PaymentDateFrom },
                    new SqlParameter { ParameterName = "@PaymentDateTo", Value = PaymentDateTo }, 
                    new SqlParameter { ParameterName = "@unitId", Value = unitId } , 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo.Trim() },                  
                    new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID } 
                 };
            var sqlQuery = @"Proc_getPaymentDetailsDateWiseForARC @PaymentDateFrom, @PaymentDateTo, @unitId, @docketNo, @entryBy";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #region get Unit List by packagecatgryid--------------bramh
        public IEnumerable<Unit> GetUnitListPackageWiseByPackagecatId()
        {
            var sqlQuery = @"proc_getUnitListPackageWise @PackageCatId";
            var sqlParams = new SqlParameter[] {                                     
                    new SqlParameter { ParameterName = "@PackageCatId", Value = SessionManager.PackageCategoryID}};// package catgryid entered through session
            var sList = this.Database.SqlQuery<Unit>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion



        /*-------------------ARC Booking Cancellation-----------------*/

        #region Get ARC booking for cancellation
        public IEnumerable<ARCCancellationRequest> GetARCBookingForCancellation(Int64? unitID, int bookingType, string docketNo, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {     
                    new SqlParameter { ParameterName = "@bookingType", Value = bookingType },            
                    new SqlParameter { ParameterName = "@unitID", Value = unitID ?? 0 },
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty},
                    new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID },
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate },
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate}
                 };
            var sqlQuery = @"PROC_getBookingForARC @bookingType, @docketNo, @unitID, @entryBy, @dateFrom, @dateTo";
            var sList = this.Database.SqlQuery<ARCCancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region cancel booking for arc
        public BookingCancellation CancelARCBooking(string docketNo)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("docketNo", docketNo)
                };

                var sqlQuery = @"Proc_cancelBookingForARC @docketNo";
                var sDetails = this.Database.SqlQuery<BookingCancellation>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        /*-------------------End ARC Booking Cancellation-----------------*/


        #region GetPackageCancilationDetails by out Anonymous User at UP Tours------------ by Bramh
        public List<cancellationRequest> GetPackageCancilationRequestatUPT(string docketNo, DateTime dateFrom, DateTime dateTo)
        {
            var sqlParams = new SqlParameter[] { 
                new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                new SqlParameter { ParameterName = "@dateFrom", Value = dateFrom.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: dateFrom },
                new SqlParameter { ParameterName = "@dateTo", Value = dateTo.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: dateTo },
                new SqlParameter { ParameterName = "@packagecategoryID", Value = SessionManager.PackageCategoryID }     
            };
            var sqlQuery = @"proc_getCancelRequestAtUPT @docketNo, @dateFrom, @dateTo, @packagecategoryID";
            var sDetails = this.Database.SqlQuery<cancellationRequest>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion



        /*-------------------UP Tour Booking Cancellation-----------------*/

        #region Get UP Tour booking for cancellation
        public IEnumerable<cancellationRequest> GetUPTBookingForCancellation(string docketNo)
        {
            var sqlParams = new SqlParameter[] {             
                   
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty}
                 };
            var sqlQuery = @"PROC_getBookingForUPT @docketNo";
            var sList = this.Database.SqlQuery<cancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region cancel booking for UP Tours
        public BookingCancellation CancelUPTBooking(string docketNo, string ipAddress)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("docketNo", docketNo),
                   new SqlParameter("ipAddress", docketNo),
                   new SqlParameter("userID", SessionManager.UserID)
                };

                var sqlQuery = @"Proc_cancelBookingForUPT @docketNo, @ipAddress, @userID";
                var sDetails = this.Database.SqlQuery<BookingCancellation>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        /*-------------------End UP Tours Booking Cancellation-----------------*/

        #region get name title
        public List<NameTitle> GetTitle()
        {
            var sqlQuery = @"proc_getTitle";
            var sDetails = this.Database.SqlQuery<NameTitle>(sqlQuery).ToList();
            return sDetails;
        }
        #endregion


        #region get Cancilled Booking Details At UPT---------------by bramh
        public List<SpecialBookedDetail> GetCancilledBookingDetailsatUPT(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_getCancilledBookingDetailsAtUPT @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Package payment details for UPT------------------BY BRAMH
        public List<PaymentDetails> GetPackagePaymentDetailsForUPT(DateTime PaymentDateFrom, DateTime PaymentDateTo, Int64 PackageId, string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PaymentDateFrom", Value = PaymentDateFrom },
                    new SqlParameter { ParameterName = "@PaymentDateTo", Value = PaymentDateTo }, 
                    new SqlParameter { ParameterName = "@PackgeId", Value = PackageId } , 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo.Trim() } 
                 };
            var sqlQuery = @"Proc_getPackagePaymentDetailsForUPT @PaymentDateFrom, @PaymentDateTo, @PackgeId, @docketNo";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #region get UPTour Special booking Payment
        public List<PaymentDetails> GetUPTourSpecialBookingPayment(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {              
                  new SqlParameter { ParameterName = "@PaymentDateFrom", Value = model.dtBookingDateFrom },
                  new SqlParameter { ParameterName = "@PaymentDateTo", Value = model.dtBookingDateTo },   
                  new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty },
                  new SqlParameter { ParameterName = "@BookingFor", Value = model.type }
                 };
            var sqlQuery = @"Proc_getPaymentDetailsDateWiseForSpcl @PaymentDateFrom, @PaymentDateTo, @docketNo, @BookingFor";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        /*-------------------CRS Booking Cancellation-----------------*/

        #region Get UP Tour booking for cancellation
        public IEnumerable<CRSCancellationRequest> GetCRSBookingForCancellation(string docketNo, int bookingType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@bookingType", Value = bookingType },
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty},
                    new SqlParameter { ParameterName = "@unitId", Value = unitID ?? 0 },
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate },
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate}
                 };
            var sqlQuery = @"PROC_getBookingForCRS @bookingType, @docketNo, @unitId, @dateFrom, @dateTo";
            var sList = this.Database.SqlQuery<CRSCancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region cancel booking for crs
        public CRSBookingCancellation CancelCRSBooking(string docketNo, string ipAddress)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                    new SqlParameter("docketNo", docketNo),
                    new SqlParameter("ipAddress", ipAddress),
                    new SqlParameter("userID", SessionManager.UserID)
                };

                var sqlQuery = @"Proc_cancelBookingForCRS @docketNo, @ipAddress, @userID";
                var sDetails = this.Database.SqlQuery<CRSBookingCancellation>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        /*-------------------End CRS Booking Cancellation-----------------*/


        /*-------------------CRS Cancellation List-----------------*/
        #region Get UP Tour cancelled booking
        public IEnumerable<CRSCancellationRequest> GetCRSCancelledBooking(string docketNo, int bookingType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@bookingType", Value = bookingType },
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty},
                    new SqlParameter { ParameterName = "@unitId", Value = unitID ?? 0 },
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate}
                 };
            var sqlQuery = @"PROC_getCancelledBookingForCRS @bookingType, @docketNo, @unitId, @dateFrom, @dateTo";
            var sList = this.Database.SqlQuery<CRSCancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion


        /*-------------------End CRS Cancellation List-----------------*/



        #region get unit Current Guest status-----------------------by bramh
        public List<BookedDetail> GetGuestStatus(UnitTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID}
                 };
            var sqlQuery = @"proc_getGuestCurrentStatus @unitId";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #region get total amount
        public decimal GetTotalUnitRoomPrice(DateTime fromDate, DateTime toDate, RoomDetail obj)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("fromDate", fromDate),
                new SqlParameter("toDate", toDate),
                new SqlParameter("singleBedRoom", obj.singleRoom),  
                new SqlParameter("doubleBedRoom", obj.doubleRoom),
                new SqlParameter("roomID", obj.roomType),
                new SqlParameter("extraBedRoom", obj.extrabed)              
            };
            var sqlQuery = @"SELECT dbo.getTotalUnitRoomPrice (@fromDate, @toDate, @singleBedRoom, @doubleBedRoom, @roomID, @extraBedRoom)";
            var sDetails = this.Database.SqlQuery<decimal>(sqlQuery, sqlParam).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get room tariff details
        public List<RoomTariffDetails> GetRoomTariffDetails(int roomID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@roomID", Value = roomID },
                    new SqlParameter { ParameterName = "@checkInDate", Value = fromDate },
                    new SqlParameter { ParameterName = "@checkOutDate", Value = toDate }
                 };
            var sqlQuery = @"proc_getRoomTariffDetails @roomID, @checkInDate, @checkOutDate";
            var sDetails = this.Database.SqlQuery<RoomTariffDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #region get set Special Package Program By Id -----------------------by bramh
        public List<SpecialPackageProgram> GetSetspecialPackageProgram(Int64 PID)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@pid", Value = PID}
                 };
            var sqlQuery = @"ProcGetSpecialPackageProgram @pid";
            var sDetails = this.Database.SqlQuery<SpecialPackageProgram>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Insert into Special Package Program ------------------------------By bramh
        public int AddSpecialPackageProgram(SpecialPackageProgram spp)
        {
            Common com = new Common();
            var sql = "Proc_AddSpecialPackageProgram @ppID,@pid,@programName,@stratEnd,@DisplayOrder, @EntryBy,@IPAddress";
            var SqlParam = new SqlParameter[]{
                new SqlParameter { ParameterName="@ppID",Value=0 },
                new SqlParameter { ParameterName="@pid",Value=spp.pid },
                new SqlParameter { ParameterName="@programName",Value=spp.programName },
                new SqlParameter { ParameterName="@stratEnd",Value=spp.stratEnd==null?"0":spp.stratEnd},
                new SqlParameter { ParameterName="@DisplayOrder",Value=spp.DisplayOrder },
                new SqlParameter { ParameterName="@EntryBy",Value=SessionManager.UserID },
                new SqlParameter { ParameterName="@IPAddress",Value=Common.GetIPAddress() }
                };
            var result = this.Database.ExecuteSqlCommand(sql, SqlParam);
            return result;
        }
        #endregion


        #region get unit Current Guest status
        public VacancyStatusDetail GetVacancyStatusDetail(VacancyStatusDetail model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@UnitId", Value = model.unitID},                  
                    new SqlParameter { ParameterName = "@RoomTypeId", Value = model.RoomTypeId},                  
                    new SqlParameter { ParameterName = "@BookingDate", Value = model.BookingDate}
                 };
            var sqlQuery = @"Proc_getDetailVacancyStatus @UnitId, @RoomTypeId, @BookingDate";
            var sDetails = this.Database.SqlQuery<VacancyStatusDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion



        /*----------------Prepone-postpone booking----------------------*/

        #region get booking details for prepone-postpone
        public PreponePostpone GetBookingDetailsForPrePostpone(string docketNo, Int64 unitID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("unitId", unitID),
                new SqlParameter("isChekIn", false)                
            };
            var sqlQuery = @"PROC_getCheckOutGuestContactInfo  @docketNo, @unitId, @isChekIn";
            var sDetails = this.Database.SqlQuery<PreponePostpone>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();
        }
        #endregion

        #region save prepone-postpone booking
        public int SavePreponePostponeBooking(PreponePostpone model)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("Proc_modifyBookingSchedule @docketNo, @unitID, @checkinDate, @checkOutDate, @userIP, @entryBy",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("unitID", model.unitID),
                   new SqlParameter("checkinDate", model.newCheckInDate),
                   new SqlParameter("checkOutDate", model.newCheckOutDate),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("entryBy", SessionManager.UserID));
                return count;
            }
            catch
            {
                return 0;
            }
        }
        #endregion
        public IEnumerable<CheckOutBillDetails> GetCheckOutBillDetailsUPT(String docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }                     
                };
            var sqlQuery = @"PROC_PrintBillDetailsUPT @docketNo";
            var sList = this.Database.SqlQuery<CheckOutBillDetails>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #region   Update Special Program -------------------------By Bramh
        public int UpdateSpecialProgram(string xml, Int64? pid)
        {
            Common com = new Common();
            var sql = @"Proc_UpdateSpecialPackageProgram  @Programlist,@IPAddress,@pid,@userId";
            var sqlParm = new SqlParameter[] {new SqlParameter { ParameterName="@Programlist",Value=xml },
                                                        new SqlParameter{ParameterName="@IPAddress",Value=Common.GetIPAddress()},
                                                        new SqlParameter{ParameterName="@pid",Value=pid},
                                                        new SqlParameter{ParameterName="@userID",Value=SessionManager.UserID}
                                                       };
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);

            return count;
        }
        #endregion

        #region get Rooms On Check In
        public List<RoomDetails> GetRoomsOnCheckInByDate(Int64 unitId, DateTime fromDate, DateTime toDate, int roomId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@fromDate", Value = fromDate },
                    new SqlParameter { ParameterName = "@toDate", Value = toDate },
                    new SqlParameter { ParameterName = "@unitID", Value = unitId },
                    new SqlParameter { ParameterName = "@roomId", Value = roomId }  
                 };
            var sqlQuery = @"Proc_getAvailableRoomsOnCheckInByDate @fromDate, @toDate, @unitId, @roomId";
            var sDetails = this.Database.SqlQuery<RoomDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Get Checked in room Guest details
        public IEnumerable<GuesRoomtDetails> GetCheckinRoomDetails(String docketNo, DateTime bookingdate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@DocketNo", Value = docketNo },
                     new SqlParameter { ParameterName = "@BookingDate", Value = bookingdate },
                    new SqlParameter("UnitID", SessionManager.UnitID)
                };
            var sqlQuery = @"Proc_getCheckedInGuestDetails @docketNo,@BookingDate,@UnitID";
            var sList = this.Database.SqlQuery<GuesRoomtDetails>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region   Insert Update Guest room Details -------------------------By Bramh
        public int InsertUpdateGuestRoomDetails(string xml, GuesRoomtDetails rl)
        {
            Common com = new Common();
            var sql = @"Proc_InsertUpdateGuestDetails  @GuestList,@EntryBy,@IPAddress,@CheckinDate";
            var sqlParm = new SqlParameter[] {new SqlParameter { ParameterName="@GuestList",Value=xml },
                                                        new SqlParameter{ParameterName="@EntryBy",Value=SessionManager.UserID},
                                                        new SqlParameter{ParameterName="@IPAddress",Value=Common.GetIPAddress()},
                                                        new SqlParameter{ParameterName="@CheckinDate",Value=rl.ChekInDate}
                                                       };
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);

            return count;
        }
        #endregion


        #region View SpecialFair
        public List<SpecialPackageFare> GetSetspecialPackageFare(Int64 PID)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@pid", Value = PID}
                 };
            var sqlQuery = @"Proc_GetSpecialFareDetails @pid";
            var sDetails = this.Database.SqlQuery<SpecialPackageFare>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get special discount
        public List<SpecialDiscount> GetSpecialDiscount()
        {
            var sqlQuery = @"Proc_getSpecialDiscountType";
            var sDetails = this.Database.SqlQuery<SpecialDiscount>(sqlQuery).ToList();
            return sDetails;
        }
        #endregion


        #region   Insert Update SpecialPackage Fare -------------------------By Bramh
        public Messg InsertUpdateSpecialPackFare(SpecialPackageFare spf)
        {
            Common com = new Common();
            var sql = @"Proc_InsertUpdateSpecialPackageFare  @fid,@pid,@fare,@applicantTypeName,@applicantTypeId,@noofPerson,@IPAddress,@EntryBy";
            var sqlParm = new SqlParameter[] {new SqlParameter { ParameterName="@fid",Value=spf.fid },
                                                        new SqlParameter { ParameterName="@pid",Value=spf.pid },
                                                        new SqlParameter{ParameterName="@fare",Value=spf.fare},
                                                        new SqlParameter{ParameterName="@applicantTypeName",Value=spf.applicantTypeName},
                                                        new SqlParameter{ParameterName="@applicantTypeId",Value=spf.applicantTypeId},
                                                        new SqlParameter{ParameterName="@noofPerson",Value=spf.noofPerson},
                                                        new SqlParameter{ParameterName="@IPAddress",Value=Common.GetIPAddress()},
                                                        new SqlParameter{ParameterName="@EntryBy",Value=SessionManager.UserID},                                                  
                                                       
                                                       };
            var sDetails = this.Database.SqlQuery<Messg>(sql, sqlParm).FirstOrDefault();
            return sDetails;
        }
        #endregion



        #region Get unit wise booking revenue
        public List<BookedDetail> GetBookingRevenue(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                    new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID ?? 0 },
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty }
                 };

            var sqlQuery = @"proc_getBookingListForUPTour @BookingDateFrom, @BookingDateTo, @unitId, @docketNo";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;


        }
        #endregion


        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> getMobileNosEmailIdForSMSEmailCRS(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_GetListToSendSMSAndMail @docketNo";
            var sList = this.Database.SqlQuery<OfficerContactDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion


        #region Package Destination----------------------
        #region insert Pakage Mapping

        public int InsertPackageMap(PackageMappingModel model)
        {

            int userID = Convert.ToInt32(SessionManager.UserID);
            string ipAddress = "";

            ipAddress = Common.GetIPAddress();

            bool hasStay = false;
            if (model.hasStayYes)
            {
                hasStay = true;
            }
            else
            {
                hasStay = false;
            }

            int isInsert = 0;

            if (model.packageTypeID != 0 && model.fromCityID != 0 && model.toCityID != 0 && model.unitID != 0 && model.RoomTypeID != 0)
            {

                isInsert = this.Database.ExecuteSqlCommand("RD_insertPackageMappingDetails  @packageID, @fromCityID, @toCityID, @hasStay, @unitID, @roomTypeID,@userID,@IPAddress,@getSequenceNo",
                   new SqlParameter("@packageID", model.packageTypeID),
                   new SqlParameter("@fromCityID", model.fromCityID),
                   new SqlParameter("@toCityID", model.toCityID),
                   new SqlParameter("@hasStay", hasStay),
                   new SqlParameter("@unitID", model.unitID),
                   new SqlParameter("@roomTypeID", model.RoomTypeID),
                   new SqlParameter("@userID", userID),
                   new SqlParameter("@IPAddress", ipAddress),
                   new SqlParameter("@getSequenceNo", model.sequenceNo));

            }
            else
            {
                isInsert = 0;
            }
            return isInsert;
        }

        #endregion


        #region Delete Pakage destination record

        public int DeletePackageMap(PackageMappingModel model, int packageDestionationID)
        {
            int userID = Convert.ToInt32(SessionManager.UserID);
            string ipAddress = "";
            ipAddress = Common.GetIPAddress();

            int isDelete = 0;

            if (packageDestionationID != 0)
            {
                isDelete = this.Database.ExecuteSqlCommand("RD_deletePackageMappingDetails  @packageDestinationID,@userID,@IPAddress",
                new SqlParameter("@packageDestinationID", packageDestionationID),
                new SqlParameter("@userID", userID),
                new SqlParameter("@IPAddress", ipAddress));
            }
            else
            {
                isDelete = 0;
            }
            return isDelete;
        }

        #endregion


        #region get PackageType

        public IEnumerable<SelectPackageType> GetPackageType()
        {
            var sqlQuery = @"RD_getPackageDetails @packageCategoryID=1";
            var sList = this.Database.SqlQuery<SelectPackageType>(sqlQuery, new SqlParameter("@packageCategoryID", 1)).ToList();
            return sList;
        }

        #endregion

        #region get From City (Destination) Details

        public IEnumerable<SelectFromCity> GetFromCity()
        {
            int userID = Convert.ToInt32(SessionManager.UserID);

            var sqlQuery = @"RD_getDestination @UserID";
            var sList = this.Database.SqlQuery<SelectFromCity>(sqlQuery, new SqlParameter("@UserID", userID)).ToList();
            return sList;
        }

        #endregion

        #region get To City (Destination) Details

        public IEnumerable<SelectToCity> GetToCity()
        {
            //var sqlQuery = @"RD_getToDestination @previousDestinationID";
            //var sList = this.Database.SqlQuery<SelectToCity>(sqlQuery, new SqlParameter("@previousDestinationID", prevoiusDestinationID)).ToList();
            //return sList;
            int userID = Convert.ToInt32(SessionManager.UserID);

            var sqlQuery = @"RD_getDestination @UserID";
            var sList = this.Database.SqlQuery<SelectToCity>(sqlQuery, new SqlParameter("@UserID", userID)).ToList();
            return sList;
        }

        #endregion

        #region get Unit Details

        public IEnumerable<SelectUnit> GetUnitDetail(int destinationID)
        {
            var sqlQuery = @"RD_getUnitDetails @destinationID";
            var sList = this.Database.SqlQuery<SelectUnit>(sqlQuery, new SqlParameter("@destinationID", destinationID)).ToList();
            return sList;
        }

        #endregion

        #region get Room Type Details

        public IEnumerable<SelectRoomType> GetRoomTypeDetail(int unitID)
        {
            var sqlQuery = @"RD_getRoomTypeDetails @unitId";
            var sList = this.Database.SqlQuery<SelectRoomType>(sqlQuery, new SqlParameter("@unitId", unitID)).ToList();
            return sList;
        }

        #endregion

        #region get Mapped Package Details

        public List<FillPackgeMappedDetails> GetMappedPackageDetails(int packageID)
        {
            int userID = Convert.ToInt32(SessionManager.UserID);

            var sqlQuery = @"RD_getMappedPackageDetails @userID,@packageID";
            var sList = this.Database.SqlQuery<FillPackgeMappedDetails>(sqlQuery, new SqlParameter("@userID", userID), new SqlParameter("@packageID", packageID)).ToList();
            return sList;
        }

        #endregion
        #endregion


        #region get unit booking details for ARC
        public SpecialBookedDetail GetUnitBookingDetailsForARC(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo},                  
                    new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID }
                 };
            var sqlQuery = @"proc_getUnitBookingDetailsForARC @docketNo, @entryBy";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region Get ARC cancelled booking
        public IEnumerable<ARCCancellationRequest> GetARCCancelledBooking(string docketNo, int bookingType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {       
                    new SqlParameter { ParameterName = "@bookingType", Value = bookingType },
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty},
                    new SqlParameter { ParameterName = "@unitId", Value = unitID ?? 0 },
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},                  
                    new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID }
                 };
            var sqlQuery = @"PROC_getCancelledBookingForARC @bookingType, @docketNo, @unitId, @dateFrom, @dateTo, @entryBy";
            var sList = this.Database.SqlQuery<ARCCancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get unit transaction details For Mail
        public UnitTransactionDetail GetTransactionDetailsUser(string docketNo)
        {
            var sqlParams = new SqlParameter[] {                    
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };
            var sqlQuery = @"proc_getTransactionDetailsOfUser @docketNo";
            var sDetails = this.Database.SqlQuery<UnitTransactionDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region Get Unit cancelled booking
        public IEnumerable<CRSCancellationRequest> GetCancelledBooking(string docketNo, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty},
                    new SqlParameter { ParameterName = "@unitId", Value = unitID ?? 0 },
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate}
                 };
            var sqlQuery = @"PROC_getCancelledBooking @docketNo, @unitId, @dateFrom, @dateTo";
            var sList = this.Database.SqlQuery<CRSCancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get contact list for up tours
        public IEnumerable<OfficerContactDetails> GetContactForUPTours(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_getContactListForUPTours @docketNo";
            var sList = this.Database.SqlQuery<OfficerContactDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion


        /*---------------UPT Booking List---------------*/

        #region get UPT booking Details
        public SpecialBookedDetail GetUPTBookingDetails(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };
            var sqlQuery = @"proc_getUPTBookingDetails @docketNo";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        /*---------------UPT Package Booking--------------*/
        #region get city tours category list
        public IEnumerable<PackageCategory> GetPackageTourCategoryForUPT()
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@categoryID", Value = SessionManager.PackageCategoryID }
                 };

            var sqlQuery = @"PROC_GetPackageCategoryForUPT @categoryID";
            var sList = this.Database.SqlQuery<PackageCategory>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion
        /*---------------End UPT Package Booking--------------*/

        /*---------------UPT One day Tours && AC Bus Booking--------------*/
        #region get city tours category list
        public IEnumerable<CityTourCategory> GetCityTourCategoryList(int packageCategoryID, string tourType)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageCategoryID", Value = packageCategoryID },
                    new SqlParameter { ParameterName = "@tourType", Value = tourType }
                 };
            var sqlQuery = @"proc_getCityTourCategoryForUPT @packageCategoryID, @tourType";
            var sList = this.Database.SqlQuery<CityTourCategory>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get AC Bus package list
        public IEnumerable<PackageTour> GetACBusTourForUPT(int packageCategoryID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@packageCategoryID", Value =packageCategoryID }
                 };
            var sqlQuery = @"proc_GetACBusPackagesForUPT @packageCategoryID";
            var sList = this.Database.SqlQuery<PackageTour>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        /*---------------End UPT One day Tours Booking--------------*/


        #region Activate package by bramh
        public Messg ActivateDeactivatePackage(int PID)
        {


            var count = this.Database.SqlQuery<Messg>("Proc_SetPackageOnline @PackageId,@IPAddress,@UserId",
                    new SqlParameter[] { 
                           
                            new SqlParameter("PackageId",PID),                           
                            new SqlParameter("IPAddress",Common.GetIPAddress()),
                            new SqlParameter("UserId",SessionManager.UserID)}).FirstOrDefault();


            return count;
        }
        #endregion


        #region Get All Package
        public IEnumerable<PackageEntry> GetAllDeactivatedPackagedb()
        {
            var Sqlquery = @"Proc_GetDeactivatedPackageList";
            var SDetails = this.Database.SqlQuery<PackageEntry>(Sqlquery).ToList();
            return SDetails;
        }

        #endregion


        /*---------------UPT Payment Details--------------*/
        #region payment details
        public List<PaymentDetails> GetPaymentDetailsForUPT(UPTPaymentDetails model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@paymentDateFrom", Value = model.dtBookingDateFrom },
                    new SqlParameter { ParameterName = "@paymentDateTo", Value = model.dtBookingDateTo }, 
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo } , 
                    new SqlParameter { ParameterName = "@bookingFor", Value = model.type },
                    new SqlParameter { ParameterName = "@packageCategoryID", Value = SessionManager.PackageCategoryID } 
                 };
            var sqlQuery = @"Proc_getPaymentListForUPT @paymentDateFrom, @paymentDateTo, @docketNo, @bookingFor, @packageCategoryID";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region advance payment details
        public List<PaymentDetails> GetAdvancePaymentForUPT(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };
            var sqlQuery = @"Proc_getAdvancePaymentForUPT @docketNo";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        /*---------------End UPT Payment Details--------------*/



        /*-------------------UPT Booking Cancellation-----------------*/

        #region Get UP Tour booking for cancellation
        public IEnumerable<CRSCancellationRequest> GetUPToursBookingForCancellation(string docketNo, int bookingType, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@bookingType", Value = bookingType },
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty},
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate },
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@packageCategoryID", Value = SessionManager.PackageCategoryID }
                 };
            var sqlQuery = @"PROC_getBookingForUPTOURS @bookingType, @docketNo, @dateFrom, @dateTo, @packageCategoryID";
            var sList = this.Database.SqlQuery<CRSCancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        /*-------------------End UP Tours Booking Cancellation-----------------*/

        #region get ARC Special booking status
        public List<BookedDetail> GetSpecialBookingForARC(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {              
                  new SqlParameter { ParameterName = "@BookingDateFrom", Value = model.dtBookingDateFrom },
                  new SqlParameter { ParameterName = "@BookingDateTo", Value = model.dtBookingDateTo },   
                  new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty },
                  new SqlParameter { ParameterName = "@BookingFor", Value = model.type },
                  new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID }
                 };
            var sqlQuery = @"proc_getSpecialBookingForARC @BookingDateFrom,@BookingDateTo,@docketNo, @BookingFor, @entryBy";
            var sDetails = this.Database.SqlQuery<BookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        /*-------------------End UPT Booking Cancellation-----------------*/


        #region verify All user for PasswordChange
        public UserLogin verifyuserforPasswordChange(string email, string roleId)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = email },
                    new SqlParameter { ParameterName = "@roleID", Value = roleId } 
                };
            var sqlQuery = @"proc_VerifyUserLogin_OtherThanCustomer @email, @roleID";
            var sDetail = this.Database.SqlQuery<UserLogin>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetail;
        }
        #endregion

        #region change Password
        public int ChangeAllUserPassword(UserChangePassword model)
        {
            int count = 0;
            try
            {
                count = this.Database.ExecuteSqlCommand("proc_changeUserPassword  @email, @password, @userID, @entryby, @IpAddress,@roleId",
                   new SqlParameter("email", model.email),
                   new SqlParameter("password", model.newPassword),
                   new SqlParameter("userID", model.userId),
                   new SqlParameter("entryby", SessionManager.UserID),
                   new SqlParameter("IpAddress", Common.GetIPAddress()),
                   new SqlParameter("roleId", model.roleID));
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return count;
        }
        #endregion

        /*---------------CRS Online booking report---------------------*/

        #region Get CRS Online booking list
        public IEnumerable<CRSOnlineBookingReport> GetCRSOnlineBookingList(CRSOnlineBookingReport model)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@bookingDateFrom", Value = model.dtBookingDateFrom },
                    new SqlParameter { ParameterName = "@bookingDateTo", Value = model.dtBookingDateTo},
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty }
                 };
            var sqlQuery = @"proc_getOnlineBookingList @bookingDateFrom, @bookingDateTo, @docketNo";
            var sList = this.Database.SqlQuery<CRSOnlineBookingReport>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get CRS Online cancellation list
        public IEnumerable<CRSOnlineCancellationReport> GetCRSOnlineCancellationList(CRSOnlineCancellationReport model)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@dateFrom", Value = model.dateFrom },
                    new SqlParameter { ParameterName = "@dateTo", Value = model.dateTo},
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty }
                 };
            var sqlQuery = @"proc_getOnlineCancellationList @dateFrom, @dateTo, @docketNo";
            var sList = this.Database.SqlQuery<CRSOnlineCancellationReport>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get Online Failed Booking list
        public IEnumerable<CRSOnlineCancellationReport> GetOnlineFailedBookingList(CRSOnlineCancellationReport model)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@bookingDateFrom", Value = model.dateFrom },
                    new SqlParameter { ParameterName = "@bookingDateTo", Value = model.dateTo},
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty }
                 };
            var sqlQuery = @"proc_getOnlineFailedBookingList @bookingDateFrom, @bookingDateTo, @docketNo";
            var sList = this.Database.SqlQuery<CRSOnlineCancellationReport>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get CRS online payment details
        public CRSOnlinePaymentDetails GetCRSOnlinePaymentDetails(CRSOnlinePaymentDetails model)
        {
            var sqlParams = new SqlParameter[] {                    
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo }
                 };
            var sqlQuery = @"proc_getOnlinePaymentDetails @docketNo";
            var sList = this.Database.SqlQuery<CRSOnlinePaymentDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion

        #region Get CRS/HQ Online bookings guest wise
        public IEnumerable<OnlineBookingRevenueDetails> GetOnlineUnitBookingGuestWiseList(OnlineUnitGuestWiseBookingReport model)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@month", Value = model.month },
                    new SqlParameter { ParameterName = "@year", Value = model.year},
                    new SqlParameter { ParameterName = "@rptType", Value = 1 },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID ?? 0}
                 };
            var sqlQuery = @"proc_getGuestWiseOnlineRevenueList @month, @year, @rptType, @unitID";
            var sList = this.Database.SqlQuery<OnlineBookingRevenueDetails>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get CRS/HQ Online package bookings guest wise
        public IEnumerable<OnlineBookingRevenueDetails> GetOnlinePackBookingGuestWiseList(OnlinePackGuestWiseBookingReport model)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@month", Value = model.month },
                    new SqlParameter { ParameterName = "@year", Value = model.year},
                    new SqlParameter { ParameterName = "@rptType", Value = 2 }                   
                 };
            var sqlQuery = @"proc_getGuestWiseOnlineRevenueList @month, @year, @rptType";
            var sList = this.Database.SqlQuery<OnlineBookingRevenueDetails>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get CRS/HQ taxi/ bus bookings guest wise
        public IEnumerable<OnlineBookingRevenueDetails> GetTaxiBusBookingGuestWiseList(OnlinePackGuestWiseBookingReport model)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@month", Value = model.month },
                    new SqlParameter { ParameterName = "@year", Value = model.year},
                    new SqlParameter { ParameterName = "@rptType", Value = 3 }                   
                 };
            var sqlQuery = @"proc_getGuestWiseOnlineRevenueList @month, @year, @rptType";
            var sList = this.Database.SqlQuery<OnlineBookingRevenueDetails>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion
        /*---------------End CRS Online booking report-------------------*/

        #region get ARC Special booking Details
        public List<SpecialBookedDetail> GetSpecialDetailsForARC(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo },
                    new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID }
                 };
            var sqlQuery = @"proc_getSpecialDetailsForARC @docketNo, @entryBy";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region get ARC Special booking Payment
        public List<PaymentDetails> GetPaymentDetailsDateWiseForSpclForARC(UPTourTotalBooking model)
        {
            var sqlParams = new SqlParameter[] {              
                  new SqlParameter { ParameterName = "@PaymentDateFrom", Value = model.dtBookingDateFrom },
                  new SqlParameter { ParameterName = "@PaymentDateTo", Value = model.dtBookingDateTo },   
                  new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty },
                  new SqlParameter { ParameterName = "@BookingFor", Value = model.type },
                  new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID }
                 };
            var sqlQuery = @"Proc_getPaymentDetailsDateWiseForSpclForARC @PaymentDateFrom, @PaymentDateTo, @docketNo, @BookingFor, @entryBy";
            var sDetails = this.Database.SqlQuery<PaymentDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Get UP Tour cancelled booking
        public IEnumerable<CRSCancellationRequest> GetCancelledBookingUPT(string docketNo, int bookingType, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {            
                    new SqlParameter { ParameterName = "@bookingType", Value = bookingType },
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo ?? string.Empty}, 
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@packageCategoryID", Value = SessionManager.PackageCategoryID }
                 };
            var sqlQuery = @"PROC_getCancelledBookingForUPT @bookingType, @docketNo, @dateFrom, @dateTo, @packageCategoryID";
            var sList = this.Database.SqlQuery<CRSCancellationRequest>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        /*------------HQ Report-----------------*/

        #region Get HQ unit booking status
        public List<HQBookingStatusReport> GetUnitWiseBookingStatus(HQBookingStatusReport model)
        {
            var sqlParams = new SqlParameter[] {                                     
                    new SqlParameter { ParameterName = "@date", Value = model.bookingDate }
                 };
            var sqlQuery = @"proc_getUnitWiseBookingCount @date";
            var sDetails = this.Database.SqlQuery<HQBookingStatusReport>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Get HQ room type wise status
        public IEnumerable<HQRoomStatusReport> GetRoomTypeWiseBookingStatus(HQBookingStatusReport model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },                    
                    new SqlParameter { ParameterName = "@dtBooking", Value = model.bookingDate }
                 };
            var sqlQuery = @"proc_getRoomTypeWiseBookingCount @unitID, @dtBooking";
            var sDetails = this.Database.SqlQuery<HQRoomStatusReport>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion
        /*------------End HQ Report-----------------*/

        /*-------------------Booking Revenue-----------------*/
        #region Get Booking Revenue
        public IEnumerable<BookingRevenue> GetBookingRevenueReport(int ReportType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@unitId", Value = unitID ?? 0 },            
                    new SqlParameter { ParameterName = "@ReportType", Value = ReportType }
                 };
            var sqlQuery = @"Proc_getRevenueReport @dateFrom, @dateTo, @unitId, @ReportType";
            var sList = this.Database.SqlQuery<BookingRevenue>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get Booking Revenue For PDF Generation
        public IEnumerable<BookingRevenueForPDF> GetBookingRevenueReportForPDF(int ReportType, Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@unitId", Value = unitID ?? 0 },            
                    new SqlParameter { ParameterName = "@ReportType", Value = ReportType }
                 };
            var sqlQuery = @"Proc_getRevenueReport @dateFrom, @dateTo, @unitId, @ReportType";
            var sList = this.Database.SqlQuery<BookingRevenueForPDF>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get Package Revenue
        public IEnumerable<BookingRevenue> GetPackageRevenueReport(int ReportType, int? PackageCategoryID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@packageID", Value = PackageCategoryID ?? 0 },            
                    new SqlParameter { ParameterName = "@ReportType", Value = ReportType }
                 };
            var sqlQuery = @"Proc_getPackageRevenueReport @dateFrom, @dateTo, @packageID, @ReportType";
            var sList = this.Database.SqlQuery<BookingRevenue>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Get Special Package Revenue
        public IEnumerable<BookingRevenue> GetSpecialPackageRevenueReport(int ReportType, string packageType, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@packageType", Value = packageType ?? string.Empty },            
                    new SqlParameter { ParameterName = "@ReportType", Value = ReportType }
                 };
            var sqlQuery = @"Proc_getSpecialPackageRevenueReport @dateFrom, @dateTo, @packageType, @ReportType";
            var sList = this.Database.SqlQuery<BookingRevenue>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion
        /*-------------------End Booking Revenue-----------------*/

        #region get package list
        public IEnumerable<PackageDetails> GetPackagesList()
        {
            var sqlQuery = @"PROC_getPackagesList";
            var sList = this.Database.SqlQuery<PackageDetails>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region Get Mobile Nos for SMS
        public CustomerDetails GetCustomerDetails(string MerchantRefNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=MerchantRefNo}
            };
            var sqlQuery = @"proc_getCustomerDetails @docketNo";
            var sList = this.Database.SqlQuery<CustomerDetails>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        #region get unit blocked room list on date
        public List<BlockReleaseDetail> GetUnitBlockedRoomsOnDate(UnitBlockRelease model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },
                    new SqlParameter { ParameterName = "@blockedDate", Value = model.dtBlocking }
                 };
            var sqlQuery = @"proc_getUnitBlockDetailsOnDate @unitID, @blockedDate";
            var sDetails = this.Database.SqlQuery<BlockReleaseDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region insert package tour query
        public int InsertBlockDetailOnDate(Int64 unitID, string blockList, DateTime blockedDate)
        {
            int count = this.Database.ExecuteSqlCommand("proc_insertUnitBlockDetailsOnDate @unitID, @userID, @blockList, @blockedDate",
               new SqlParameter("unitID", unitID),
               new SqlParameter("userID", SessionManager.UserID),
               new SqlParameter("blockList", blockList),
               new SqlParameter("blockedDate", blockedDate));
            return count;
        }
        #endregion


        #region save checkout detail
        public int SaveCheckOutDetails(CustomerRegistration model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
               new SqlParameter("checkOutDate", model.checkOutDateActual),
               new SqlParameter("checkOutTime",model.checkOutTime),
               new SqlParameter("unitId", model.unitID),
               new SqlParameter("userID", SessionManager.UserID),
               new SqlParameter("checkOutByIp", model.userIP)
            };
            var sqlQuery = @"Proc_saveCheckOutDetail @docketNo, @checkOutDate, @checkOutTime, @unitId, @userID, @checkOutByIp";
            int sDetails = this.Database.ExecuteSqlCommand(sqlQuery, sqlParam);
            return sDetails;

        }
        #endregion

        #region Get contact details to send customer query mail
        public IEnumerable<OfficerContactDetails> GetContactForCustomerQuery(int packageID)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@packageID",Value=packageID}
            };
            var sqlQuery = @"proc_getContactDetailsForQuery @packageID";
            var sList = this.Database.SqlQuery<OfficerContactDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion

        /*---------------Anonymous user profile updation---------------*/

        #region Get Anonymous Customer Details
        public OnlineCustomer GetAnonymousCustomerDetails(string email)
        {
            var sqlQuery = "GetAnonymousCustomerDetails @email";
            var sqlParams = new SqlParameter[] { 
                        new SqlParameter { ParameterName = "@email", Value = email }};

            var details = this.Database.SqlQuery<OnlineCustomer>(sqlQuery, sqlParams).FirstOrDefault();
            return details;
        }
        #endregion

        #region Update Anonymous Customer Profile
        public int UpdateAnonymousCustomerProfile(OnlineCustomer model)
        {
            var sql = @"proc_updateAnonymousCustomerProfile @userID, @email, @name, @address, @cityID, @stateID, @otherCity, @otherState, @countryID, @pincode, @mobileNo, @IPAdress, @EntryBy";
            var SqlParam = new SqlParameter[]{
                new SqlParameter("userID",SessionManager.UserID),
                new SqlParameter("email",SessionManager.Username),
                new SqlParameter("name",model.name),
                new SqlParameter("address",model.address ?? string.Empty),
                new SqlParameter("cityID",model.cityID ?? (object)DBNull.Value),
                new SqlParameter("stateID",model.stateID ?? (object)DBNull.Value),
                new SqlParameter("otherCity", model.otherCity ?? string.Empty),            
                new SqlParameter("otherState", model.otherState ?? string.Empty),
                new SqlParameter("countryID",model.countryID),
                new SqlParameter("pincode",model.pincode ?? string.Empty),
                new SqlParameter("mobileNo",model.mobileNo ?? string.Empty),               
                new SqlParameter("IPAdress",model.ipAddress),
                new SqlParameter("EntryBy",SessionManager.UserID)
              };
            var result = this.Database.ExecuteSqlCommand(sql, SqlParam);
            return result;
        }
        #endregion

        /*---------------End anonymous user profile updation---------------*/
        #region insert Customer Booking
        public CustomerRegistration InsertCustomerBookingBulk(CustomerRegistration model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("roleID", model.roleID),
               new SqlParameter("name", model.name),
               new SqlParameter("address", model.address ?? string.Empty),
               new SqlParameter("cityID", model.cityID ?? 0),
               new SqlParameter("otherCity", model.otherCity ?? string.Empty),
               new SqlParameter("stateID", model.stateID ?? 0),
               new SqlParameter("otherState", model.otherState ?? string.Empty),
               new SqlParameter("countryID", model.countryID ?? 0),
               new SqlParameter("pincode", model.pincode ?? string.Empty),
               new SqlParameter("email", model.email ?? string.Empty),
               new SqlParameter("mobileNo", model.mobileNo ?? string.Empty),
               new SqlParameter("phone", model.phone ?? string.Empty),
               new SqlParameter("id", model.ID ?? string.Empty),
               new SqlParameter("unitID", model.unitID),
               //new SqlParameter("checkinDate", model.checkInDate), 
               //new SqlParameter("noOfGuests", model.noOfGuests),
               new SqlParameter("userIP", model.userIP), 
               new SqlParameter("advancedAmount", model.advanceAmount?? (object)DBNull.Value),
               //new SqlParameter("checkOutDate", model.checkOutDate),
               new SqlParameter("IdType", model.IdentityType),
               new SqlParameter("isStaff", model.isStaff),
               new SqlParameter("staffId", model.staffId),
               new SqlParameter("staffIdDocPath", model.staffIdDocPath),
               new SqlParameter("staffGrade", model.staffGrade),
               new SqlParameter("staffFacility", model.staffFacility),
               new SqlParameter("strXML", model.bookingXML),
               new SqlParameter("BookingFor", model.bookingFor),
               new SqlParameter("receiptNo", model.receiptNo?? string.Empty),
               new SqlParameter("applicantType", model.applicantType?? 1),
               new SqlParameter("nameTitle", model.nameTitle?? 1),
               new SqlParameter("EntryBy", SessionManager.UserID),
               new SqlParameter("bookingBy", model.bookingBy ),
            };
            var sqlQuery = @"Proc_saveCustomerBookingDetailsBulk  @roleID, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @email, @mobileNo, @phone, @id, @unitID, @userIP, @advancedAmount, @IdType, @isStaff, @staffId, @staffIdDocPath, @staffGrade, @staffFacility, @strXML, @BookingFor, @receiptNo, @applicantType, @nameTitle, @EntryBy, @bookingBy";
            var sDetails = this.Database.SqlQuery<CustomerRegistration>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();

        }
        #endregion

        #region Get Booking Revenue
        public IEnumerable<BookingCountReport> GetUnitWiseCount(Int64? unitID, string countFor, DateTime fromdate)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitId", Value = unitID ?? 0 },            
                    new SqlParameter { ParameterName = "@countFor", Value = countFor?? string.Empty },
                    new SqlParameter { ParameterName = "@fromDate", Value = fromdate}
                 };
            var sqlQuery = @"Proc_getUnitWiseCount @unitId, @countFor, @fromDate";
            var sList = this.Database.SqlQuery<BookingCountReport>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion


        #region PackageContact
        public int InsertUpdatePackageContact(PackageContact model)
        {

            var sqlParam = new SqlParameter[] {
               new SqlParameter("@ContactID", model.ContactID),
               new SqlParameter("@PackageID", model.PackageID),
               new SqlParameter("@contactName", model.contactName),
               new SqlParameter("@address", model.address),
                new SqlParameter("@phoneNo", model.phoneNo ),
               new SqlParameter("@mobileNo", model.mobileNo),              
               new SqlParameter("@nodalOfficer", model.nodalOfficer ),
               new SqlParameter("@email", model.email ),
               //new SqlParameter("@unitID",a),
               new SqlParameter("@userId",SessionManager.UserID)

            };
            var sqlQuery = @"Proc_InsertUpdatePackageContact @contactID,@PackageID,@contactName,@address,@phoneNo,@mobileNo,@nodalOfficer,@email,@userId";
            var sDetails = this.Database.ExecuteSqlCommand(sqlQuery, sqlParam);
            return sDetails;

        }
        #endregion

        #region get package contacts
        public IEnumerable<PackageContact> GetPackageContact(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackagesContactsByPackageID @packageID";
            var sList = this.Database.SqlQuery<PackageContact>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region Package Inclusion Exclusion
        public int InsertUpdatePackageINCEXC(IncExc model)
        {

            var sqlParam = new SqlParameter[] {
               new SqlParameter("@PackageID", model.PackageID),
               new SqlParameter("@Ins_Type", model.Ins_Type),
               new SqlParameter("@Ins_Description", model.Ins_Description),
               new SqlParameter("@userId",SessionManager.UserID)

            };
            var sqlQuery = @"proc_InsertUpdatePackageInclusionExclusion @PackageID,@Ins_Type,@Ins_Description,@UserID";
            var sDetails = this.Database.ExecuteSqlCommand(sqlQuery, sqlParam);
            return sDetails;

        }
        #endregion

        #region get Inclusion Exclusion
        public IEnumerable<IncExc> GetPackageIncExc(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@PackageID", Value = packageID }
                 };

            var sqlQuery = @"proc_getPackageInclusionExclusion @PackageID";
            var sList = this.Database.SqlQuery<IncExc>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion


        #region get counter package booking details
        public PackageTransactionDetail GetPackageBookingDetails(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };

            var sqlQuery = @"proc_getCounterPackBookingDtls @docketNo";
            var sList = this.Database.SqlQuery<PackageTransactionDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }
        #endregion


        #region get CRS booking Details
        public SpecialBookedDetail GetCRSBookingDetails(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                 };
            var sqlQuery = @"proc_getCRSBookingDetails @docketNo";
            var sDetails = this.Database.SqlQuery<SpecialBookedDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion


        #region Get Special PackageName for mail
        public SpecialPackageName GetCounterSpecialPackageName(string docketNo)
        {
            var sqlParams = new SqlParameter[] {
                new SqlParameter {ParameterName="docketNo", Value=docketNo}
            };
            var sqlQuery = @"proc_getCounterSpecialPackName @docketNo";
            var pDetails = this.Database.SqlQuery<SpecialPackageName>(sqlQuery, sqlParams).FirstOrDefault();
            return pDetails;
        }
        #endregion

        /*--------------------Taxi/ Bus  Enquiry-------------------*/
        #region get source cities
        public IEnumerable<BusTaxiSourceCity> GetFromCityList()
        {
            var sqlQuery = @"proc_getFromCityForBusTaxi";
            var sList = this.Database.SqlQuery<BusTaxiSourceCity>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region insert bus taxi enquiry
        public BusTaxiEnquiry InsertBusTaxiEnquiry(BusTaxiEnquiry model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@enquiryType", Value = model.enquiryType },
                    new SqlParameter { ParameterName = "@fromCity", Value = model.fromCity },
                    new SqlParameter { ParameterName = "@toCity", Value = model.toCity },
                    new SqlParameter { ParameterName = "@dateOfJourney", Value = model.dateOfJourney  },
                    new SqlParameter { ParameterName = "@dateOfReturn", Value = model.dateOfReturn ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@pickupDate", Value = model.pickupDate },
                    new SqlParameter { ParameterName = "@pickupTime", Value = model.pickupTime },
                    new SqlParameter { ParameterName = "@pickupAddress", Value = model.pickupAddress },
                    new SqlParameter { ParameterName = "@firstName", Value = model.firstName },
                    new SqlParameter { ParameterName = "@lastName", Value = model.lastName },
                    new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
                    new SqlParameter { ParameterName = "@phoneNo", Value = model.phoneNo ?? string.Empty },
                    new SqlParameter { ParameterName = "@email", Value = model.email ?? string.Empty },
                    new SqlParameter { ParameterName = "@message", Value = model.message },
                    new SqlParameter { ParameterName = "@ipAddress", Value = model.ipAddress }                   
            };
            var sqlQuery = @"proc_saveBusTaxiEnquiry @enquiryType, @fromCity, @toCity, @dateOfJourney, @dateOfReturn, @pickupDate, @pickupTime, @pickupAddress, @firstName, @lastName, @mobileNo, @phoneNo, @email, @message, @ipAddress";

            var sDetails = this.Database.SqlQuery<BusTaxiEnquiry>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #region Get contact details to send customer query mail
        public BusTaxiEnquiry GetTaxiBusEnquiry(string enquiryNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@enquiryNo",Value=enquiryNo}
            };
            var sqlQuery = @"proc_getBusTaxiEnquiryDetail @enquiryNo";
            var sList = this.Database.SqlQuery<BusTaxiEnquiry>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        #region get bus taxi enquiry list
        public IEnumerable<BusTaxiEnquiry> GetBusTaxiEnquiryList(BusTaxiEnquiryReport model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@uptourId",Value =model.uptourId ?? 0},
                new SqlParameter{ParameterName="@dateFrom",Value = model.dateFrom},
                new SqlParameter{ParameterName="@dateTo",Value = model.dateTo},
                new SqlParameter{ParameterName="@enquiryNo",Value = model.enquiryNo ?? string.Empty}
            };
            var sqlQuery = @"proc_getBusTaxiEnquiryList @uptourId, @dateFrom, @dateTo, @enquiryNo";
            var sList = this.Database.SqlQuery<BusTaxiEnquiry>(sqlQuery, sqlParam).ToList();
            return sList;
        }

        #endregion

        #region Get contact details to send customer query mail
        public BusTaxiEnquiryReply GetTaxiBusEnquiryDetails(string enquiryNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@enquiryNo",Value=enquiryNo}
            };
            var sqlQuery = @"proc_getBusTaxiEnquiryDetail @enquiryNo";
            var sList = this.Database.SqlQuery<BusTaxiEnquiryReply>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        #region Get booking details to send mail
        public BusTaxiBookingDetails GetTaxiBusBookingDetails(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_getBusTaxiBookingDetail @docketNo";
            var sList = this.Database.SqlQuery<BusTaxiBookingDetails>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        #region save bus taxi enquiry reply
        public int SaveBusTaxiEnquiryReply(BusTaxiEnquiryReply model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@enquiryNo", Value = model.enquiryNo },
                    new SqlParameter { ParameterName = "@amount", Value = model.amount },
                    new SqlParameter { ParameterName = "@remark", Value = model.remark },
                    new SqlParameter { ParameterName = "@documentPath", Value = model.documentPath  },
                    new SqlParameter { ParameterName = "@replyBy", Value = model.userID },
                    new SqlParameter { ParameterName = "@replyIP", Value = model.userIP }                          
            };
            var sqlQuery = @"proc_saveBusTaxiEnquiryReply @enquiryNo, @amount, @remark, @documentPath, @replyBy, @replyIP";

            var result = this.Database.ExecuteSqlCommand(sqlQuery, sqlParams);
            return result;

        }
        #endregion

        #region insert booking request for taxi/bus
        public PostPaymentData InsertBusTaxiBookRequest(BusTaxiEnquiryReply model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                    new SqlParameter("userID", SessionManager.UserID),
                    new SqlParameter("enquiryNo", model.enquiryNo),                    
                   //new SqlParameter("fromCity", model.fromCity),
                   //new SqlParameter("toCity", model.toCity),
                   //new SqlParameter("dateOfJourney", model.dateOfJourney),
                   //new SqlParameter("dateOfReturn", model.dateOfReturn ?? (object)DBNull.Value),
                   //new SqlParameter("pickupDate", model.pickupDate),
                   //new SqlParameter("pickupTime", model.pickupTime),
                   //new SqlParameter("pickupAddress", model.pickupAddress),
                   //new SqlParameter("amount", model.amount),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("description", model.description)   ,
                   new SqlParameter("bookingType", model.enquiryType.ToUpper())
                
                };

                var sqlQuery = @"proc_InsertBusTaxiBookRequest_EnqueryBased @userID, @enquiryNo, @userIP, @mode, @currency, @description, @bookingType";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #region insert bus taxi booking by UPT
        public BusTaxiBooking InsertBusTaxiBooking(BusTaxiBooking model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@bookingType", Value = model.enquiryType },
                    new SqlParameter { ParameterName = "@fromCity", Value = model.fromCity },
                    new SqlParameter { ParameterName = "@toCity", Value = model.toCity },
                    new SqlParameter { ParameterName = "@dateOfJourney", Value = model.dateOfJourney  },
                    new SqlParameter { ParameterName = "@dateOfReturn", Value = model.dateOfReturn ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@pickupDate", Value = model.pickupDate },
                    new SqlParameter { ParameterName = "@pickupTime", Value = model.pickupTime },
                    new SqlParameter { ParameterName = "@pickupAddress", Value = model.pickupAddress },
                    new SqlParameter { ParameterName = "@firstName", Value = model.firstName },
                    new SqlParameter { ParameterName = "@lastName", Value = model.lastName },
                    new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
                    new SqlParameter { ParameterName = "@phoneNo", Value = model.phoneNo ?? string.Empty },
                    new SqlParameter { ParameterName = "@email", Value = model.email ?? string.Empty },
                    //new SqlParameter { ParameterName = "@message", Value = model.message },
                    new SqlParameter { ParameterName = "@ipAddress", Value = model.ipAddress },
                    new SqlParameter { ParameterName = "@amount", Value = model.amount },
                    new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID },
                    new SqlParameter { ParameterName = "@bookingBy", Value = model.bookingBy },
                    new SqlParameter { ParameterName = "@documentPath", Value = model.documentPath?? string.Empty }
            };
            var sqlQuery = @"proc_saveBusTaxiBooking @bookingType, @fromCity, @toCity, @dateOfJourney, @dateOfReturn, @pickupDate, @pickupTime, @pickupAddress, @firstName, @lastName, @mobileNo, @phoneNo, @email, @ipAddress, @amount, @entryBy, @bookingBy, @documentPath";

            var sDetails = this.Database.SqlQuery<BusTaxiBooking>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #region Get booking details to send mail for counter booking
        public BusTaxiBookingDetails GetTaxiBusCounterBookingDetails(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_getBusTaxiCounterBookingDetail @docketNo";
            var sList = this.Database.SqlQuery<BusTaxiBookingDetails>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        /*--------------------End Taxi/ Bus  Enquiry-------------------*/

        /*--------------------Lawn/ Banquet  Enquiry-------------------*/

        #region get destination wise unit list
        public List<Unit> GetUnitsByDestination(Int64 destinationID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@destinationID", Value = destinationID }                   
                };

            var sqlQuery = @"proc_getUnitListByDestination @destinationID";
            var sList = this.Database.SqlQuery<Unit>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get all functions
        public IEnumerable<Function> GetFunctionList()
        {
            var sqlQuery = @"proc_getFunctions";
            var sList = this.Database.SqlQuery<Function>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region insert lawn enquiry
        public LawnEnquiry InsertLawnEnquiry(LawnEnquiry model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@enquiryType", Value = model.enquiryType },
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },
                    new SqlParameter { ParameterName = "@bookingDate", Value = model.lawnBookingDate },
                    new SqlParameter { ParameterName = "@functionType", Value = model.functionID  },
                    new SqlParameter { ParameterName = "@noOfGuests", Value = model.noOfLawnGuest },                    
                    new SqlParameter { ParameterName = "@firstName", Value = model.firstName },
                    new SqlParameter { ParameterName = "@lastName", Value = model.lastName },
                    new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
                    new SqlParameter { ParameterName = "@phoneNo", Value = model.phoneNo ?? string.Empty },
                    new SqlParameter { ParameterName = "@email", Value = model.email ?? string.Empty },
                    new SqlParameter { ParameterName = "@message", Value = model.message },
                    new SqlParameter { ParameterName = "@ipAddress", Value = model.ipAddress }                   
            };
            var sqlQuery = @"proc_saveLawnEnquiry @enquiryType, @unitID, @bookingDate, @functionType, @noOfGuests, @firstName, @lastName, @mobileNo, @phoneNo, @email, @message, @ipAddress";

            var sDetails = this.Database.SqlQuery<LawnEnquiry>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #region Get contact details to send customer query mail
        public LawnEnquiry GetLawnBanquetEnquiry(string enquiryNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@enquiryNo",Value=enquiryNo}
            };
            var sqlQuery = @"proc_getLawnBanquetEnquiryDetail @enquiryNo";
            var sList = this.Database.SqlQuery<LawnEnquiry>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        #region get lawn/ banquet enquiry list
        public IEnumerable<LawnEnquiry> GetLawnBanquetEnquiryList(LawnEnquiryReport model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@unitId",Value =model.unitID ?? 0},
                new SqlParameter{ParameterName="@dateFrom",Value = model.dateFrom},
                new SqlParameter{ParameterName="@dateTo",Value = model.dateTo},
                new SqlParameter{ParameterName="@enquiryNo",Value = model.enquiryNo ?? string.Empty},
                new SqlParameter{ParameterName="@enquiryType",Value = model.enquiryType}                
            };
            var sqlQuery = @"proc_getLawnBanquetEnquiryList @unitId, @dateFrom, @dateTo, @enquiryNo, @enquiryType";
            var sList = this.Database.SqlQuery<LawnEnquiry>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion


        /*--------------------End Lawn/ Banquet  Enquiry-------------------*/

        /*--------------------Auditorium  Enquiry-------------------*/

        #region get all functions
        public IEnumerable<Function> GetAuditoriumFunctionList()
        {
            var sqlQuery = @"proc_getAuditoriumFunctions";
            var sList = this.Database.SqlQuery<Function>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region insert auditorium enquiry
        public AuditoriumEnquiry InsertAuditoriumEnquiry(AuditoriumEnquiry model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@enquiryType", Value = model.enquiryType },                   
                    new SqlParameter { ParameterName = "@bookingDate", Value = model.audibookingDate },
                    new SqlParameter { ParameterName = "@functionType", Value = model.audiFunctionID  },
                    new SqlParameter { ParameterName = "@noOfGuests", Value = model.noOfAudiGuest },                    
                    new SqlParameter { ParameterName = "@firstName", Value = model.firstName },
                    new SqlParameter { ParameterName = "@lastName", Value = model.lastName },
                    new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
                    new SqlParameter { ParameterName = "@phoneNo", Value = model.phoneNo ?? string.Empty },
                    new SqlParameter { ParameterName = "@email", Value = model.email ?? string.Empty },
                    new SqlParameter { ParameterName = "@message", Value = model.message },
                    new SqlParameter { ParameterName = "@ipAddress", Value = model.ipAddress }                   
            };
            var sqlQuery = @"proc_saveAuditoriumEnquiry @enquiryType, @bookingDate, @functionType, @noOfGuests, @firstName, @lastName, @mobileNo, @phoneNo, @email, @message, @ipAddress";

            var sDetails = this.Database.SqlQuery<AuditoriumEnquiry>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;

        }
        #endregion

        #region Get contact details to send customer query mail
        public AuditoriumEnquiry GetAuditoriumEnquiry(string enquiryNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@enquiryNo",Value=enquiryNo}
            };
            var sqlQuery = @"proc_getAuditoriumEnquiryDetail @enquiryNo";
            var sList = this.Database.SqlQuery<AuditoriumEnquiry>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        #region get auditorium enquiry list
        public IEnumerable<AuditoriumEnquiry> GetAuditoriumEnquiryList(AuditoriumReport model)
        {
            var sqlParam = new SqlParameter[] {               
                new SqlParameter{ParameterName="@dateFrom",Value = model.dateFrom},
                new SqlParameter{ParameterName="@dateTo",Value = model.dateTo},
                new SqlParameter{ParameterName="@enquiryNo",Value = model.enquiryNo ?? string.Empty}                    
            };
            var sqlQuery = @"proc_getAuditoriumEnquiryList @dateFrom, @dateTo, @enquiryNo";
            var sList = this.Database.SqlQuery<AuditoriumEnquiry>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion


        /*--------------------End Auditorium Enquiry-------------------*/

        /*--------------------Advance Payment Room Wise----------------*/

        #region get booking details based on room id
        public AdvancePaymentRoomWise GetBookingDetailsByRoom(AdvancePaymentRoomWise model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("bookedRoomID", model.bookedRoomID),
                new SqlParameter("unitId", model.unitID)                             
            };
            var sqlQuery = @"proc_getBookingDetailsForChange  @bookedRoomID, @unitId";
            var sDetails = this.Database.SqlQuery<AdvancePaymentRoomWise>(sqlQuery, sqlParam).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region save advance payment
        public int InsertAdvancePaymentByRoom(AdvancePaymentRoomWise model)
        {
            int count = this.Database.ExecuteSqlCommand("proc_insertAdvancePaymentByRoom @unitID, @docketNo, @advanceAmount, @paymentDate, @userIP, @receiptNo, @categoryID, @roomNoID, @EntryBy",
               new SqlParameter("unitID", model.unitID),
               new SqlParameter("docketNo", model.docketNo),
               new SqlParameter("advanceAmount", model.advanceAmount),
               new SqlParameter("paymentDate", model.paymentDate),
               new SqlParameter("userIP", model.userIP),
               new SqlParameter("receiptNo", model.receiptNo ?? string.Empty),
               new SqlParameter("categoryID", model.CatId),
               new SqlParameter("roomNoID", model.currentRoomNoID),
               new SqlParameter("EntryBy", SessionManager.UserID));
            return count;
        }
        #endregion
        /*-------------------End Advance Payment Room Wise----------------*/
        #region Get All Package
        public IEnumerable<PackageEntry> GetPackageByCatIdAndname(int PackagecatId, string pName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("PackageCatId", PackagecatId),
                new SqlParameter("Packagename",pName) 
            };
            var Sqlquery = @"Proc_GetPackagesbyPackageCatIdAndname @PackageCatId,@Packagename";
            var SDetails = this.Database.SqlQuery<PackageEntry>(Sqlquery, sqlParam).ToList();
            return SDetails;
        }

        #endregion

        #region get lawn/ banquet enquiry list for Unit
        public IEnumerable<LawnEnquiry> GetLawnBanquetEnquiryListForUNIT(LawnEnquiryReport model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@unitId",Value =model.unitID ?? 0},
                new SqlParameter{ParameterName="@dateFrom",Value = model.dateFrom},
                new SqlParameter{ParameterName="@dateTo",Value = model.dateTo},
                new SqlParameter{ParameterName="@enquiryNo",Value = model.enquiryNo ?? string.Empty},
                new SqlParameter{ParameterName="@enquiryType",Value = string.IsNullOrEmpty(model.enquiryType)?"All":model.enquiryType}                 
            };
            var sqlQuery = @"proc_getLawnBanquetEnquiryListForUnit @unitId, @dateFrom, @dateTo, @enquiryNo, @enquiryType";
            var sList = this.Database.SqlQuery<LawnEnquiry>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion

        //By Tabeen
        #region get user details for resetting password
        public ForgotPassword GetUserDetailsForPasswordReset(ForgotPassword model)
        {
            var sqlParam = new SqlParameter[] {
                    new SqlParameter{ParameterName="@username",Value = model.userName },
                    new SqlParameter{ParameterName="@verifyBy",Value = model.verifyBy },                  
                    new SqlParameter{ParameterName="@randomNo",Value = model.randomNo }                          
            };
            var sqlQuery = @"proc_getUserDetailsForPwdReset @username, @verifyBy, @randomNo";
            var details = this.Database.SqlQuery<ForgotPassword>(sqlQuery, sqlParam).FirstOrDefault();
            return details;
        }
        #endregion

        //End By Tabeen
        #region get user details on forget pwd Anurag
        public IEnumerable<ForgotPassword> getAuthoUserDataForForgotPasswordEO(string Loginemail, string Email, string mobile, string randomNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@LoginId",Value =Loginemail },
                  new SqlParameter{ParameterName="@EmailID",Value =Email ?? string.Empty },
                    new SqlParameter{ParameterName="@MobileNo",Value =mobile  ?? string.Empty},
                     new SqlParameter{ParameterName="@randomNo",Value = Convert.ToInt32( randomNo ) }
                          
            };
            var sqlQuery = @"sp_getAuthorizedUserDataForForgotPassowrd  @LoginId , @EmailID ,@MobileNo,@randomNo ";
            var sList = this.Database.SqlQuery<ForgotPassword>(sqlQuery, sqlParam).ToList();
            return sList;
        }

        public changepwdByLink GetUserDetailsforChangingPwd(string userId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@userId",Value = userId },                
            };
            var sqlQuery = @"sp_getuserDetailsforchangingPwd  @userId";
            var details = this.Database.SqlQuery<changepwdByLink>(sqlQuery, sqlParam).FirstOrDefault();
            return details;
        }

        //public IEnumerable<ForgotPassword> getuserDetailsforchangingPwd(string UserId)
        //{
        //    var sqlParam = new SqlParameter[] {
        //        new SqlParameter{ParameterName="@UserId",Value =UserId },

        //    };
        //    var sqlQuery = @"sp_getuserDetailsforchangingPwd  @UserId ";
        //    var sList = this.Database.SqlQuery<ForgotPassword>(sqlQuery, sqlParam).ToList();
        //    return sList;
        //}

        public int UpdateUserPassword(Int64 UserId, string encpwd)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@UserId",Value =UserId },
                 new SqlParameter{ParameterName="@encpwd",Value =encpwd }
                 
            };
            var sqlQuery = @"sp_updatepassword  @UserId,@encpwd";
            var sList = this.Database.ExecuteSqlCommand(sqlQuery, sqlParam);
            return sList;
        }
        #endregion

        #region get locked account list
        public List<LockAccountDetails> GetLockedAccounts(UnlockAccount model)
        {
            var sqlParam = new SqlParameter[] {               
                new SqlParameter{ParameterName="@email",Value = model.email  ?? string.Empty},
                new SqlParameter{ParameterName="@roleID",Value = model.roleID  ?? string.Empty}                
            };

            var sqlQuery = @"proc_getLockedAccount @email, @roleID";
            var sList = this.Database.SqlQuery<LockAccountDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion

        #region unlock accounts
        public int UnlockAccounts(string unlockXml)
        {
            var sqlparam = new SqlParameter[]{
                                            new SqlParameter("@unlockXml", unlockXml)             
                                        };

            var sqlquery = @"proc_unLockAccounts @unlockXml";
            int result = this.Database.ExecuteSqlCommand(sqlquery, sqlparam);
            return result;
        }
        #endregion


        /*--------------------Auditorium  Enquiry-------------------*/

        //#region get all functions
        //public IEnumerable<Function> GetAuditoriumFunctionList()
        //{
        //    var sqlQuery = @"proc_getAuditoriumFunctions";
        //    var sList = this.Database.SqlQuery<Function>(sqlQuery).ToList();
        //    return sList;
        //}
        //#endregion

        //#region insert auditorium enquiry
        //public AuditoriumEnquiry InsertAuditoriumEnquiry(AuditoriumEnquiry model)
        //{
        //    var sqlParams = new SqlParameter[] { 
        //            new SqlParameter { ParameterName = "@enquiryType", Value = model.enquiryType },                   
        //            new SqlParameter { ParameterName = "@bookingDate", Value = model.audibookingDate },
        //            new SqlParameter { ParameterName = "@functionType", Value = model.audiFunctionID  },
        //            new SqlParameter { ParameterName = "@noOfGuests", Value = model.noOfAudiGuest },                    
        //            new SqlParameter { ParameterName = "@firstName", Value = model.firstName },
        //            new SqlParameter { ParameterName = "@lastName", Value = model.lastName },
        //            new SqlParameter { ParameterName = "@mobileNo", Value = model.mobileNo },
        //            new SqlParameter { ParameterName = "@phoneNo", Value = model.phoneNo ?? string.Empty },
        //            new SqlParameter { ParameterName = "@email", Value = model.email ?? string.Empty },
        //            new SqlParameter { ParameterName = "@message", Value = model.message },
        //            new SqlParameter { ParameterName = "@ipAddress", Value = model.ipAddress }                   
        //    };
        //    var sqlQuery = @"proc_saveAuditoriumEnquiry @enquiryType, @bookingDate, @functionType, @noOfGuests, @firstName, @lastName, @mobileNo, @phoneNo, @email, @message, @ipAddress";

        //    var sDetails = this.Database.SqlQuery<AuditoriumEnquiry>(sqlQuery, sqlParams).FirstOrDefault();
        //    return sDetails;

        //}
        //#endregion

        #region get special deal list
        public IEnumerable<PackageSpecialPriceDealsDetails> GetSpecialDeals(int dealType)
        {
            var sqlQuery = @"proc_getSpecialDealDetails @type = " + dealType;
            var sList = this.Database.SqlQuery<PackageSpecialPriceDealsDetails>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region insert special deals
        public int InsertSpecialDeals(PackageSpecialPriceDeals model)
        {
            var sql = new SqlParameter[]{
                                            new SqlParameter("dealTitle",model.dealTitle),
                                            new SqlParameter("dealFromDate", model.dealFromDate),
                                            new SqlParameter("dealToDate", model.dealToDate),
                                            new SqlParameter("dealAmount", model.dealAmount),
                                            new SqlParameter("dealPercent", model.dealPercent),
                                            new SqlParameter("dealDescription", model.dealDescription),                                           
                                            new SqlParameter("packageID",model.packageID),
                                            new SqlParameter("noOfPersons", model.noOfPersons),
                                            new SqlParameter("isIndian", model.isIndian),
                                            new SqlParameter("userID", SessionManager.UserID),
                                            new SqlParameter("ipAddress", Common.GetIPAddress()),
                                            new SqlParameter("dealID", model.dealID)                                        
                       
                                        };

            var sqlquery = @"proc_SavePackageSpecialDeals @dealTitle, @dealFromDate, @dealToDate, @dealAmount, @dealPercent, @dealDescription, @packageID, @noOfPersons, @isIndian, @userID, @ipAddress, @dealID";
            int sDetails = this.Database.ExecuteSqlCommand(sqlquery, sql);
            return sDetails;


        }
        #endregion

        //#region get auditorium enquiry list
        //public IEnumerable<AuditoriumEnquiry> GetAuditoriumEnquiryList(AuditoriumReport model)
        //{
        //    var sqlParam = new SqlParameter[] {               
        //        new SqlParameter{ParameterName="@dateFrom",Value = model.dateFrom},
        //        new SqlParameter{ParameterName="@dateTo",Value = model.dateTo},
        //        new SqlParameter{ParameterName="@enquiryNo",Value = model.enquiryNo ?? string.Empty}                    
        //    };
        //    var sqlQuery = @"proc_getAuditoriumEnquiryList @dateFrom, @dateTo, @enquiryNo";
        //    var sList = this.Database.SqlQuery<AuditoriumEnquiry>(sqlQuery, sqlParam).ToList();
        //    return sList;
        //}
        //#endregion


        /*--------------------End Auditorium Enquiry-------------------*/



        /*--------------------Unit Special Deals-------------------*/


        //#region get special deal list
        //public IEnumerable<PackageSpecialPriceDealsDetails> GetSpecialDeals(int dealType)
        //{
        //    var sqlQuery = @"proc_getSpecialDealDetails @type = " + dealType;
        //    var sList = this.Database.SqlQuery<PackageSpecialPriceDealsDetails>(sqlQuery).ToList();
        //    return sList;
        //}
        //#endregion

        #region insert unit special deals
        public int InsertUnitSpecialDeals(UnitSpecialPriceDeals model, string dealxml)
        {
            var sql = new SqlParameter[]{
                                            new SqlParameter("unitID",model.unitID),
                                            new SqlParameter("dealTitle",model.dealTitle),
                                            new SqlParameter("dealFromDate", model.dealFromDate),
                                            new SqlParameter("dealToDate", model.dealToDate),
                                            new SqlParameter("dealAmount", model.dealAmount),
                                            new SqlParameter("dealPercent", model.dealPercent),
                                            new SqlParameter("dealDescription", model.dealDescription),                               
                                            new SqlParameter("userID", SessionManager.UserID),
                                            new SqlParameter("ipAddress", Common.GetIPAddress()),
                                            new SqlParameter("dealxml", dealxml),
                                            //new SqlParameter("dealID", model.dealID)                                        
                       
                                        };

            var sqlquery = @"proc_insertUnitSpecialDeals @unitID, @dealTitle, @dealFromDate, @dealToDate, @dealAmount, @dealPercent, @dealDescription, @packageID, @noOfPersons, @isIndian, @userID, @ipAddress, @dealxml";
            int sDetails = this.Database.ExecuteSqlCommand(sqlquery, sql);
            return sDetails;
        }
        #endregion

        //#region get auditorium enquiry list
        //public IEnumerable<AuditoriumEnquiry> GetAuditoriumEnquiryList(AuditoriumReport model)
        //{
        //    var sqlParam = new SqlParameter[] {               
        //        new SqlParameter{ParameterName="@dateFrom",Value = model.dateFrom},
        //        new SqlParameter{ParameterName="@dateTo",Value = model.dateTo},
        //        new SqlParameter{ParameterName="@enquiryNo",Value = model.enquiryNo ?? string.Empty}                    
        //    };
        //    var sqlQuery = @"proc_getAuditoriumEnquiryList @dateFrom, @dateTo, @enquiryNo";
        //    var sList = this.Database.SqlQuery<AuditoriumEnquiry>(sqlQuery, sqlParam).ToList();
        //    return sList;
        //}
        //#endregion


        /*--------------------End Auditorium Enquiry-------------------*/


        /*---------------------Packages Checkin------------------------*/

        #region get unit booking Details
        public PackageCheckin GetPackageBookingDetailsForCheckin(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_getPackBookingDetails @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<PackageCheckin>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get booked room details for package
        public IList<PackageRoomDetail> GetPackageBookedRoomDetails(PackageCheckin model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
                new SqlParameter("unitId", model.unitID)            
            };
            var sqlQuery = @"Proc_getPackageBookedRoomDetail  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<PackageRoomDetail>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }
        #endregion

        #region insert package checkin details
        public int InsertPackageCheckinDetail(PackageCheckin model, string roomDetailXml)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("proc_InsertPackageCheckinDetails @docketNo, @userID, @unitID, @userIP, @roomDetailXml",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("unitID", SessionManager.UnitID),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("roomDetailXml", roomDetailXml)
                  );
                return count;
            }
            catch
            { }
            return 0;
        }
        #endregion

        #region get package checkin details
        public List<PackageRoomDetail> GetPackCheckinDetails(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("unitID", SessionManager.UnitID)
            };
            var sqlQuery = @"proc_GetPackCheckinDetails  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<PackageRoomDetail>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }
        #endregion

        /*---------------------End Packages Checkin------------------------*/

        /*--------------Taxi/Bus Booking List------------------------------*/

        #region get taxi/bus booking list
        public IEnumerable<BusTaxiBookingDetails> GetTaxiBusBookingList(BusTaxiBookingReport model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@uptourId", Value = model.uptourId??(object)DBNull.Value },
                    new SqlParameter { ParameterName = "@dateFrom", Value = model.dateFrom ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@dateTo", Value = model.dateTo ?? (object)DBNull.Value  },
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty}
                 };
            var sqlQuery = @"proc_getBusTaxiBookingList @uptourId, @dateFrom, @dateTo, @docketNo";
            var sDetails = this.Database.SqlQuery<BusTaxiBookingDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        /*--------------End Taxi/Bus Booking List--------------------------*/


        /*---------------------Packages Checkout------------------------*/

        #region get package booking Details
        public PackageCheckout GetPackageBookingDetailsForCheckout(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_getPackCheckoutDetails @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<PackageCheckout>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region get booked room details for package
        public IList<PackageCheckOutRoomDetail> GetPackageCheckoutRoomDetails(PackageCheckout model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", model.docketNo),
                new SqlParameter("unitId", model.unitID)            
            };
            var sqlQuery = @"Proc_getPackageCheckoutRoomDetail  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<PackageCheckOutRoomDetail>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }
        #endregion

        #region insert package checkout details
        public int InsertPackageCheckoutDetail(PackageCheckout model, string roomDetailXml)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("proc_InsertPackageCheckoutDetails @docketNo, @userID, @unitID, @userIP, @roomDetailXml",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("userID", SessionManager.UserID),
                   new SqlParameter("unitID", SessionManager.UnitID),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("roomDetailXml", roomDetailXml)
                  );
                return count;
            }
            catch
            { }
            return 0;
        }
        #endregion

        #region get package checkin details
        public List<PackageCheckOutRoomDetail> GetPackCheckoutDetails(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("unitID", SessionManager.UnitID)
            };
            var sqlQuery = @"proc_GetPackCheckoutInfo  @docketNo, @unitId";
            var sDetails = this.Database.SqlQuery<PackageCheckOutRoomDetail>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }
        #endregion
        /*---------------------End Packages Checkin------------------------*/


        /*----------------Prepone-postpone booking on CRS using DocketNo----------------------*/

        #region get booking details for prepone-postpone
        public PreponePostponeCRS GetBookingDetailsForPrePostpone(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("docketNo", docketNo),
                new SqlParameter("isChekIn", false)                
            };
            var sqlQuery = @"PROC_getDetailsForPreponePostPoneByUnit  @docketNo, @isChekIn";
            var sDetails = this.Database.SqlQuery<PreponePostponeCRS>(sqlQuery, sqlParam).ToList();
            return sDetails.FirstOrDefault();
        }
        #endregion

        #region save prepone-postpone booking
        public int SavePreponePostponeBookingByCrs(PreponePostponeCRS model)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("Proc_modifyBookingSchedule @docketNo, @unitID, @checkinDate, @checkOutDate, @userIP, @entryBy",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("unitID", model.unitID),
                   new SqlParameter("checkinDate", model.newCheckInDate),
                   new SqlParameter("checkOutDate", model.newCheckOutDate),
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("entryBy", SessionManager.UserID));
                return count;
            }
            catch
            {
                return 0;
            }
        }
        #endregion

        /* --------------------End Prepone and Postpone booking on CRS using DocketNo-----------------------*/

        /* --------------------Update Fail Payment and Change Status to Booked using DocketNo-----------------------*/
        #region Update Fail Payment and Change Status to Booked
        public int UpdateFailPaymentResponceCRS(UpdatePayment model)
        {
            try
            {
                int count = this.Database.ExecuteSqlCommand("ProcUpdatetOnlineBookinStatus @docketNo, @paymentId, @transactionId, @Remark, @userIP, @entryBy",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("paymentId", model.PaymentId),
                   new SqlParameter("transactionId", model.TransactionId),
                   new SqlParameter("Remark", model.Remark),
                   new SqlParameter("userIP", Common.GetIPAddress()),
                   new SqlParameter("entryBy", SessionManager.UserID));
                return count;
            }
            catch
            {
                return 0;
            }
        }
        #endregion
        /* --------------------End Update Fail Payment and Change Status to Booked using DocketNo-----------------------*/

        /*------------------Real Time Booking for Taxi----------------------------------------*/
        #region Real Time Booking for Taxi


        public IEnumerable<BusTaxiBookingDetails> GetReleasedListTaxi(BusTaxiBookingReport model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@uptourId", Value = model.uptourId },
                    new SqlParameter { ParameterName = "@dateFrom", Value = model.dateFrom ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@dateTo", Value = model.dateTo ?? (object)DBNull.Value  },
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty}
                 };
            var sqlQuery = @"proc_getReleasedTaxiBookingList @uptourId, @dateFrom, @dateTo, @docketNo";
            var sDetails = this.Database.SqlQuery<BusTaxiBookingDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public decimal? getguidetariffbynoofperson(int? noofperson)
        {
            SqlParameter param = new SqlParameter("@noOfPerson", noofperson);
            var sList = this.Database.SqlQuery<decimal>("Execute proc_getguidetariff @noOfPerson", param);
            return sList.FirstOrDefault();
        }

        public IEnumerable<packagecategory> getpackagecategoryuptoursname()
        {
            var sList = this.Database.SqlQuery<packagecategory>("Execute proc_getPackageCategoryUptoursName").ToList();
            return sList;
        }

        public IEnumerable<bustaxibookingconfirm> getbustaxibookingconfirmation(string docketno)
        {
            SqlParameter param = new SqlParameter("@docketno", docketno);
            var sList = this.Database.SqlQuery<bustaxibookingconfirm>("Execute proc_customerbustaxidetail @docketno", param).ToList();
            return sList;
        }

        public IEnumerable<decimal> getBusTaxitariff(Int64? bustaxiid, int? duration, int? km, string bookingtype, string departuretime)
        {
            SqlParameter[] param = new SqlParameter[5];
            param[0] = new SqlParameter("@bustaxiId", bustaxiid);
            param[1] = new SqlParameter("@duration", duration);
            param[2] = new SqlParameter("@Km", km);
            param[3] = new SqlParameter("@type", bookingtype);
            param[4] = new SqlParameter("@departuretime", departuretime);
            var sList = this.Database.SqlQuery<decimal>("Select [dbo].[FN_getBusTaxitariff](@bustaxiId,@duration,@Km,@type,@departuretime)", param);
            return sList;
        }


        public IEnumerable<busortaxilist> GetBusTaxiNameList(string bustaxi, int? UptoursId)
        {
            SqlParameter[] param = new SqlParameter[2];
            param[0] = new SqlParameter("@busortaxi", bustaxi);
            if (UptoursId == null)
            {
                param[1] = new SqlParameter("@UptoursId", DBNull.Value);
            }
            else
            {
                param[1] = new SqlParameter("@UptoursId", UptoursId);
            }
            var sqlQuery = @"proc_bustaxiNameList @busortaxi,@UptoursId";
            var sList = this.Database.SqlQuery<busortaxilist>(sqlQuery, param).ToList();

            return sList;
        }

        public IEnumerable<busortaxilist> GetBusTaxiNameList(string bustaxi, int uptoursid)
        {
            var sqlQuery = @"proc_bustaxiNameList @busortaxi, @UptoursId";

            var sqlParam = new SqlParameter[] {
                new SqlParameter("@busortaxi", bustaxi),
                new SqlParameter("@UptoursId", uptoursid)
                
            };
            var sList = this.Database.SqlQuery<busortaxilist>(sqlQuery, sqlParam).ToList();
            return sList;
        }


        public IEnumerable<BusTaxiSourceCity> GetFromCityBusTaxiList()
        {
            var sqlQuery = @"proc_getFromCityForBusTaxiBooking";
            var sList = this.Database.SqlQuery<BusTaxiSourceCity>(sqlQuery).ToList();
            return sList;
        }

        public IEnumerable<BusTaxiSourceCity> GetFromCityBusTaxiListByUpToursId(int? UptoursId)
        {
            SqlParameter param = null;
            if (UptoursId == null)
            {
                param = new SqlParameter("@UptoursId", DBNull.Value);
            }
            else
            {
                param = new SqlParameter("@UptoursId", UptoursId);
            }
            var sqlQuery = @"proc_getFromCityForBusTaxiBooking @UptoursId";
            var sList = this.Database.SqlQuery<BusTaxiSourceCity>(sqlQuery, param).ToList();
            return sList;
        }

        public List<BusTaxiDestinationCity> GetDestinationCityBusTaxiList()
        {
            var sqlQuery = @"proc_getDestinationCityForBusTaxiBooking";
            var sList = this.Database.SqlQuery<BusTaxiDestinationCity>(sqlQuery).ToList();
            return sList;
        }

        public List<BusTaxiSourceCity> GetFromCityDetails(int cityId)
        {
            var sqlQuery = @"proc_getFromCityDetails @cityId";
            var sqlParm = new SqlParameter[]{
        new SqlParameter("@cityId",cityId)};
            var sList = this.Database.SqlQuery<BusTaxiSourceCity>(sqlQuery, sqlParm).ToList();
            return sList;
        }


        public List<BusTaxiList> GetBusTaxilist(int fromCityId, string Duration, string Type, string BusTaxitype, decimal KM, Int64 BustaxiId, DateTime DepartureTime, DateTime departuredate, int noOfPerson)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("@fromCityId", fromCityId),
                new SqlParameter("@Duration", Duration),
                new SqlParameter("@Type", Type),
                new SqlParameter("@BusTaxitype", BusTaxitype),
                new SqlParameter("@Km", KM),
                new SqlParameter("@BustaxiId", BustaxiId),
                new SqlParameter("@DepartureTime", DepartureTime),
                new SqlParameter("@Departuredate", departuredate),
                new SqlParameter("@noOfPerson", noOfPerson),
                new SqlParameter("@IsGuid", SessionManager.IsGuid)
            };
            var sqlQuery = @"Proc_GetBusTaxiList  @fromCityId, @Duration,@Type,@BusTaxitype,@Km,@BustaxiId,@DepartureTime,@Departuredate,@noOfPerson,@IsGuid";
            var sDetails = this.Database.SqlQuery<BusTaxiList>(sqlQuery, sqlParam).ToList();
            return sDetails;
        }

        public FareBreakup GetFareBreakup(string Duration, string Type, decimal KM, Int64 BustaxiId, DateTime DepartureTime, int noOfPerson)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter("@busTaxiId", BustaxiId),
                new SqlParameter("@duration", Duration),
                new SqlParameter("@Km", KM),
                new SqlParameter("@type", Type),                
                new SqlParameter("@departureTime", DepartureTime),
                 new SqlParameter("@noOfPerson", noOfPerson)
            };
            var sqlQuery = @"Proc_GetFairBreakUp  @busTaxiId, @duration,@Km,@type,@departureTime,@noOfPerson";
            var sDetails = this.Database.SqlQuery<FareBreakup>(sqlQuery, sqlParam).ToList().FirstOrDefault();
            return sDetails;
        }

        #endregion

        #region Save Bus Taxi Booking Details
        public string insertbustaxibookingdetails(UPTBusTaxibooking bustaxibooking, string ipaddress)
        {
            SqlParameter[] param = new SqlParameter[38];
            if (string.IsNullOrEmpty(bustaxibooking.email))
            {
                param[0] = new SqlParameter("@email", DBNull.Value);
            }
            else
            {
                param[0] = new SqlParameter("@email", bustaxibooking.email);
            }
            param[1] = new SqlParameter("@roleID", "UPT");
            param[2] = new SqlParameter("@name", bustaxibooking.name);
            param[3] = new SqlParameter("@address", bustaxibooking.address);
            if (bustaxibooking.cityID == null)
            {
                param[4] = new SqlParameter("@cityID", DBNull.Value);
            }
            else
            {
                param[4] = new SqlParameter("@cityID", bustaxibooking.cityID);
            }
            if (string.IsNullOrEmpty(bustaxibooking.otherCity))
            {
                param[5] = new SqlParameter("@otherCity", DBNull.Value);
            }
            else
            {
                param[5] = new SqlParameter("@otherCity", bustaxibooking.otherCity);
            }
            if (bustaxibooking.stateID == null)
            {
                param[6] = new SqlParameter("@stateID", DBNull.Value);
            }
            else
            {
                param[6] = new SqlParameter("@stateID", bustaxibooking.stateID);
            }
            if (string.IsNullOrEmpty(bustaxibooking.otherState))
            {
                param[7] = new SqlParameter("@otherstate", DBNull.Value);
            }
            else
            {
                param[7] = new SqlParameter("@otherstate", bustaxibooking.otherState);
            }
            param[8] = new SqlParameter("@countryID", bustaxibooking.countryID);
            if (string.IsNullOrEmpty(bustaxibooking.pincode))
            {
                param[9] = new SqlParameter("@pincode", DBNull.Value);
            }
            else
            {
                param[9] = new SqlParameter("@pincode", bustaxibooking.pincode);
            }
            param[10] = new SqlParameter("@mobileNo", bustaxibooking.mobileNo);
            if (string.IsNullOrEmpty(bustaxibooking.ID))
            {
                param[11] = new SqlParameter("@ID", DBNull.Value);
            }
            else
            {
                param[11] = new SqlParameter("@ID", bustaxibooking.ID);
            }
            if (bustaxibooking.IdentityType == null)
            {
                param[12] = new SqlParameter("@IdType", DBNull.Value);
            }
            else
            {
                param[12] = new SqlParameter("@IdType", bustaxibooking.IdentityType);
            }
            param[13] = new SqlParameter("@EntryBy", SessionManager.UserID);
            param[14] = new SqlParameter("@IPAddress", ipaddress);
            param[15] = new SqlParameter("@nameTitle", bustaxibooking.nameTitle);
            if (!string.IsNullOrEmpty(bustaxibooking.dateOfBirth))
            {
                int i = bustaxibooking.dateOfBirth.IndexOf("/");
                int il = bustaxibooking.dateOfBirth.LastIndexOf("/");
                string dtdate = bustaxibooking.dateOfBirth.Substring(0, bustaxibooking.dateOfBirth.IndexOf("/"));
                string dtmonth = bustaxibooking.dateOfBirth.Substring(bustaxibooking.dateOfBirth.IndexOf("/") + 1, bustaxibooking.dateOfBirth.LastIndexOf("/") - 3);
                string dtyear = bustaxibooking.dateOfBirth.Substring(bustaxibooking.dateOfBirth.LastIndexOf("/") + 1);
                param[16] = new SqlParameter("@Dobdate", string.IsNullOrEmpty(bustaxibooking.dateOfBirth) ? (int?)null : Convert.ToInt32(bustaxibooking.dateOfBirth.Substring(0, bustaxibooking.dateOfBirth.IndexOf("/"))));
                param[17] = new SqlParameter("@DobMonth", string.IsNullOrEmpty(bustaxibooking.dateOfBirth) ? (int?)null : Convert.ToInt32(bustaxibooking.dateOfBirth.Substring(bustaxibooking.dateOfBirth.IndexOf("/") + 1, bustaxibooking.dateOfBirth.LastIndexOf("/") - 3)));
                param[18] = new SqlParameter("@DobYear", string.IsNullOrEmpty(bustaxibooking.dateOfBirth) ? (int?)null : Convert.ToInt32(bustaxibooking.dateOfBirth.Substring(bustaxibooking.dateOfBirth.LastIndexOf("/") + 1)));
            }
            else
            {
                param[16] = new SqlParameter("@Dobdate", DBNull.Value);
                param[17] = new SqlParameter("@DobMonth", DBNull.Value);
                param[18] = new SqlParameter("@DobYear", DBNull.Value);
            }
            if (bustaxibooking.age == null)
            {
                param[19] = new SqlParameter("@Age", bustaxibooking.age);
            }
            else
            {
                param[19] = new SqlParameter("@Age", bustaxibooking.age);
            }
            param[20] = new SqlParameter("@BookingFor", bustaxibooking.busortaxi);
            param[21] = new SqlParameter("@bookingType", bustaxibooking.bookingtype);
            int busortaxiid = 0;
            if (bustaxibooking.busortaxi == "T")
            {
                busortaxiid = (int)bustaxibooking.taxiid;
            }
            else if (bustaxibooking.busortaxi == "B")
            {
                busortaxiid = (int)bustaxibooking.busid;
            }
            param[22] = new SqlParameter("@BusTaxiId", busortaxiid);
            param[23] = new SqlParameter("@fromDate", bustaxibooking.journeydate);
            param[24] = new SqlParameter("@noOfTourists", bustaxibooking.noofpersons);
            decimal servicetaxpercentage = Convert.ToDecimal(ConfigurationManager.AppSettings["ServiceTaxBusTaxi"].ToString());


            param[25] = new SqlParameter("@serviceTaxPer", servicetaxpercentage);

            param[26] = new SqlParameter("@Duration", bustaxibooking.duration);
            param[27] = new SqlParameter("@fromTime", DateTime.Parse(bustaxibooking.timeofdeparture));
            //    var basetariff=db.Database.SqlQuery<decimal>("Select [dbo].[FN_getBusTaxitariff]("+busortaxiid+","+bustaxibooking.duration+","+bustaxibooking.distance+",'"+bustaxibooking.bookingtype+"','"+DateTime.Parse(bustaxibooking.timeofdeparture)+"')");

            param[28] = new SqlParameter("@FromCityId", bustaxibooking.fromCityId);
            param[29] = new SqlParameter("@fromCity", bustaxibooking.fromCity);
            param[30] = new SqlParameter("@toCityId", bustaxibooking.toCityId);
            param[31] = new SqlParameter("@toCity", bustaxibooking.toCity);
            param[32] = new SqlParameter("@km", bustaxibooking.distance);
            param[33] = new SqlParameter("@noofvehicles", bustaxibooking.noofvehicles);
            if (bustaxibooking.advanceamount == null)
            {
                param[34] = new SqlParameter("@AdvanceAmount", DBNull.Value);
            }
            else
            {
                param[34] = new SqlParameter("@AdvanceAmount", bustaxibooking.advanceamount);
            }
            if (string.IsNullOrEmpty(bustaxibooking.receiptno))
            {
                param[35] = new SqlParameter("@receiptno", DBNull.Value);
            }
            else
            {
                param[35] = new SqlParameter("@receiptno", bustaxibooking.receiptno);
            }
            if (bustaxibooking.paymentdate == null)
            {
                param[36] = new SqlParameter("@paymentdate", DBNull.Value);
            }
            else
            {
                param[36] = new SqlParameter("@paymentdate", bustaxibooking.paymentdate);
            }
            if (bustaxibooking.guiderequired == null)
            {
                param[37] = new SqlParameter("@IsGuide", false);
            }
            else
            {
                param[37] = new SqlParameter("@IsGuide", bustaxibooking.guiderequired);
            }
            var docketno = this.Database.SqlQuery<string>("Execute Proc_saveCustomerBookingDetailsforUPT @email,@roleID,@name,@address,@cityID,@otherCity,@stateID,@otherstate,@countryID,@pincode,@mobileNo,@ID,@IdType,@EntryBy,@IPAddress,@nameTitle,@Dobdate,@DobMonth,@DobYear,@Age,@BookingFor,@bookingType,@BusTaxiId,@fromDate,@noOfTourists,@serviceTaxPer,@Duration,@fromTime,@FromCityId,@fromCity,@toCityId,@toCity,@km,@noofvehicles,@AdvanceAmount,@receiptno,@paymentdate,@IsGuide", param);
            return docketno == null ? "" : docketno.FirstOrDefault();
        }
        #endregion

        #region Insert Payment Details for Bus Taxi Booking
        public PostPaymentData InsertBusTaxiBookRequest(BusTaxiPayment model)
        {
            var sqlQuery = @"proc_InsertBusTaxiBookRequest @userID,@BookingFor,@bookingType,@fromCity,@toCity,@fromCityId,@toCityId,@BusTaxiId,@Fromdate,@FromTime,@noOfPerson,@amount,@userIP,@Duration,@baseTariff,@serviceTaxPer,@serviceTaxAmt,@mode,@NoOfBusTaxi,@GuidTariff,@isGuid,@Killometers";
            var sqlParam = new SqlParameter[]{
                new SqlParameter("@userID",SessionManager.UserID),
                new SqlParameter("@BookingFor",model.enquiryType),
                new SqlParameter("@bookingType",model.For),
                new SqlParameter("@fromCity",model.FromCityName),
                new SqlParameter("@toCity",model.toCity),
                new SqlParameter("@fromCityId",model.fromCity),
                new SqlParameter("@toCityId",model.ToCityCode),
                new SqlParameter("@BusTaxiId",model.BusTaxiId),
                new SqlParameter("@Fromdate",model.dateOfJourney),
                new SqlParameter("@FromTime",model.AvilableTime),
                new SqlParameter("@noOfPerson",model.noOfperson),
                new SqlParameter("@amount",model.amount),                 
                new SqlParameter("@userIP",Common.GetIPAddress()),
                new SqlParameter("@Duration",Convert.ToInt32(model.Duration)),
                new SqlParameter("@baseTariff",model.Tariff),
                new SqlParameter("@serviceTaxPer",model.serviceChargePer),
                new SqlParameter("@serviceTaxAmt",model.servicetaxtAmt),
                new SqlParameter("@mode",model.mode),
                new SqlParameter("@NoOfBusTaxi",model.BusTaxiCount),
                new SqlParameter("@GuidTariff",model.GuidTariff),
                new SqlParameter("@isGuid",model.IsGuid),
                new SqlParameter("@Killometers",Convert.ToInt32(model.km))
                 
            };
            var sList = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion

        #region booking details of bus taxi  anurag

        public IEnumerable<BusTaxiBookingDetails> GetBookingListBusTaxi(BusTaxiBookingReport model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@uptourId", Value = model.uptourId },
                    new SqlParameter { ParameterName = "@dateFrom", Value = model.dateFrom ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@dateTo", Value = model.dateTo ?? (object)DBNull.Value  },
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty}
                 };
            var sqlQuery = @"proc_getTaxiBusBookingList @uptourId, @dateFrom, @dateTo, @docketNo";
            var sDetails = this.Database.SqlQuery<BusTaxiBookingDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        #endregion


        #region Get Booking Revenue
        public IEnumerable<BookingRevenue> GetBuxTaxiBookingRevenueReport(int ReportType, Int64? UptoursId, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@uptour", Value = UptoursId ?? 0 },            
                    new SqlParameter { ParameterName = "@ReportType", Value = ReportType }
                 };
            var sqlQuery = @"Proc_getBusTaxiRevenueReport @dateFrom, @dateTo, @uptour, @ReportType";
            var sList = this.Database.SqlQuery<BookingRevenue>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        #region get Uptours list
        public IEnumerable<PackageCategory> GetUptoursList()
        {
            var sqlQuery = @"PROC_GetUpToursName";
            var sList = this.Database.SqlQuery<PackageCategory>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region get Bus Taxi details
        public IEnumerable<BusTaxiDetails> GetBusTaxiDetail(int UptoursId, int taxiId)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@UptoursId", Value = UptoursId },
                    new SqlParameter { ParameterName = "@TaxiId", Value = taxiId }
                  
                 };
            var sqlQuery = @"GetBusTaxiDetails @UptoursId, @TaxiId";
            var sDetails = this.Database.SqlQuery<BusTaxiDetails>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion


        #region Insert BillDetails BusTaxi
        public ReleseBusTaxi InsertBillDetails(ReleseBusTaxi model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@docketNo", Value = model.DocketNo },
                    new SqlParameter { ParameterName = "@BillDate", Value = model.ReleseDate },
                    new SqlParameter { ParameterName = "@billDetail", Value = "" },
                    new SqlParameter { ParameterName = "@amount", Value = model.NetPaybal },
                    new SqlParameter { ParameterName = "@AdditionalKm", Value = model.ExtraKm },
                    new SqlParameter { ParameterName = "@ExtraKmCharges", Value = model.ExtraKmCharges },
                    new SqlParameter { ParameterName = "@Extradays", Value = model.ExtraDays },
                    new SqlParameter { ParameterName = "@ExtraNightHaltCharges", Value = model.ExtraNightHaltCharges },
                    new SqlParameter { ParameterName = "@ExtraHours", Value = model.ExtrHours },
                    new SqlParameter { ParameterName = "@ExtraHoursCharges", Value = model.ExtrHoursCharges },
                    new SqlParameter { ParameterName = "@OtherAmount", Value = model.OtherAmount },
                    new SqlParameter { ParameterName = "@userID", Value = SessionManager.UserID },
                    new SqlParameter { ParameterName = "@BusTaxiId", Value = model.BusTaxiId },
                    new SqlParameter { ParameterName = "@UptoursId", Value = SessionManager.PackageCategoryID==0?model.uptoursid:SessionManager.PackageCategoryID },
                    new SqlParameter { ParameterName = "@requestId", Value = model.RequestId },
                    new SqlParameter { ParameterName = "@NetPaybal", Value = model.NetPaybal },
                    new SqlParameter { ParameterName = "@VehicleNo", Value = model.VehicleNo },
                    new SqlParameter { ParameterName = "@Drivername", Value = model.DriverName },
                    new SqlParameter { ParameterName = "@OpenMeterred", Value = model.OpenMeterReading },
                    new SqlParameter { ParameterName = "@CloseMeterred", Value = model.ClosingMeterReading },
                    new SqlParameter { ParameterName = "@OpenDate", Value = model.OpenDate },
                    new SqlParameter { ParameterName = "@CloseDate", Value = model.ClosingDate },
                    new SqlParameter { ParameterName = "@OpenTime", Value = model.OpeningTime },
                    new SqlParameter { ParameterName = "@CloseTime", Value = model.ClosingTime } 
                  
            };
            var sqlQuery = @"Proc_InsertBusTaxiBillDetails  @docketNo, @BillDate , @billDetail , @amount, @AdditionalKm , @ExtraKmCharges,@Extradays,@ExtraNightHaltCharges,
                        @ExtraHours , @ExtraHoursCharges , @OtherAmount, @userID , @BusTaxiId ,@UptoursId,@requestId , @NetPaybal,@VehicleNo ,@Drivername ,@OpenMeterred ,@CloseMeterred ,
                      @OpenDate ,@CloseDate ,@OpenTime ,@CloseTime";
            var sDetails = this.Database.SqlQuery<ReleseBusTaxi>(sqlQuery, sqlParams).ToList().FirstOrDefault();
            return sDetails;
        }
        #endregion


        #region get Bus Taxi bill details
        public BusTaxiBillDetails GetBusTaxiBillDetail(string DocketNo)
        {
            var sqlParams = new SqlParameter[] {      

                    new SqlParameter { ParameterName = "@docketNo", Value = DocketNo }
                  
                 };
            var sqlQuery = @"Proc_GetBillDetailsByDocketNo @docketNo";
            var sDetails = this.Database.SqlQuery<BusTaxiBillDetails>(sqlQuery, sqlParams).ToList().FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region User Registration by Syed
        public int InsertUserRegistration(UserRegistration ur, string ipaddress)
        {
            int i = 0;
            try
            {
                SqlParameter[] param = new SqlParameter[12];
                param[0] = new SqlParameter("@Name", ur.name);
                param[1] = new SqlParameter("@EmailAddress", ur.email);
                param[2] = new SqlParameter("@Password", ur.password);
                param[3] = new SqlParameter("@Address", ur.address);
                param[4] = new SqlParameter("@CountryId", ur.countryID);
                param[5] = new SqlParameter("@StateId", ur.stateID == null ? (object)DBNull.Value : ur.stateID);
                param[6] = new SqlParameter("@OtherState", string.IsNullOrEmpty(ur.otherState) ? (object)DBNull.Value : ur.otherState);
                param[7] = new SqlParameter("@CityId", ur.cityID == null ? (object)DBNull.Value : ur.cityID);
                param[8] = new SqlParameter("@OtherCity", string.IsNullOrEmpty(ur.otherCity) ? (object)DBNull.Value : ur.otherCity);
                param[9] = new SqlParameter("@PinCode", ur.pincode);
                param[10] = new SqlParameter("@MobileNo", ur.mobileNo);
                param[11] = new SqlParameter("@IPAddress", ipaddress);
                i = this.Database.ExecuteSqlCommand("Execute proc_InsertUserRegistration @Name,@EmailAddress,@Password,@Address,@CountryId,@StateId,@OtherState,@CityId,@OtherCity,@PinCode,@MobileNo,@IPAddress", param);
            }
            catch { }
            return i;
        }
        #endregion

        #region to check email and mobile existence by syed
        public int CheckEmailExistenceforUserReg(string email)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@email", Value = email }
                };

            var sqlQuery = @"proc_checkEmailExistenceforUserReg @email";
            var sDetails = this.Database.SqlQuery<int>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }

        public int CheckMoblieNoExistenceforUserReg(string mobileno)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@mobileno", Value = mobileno }
                };

            var sqlQuery = @"proc_checkMobileNoExistenceforUserReg @mobileno";
            var sDetails = this.Database.SqlQuery<int>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion



        /*------------------End Real Time Booking for Taxi----------------------------------------*/


        public int ReleseBlockedRoom(int blockId)
        {
            var sqlparmets = new SqlParameter[]{
                new SqlParameter{ParameterName="@blockId",Value=blockId},
                new SqlParameter{ParameterName="@userId",Value=SessionManager.UserID}
            };
            var sql = @"Proc_ReleseBlockRoom @blockId,@userId";
            int res = this.Database.ExecuteSqlCommand(sql, sqlparmets);
            return res;
        }


        #region select insert taxidetails by syed
        public int InsertTaxiDetails(taxidetails td, string ipaddress)
        {
            int i = 0;
            try
            {
                SqlParameter[] param = new SqlParameter[8];
                param[0] = new SqlParameter("@UptoursId", td.Uptoursid);
                param[1] = new SqlParameter("@BusTaxiName", td.taxiname);
                param[2] = new SqlParameter("@BusTaxiDiscription", td.taxidescription);
                param[3] = new SqlParameter("@BusTaxiType", td.taxitype);
                param[4] = new SqlParameter("@Standerd", td.standard);
                param[5] = new SqlParameter("@MaxCapacity", td.maxcapacity);
                param[6] = new SqlParameter("@UserId", td.userid);
                param[7] = new SqlParameter("@IPAddress", ipaddress);
                i = this.Database.ExecuteSqlCommand("Execute proc_InsertTaxiDetails @UptoursId,@BusTaxiName,@BusTaxiDiscription,@BusTaxiType,@Standerd,@MaxCapacity,@UserId,@IPAddress", param);
            }
            catch { }
            return i;
        }

        public List<taxidetails> GetTaxiDetails()
        {
            List<taxidetails> t = this.Database.SqlQuery<taxidetails>("Execute proc_GetTaxiDetails").ToList();
            return t;
        }

        public taxidetails GetTaxiDetailsByBusTaxiId(long? bustaxiid)
        {
            SqlParameter param = new SqlParameter("@BusTaxiId", bustaxiid);
            taxidetails t = this.Database.SqlQuery<taxidetails>("Execute proc_GetTaxiDetailsByBusTaxiId @BusTaxiId", param).FirstOrDefault();
            return t;
        }

        public int UpdateTaxiDetails(taxidetails td, string ipaddress)
        {
            int i = 0;
            try
            {
                SqlParameter[] param = new SqlParameter[9];
                param[0] = new SqlParameter("@BusTaxiId", td.BusTaxiId);
                param[1] = new SqlParameter("@UptoursId", td.Uptoursid);
                param[2] = new SqlParameter("@BusTaxiName", td.taxiname);
                param[3] = new SqlParameter("@BusTaxiDiscription", td.taxidescription);
                param[4] = new SqlParameter("@BusTaxiType", td.taxitype);
                param[5] = new SqlParameter("@Standerd", td.standard);
                param[6] = new SqlParameter("@MaxCapacity", td.maxcapacity);
                param[7] = new SqlParameter("@UserId", td.userid);
                param[8] = new SqlParameter("@IPAddress", ipaddress);
                i = this.Database.ExecuteSqlCommand("Execute proc_UpdateTaxiDetails @BusTaxiId,@UptoursId,@BusTaxiName,@BusTaxiDiscription,@BusTaxiType,@Standerd,@MaxCapacity,@UserId,@IPAddress", param);
            }
            catch { }
            return i;
        }

        public int DeleteTaxiDetails(long? bustaxiid)
        {
            int i = 0;
            try
            {
                SqlParameter param = new SqlParameter("@BusTaxiId", bustaxiid);
                i = this.Database.ExecuteSqlCommand("Execute proc_DeleteTaxiDetails @BusTaxiId", param);

            }
            catch { }
            return i;
        }
        #endregion

        #region insert tariffdetails by Syed
        public int InsertTariffDetails(tariffdetails td, string ipaddress)
        {
            int i = 0;
            try
            {
                SqlParameter[] param = new SqlParameter[12];
                param[0] = new SqlParameter("@BusTaxiId", td.BusTaxiId);
                param[1] = new SqlParameter("@MinHours", td.MinHours);
                param[2] = new SqlParameter("@MinimumKm", td.MinimumKm);
                param[3] = new SqlParameter("@FullDayMinTariff", td.FullDayMinTariff);
                param[4] = new SqlParameter("@AddLocalKmCharges", td.AddLocalKmCharges);
                param[5] = new SqlParameter("@AddOutofStationKmCharges", td.AddOutofStationKmCharges);
                param[6] = new SqlParameter("@NighthHaltCharges", td.NighthHaltCharges);
                param[7] = new SqlParameter("@AdditionalHrsCharges", td.AdditionalHrsCharges);
                param[8] = new SqlParameter("@NightHaltTimeAfterDeparture", td.NightHaltTimeAfterDeparture);
                param[9] = new SqlParameter("@NightHaltTimeBeforeArri", td.NightHaltTimeBeforeArri);
                param[10] = new SqlParameter("@IPAddress", ipaddress);
                param[11] = new SqlParameter("@UserId", td.UserId);
                i = this.Database.ExecuteSqlCommand("Execute proc_InsertTariffDetails @BusTaxiId,@MinHours,@MinimumKm,@FullDayMinTariff,@AddLocalKmCharges,@AddOutofStationKmCharges,@NighthHaltCharges,@AdditionalHrsCharges,@NightHaltTimeAfterDeparture,@NightHaltTimeBeforeArri,@IPAddress,@UserId", param);
            }
            catch { }
            return i;
        }

        public List<tariffdetails> GetTariffDetails()
        {
            List<tariffdetails> t = this.Database.SqlQuery<tariffdetails>("Execute proc_GetTariffDetails").ToList();
            return t;
        }

        public tariffdetails GetTariffDetailsByTariffId(long? TariffId)
        {
            SqlParameter param = new SqlParameter("@TariffId", TariffId);
            tariffdetails t = this.Database.SqlQuery<tariffdetails>("Execute proc_GetTariffDetailsByTariffId @TariffId", param).FirstOrDefault();
            return t;
        }

        public int UpdateTariffDetails(tariffdetails td, string ipaddress)
        {
            int i = 0;
            try
            {
                SqlParameter[] param = new SqlParameter[13];
                param[0] = new SqlParameter("@TariffId", td.TariffId);
                param[1] = new SqlParameter("@BusTaxiId", td.BusTaxiId);
                param[2] = new SqlParameter("@MinHours", td.MinHours);
                param[3] = new SqlParameter("@MinimumKm", td.MinimumKm);
                param[4] = new SqlParameter("@FullDayMinTariff", td.FullDayMinTariff);
                param[5] = new SqlParameter("@AddLocalKmCharges", td.AddLocalKmCharges);
                param[6] = new SqlParameter("@AddOutofStationKmCharges", td.AddOutofStationKmCharges);
                param[7] = new SqlParameter("@NighthHaltCharges", td.NighthHaltCharges);
                param[8] = new SqlParameter("@AdditionalHrsCharges", td.AdditionalHrsCharges);
                param[9] = new SqlParameter("@NightHaltTimeAfterDeparture", td.NightHaltTimeAfterDeparture);
                param[10] = new SqlParameter("@NightHaltTimeBeforeArri", td.NightHaltTimeBeforeArri);
                param[11] = new SqlParameter("@IPAddress", ipaddress);
                param[12] = new SqlParameter("@UserId", td.UserId);
                i = this.Database.ExecuteSqlCommand("Execute proc_UpdateTariffDetails @TariffId,@BusTaxiId,@MinHours,@MinimumKm,@FullDayMinTariff,@AddLocalKmCharges,@AddOutofStationKmCharges,@NighthHaltCharges,@AdditionalHrsCharges,@NightHaltTimeAfterDeparture,@NightHaltTimeBeforeArri,@IPAddress,@UserId", param);
            }
            catch { }
            return i;
        }

        public int DeleteTariffDetails(long? TariffId)
        {
            int i = 0;
            try
            {
                SqlParameter param = new SqlParameter("@TariffId", TariffId);
                i = this.Database.ExecuteSqlCommand("Execute proc_DeleteTariffDetails @TariffId", param);
            }
            catch { }
            return i;
        }
        #endregion

        #region insert taxiimagedetails by syed
        public int InsertTaxiImageDetails(taxiimagedetails tid, string ipaddress)
        {
            int i = 0;
            try
            {
                SqlParameter[] param = new SqlParameter[5];
                param[0] = new SqlParameter("@BusTaxiId", tid.BusTaxiId);
                param[1] = new SqlParameter("@ImageCaption", tid.ImageCaption);
                param[2] = new SqlParameter("@ImageUrl", tid.ImageUrl);
                param[3] = new SqlParameter("@IPAddress", ipaddress);
                param[4] = new SqlParameter("@UserId", tid.UserId);
                i = this.Database.ExecuteSqlCommand("Execute proc_InsertTaxiImageDetails @BusTaxiId,@ImageCaption,@ImageUrl,@IPAddress,@UserId", param);
            }
            catch { }
            return i;
        }

        public List<taxiimagedetails> GetTaxiImageDetails()
        {
            List<taxiimagedetails> t = this.Database.SqlQuery<taxiimagedetails>("Execute proc_GetTaxiImageDetails").ToList();
            return t;
        }

        public taxiimagedetails GetTaxiImageDetailsByBusTaxiImgId(long? BusTaxiImgId)
        {
            SqlParameter param = new SqlParameter("@BusTaxiImgId", BusTaxiImgId);
            taxiimagedetails t = this.Database.SqlQuery<taxiimagedetails>("Execute proc_GetTaxiImageDetailsByBusTaxiImgId @BusTaxiImgId", param).FirstOrDefault();
            return t;
        }

        public int UpdateTaxiImageDetails(taxiimagedetails tid, string ipaddress)
        {
            int i = 0;
            try
            {
                SqlParameter[] param = new SqlParameter[6];
                param[0] = new SqlParameter("@BusTaxiImgId", tid.BusTaxiImgId);
                param[1] = new SqlParameter("@BusTaxiId", tid.BusTaxiId);
                param[2] = new SqlParameter("@ImageCaption", tid.ImageCaption);
                param[3] = new SqlParameter("@ImageUrl", tid.ImageUrl);
                param[4] = new SqlParameter("@IPAddress", ipaddress);
                param[5] = new SqlParameter("@UserId", tid.UserId);
                i = this.Database.ExecuteSqlCommand("Execute proc_UpdateTaxiImageDetails @BusTaxiImgId,@BusTaxiId,@ImageCaption,@ImageUrl,@IPAddress,@UserId", param);
            }
            catch { }
            return i;
        }


        public int DeleteTaxiImageDetails(long? BusTaxiImgId)
        {
            int i = 0;
            try
            {
                SqlParameter param = new SqlParameter("@BusTaxiImgId", BusTaxiImgId);
                i = this.Database.ExecuteSqlCommand("Execute proc_DeleteTaxiImageDetails @BusTaxiImgId", param);
            }
            catch { }
            return i;
        }
        #endregion


        #region save Banq Lawn enquiry reply
        public int SaveBanqLawnEnquiryReply(LawnEnquiry model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@enquiryNo", Value = model.enquiryNo },
                    new SqlParameter { ParameterName = "@amount", Value = model.amount },
                    new SqlParameter { ParameterName = "@remark", Value = model.remark },
                    new SqlParameter { ParameterName = "@documentPath", Value = model.documentPath  },
                    new SqlParameter { ParameterName = "@replyBy", Value = model.userID },
                    new SqlParameter { ParameterName = "@replyIP", Value = model.userIP }                          
            };
            var sqlQuery = @"proc_saveLAWNBANQUITReply @enquiryNo, @amount, @remark, @documentPath, @replyBy, @replyIP";

            var result = this.Database.ExecuteSqlCommand(sqlQuery, sqlParams);
            return result;

        }
        #endregion

        #region insert booking request for Lawn and  Banquit
        public PostPaymentData InsertLawnBanquitBookRequest(LawnEnquiry model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                    new SqlParameter("userID", SessionManager.UserID),
                    new SqlParameter("enquiryNo", model.enquiryNo),                    
                 
                   new SqlParameter("userIP", model.userIP),
                   new SqlParameter("mode", model.mode),
                   new SqlParameter("currency", model.currency),
                   new SqlParameter("description", model.description)   ,
                   new SqlParameter("bookingType", model.enquiryType.ToUpper())
                
                };

                var sqlQuery = @"proc_InsertbanqLawnBookRequest_EnqueryBased @userID, @enquiryNo, @userIP, @mode, @currency, @description, @bookingType";
                var sDetails = this.Database.SqlQuery<PostPaymentData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion

        #region Get booking details to send mail
        public LawnBanquitBookingDetails GetLawnBanquetBookingDetails(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_getLawnBanquetBookingDetail @docketNo";
            var sList = this.Database.SqlQuery<LawnBanquitBookingDetails>(sqlQuery, sqlParam).FirstOrDefault();
            return sList;
        }
        #endregion


        #region created by Syed
        public IEnumerable<LawnBanquetBooking> GetLawnBanquetBookingList(LawnBanquetBooking model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@UnitId", Value = model.UnitId },
                    new SqlParameter { ParameterName = "@dateFrom", Value = model.dateFrom ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@dateTo", Value = model.dateTo ?? (object)DBNull.Value  },
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo ?? string.Empty}
                 };
            var sqlQuery = @"proc_LawnBanquetBookingDetails @UnitId, @dateFrom, @dateTo, @docketNo";
            var sDetails = this.Database.SqlQuery<LawnBanquetBooking>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public IEnumerable<BookingRevenue> GetBanquetLawnBookingRevenue(Int64? unitID, DateTime fromDate, DateTime toDate)
        {
            var sqlParams = new SqlParameter[] {
                    new SqlParameter { ParameterName = "@dateFrom", Value = fromDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: fromDate},
                    new SqlParameter { ParameterName = "@dateTo", Value = toDate.ToString("dd/MM/yyyy")=="01-01-1900" ? (object)DBNull.Value: toDate},
                    new SqlParameter { ParameterName = "@UnitId", Value = unitID ?? 0 }
                 };
            var sqlQuery = @"proc_GetBanquetLawnBookingRevenue @dateFrom, @dateTo, @UnitId";
            var sList = this.Database.SqlQuery<BookingRevenue>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion



        #region Save Lawn banquiet Booking Details
        public UnitLawnBanquetBooking insertLawnBanquietbookingdetails(UnitLawnBanquetBooking model, string ipaddress)
        {
            SqlParameter[] param = new SqlParameter[29];

            param[0] = new SqlParameter("@roleID", "UNT");
            param[1] = new SqlParameter("@name", model.name);
            param[2] = new SqlParameter("@address", string.IsNullOrEmpty(model.address) ? "" : model.address);
            if (model.cityID == null)
            {
                param[3] = new SqlParameter("@cityID", DBNull.Value);
            }
            else
            {
                param[3] = new SqlParameter("@cityID", model.cityID);
            }
            if (string.IsNullOrEmpty(model.otherCity))
            {
                param[4] = new SqlParameter("@otherCity", DBNull.Value);
            }
            else
            {
                param[4] = new SqlParameter("@otherCity", model.otherCity);
            }
            if (model.stateID == null)
            {
                param[5] = new SqlParameter("@stateID", DBNull.Value);
            }
            else
            {
                param[5] = new SqlParameter("@stateID", model.stateID);
            }
            if (string.IsNullOrEmpty(model.otherState))
            {
                param[6] = new SqlParameter("@otherState", DBNull.Value);
            }
            else
            {
                param[6] = new SqlParameter("@otherState", model.otherState);
            }
            if (string.IsNullOrEmpty(Convert.ToString(model.countryID)))
            {
                param[7] = new SqlParameter("@countryID", DBNull.Value);
            }
            else
            {
                param[7] = new SqlParameter("@countryID", model.countryID);
            }

            if (string.IsNullOrEmpty(model.pincode))
            {
                param[8] = new SqlParameter("@pincode", DBNull.Value);
            }
            else
            {
                param[8] = new SqlParameter("@pincode", model.pincode);
            }
            if (string.IsNullOrEmpty(model.email))
            {
                param[9] = new SqlParameter("@email", DBNull.Value);
            }
            else
            {
                param[9] = new SqlParameter("@email", model.email);
            }
            param[10] = new SqlParameter("@mobileNo", model.mobileNo);

            param[11] = new SqlParameter("@unitID", SessionManager.UnitID);

            param[12] = new SqlParameter("@checkinDate", model.checkInDate);

            param[13] = new SqlParameter("@noOfGuests", model.noOfGuests);
            param[14] = new SqlParameter("@userIP", ipaddress);
            param[15] = new SqlParameter("@advancedAmount", model.advanceAmount);
            param[16] = new SqlParameter("@IdType", model.IdentityType);
            param[17] = new SqlParameter("@BookingFor", model.Bookingfor);
            param[18] = new SqlParameter("@receiptNo", model.advanceReceptNo);
            param[19] = new SqlParameter("@nameTitle", model.nameTitle);
            param[20] = new SqlParameter("@EntryBy", SessionManager.UserID);
            param[21] = new SqlParameter("@bookingBy", "UNT");
            if (!string.IsNullOrEmpty(model.dateOfBirth))
            {
                int i = model.dateOfBirth.IndexOf("/");
                int il = model.dateOfBirth.LastIndexOf("/");
                string dtdate = model.dateOfBirth.Substring(0, model.dateOfBirth.IndexOf("/"));
                string dtmonth = model.dateOfBirth.Substring(model.dateOfBirth.IndexOf("/") + 1, model.dateOfBirth.LastIndexOf("/") - 3);
                string dtyear = model.dateOfBirth.Substring(model.dateOfBirth.LastIndexOf("/") + 1);
                param[22] = new SqlParameter("@Dobdate", string.IsNullOrEmpty(model.dateOfBirth) ? (int?)null : Convert.ToInt32(model.dateOfBirth.Substring(0, model.dateOfBirth.IndexOf("/"))));
                param[23] = new SqlParameter("@DobMonth", string.IsNullOrEmpty(model.dateOfBirth) ? (int?)null : Convert.ToInt32(model.dateOfBirth.Substring(model.dateOfBirth.IndexOf("/") + 1, model.dateOfBirth.LastIndexOf("/") - 3)));
                param[24] = new SqlParameter("@DobYear", string.IsNullOrEmpty(model.dateOfBirth) ? (int?)null : Convert.ToInt32(model.dateOfBirth.Substring(model.dateOfBirth.LastIndexOf("/") + 1)));
            }
            else
            {
                param[22] = new SqlParameter("@Dobdate", DBNull.Value);
                param[23] = new SqlParameter("@DobMonth", DBNull.Value);
                param[24] = new SqlParameter("@DobYear", DBNull.Value);
            }
            if (model.age == null)
            {
                param[25] = new SqlParameter("@Age", model.age);
            }
            else
            {
                param[25] = new SqlParameter("@Age", model.age);
            }
            param[26] = new SqlParameter("@functionID", model.functionID);
            param[27] = new SqlParameter("@Tariff", model.Tariff);
            param[28] = new SqlParameter("@phone", string.IsNullOrEmpty(model.phone) ? "" : model.phone);

            var Docket = this.Database.SqlQuery<UnitLawnBanquetBooking>(@"Proc_saveBanquetLawnBooking @roleID,@name,@address,@cityID,@otherCity,@stateID,@otherState, @countryID, @pincode, @email, @mobileNo,@unitID,@checkinDate,@noOfGuests,@userIP,@advancedAmount,@IdType,@BookingFor,@receiptNo,@nameTitle,@EntryBy,@bookingBy,@dobDate,@dobMonth,@dobYear,@age,@functionID,@Tariff,@phone", param);
            return Docket.FirstOrDefault(); ;
        }

        #endregion



        #region Get Customer List FOR unit AUTOFILL-----------------------------By Bramh
        public IEnumerable<GuestList> getGuestListUNIT(int UserId, string name, string mobileno, string Email, int unitid)
        {
            var sql = @"Proc_GetGuestDetails_UNIT @userID,@Name,@mobile,@email,@unitId";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@userID", Value = UserId },
                new SqlParameter { ParameterName = "@Name", Value =name?? string.Empty },
                new SqlParameter { ParameterName = "@mobile", Value = mobileno ?? string.Empty},
                new SqlParameter { ParameterName = "@email", Value =Email?? string.Empty},
                new SqlParameter { ParameterName = "@unitId", Value =unitid}};
            var count = this.Database.SqlQuery<GuestList>(sql, sqlParm).ToList();
            return count;
        }

        public CustomerRegistration getCustomerDetailsAutoFill(Int64 UserId)
        {
            var sql = @"Proc_getUserDetailsForAutofilldata @userid";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@userid", Value = UserId }};
            var count = this.Database.SqlQuery<CustomerRegistration>(sql, sqlParm).FirstOrDefault();
            return count;
        }
        #endregion
        public List<AdvanceAmountDetails> GetAdvanceAmountList(string DocketNo, Int64 AdvancePaymentId, Int64 UnitID)
        {
            var sql = @"Proc_getAdvanceAmountBookingDetails @docketNo,@AdvanceAmountId,@unitID";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@docketNo", Value = DocketNo },
                new SqlParameter { ParameterName = "@AdvanceAmountId", Value = AdvancePaymentId },
                new SqlParameter { ParameterName = "@unitID", Value = UnitID }};
            var count = this.Database.SqlQuery<AdvanceAmountDetails>(sql, sqlParm).ToList();
            return count;
        }

        public List<RoomBookingDetails> getRoomBookingList(string DocketNo, int RequestId, Int64 UnitID)
        {
            var sql = @"Proc_getRoomBookingDetails @docketNo, @Requestid,@unitId";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@docketNo", Value = DocketNo },
                new SqlParameter { ParameterName = "@Requestid", Value = RequestId },
                new SqlParameter { ParameterName = "@unitId", Value = UnitID }};
            var count = this.Database.SqlQuery<RoomBookingDetails>(sql, sqlParm).ToList();
            return count;
        }

        #region get unit booking Details
        public List<BookingChange> GetUnitBookingDetailseEDIT(string docketNo, Int64 unitID)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                    new SqlParameter { ParameterName = "@unitID", Value =unitID }
                 };
            var sqlQuery = @"proc_getUnitBookingDetails @docketNo, @unitID";
            var sDetails = this.Database.SqlQuery<BookingChange>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        public int UpdateRoomOccupancyByReqId(RoomBookingDetails model)
        {
            var sql = @"proc_UpdateRoomOccupancyByRequestId @requestId,@singelRooms,@doubleRooms";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@requestId", Value = model.requestID },
                new SqlParameter { ParameterName = "@singelRooms", Value = model.singleRoom },
                new SqlParameter { ParameterName = "@doubleRooms", Value = model.doubleRoom }};
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);
            return count;
        }

        public int UpdateAdvanceAmountByAdvanceAmtId(AdvanceAmountDetails model)
        {
            var sql = @"Proc_UpdateAdvanceAmount @advanceAmount,@receiptNo,@paymentDate,@advancePaymentID";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@advanceAmount", Value = model.advanceAmount },
                new SqlParameter { ParameterName = "@receiptNo", Value = model.receiptNo },
                new SqlParameter { ParameterName = "@paymentDate", Value = model.paymentDate },
                new SqlParameter { ParameterName = "@advancePaymentID", Value = model.advancePaymentID }};
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);
            return count;
        }

        #region Booking at a Glance
        public List<UnitBookingAtAGlanceHeader> getUnitBookingAtAGlanceHeaders(int unitId)
        {
            var sql = @"proc_getUnitBookingAtAGlanceHeader @unitId";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@unitId", Value = unitId }};
            var count = this.Database.SqlQuery<UnitBookingAtAGlanceHeader>(sql, sqlParm).ToList();
            return count;
        }
        #endregion

        #region Unit Revenue and Tax Report
        public List<BillRevenueDetails> getUnitRevenueAndTaxReport(UnitRevenueRepoprt model)
        {
            var sql = @"Proc_GetUnitLevelTaxReort @unitId,@fromdate,@todate";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@unitId", Value = model.UnitId },
                new SqlParameter { ParameterName = "@fromdate", Value = model.fromDate },
                new SqlParameter { ParameterName = "@todate", Value = model.Todate }};
            var count = this.Database.SqlQuery<BillRevenueDetails>(sql, sqlParm).ToList();
            return count;
        }
        #endregion

        #region Get Mobile Nos and Email Ids for SMS and Email
        public IEnumerable<OfficerContactDetails> getMobileNosEmailIdForSMSEmail_BANQ_LAWN_CRS(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_GetListToSendSMSAndMailBANQLAWN @docketNo";
            var sList = this.Database.SqlQuery<OfficerContactDetails>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion


        #region Get Ac Bus Package List
        public IEnumerable<PackageEntry> getACBUSPackageList()
        {
            var sqlQuery = @"Proc_GetAcBusPackageList";
            var sList = this.Database.SqlQuery<PackageEntry>(sqlQuery).ToList();
            return sList;
        }
        #endregion

        #region Get Ac Bus blocked List
        public List<PackageBlockModel> getACBUSPackageBlockedList(int Packageid, DateTime fromdate, DateTime todate)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@PackageId",Value=Packageid},
                new SqlParameter{ParameterName="@FromDate",Value=fromdate},
                new SqlParameter{ParameterName="@ToDate",Value=todate}
            };
            var sqlQuery = @"Proc_getBlockPackageList @PackageId,@FromDate , @ToDate";
            var sList = this.Database.SqlQuery<PackageBlockModel>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        #endregion


        public int Insert_AcBus_Blocked(PackageBlockModel model)
        {
            var sql = @"Proc_InsertBlockPackage @PackageId,@BlockDate,@IPAddress,@EntryBY";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@PackageId", Value = model.Packageid },
                new SqlParameter { ParameterName = "@BlockDate", Value = model.Blockdate },
                new SqlParameter { ParameterName = "@IPAddress", Value = Common.GetIPAddress() },
                new SqlParameter { ParameterName = "@EntryBY", Value = SessionManager.UserID }};
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);
            return count;
        }

        public int ReleseBlockedACBUSTOUR(Int64 BlockId)
        {
            var sql = @"Proc_ReleseBlockedACBUS @blockid,@ipAddress,@entryBy";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@blockid", Value = BlockId},                
                new SqlParameter { ParameterName = "@ipAddress", Value = Common.GetIPAddress() },
                new SqlParameter { ParameterName = "@entryBy", Value = SessionManager.UserID }};
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);
            return count;
        }

        #region all unit Booking Report header
        public List<AllUnitBookingHQHeader> AllUnitBookingCountReportHeaders()
        {
            var sql = @"getAllUnitBookingCountHeader";
            var count = this.Database.SqlQuery<AllUnitBookingHQHeader>(sql).ToList();
            return count;
        }
        #endregion


        #region Insert Bill Details Banquet Lawan
        public BanquitLawnBill InsertBanqUitLawnBillDEtails(BanquitLawnBill model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo },
                    new SqlParameter { ParameterName = "@BillDate", Value = model.BillDate.ToString("dd/MM/yyyy") },
                   // new SqlParameter { ParameterName = "@billDetail", Value = "" },
                    new SqlParameter { ParameterName = "@Tariff", Value = model.Tariff ?? 0 },
                    new SqlParameter { ParameterName = "@OtherAmount", Value = model.OtherAmount },
                    new SqlParameter { ParameterName = "@serviceTax", Value = model.ServiceTax },
                    new SqlParameter { ParameterName = "@ServiceTaxAmount", Value = model.ServiceTaxAmount },
                    new SqlParameter { ParameterName = "@LuxuryTax", Value = model.Luxurytax },
                    new SqlParameter { ParameterName = "@LuxuryTaxAmount", Value = model.LuxurytaxAmount },
                    new SqlParameter { ParameterName = "@DiscountPer", Value = model.DiscountPer },
                    new SqlParameter { ParameterName = "@DiscountAmount", Value = model.DiscountAmount },
                    new SqlParameter { ParameterName = "@TotalAmount", Value = model.TotalAmount },
                    new SqlParameter { ParameterName = "@AdvanceAmount", Value = model.advanceAmount },                    
                    new SqlParameter { ParameterName = "@NetPayable", Value = model.NetPayble },
                    new SqlParameter { ParameterName = "@IPAddress", Value =Common.GetIPAddress() },
                    new SqlParameter { ParameterName = "@EntryBy", Value = SessionManager.UnitID }
                           
                  
            };
            var sqlQuery = @"proc_InsertBanqLawnBillDetails  @docketNo,@BillDate,@Tariff,@OtherAmount,@serviceTax,@ServiceTaxAmount,@LuxuryTax,@LuxuryTaxAmount,@DiscountPer,@DiscountAmount,@TotalAmount,@AdvanceAmount,@NetPayable,@IPAddress,@EntryBy";
            var sDetails = this.Database.SqlQuery<BanquitLawnBill>(sqlQuery, sqlParams).ToList().FirstOrDefault();
            return sDetails;
        }
        #endregion


        #region GET BANQUET LAWN BILL BY DOCKET
        public BanquitLawnBill GetLawnBanquetBillbyDocket(string docketNo)
        {
            var sql = @"proc_getBanqLawnBillDetails @docketNo";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@docketNo", Value = docketNo}};
            var count = this.Database.SqlQuery<BanquitLawnBill>(sql, sqlParm).ToList().FirstOrDefault();
            return count;
        }
        #endregion


        #region get Daly Sale Report
        public DalySaleReportModel GetDalySaleReportforFillForm(Int64 unitId, DateTime saleDate)
        {
            var sql = @"Proc_getDalySaleReport @unitId,@saleDate";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@unitId", Value = unitId},
               new SqlParameter { ParameterName = "@saleDate", Value = saleDate}};
            var count = this.Database.SqlQuery<DalySaleReportModel>(sql, sqlParm).ToList().FirstOrDefault();
            return count;
        }
        #endregion


        #region Insert Daily Sale Report
        public int InsertUpdateDalySaleReport(DalySaleReportModel model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@Saleid", Value = model.Saleid },
                    new SqlParameter { ParameterName = "@NameOfStation", Value = model.NameOfStation },
                    new SqlParameter { ParameterName = "@saleDate", Value = model.SaleDate },
                    new SqlParameter { ParameterName = "@UnitId", Value = model.UnitId },
                    new SqlParameter { ParameterName = "@NameofUnit", Value = model.NameofUnit },
                    new SqlParameter { ParameterName = "@TotalRooms", Value = model.TotalRooms },
                    new SqlParameter { ParameterName = "@OccupidRooms", Value = model.OccupidRooms },
                    new SqlParameter { ParameterName = "@TotalPerRoom", Value = model.TotalPerRoom },
                    new SqlParameter { ParameterName = "@AccomodationCharges", Value = model.AccomodationCharges },
                    new SqlParameter { ParameterName = "@Canteen", Value = model.Canteen },
                    new SqlParameter { ParameterName = "@Bar", Value = model.Bar },
                    new SqlParameter { ParameterName = "@BanquitHallLawn", Value = model.BanquitHallLawn },
                    new SqlParameter { ParameterName = "@Miscellaneous", Value = model.Miscellaneous },
                    new SqlParameter { ParameterName = "@Total", Value = model.Total },                    
                    new SqlParameter { ParameterName = "@TotalIncomeTillDate", Value = model.TotalIncomeTillDate },
                    new SqlParameter { ParameterName = "@UserId", Value =SessionManager.UnitID },
                    new SqlParameter { ParameterName = "@transip", Value =  Common.GetIPAddress()}
                           
                  
            };
            var sqlQuery = @"Proc_InsertUpdateDalySaleReport  @Saleid,@NameOfStation,@saleDate,@UnitId,@NameofUnit,@TotalRooms,@OccupidRooms,@TotalPerRoom,@AccomodationCharges,@Canteen,@Bar,@BanquitHallLawn,@Miscellaneous,@Total,@TotalIncomeTillDate,@UserId,@transip";
            var sDetails = this.Database.ExecuteSqlCommand(sqlQuery, sqlParams);
            return sDetails;
        }
        #endregion



        #region get Daly Sale Report for View
        public List<DalySaleReportModel> GetDalySaleReportforView(Int64 unitId, DateTime fromDate, DateTime date, int Procid)
        {
            var sql = @"Proc_getDalySaleReportForView @unitId,@fromDate,@date,@procid";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@unitId", Value = unitId},
                new SqlParameter { ParameterName = "@fromDate", Value = fromDate},
                new SqlParameter { ParameterName = "@date", Value = date},
                new SqlParameter { ParameterName = "@procid", Value = Procid}};
            var count = this.Database.SqlQuery<DalySaleReportModel>(sql, sqlParm).ToList();
            return count;
        }
        #endregion


        #region get room Tariff details
        public RoomTariffMode getRoomTariffDetails(int roomId, int sesionId, int noOfBeds)
        {
            var sql = @"Proc_GetRoomDetailsByRoomId @roomId,@sesionId,@noOfBeds";
            var sqlParm = new SqlParameter[] {                
               new SqlParameter { ParameterName = "@roomId", Value = roomId},
               new SqlParameter { ParameterName = "@sesionId", Value = sesionId},
               new SqlParameter { ParameterName = "@noOfBeds", Value = noOfBeds}
            };
            var count = this.Database.SqlQuery<RoomTariffMode>(sql, sqlParm).ToList().FirstOrDefault();
            return count;
        }
        #endregion

        #region get Unit booking Details for Edit at CRS
        public List<BookingChange> GetUnitBookingDetailseEDITAtCRS(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo }
                    
                 };
            var sqlQuery = @"proc_getUnitBookingDetailsForEditAtCRS @docketNo";
            var sDetails = this.Database.SqlQuery<BookingChange>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion

        #region Get Day Closing Report
        public List<BookingCustomerDetailsModel> GetDayClosingReport(CRSReportModel model)
        {
            var sql = @"Proc_GetDayWiseClosingReport @reportDate,@bookingType,@bookingStatus";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@reportDate", Value = model.reportDate},
                new SqlParameter { ParameterName = "@bookingType", Value = model.bookingFor??string.Empty},                
                new SqlParameter { ParameterName = "@bookingStatus", Value = model.bookingStatus??string.Empty}};
            var count = this.Database.SqlQuery<BookingCustomerDetailsModel>(sql, sqlParm).ToList();
            return count;
        }
        #endregion


        #region Update Fail Payment by reconcile the payment status by API
        public QueryResult UpdateFailPaymentByAPI(ReconcileApiValues model)
        {
            try
            {
                var count = this.Database.SqlQuery<QueryResult>("procUpdatetOnlineBookinStatusByAPI @docketNo, @paymentId, @transactionId,@amount,@paymentDate,@referenceNo, @Remark, @userIP, @entryBy",
                   new SqlParameter("docketNo", model.docketNo),
                   new SqlParameter("paymentId", model.paymentId),
                   new SqlParameter("transactionId", model.transactionId),
                   new SqlParameter("amount", model.amount),
                   new SqlParameter("paymentDate", model.dateTime),
                   new SqlParameter("referenceNo", model.referenceNo),
                   new SqlParameter("Remark", "Updated By API"),
                   new SqlParameter("userIP", Common.GetIPAddress()),
                   new SqlParameter("entryBy", SessionManager.UserID)).ToList().FirstOrDefault();
                return count;
            }
            catch
            {
                return null;
            }
        }
        #endregion

        //#region Method View GST Report
        //public List<UnitReportGST> GetGSTView(string fromDate, string toDate)
        //{
        //    var SqlParams = new SqlParameter[]{

        //    new SqlParameter{ParameterName="@fromDate",Value=fromDate?? (object)DBNull.Value},
        //    new SqlParameter{ParameterName="@toDate",Value=toDate?? (object)DBNull.Value},
        //    };
        //    var sqlProc = @"proc_ViewReportGST @fromDate,@toDate";
        //    var list = this.Database.SqlQuery<UnitReportGST>(sqlProc, SqlParams).ToList();
        //    return list;
        //}
        //#endregion


        #region Method View GST Report

        public IEnumerable<UnitReportGST> GetGSTView(UnitReportGST model)
        {
            var sqlParams = new SqlParameter[] {      
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID },
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate ?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate ?? (object)DBNull.Value  },
                    new SqlParameter { ParameterName = "@bookingBy", Value = model.bookingBy ?? (object)DBNull.Value  },
                 };
            var sqlQuery = @"proc_ViewReportGST @unitID, @fromDate, @toDate,@bookingBy";
            var sDetails = this.Database.SqlQuery<UnitReportGST>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public IEnumerable<TotalBookingDetail> GetTotalUnitList()
        {
            var sqlQuery = @"proc_BindUnitId";
            var sList = this.Database.SqlQuery<TotalBookingDetail>(sqlQuery).ToList();
            return sList;
        }

        public IEnumerable<TotalBookingDetail> BindTotalBookingList(TotalBookingDetail model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@UnitID",Value =model.UnitID},
                new SqlParameter{ParameterName="@fromDate",Value = model.fromDate?? (object)DBNull.Value },
                new SqlParameter{ParameterName="@toDate",Value = model.toDate?? (object)DBNull.Value }
                               
            };
            var sqlQuery = @"proc_ViewTourismBookinDetail @UnitID, @fromDate, @toDate";
            var sList = this.Database.SqlQuery<TotalBookingDetail>(sqlQuery, sqlParam).ToList();
            return sList;
        }

        public IEnumerable<GSTBookingDetail> GetGSTandTarrifView(GSTBookingDetail model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@UnitID",Value =model.UnitID},
                new SqlParameter{ParameterName="@fromDate",Value = model.fromDate?? (object)DBNull.Value },
                new SqlParameter{ParameterName="@toDate",Value = model.toDate?? (object)DBNull.Value }
                               
            };
            var sqlQuery = @"pro_ViewGSTAndTarrifforHQ @UnitID, @fromDate, @toDate";
            var sList = this.Database.SqlQuery<GSTBookingDetail>(sqlQuery, sqlParam).ToList();
            return sList;
        }


        #region insert booking request for Paramotor
        public PostRequestData InsertParamotorBookRequest(ParamotorBookingModel model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("@email", model.email),
                   new SqlParameter("@name", model.name),
                   new SqlParameter("@address", model.address),
                   new SqlParameter("@cityID", model.cityID),
                   new SqlParameter("@otherCity", model.otherCity),
                   new SqlParameter("@stateID", model.stateID),
                   new SqlParameter("@otherState", model.otherState),
                   new SqlParameter("@countryID", model.countryID),
                   new SqlParameter("@pincode", model.pincode),                   
                   new SqlParameter("@mobileNo", model.mobileNo),
                   new SqlParameter("@transIP", model.userIP),
                   new SqlParameter("@RideDate", model.rideDate),
                   new SqlParameter("@noOfGuestforTwoMinRide", model.noOfGuestforTwoMinRide),
                   new SqlParameter("@noOfGuestforFourMinRide", model.noOfGuestforFourMinRide),
                   new SqlParameter("@amount", model.amount),
                   new SqlParameter("@unitRateForTwoMinRide", model.unitRateForTwoMinRide),
                   new SqlParameter("@unitRateforFourMinRide", model.unitRateforFourMinRide),  
                   new SqlParameter("@mode", model.mode),
                   new SqlParameter("@currency", model.currency),
                   new SqlParameter("@description", model.description)
                };

                var sqlQuery = @"Proc_InsertParamotorBookingRequest @email, @name, @address, @cityID, @otherCity, @stateID, @otherState, @countryID, @pincode, @mobileNo, @transIP,
                               @RideDate, @noOfGuestforTwoMinRide, @noOfGuestforFourMinRide, @amount, @unitRateForTwoMinRide, @unitRateforFourMinRide, @mode,
                                @currency,@description";
                var sDetails = this.Database.SqlQuery<PostRequestData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion
        #region Manish kumar 01/07/2017
        #region insert booking request for special Booking tours
        public PostRequestData InsertHotAirBaloonRideBookRequest(HotAirBaloonBookingDetailsModel model)
        {
            try
            {
                var sqlParams = new SqlParameter[] { 
                   new SqlParameter("@email", model.email),
                   new SqlParameter("@name", model.name),
                   new SqlParameter("@address", model.address),
                   new SqlParameter("@cityID", model.cityID),
                   new SqlParameter("@otherCity", model.otherCity),
                   new SqlParameter("@stateID", model.stateID),
                   new SqlParameter("@otherState", model.otherState),
                   new SqlParameter("@countryID", model.countryID),              
                   new SqlParameter("@pincode", model.pincode),
                   new SqlParameter("@mobileNo", model.mobileNo),
                   new SqlParameter("@transIP", model.ipAddress),
                   new SqlParameter("@RideDate", DateTime.ParseExact(model.RideDate,"dd/MM/yyyy",System.Globalization.CultureInfo.InvariantCulture) ),
                   new SqlParameter("@noofPersons", model.NoofPersons),
                   new SqlParameter("@rideAmount", model.RideAmount),
                   new SqlParameter("@mode", model.mode),
                   new SqlParameter("@currency", model.currency),
                   new SqlParameter("@description", model.description),
                   new SqlParameter("@unitRate", model.UnitRate)
                };

                var sqlQuery = @"Proc_InserHotAirBaloonRideRequestDetails @email,@name,@address,@cityID,@otherCity,@stateID,@otherState,@countryID,@pincode,@mobileNo,@transIP,@RideDate,@noofPersons,@rideAmount,@mode,@currency,@description,@unitRate";
                var sDetails = this.Database.SqlQuery<PostRequestData>(sqlQuery, sqlParams).FirstOrDefault();
                return sDetails;
            }
            catch
            { return null; }
        }
        #endregion
        #region
        public ParamotorBookingModel GetParaMotorBookingView(string DocketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value =DocketNo}
            };
            var sqlQuery = @"Proc_GetParamoterRideDetails @docketNo";
            var sList = this.Database.SqlQuery<ParamotorBookingModel>(sqlQuery, sqlParam).ToList().FirstOrDefault();
            return sList;
        }
        public HotAirBaloonBookingDetailsModel GetHotAirBaloonRideBookingView(string DocketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value =DocketNo}
            };
            var sqlQuery = @"Proc_GetHotAirBaloonRideDetails @docketNo";
            var sList = this.Database.SqlQuery<HotAirBaloonBookingDetailsModel>(sqlQuery, sqlParam).ToList().FirstOrDefault();
            return sList;
        }
        public ParamotorBookingModel GetParaMotorBookingViewByMobile(CheckStatus model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value =model.DocketNo},
                new SqlParameter{ParameterName="@MobileNo",Value =model.MobileNumber}
            };
            var sqlQuery = @"Proc_GetParamoterRideDetailsByMobileNo @docketNo,@MobileNo";
            var sList = this.Database.SqlQuery<ParamotorBookingModel>(sqlQuery, sqlParam).ToList().FirstOrDefault();
            return sList;
        }
        public HotAirBaloonBookingDetailsModel GetHotAirBaloonRideBookingViewByMobile(CheckStatus model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value =model.DocketNo},
                new SqlParameter{ParameterName="@MobileNo",Value =model.MobileNumber}
            };
            var sqlQuery = @"Proc_GetHotAirBaloonRideDetailsByMobileNo @docketNo,@MobileNo";
            var sList = this.Database.SqlQuery<HotAirBaloonBookingDetailsModel>(sqlQuery, sqlParam).ToList().FirstOrDefault();
            return sList;
        }
        public List<UnitAmountDetailsSlabWise> GetUnitPaymentInfoForTaxSlabs(DateTime dtCheckin, DateTime dtCheckout, int roomId, int single, int doubles, int extraBedRoom)
        {
            var sqlParams = new SqlParameter[] { 
                   
                    new SqlParameter { ParameterName = "@fromDate", Value = dtCheckin },
                    new SqlParameter { ParameterName = "@toDate", Value = dtCheckout},
                    new SqlParameter { ParameterName = "@singleBedRoom", Value = single },
                    new SqlParameter { ParameterName = "@doubleBedRoom", Value = doubles },
                    new SqlParameter { ParameterName = "@roomID", Value = roomId },
                    new SqlParameter { ParameterName = "@extraBedRoom", Value = extraBedRoom }
                 };
            var sqlQuery = @"GetUnitRoomTaxAmountForGST @fromDate, @toDate, @singleBedRoom, @doubleBedRoom, @roomID, @extraBedRoom";
            var sDetails = this.Database.SqlQuery<UnitAmountDetailsSlabWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        #endregion
        #endregion
        #endregion

        #region Ankita Tripathi
        public List<ViewBookedDetail> ViewBookedDetail(ViewBookedDetail model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value },
                   new SqlParameter { ParameterName = "@docketNo", Value = model.docketNo?? (object)DBNull.Value }
                 };

            var sqlQuery = @"proc_ViewBookedRequest @fromDate,@toDate,@docketNo";
            var sDetails = this.Database.SqlQuery<ViewBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;


        }

        public List<CancelBookingDetail> CancelDetailList(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"proc_ViewBookingForCancellation @docketNo";
            var sDetails = this.Database.SqlQuery<CancelBookingDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public List<CancelBookingDetail> DetailsOfCancellationConfirmation(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"proc_CancellationConfirmationDetail @docketNo";
            var sDetails = this.Database.SqlQuery<CancelBookingDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public List<CancelBookingDetail> ViewpackagedetailUnitwise(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo }
                 };
            var sqlQuery = @"proc_ViewpackagedetailUnitwise @docketNo";
            var sDetails = this.Database.SqlQuery<CancelBookingDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public List<CancelBookingDetail> BookingForCancellation(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"proc_DetailsOfBookingForCancellation @docketNo";
            var sDetails = this.Database.SqlQuery<CancelBookingDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public IEnumerable<CancelBookingDetail> getMobileNoAndEmailId(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            var sqlQuery = @"proc_GetOnlineListForSMS @docketNo";
            var sList = this.Database.SqlQuery<CancelBookingDetail>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        public ViewBookedDetail InsertCancelBooking(string docketNo, decimal refaundPer, decimal refaundAmount)
        {

            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                     new SqlParameter { ParameterName = "@refaundPer", Value =refaundPer },
                      new SqlParameter { ParameterName = "@refaundAmount", Value =refaundAmount }
                 };
            var sqlQuery = @"proc_InsertBookingCancellationRequestDetail @docketNo,@refaundPer,@refaundAmount";
            var sList = this.Database.SqlQuery<ViewBookedDetail>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;


        }
        public IEnumerable<CancelBookingDetail> PackageAccomodationList(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursAccomodation @packageID";
            var sList = this.Database.SqlQuery<CancelBookingDetail>(sqlQuery, sqlParams).ToList();
            return sList;
        }

        public List<ViewBookedDetail> ViewCancelDetail(ViewBookedDetail model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value }
                   
                 };

            var sqlQuery = @"proc_ViewOnlineCancelledDetail @fromDate,@toDate";
            var sDetails = this.Database.SqlQuery<ViewBookedDetail>(sqlQuery, sqlParams).ToList();
            return sDetails;


        }

        #endregion

        #region UNIT
        public List<LawnBanquetBookingCancle> CancelDetailListforUnit(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"ViewCancelLawnBanquet @docketNo";
            var sDetails = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public List<LawnBanquetBookingCancle> ViewpackagedetailforUnitwise(string docketNo)
        {
            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo }
                 };
            var sqlQuery = @"proc_ViewpackagedetailUnitwise @docketNo";
            var sDetails = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public List<LawnBanquetBookingCancle> LawnBanquetCancellationList(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"proc_CancellationConfirmationDetail @docketNo";
            var sDetails = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public List<LawnBanquetBookingCancle> LawnBookingForCancellation(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            var sqlQuery = @"DetailforLawnBanquetCancellation @docketNo";
            var sDetails = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public IEnumerable<LawnBanquetBookingCancle> getMobileNoAndEmailIdforUnit(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
            };
            //var sqlQuery = @"proc_GetOnlineListForSMS @docketNo";
            var sqlQuery = @"proc_GetListToSendSMSAndMailBANQLAWN @docketNo";
            var sList = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        public List<LawnBanquetBookingCancle> getEmailIdBookingForCancellationforUnit(string docketNo)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@docketNo", Value = docketNo }
                };

            // var sqlQuery = @"proc_DetailsOfBookingForCancellation @docketNo";proc_getLawnBanquetBookingDetail
            var sqlQuery = @"proc_getLawnBanquetBookingDetail @docketNo";
            var sDetails = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }
        public IEnumerable<LawnBanquetBookingCancle> PackageAccomodationListforUnit(int packageID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@packageID", Value = packageID }
                 };

            var sqlQuery = @"PROC_getPackageToursAccomodation @packageID";
            var sList = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        public LawnBanquetBookingCancle InsertCancelBookingforUnit(string docketNo, decimal refaundPer, decimal refaundAmount)
        {

            var sqlParams = new SqlParameter[] {              
                    new SqlParameter { ParameterName = "@docketNo", Value =docketNo },
                     new SqlParameter { ParameterName = "@refaundPer", Value =refaundPer },
                      new SqlParameter { ParameterName = "@refaundAmount", Value =refaundAmount }
                 };
            var sqlQuery = @"proc_InsertBookingCancellationRequestDetail @docketNo,@refaundPer,@refaundAmount";
            var sList = this.Database.SqlQuery<LawnBanquetBookingCancle>(sqlQuery, sqlParams).FirstOrDefault();
            return sList;
        }

        public List<ViewGSTDetailOnline> ViewGSTReportForOnlineBooking(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
               // new SqlParameter{ParameterName="@unitID",Value=unitID}
            };

            var sqlQuery = @"proc_ViewGSTReportForOnlineBooking @docketNo";
            var sList = this.Database.SqlQuery<ViewGSTDetailOnline>(sqlQuery, sqlParam).ToList();
            return sList;
        }

        #endregion

        #region UPTourism Online Booking Detail

        public List<OnlineBooking> OnlineBooking(string docketNo)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
              
            };

            var sqlQuery = @"proc_OnlineBookingDetailforUPTourism @docketNo";
            var sList = this.Database.SqlQuery<OnlineBooking>(sqlQuery, sqlParam).ToList();
            return sList;
        }

        public IEnumerable<OnlineBooking> SendOTPForMobile(OnlineBooking model)
        {
            var sqlparam = new SqlParameter[]
            { 
              new SqlParameter{ParameterName="@flag",Value= model.flag },
              new SqlParameter{ParameterName="@UserId",Value=model.userId  },              
              new SqlParameter{ParameterName="@MobileNo",Value=model.mobileNo??(object)DBNull.Value  } ,              
             new SqlParameter{ParameterName="@OTPSend",Value=model.otp??0  }
            };
            var sqlQuery = @"proc_SendOTPNumber @flag,@UserId,@MobileNo,@OTPSend";
            var sList = this.Database.SqlQuery<OnlineBooking>(sqlQuery, sqlparam).ToList();
            return sList;
        }




        //public IEnumerable<OnlineBooking> GetUserDetailsByEmailAndMobileNo(OnlineBooking model)
        //{
        //    var sqlparam = new SqlParameter[]
        //    { 

        //      new SqlParameter{ParameterName="@UserId",Value=model.userId  },              
        //      new SqlParameter{ParameterName="@MobileNo",Value=model.mobileNo  }               

        //    };
        //    var sqlQuery = @"proc_SendOTPNumber @UserId,@MobileNo";
        //    var sList = this.Database.SqlQuery<OnlineBooking>(sqlQuery, sqlparam).ToList();
        //    return sList;
        //}


        public OnlineBooking GetUserDetailsByEmailAndMobileNo(int flag, Int64 userid, string mobileno, string emailid, string UserName)
        {
            var sqlparam = new SqlParameter[]
            { 
             
              new SqlParameter{ParameterName="@flag",Value= flag },
              new SqlParameter{ParameterName="@Id",Value=userid  },
              new SqlParameter{ParameterName="@MobileNo",Value=mobileno==null?"":mobileno  },
              new SqlParameter{ParameterName="@EmailId",Value=emailid==null?"":emailid  },
              
              new SqlParameter{ParameterName="@userName",Value=UserName  }
            
            };

            var sqlQuery = @"Proc_GetUserDetailsByEmailAndMobileNo @flag,@Id,@MobileNo,@EmailId,@userName";

            var IList = this.Database.SqlQuery<OnlineBooking>(sqlQuery, sqlparam).ToList().FirstOrDefault();

            return IList;


        }





        #region Display Slab Wise Detail
        public List<UnitAmountDetailsSlabWise> GetGSTDetailSlabWise(UnitAmountDetailsSlabWise model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@unitId", Value = model.UnitID }
                   
                 };

            var sqlQuery = @"proc_GetPaymentSlabDetail @fromDate,@toDate,@unitId";
            var sDetails = this.Database.SqlQuery<UnitAmountDetailsSlabWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public List<UnitAmountDetailsSlabWise> GetGSTDetailSlabWiseCurrent(UnitAmountDetailsSlabWise model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@unitId", Value = model.UnitID }
                   
                 };

            var sqlQuery = @"proc_GetPaymentSlabDetail_Current @fromDate,@toDate,@unitId";
            var sDetails = this.Database.SqlQuery<UnitAmountDetailsSlabWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public List<UnitAmountDetailsSlabWise> GetGSTDetailSlabWiseforUnit(UnitAmountDetailsSlabWise model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value },
                   // new SqlParameter { ParameterName = "@unitId", Value = model.UnitID}
                   
                 };

            var sqlQuery = @"proc_getSlabWiseGSTforUnit @fromDate,@toDate";
            var sDetails = this.Database.SqlQuery<UnitAmountDetailsSlabWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        #endregion

        public List<UnitAmountDetailsSlabWise> GetOnlineDocketSlabWise(UnitAmountDetailsSlabWise model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@unitId", Value = model.UnitID }
                   
                 };

            var sqlQuery = @"proc_GetPaymentSlabDetail_DetailsView @fromDate,@toDate,@unitId";
            var sDetails = this.Database.SqlQuery<UnitAmountDetailsSlabWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public List<UnitAmountDetailsSlabWise> GetOnlineDocketSlabWiseCurrent(UnitAmountDetailsSlabWise model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@unitId", Value = model.UnitID }
                   
                 };

            var sqlQuery = @"proc_GetPaymentSlabDetail_DetailsViewCurrent @fromDate,@toDate,@unitId";
            var sDetails = this.Database.SqlQuery<UnitAmountDetailsSlabWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        public List<UnitAmountDetailsSlabWise> GetGSTSlabWiseforUnit(UnitAmountDetailsSlabWise model)
        {
            var sqlParams = new SqlParameter[] {                     
                    new SqlParameter { ParameterName = "@fromDate", Value = model.fromDate?? (object)DBNull.Value },
                    new SqlParameter { ParameterName = "@toDate", Value = model.toDate?? (object)DBNull.Value },
                  //  new SqlParameter { ParameterName = "@unitId", Value = model.UnitID }
                   
                 };

            var sqlQuery = @"proc_GetPaymentSlabDetail_DetailsViewforUnit @fromDate,@toDate";
            var sDetails = this.Database.SqlQuery<UnitAmountDetailsSlabWise>(sqlQuery, sqlParams).ToList();
            return sDetails;
        }

        #endregion
        #region riya
        public IEnumerable<TourList> BindTourBookingList(TourList model)//bind excel as well as grid to show all the list
        {
            var sqlParam = new SqlParameter[] {
               
                new SqlParameter{ParameterName="@fromDate",Value = model.fromDate?? (object)DBNull.Value },
                new SqlParameter{ParameterName="@toDate",Value = model.toDate?? (object)DBNull.Value }
                               
            };
            var sqlQuery = @"proc_ViewPackageTourismBookinDetail @fromDate, @toDate";
            var sList = this.Database.SqlQuery<TourList>(sqlQuery, sqlParam).ToList();
            return sList;
        }
        public List<ViewTourList> ViewGSTReportForPackageOnlineBooking(string docketNo)//view detal of particular docket number
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter{ParameterName="@docketNo",Value=docketNo}
               // new SqlParameter{ParameterName="@unitID",Value=unitID}
            };

            var sqlQuery = @"proc_ViewGSTReportForPackageOnlineBooking @docketNo";
            var sList = this.Database.SqlQuery<ViewTourList>(sqlQuery, sqlParam).ToList();
            return sList;
        }

        #endregion
        #region special unit
        #region get all Special Units
        public IEnumerable<M_Unit> GetallSpecialUnits(int unitid)
        {
            var sqlQuery = "proc_getMasterData @masterID,@UnitId";
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@masterID", Value = 8 },
                    new SqlParameter { ParameterName = "@UnitId", Value = unitid }};

            var Unitlist = this.Database.SqlQuery<M_Unit>(sqlQuery, sqlParams).ToList();
            return Unitlist;

        }
        #endregion
        #region special get unit info
        public SpecialUnitDetails GetSpecialUnitDisplayinfo(int unitID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                 };
            var sqlQuery = @"PROC_getUnitDetails @unitID";
            var sDetails = this.Database.SqlQuery<SpecialUnitDetails>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion
        #region get special unit wise amenity list
        public List<UnitAmenities> GetSpecialUnitWiseAmenitiesList(Int64 unitID)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID }
                };

            var sqlQuery = @"PROC_getUnitAmenities @unitID";
            var sList = this.Database.SqlQuery<UnitAmenities>(sqlQuery, sqlParams).ToList();
            return sList;
        }
        #endregion

        public List<UnitRooms> GetSpecialUnitRoomList(Int64 unitID, DateTime checkInDate, DateTime checkOutDate, int noOfRooms)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = unitID },
                    new SqlParameter { ParameterName = "@checkInDate", Value = checkInDate },
                    new SqlParameter { ParameterName = "@checkOutDate", Value = checkOutDate },
                    new SqlParameter { ParameterName = "@noOfRooms", Value = noOfRooms }
                };

            var sqlQuery = @"PROC_getSpecialUnitRoomsList @unitID, @checkInDate, @checkOutDate, @noOfRooms";
            var sList = this.Database.SqlQuery<UnitRooms>(sqlQuery, sqlParams).ToList();
            return sList;
        }

        public SpecialUnitBooking getDestination(SpecialUnitBooking model)
        {
            var sqlParams = new SqlParameter[] { 
                    new SqlParameter { ParameterName = "@unitID", Value = model.unitID }
                 };
            var sqlQuery = @"PROC_getunitname @unitID";
            var sDetails = this.Database.SqlQuery<SpecialUnitBooking>(sqlQuery, sqlParams).FirstOrDefault();
            return sDetails;
        }
        #endregion

        #region insert OGA Registration
        public int InsertOGARegistration(OGAModel model)
        {

            var sql = @"proc_Insert_T_OGARegistration  @Name, @Address1, @Address2, @ContactNo, @EmailId,@IpAddress";
            var sqlParm = new SqlParameter[] {
                new SqlParameter { ParameterName = "@Name", Value = model.Name },
                new SqlParameter { ParameterName = "@Address1", Value = model.Address1 },
                new SqlParameter { ParameterName = "@Address2", Value = model.Address2 ?? string.Empty },
                new SqlParameter { ParameterName = "@ContactNo", Value = model.ContactNo },
                new SqlParameter { ParameterName = "@EmailId", Value = model.EmailId ?? string.Empty },
                new SqlParameter { ParameterName = "@IPAddress", Value = Common.GetIPAddress() }};
            var count = this.Database.ExecuteSqlCommand(sql, sqlParm);
            return count;

        }
        #endregion
    }
}