﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;


namespace UP_TourismBooking.Models
{
    public class BookingCancellation
    {

        //[Required(ErrorMessage = "Enter Docket Number")]
        public string docketNo { get; set; }
        public string UnitName { get; set; }
        public Int32 NoofRooms { get; set; }
        public string cancelRefNo { get; set; }
        public string roomType { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? FromDate { get; set; }

        [DataType(DataType.Date, ErrorMessage = "Check In Date should be a date!")]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime? ToDate { get; set; }

        public Int64 unitID { get; set; }

        public List<cancellationRequest> lstCanceRequest { get; set; }
    }

    public class cancellationRequest
    {
        public string docketNo { get; set; }
        public string UnitName { get; set; }
        public string NoofRooms { get; set; }
        public Int32 noOfPerson { get; set; }
        public string cancelRefNo { get; set; }
        public string roomType { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string cancelRequestDate { get; set; }
        public decimal amount { get; set; }

        public string totalRooms { get; set; }
        public string name { get; set; }
        public string bookingThrough { get; set; }
        public string bookingType { get; set; }
        public string onDate { get; set; }
        public string toDate { get; set; }
        public string packageName { get; set; }
        public Int32 packageID { get; set; }
        public Int32 unitID { get; set; }
        public string cancelationStatus { get; set; }
        public DateTime checkInDate { get; set; }
        public string checkOutDate { get; set; }
        public string bankReferenceNo { get; set; }
        public string bookingDate { get; set; }
        public string checkinCheckoutDate { get; set; }
    }

    public class CRSBookingCancellation
    {       
        public string docketNo { get; set; }
        [Required(ErrorMessage="Select Booking Type!")]
        public int bookingType { get; set; }

        //[Required(ErrorMessage = "Select Unit!")]
        public Int64? unitID { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public string UnitName { get; set; }
        public Int32 NoofRooms { get; set; }
        public string cancelRefNo { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string BookingFor { get; set; }
        public List<CRSCancellationRequest> lstCanceRequest { get; set; }
    }

    public class CRSCancellationRequest
    {
        public string docketNo { get; set; }
        public string totalRooms { get; set; }
        public string name { get; set; }
        public DateTime checkInDate { get; set; }
        public string checkOutDate { get; set; }
        public Int32 noOfPerson { get; set; }
        public string packageName { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string cancelRefNo { get; set; }
        public string cancelConfirmationDate { get; set; }
        public decimal refaundPer { get; set; }
        public decimal refaundAmount { get; set; }
        //public string cancelRequestDate { get; set; }
        //public decimal amount { get; set; }

        //public string name { get; set; }
        //public string bookingThrough { get; set; }
        //public string bookingType { get; set; }
        //public string onDate { get; set; }
        //public string toDate { get; set; }
        //public string packageName { get; set; }
        //public Int32 packageID { get; set; }
        //public Int32 unitID { get; set; }
        //public string cancelationStatus { get; set; }
       
    }

    public class ARCCancellationRequest
    {
        public string docketNo { get; set; }
        public string totalRooms { get; set; }
        public string name { get; set; }
        public DateTime checkInDate { get; set; }
        public string checkOutDate { get; set; }
        public Int32 noOfPerson { get; set; }
        public string packageName { get; set; }
        public string bookingType { get; set; }
        public string bookingBy { get; set; }
        public string cancelRefNo { get; set; }
        public string cancelConfirmationDate { get; set; } 
    }

    public class ARCBookingCancellation
    {
        public string docketNo { get; set; }
        [Required(ErrorMessage = "Select Booking Type!")]
        public int bookingType { get; set; }

        [Required(ErrorMessage = "Select Unit!")]
        public Int64? unitID { get; set; }
        public DateTime? fromDate { get; set; }
        public DateTime? toDate { get; set; }
        public string UnitName { get; set; }
        public Int32 NoofRooms { get; set; }
        public string cancelRefNo { get; set; }
        public string cancelConfirmationDate { get; set; }
        public string BookingFor { get; set; }
        public List<ARCCancellationRequest> lstCanceRequest { get; set; }
    }
}