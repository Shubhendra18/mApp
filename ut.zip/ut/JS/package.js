﻿function EditPackage(packageID) {
    $('#divLoader').show();

    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Admin/EditPackage",
        contentType: 'application/html; charset=utf-8',
        data: { packageID: packageID },
        type: 'GET',
        dataType: 'html',
        success: function (result) {
            $('#divLoader').hide();
            $('#divTask').html(result);
        },
        error: function (xhr, status) {
            $('#divLoader').hide();
            alert(status);
        }
    });
}

function DeletePackage(packageID) {
    if (confirm("Are you sure to delete ?")) {
        $('#divLoader').show();

        $.ajax({
            url: window.location.protocol + "//" + window.location.host + "/booking/Admin/DeletePackage",
            contentType: 'application/html; charset=utf-8',
            data: { packageID: packageID },
            type: 'GET',
            dataType: 'html',
            success: function (result) {
                $('#divGrid').html(result);
                $('#divLoader').hide();
                ShowDeleteMessage();

            },
            error: function (xhr, status) {
                $('#divLoader').hide();
                alert(status);
            }
        });
    }
    else {
        return false;
    }
}

function BindPackageGrid() {

    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Admin/BindPackageGrid",
        contentType: 'application/html; charset=utf-8',
        type: 'GET',
        dataType: 'html',
        success: function (result) {
            $('#divGrid').html(result);
        },
        error: function (xhr, status) {
            alert(xhr);
        }
    });
}

function ResetPackage() {
    window.location.href = window.location.protocol + "//" + window.location.host + "/booking/Admin/Package";
}

/* Package Contact */
function EditContact(packageID, contactID) {
    $('#divLoader').show();

    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Admin/EditContact",
        contentType: 'application/html; charset=utf-8',
        data: { packageID: packageID, contactID: contactID },
        type: 'GET',
        dataType: 'html',
        success: function (result) {
            $('#divLoader').hide();
            $('#divTask').html(result);
        },
        error: function (xhr, status) {
            $('#divLoader').hide();
            alert(status);
        }
    });
}

function DeleteContact(packageID, contactID) {
    if (confirm("Are you sure to delete ?")) {
        $('#divLoader').show();

        $.ajax({
            url: window.location.protocol + "//" + window.location.host + "/booking/Admin/DeleteContact",
            contentType: 'application/html; charset=utf-8',
            data: { packageID: packageID, contactID: contactID },
            type: 'GET',
            dataType: 'html',
            success: function (result) {
                $('#divGrid').html(result);
                $('#divLoader').hide();
                ShowDeleteMessage();

            },
            error: function (xhr, status) {
                $('#divLoader').hide();
                alert(status);
            }
        });
    }
    else {
        return false;
    }
}

function BindContactGrid() {

    var packageID = $('#PackageID').val();

    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Admin/BindContactGrid",
        contentType: 'application/html; charset=utf-8',
        data: { Id: packageID },
        type: 'GET',
        dataType: 'html',
        success: function (result) {
            $('#divGrid').html(result);
        },
        error: function (xhr, status) {
            alert(xhr);
        }
    });
}

function ResetContact() {
  
    $('#divLoader').show();
    var packageID = $('#PackageID').val();

        $.ajax({
            url: window.location.protocol + "//" + window.location.host + "/booking/Admin/Contact",
            contentType: 'application/html; charset=utf-8',
            data: { Id: packageID },
            type: 'GET',
            dataType: 'html',
            success: function (result) {
                $('#contentContact').html(result);
                $('#divLoader').hide();               
            },
            error: function (xhr, status) {
                $('#divLoader').hide();
                alert(status);
            }
        });
    }
   
/*Package Terms n Condition*/
$('#btnSave').click(function () {
    $('#TermsCondition').val(CKEDITOR.instances[$textarea.attr('name')].getClearText());
    $('#CancellationPolicy').val(CKEDITOR.instances[$textarea.attr('name')].getClearText());
});

function ReBindCKEditor() {
    delete CKEDITOR.instances['TermsCondition'];
    $('#TermsCondition').ckeditor();

    delete CKEDITOR.instances['CancellationPolicy'];
    $('#CancellationPolicy').ckeditor();
}


/* Package Overview */
$('[name="tabs"]').click(function () {

    var action = $(this).attr('data-val');
    var value = $(this).attr('data-id');
    var content = $(this).siblings('div').attr('id');
    $('#divLoader').show();

    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Admin/" + action,
        contentType: 'application/html; charset=utf-8',
        data: { Id: value },
        type: 'GET',
        dataType: 'html',
        success: function (result) {
            $('#divLoader').hide();
            $('#' +content).html(result);
        },
        error: function (xhr, status) {
            $('#divLoader').hide();
            alert(status);
        }
    });
  
});


