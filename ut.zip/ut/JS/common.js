﻿function ClosePopup() {
    $('#lbl_msg').html('');
    $('#msgBox').hide();
}