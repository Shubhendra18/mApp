﻿
function EditPackageCategory(packageCategoryID) {
    $('#divLoader').show();

    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Admin/EditPackageCategory",
        contentType: 'application/html; charset=utf-8',
        data: { packageCategoryID: packageCategoryID },
        type: 'GET',
        dataType: 'html',
        success: function (result) {
            $('#divLoader').hide();
            $('#divTask').html(result);
        },
        error: function (xhr, status) {
            $('#divLoader').hide();
            alert(status);
        }
    });
}

function DeletePackageCategory(packageCategoryID) {
    if (confirm("Are you sure to delete ?")) {
        $('#divLoader').show();

        $.ajax({
            url: window.location.protocol + "//" + window.location.host + "/booking/Admin/DeletePackageCategory",
            contentType: 'application/html; charset=utf-8',
            data: { packageCategoryID: packageCategoryID },
            type: 'GET',
            dataType: 'html',
            success: function (result) {
                $('#divGrid').html(result);
                $('#divLoader').hide();
                ShowDeleteMessage();

            },
            error: function (xhr, status) {
                $('#divLoader').hide();
                alert(status);
            }
        });
    }
    else {
        return false;
    }
}

function BindPackageCategoryGrid() {
   
    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Admin/BindPackageCategoryGrid",
        contentType: 'application/html; charset=utf-8',
        type: 'GET',
        dataType: 'html',
        success: function (result) {
            $('#divGrid').html(result);
        },
        error: function (xhr, status) {
            alert(xhr);
        }
    });
}


function ResetPackageCategory() { 
    window.location.href = window.location.protocol + "//" + window.location.host + "/booking/Admin/PackageCategory";
}
