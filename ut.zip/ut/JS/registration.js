﻿$(function (){
    $('#countryID').change(function (e) {
      
        if ($("#countryID option:selected").text().toLowerCase() != "india") {
            $('#cityID').hide();
            $('#stateID').hide();
            $('#cityID').siblings("span[class='field-validation-error']").empty();
            $('#stateID').siblings("span[class='field-validation-error']").empty();

            $('#otherState').show();
            $('#otherCity').show();            
        }
        else {            
            $('#cityID').show();
            $('#stateID').show();

            $('#otherState').hide();
            $('#otherCity').hide();
            $('#otherCity').siblings("span[class='field-validation-error']").empty();
            $('#otherState').siblings("span[class='field-validation-error']").empty();
            
            BindState($(this).val());
        }
    });
});

$(function () {
    $('#stateID').change(function (e) {
       
        if ($("#stateID").val() != "0") {
            $('#cityID').show();
            $('#otherCity').hide();
            $('#otherCity').siblings("span[class='field-validation-error']").empty();

            BindCity($(this).val());
        }
        else {
            $('#cityID').hide();
            $('#cityID').siblings("span[class='field-validation-error']").empty();
            $('#otherCity').show();           
        }
    });
});


function BindState(vr_countryID) {
    
    if (vr_countryID != "") {
        $.ajax({
            url: window.location.protocol + "//" + window.location.host + "/booking/Master/GetStates",
            //global: false,
            //url: domainName + "/Master/GetStates",            
            contentType: 'application/html; charset=utf-8',
            data: { countryID: vr_countryID },
            type: 'GET',
            dataType: 'json',
            async: false
        })
          .success(function (data) {

              $("#stateID").empty();
              $("#stateID").append('<option value="">--Select State--</option>');
              $("#cityID").empty();
              $("#cityID").append('<option value="">--Select City--</option>');

              $.each(data, function (id, result) {
                  $("#stateID").append('<option value="' + result.Value + '">' + result.Text + '</option>');
              });
          })
          .error(function (xhr, status) {
              alert(status);
          })
    }
    else {
        $("#stateID").empty();
        $("#stateID").append('<option value="">--Select State--</option>');
        $("#cityID").empty();
        $("#cityID").append('<option value="">--Select City--</option>');
    }
}

function BindCity(vr_stateID) {

    if (vr_stateID != "") {
        $.ajax({
            //url: window.location.protocol + "//" + window.location.host + "/booking/Master/GetCities",
            url: window.location.protocol + "//" + window.location.host + "/Master/GetCities",
            //global: false,
            //url: domainName + "/Master/GetCities",
            contentType: 'application/html; charset=utf-8',
            data: { stateID: vr_stateID },
            type: 'GET',
            dataType: 'json',
            async: false
        })
          .success(function (data) {

              $("#cityID").empty();
              $("#cityID").append('<option value="">--Select City--</option>');
              $.each(data, function (id, result) {
                  $("#cityID").append('<option value="' + result.Value + '">' + result.Text + '</option>');
              });
          })
          .error(function (xhr, status) {
              alert(status);
          })
    }
    else {
        $("#cityID").empty();
        $("#cityID").append('<option value="">--Select City--</option>');
    }
}


$(function () {
    $('#btnConfirm').click(function (e) {
        var returnUrl = $('#hdnUrl').val();
        if (returnUrl == "")
        {
            returnUrl = window.location.href;
        }
        window.location = returnUrl;
    });
});



