﻿function setCountery() {
    
    $.ajax({
        url: window.location.protocol + "//" + window.location.host + "/booking/Master/GetAllDestinations",
        // url: '/Controller/Action',
        contentType: 'application/html; charset=utf-8',
        data: { countryID: 1 },
        type: 'GET',
        dataType: 'json'
    })
              .success(function (data) {

                  $("#Destination").empty();
                  $("#Destination").append('<option value="">--Select State--</option>');
                  $("#Destination").empty();
                  $("#Destination").append('<option value="">--Select City--</option>');

                  $.each(data, function (id, result) {
                      $("#Destination").append('<option value="' + result.Value + '">' + result.Text + '</option>');
                  });
              })
              .error(function (xhr, status) {
                  alert(status);
              })
        }



