import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { ComposeMailModel } from "../models/ComposeMail";
@Injectable({
  providedIn: 'root'
})
export class ApihandlerService {
  private baseUrl = "http://localhost:4876"
  constructor(private http: HttpClient) { }
  UserLogin(loginData) {
    return this.http.post(this.baseUrl + "/Admin/UserLogin", loginData);
  }
  GroupMaster() {
    return this.http.get(this.baseUrl + "/Admin/GroupMaster");
  }
  AddUpdateGroupMaster(groupMasterData) {
    return this.http.post(this.baseUrl + "/Admin/AddUpdateGroupMaster", groupMasterData);
  }
  DeleteGroupMaster(groupId) {
    return this.http.delete(this.baseUrl + "/Admin/DeleteGroupMaster/" + groupId.groupId);
  }
  composemail(mailForm: ComposeMailModel) {
    return this.http.post(this.baseUrl + "/Mailer/Compose", mailForm);
  }
  getmail() {
    return this.http.get(this.baseUrl + "/Mailer/InboxMail");
  }
}
