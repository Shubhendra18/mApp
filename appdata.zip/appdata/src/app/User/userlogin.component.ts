import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['../../assets/css/loginpage.css','../../assets/css/bootstrap.min.3.37.css']
})
export class UserloginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
