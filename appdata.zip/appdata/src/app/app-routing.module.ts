import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InboxComponent } from './Admin/inbox.component';
import { ComposeComponent } from './Admin/compose.component';
import { AdminloginComponent } from './admin/adminlogin.component';
import { UserloginComponent } from './User/userlogin.component';
import { DashboardComponent } from './Admin/dashboard.component';
import { ManageGroupComponent } from './Admin/manage-group.component';


const routes: Routes = [
  //**********Admin************ */
  { path: 'admin', component: AdminloginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'managegroup', component: ManageGroupComponent },
  { path: 'inbox', component: InboxComponent },
  { path: 'compose', component: ComposeComponent },
  { path: 'user', component: UserloginComponent },
  { path: '', component: AdminloginComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
