﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using MandiParishadWebApi.Filters;
using MandiParishadWebApi.Models;
namespace MandiParishadWebApi.Models
{
    public class AdminContext : DbContext
    {
        public AdminContext() : base("MandiContext")
        {

        }
        public DbSet<M_GroupMaster> M_GroupMaster { get; set; }
        public AfterUserLogin UserLogin(string UserName)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@userName",Value=UserName},
                new SqlParameter {ParameterName="@LastLoginIP",Value=Common.GetIPAddress()},

                 };
            var sqlQuery = @"Proc_userLogin_selectLogin @userName,@LastLoginIP";
            var res = this.Database.SqlQuery<AfterUserLogin>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public object AddUpdateGroupName(int transId, String GroupName, int UserId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=transId},
                new SqlParameter {ParameterName="@groupName",Value=GroupName},
                new SqlParameter {ParameterName="@userId",Value=UserId},
                 };
            var sqlQuery = @"sp_saveUpdateGroup @transId,@groupName,@userId";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
        public object DeleteGroup(int groupId)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@transId",Value=groupId},
                 };
            var sqlQuery = @"sp_deleteGroup @transId";
            var res = this.Database.SqlQuery<object>(sqlQuery, sqlParam).Count();
            return res;
        }
    }
}