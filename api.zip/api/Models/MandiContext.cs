﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using MandiParishadWebApi.Models;

namespace MandiParishadWebApi.Models
{
    public class MandiContext : DbContext
    {
        public MandiContext() : base("MandiContext")
        {

        }
       
        public ComposeMail Create(ComposeMail model)
        {
            var sqlParam = new SqlParameter[] {
                new SqlParameter {ParameterName="@priority",Value=model.Priority},
                new SqlParameter {ParameterName="@smsalert",Value=model.SMSAlert},
                new SqlParameter {ParameterName="@to",Value=model.ToUser},
                new SqlParameter {ParameterName="@subject",Value=model.Subject},
                new SqlParameter {ParameterName="@message",Value=model.Message}

                 };
            var sqlQuery = @"sp_ComposeMail @priority,@smsalert,@to,@subject,@message";
            var res = this.Database.SqlQuery<ComposeMail>(sqlQuery, sqlParam).FirstOrDefault();
            return res;
        }
        public List<ComposeMail> Getmail()
        {
            var sqlQuery = @"sp_GetMails";
            var res = this.Database.SqlQuery<ComposeMail>(sqlQuery).ToList();
            return res;
        }
    }
}