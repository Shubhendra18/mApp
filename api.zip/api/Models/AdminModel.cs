﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MandiParishadWebApi.Models
{
    public class DisplayMessage
    {
        public string Message { get; set; }
        public string Type { get; set; }
    }
    public class UserLogin
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
    public class AfterUserLogin
    {
        public Int64 userId { get; set; }
        public string userName { get; set; }
        public int groupID { get; set; }
        public string Mandi { get; set; }
        public Int64? MandiID { get; set; }
        public DateTime LastLogin { get; set; }
        public string password { get; set; }
        public string Activeflag { get; set; }
    }
    public class M_GroupMaster
    {
        [Key]
        public int groupId { get; set; }
        public string groupName { get; set; }
        public bool? isDeleted { get; set; }
        public DateTime transDate { get; set; }
        public int userId { get; set; }
        public int GroupOrder { get; set; }

    }
    public class AddUpdateUserMaster
    {
        public string groupName { get; set; }
        public int userId { get; set; }
        public int transId { get; set; }

        
    }
}