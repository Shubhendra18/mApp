﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MandiParishadWebApi.Filters
{
    public class Common
    {
        public string SingleHashing(string value)
        {
            string hashCode = "";
            hashCode = System.Web.Security.FormsAuthentication.HashPasswordForStoringInConfigFile(value, "MD5");
            return hashCode;
        }
        public static String GetIPAddress()
        {
            String ip = "";
            try
            {
                ip = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
                if (!string.IsNullOrEmpty(ip))
                {
                    string[] ipRange = ip.Split(',');
                    int le = ipRange.Length - 1;
                    string trueIP = ipRange[le];
                }
                else
                {
                    ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
                }
            }
            catch
            {
                ip = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"].ToString();
            }
            return ip;
        }
    }
}